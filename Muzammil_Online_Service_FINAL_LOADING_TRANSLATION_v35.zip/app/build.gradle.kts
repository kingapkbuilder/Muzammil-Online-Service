plugins { id("com.android.application") }
android {
    namespace="com.muzammil.onlineservice"
    compileSdk=35
    defaultConfig {
        applicationId="com.muzammil.onlineservice"
        minSdk=24
        targetSdk=35
        versionCode = 35
        versionName = "3.8"
    }
}


dependencies { implementation("androidx.core:core:1.15.0") }
