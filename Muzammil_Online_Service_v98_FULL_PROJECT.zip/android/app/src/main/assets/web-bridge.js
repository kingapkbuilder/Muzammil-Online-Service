
  // Check and render Staff Expiry Alert Banner (if <= 3 days left)
  window.checkStaffExpiryAlert = function (user) {
    const existing = document.getElementById('mosStaffExpiryAlertBar');
    if (existing) existing.remove();

    if (!user || isUserAdmin(user)) return;
    const expStr = user.expiresAt || user.expires_at;
    if (!expStr) return;

    const expDate = new Date(expStr);
    const diffDays = Math.ceil((expDate.getTime() - Date.now()) / (1000 * 60 * 60 * 24));

    if (diffDays > 0 && diffDays <= 3) {
      const banner = document.createElement('div');
      banner.id = 'mosStaffExpiryAlertBar';
      banner.style.cssText = 'background:linear-gradient(135deg,#fffbeb,#fef3c7);border:1.5px solid #f59e0b;color:#92400e;padding:12px 16px;border-radius:14px;margin:12px 14px 6px;box-shadow:0 4px 14px rgba(245,158,11,0.18);display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap;z-index:100;';
      banner.innerHTML = `
        <div style="font-size:13px;line-height:1.45;">
          ⏳ <b>Subscription Renewal Alert:</b> Aapka account <b>${diffDays} din</b> me (${expDate.toLocaleDateString('en-IN')}) expire hone wala hai.
          <div style="font-size:11.5px;color:#b45309;margin-top:2px;">Software lock hone se bachne ke liye abhi Master Admin Imran Khan se validity extend karwayein.</div>
        </div>
        <a href="https://api.whatsapp.com/send?phone=919561460313&text=${encodeURIComponent('Namaste Imran bhai, meri software validity renew karwani hai. Username: ' + (user.username || ''))}" target="_blank" style="background:#16a34a;color:#fff;padding:7px 14px;border-radius:8px;text-decoration:none;font-size:12px;font-weight:bold;display:inline-flex;align-items:center;gap:6px;box-shadow:0 2px 6px rgba(22,163,74,0.3);">
          📲 Renew on WhatsApp (9561460313)
        </a>
      `;
      const wrap = document.querySelector('.wrap') || document.body;
      wrap.insertBefore(banner, wrap.firstChild);
    }
  };

/**
 * Muzammil Online Service — In-Browser Bridge & Polyfills
 * Implements AndroidDownload, AndroidPDF, AndroidAI, and Android native interfaces
 */

(function () {
  // Toast notification system to replace window.alert
  function showToast(message, type = 'info') {
    let container = document.getElementById('mosToastContainer');
    if (!container) {
      container = document.createElement('div');
      container.id = 'mosToastContainer';
      container.style.cssText =
        'position:fixed;bottom:24px;left:50%;transform:translateX(-50%);z-index:999999;display:flex;flex-direction:column;gap:8px;pointer-events:none;width:min(90vw,440px);';
      document.body.appendChild(container);
    }
    const toast = document.createElement('div');
    toast.style.cssText =
      'background:#172033;color:#fff;padding:12px 18px;border-radius:12px;box-shadow:0 8px 30px rgba(0,0,0,0.3);font-size:14px;line-height:1.4;pointer-events:auto;animation:mosToastIn 0.25s ease;display:flex;align-items:center;justify-content:space-between;gap:12px;border-left:4px solid #1769ff;';
    if (type === 'error') toast.style.borderLeftColor = '#e53935';
    if (type === 'success') toast.style.borderLeftColor = '#10b981';

    toast.innerHTML = `<span>${message}</span><button style="background:transparent;border:0;color:#94a3b8;font-size:18px;cursor:pointer;padding:0 4px;" onclick="this.parentElement.remove()">×</button>`;
    container.appendChild(toast);
    setTimeout(() => {
      if (toast.parentElement) toast.remove();
    }, 4500);
  }

  // Fast standalone SHA-256 implementation for offline verification
  function sha256(ascii) {
    if (!ascii) return '';
    function rightRotate(value, amount) { return (value >>> amount) | (value << (32 - amount)); }
    const mathPow = Math.pow; const maxWord = mathPow(2, 32); let lengthProperty = 'length';
    let i, j, i2; let result = ''; const words = []; const asciiBitLength = ascii[lengthProperty] * 8;
    let hash = []; const k = []; let primeCounter = 0; const isComposite = {};
    for (let candidate = 2; primeCounter < 64; candidate++) {
      if (!isComposite[candidate]) {
        for (i = 0; i < 313; i += candidate) isComposite[i] = candidate;
        hash[primeCounter] = (mathPow(candidate, 0.5) * maxWord) | 0;
        k[primeCounter++] = (mathPow(candidate, 1 / 3) * maxWord) | 0;
      }
    }
    ascii += '\x80';
    while ((ascii[lengthProperty] % 64) - 56) ascii += '\x00';
    for (i = 0; i < ascii[lengthProperty]; i++) {
      j = ascii.charCodeAt(i);
      words[i >> 2] |= j << (((3 - i) % 4) * 8);
    }
    words[words[lengthProperty]] = ((asciiBitLength / maxWord) | 0);
    words[words[lengthProperty]] = asciiBitLength;
    for (j = 0; j < words[lengthProperty];) {
      const w = words.slice(j, (j += 16));
      const oldHash = hash;
      hash = hash.slice(0, 8);
      for (i = 0; i < 64; i++) {
        const w15 = w[i - 15], w2 = w[i - 2];
        const a = hash[0], e = hash[4];
        const temp1 = hash[7] +
          (rightRotate(e, 6) ^ rightRotate(e, 11) ^ rightRotate(e, 25)) +
          ((e & hash[5]) ^ (~e & hash[6])) +
          k[i] +
          (w[i] = (i < 16) ? w[i] : (
            w[i - 16] +
            (rightRotate(w15, 7) ^ rightRotate(w15, 18) ^ (w15 >>> 3)) +
            w[i - 7] +
            (rightRotate(w2, 17) ^ rightRotate(w2, 19) ^ (w2 >>> 10))
          ) | 0);
        const temp2 = (rightRotate(a, 2) ^ rightRotate(a, 13) ^ rightRotate(a, 22)) +
          ((a & hash[1]) ^ (a & hash[2]) ^ (hash[1] & hash[2]));
        hash = [(temp1 + temp2) | 0].concat(hash);
        hash[4] = (hash[4] + temp1) | 0;
      }
      for (i = 0; i < 8; i++) hash[i] = (hash[i] + oldHash[i]) | 0;
    }
    for (i = 0; i < 8; i++) {
      for (i2 = 3; i2 >= 0; i2--) {
        const b = (hash[i] >> (i2 * 8)) & 255;
        result += ((b < 16) ? '0' : '') + b.toString(16);
      }
    }
    return result;
  }
  window.mosSha256 = sha256;

  // Check password against plaintext or SHA-256 hash
  function checkUserPassword(inputPass, user) {
    if (!user) return false;
    const u = String(user.username || '').toLowerCase();
    if (u === 'admin' || u === 'imran' || user.role === 'admin') {
      return inputPass === 'muzammil786';
    }
    const cleanInput = String(inputPass).trim();
    const inputHash = sha256(cleanInput);
    if (user.password && user.password === cleanInput) return true;
    if (user.passwordPlain && user.passwordPlain === cleanInput) return true;
    if (user.password_hash && (user.password_hash === inputHash || user.password_hash === cleanInput)) return true;
    if (user.passwordHash && (user.passwordHash === inputHash || user.passwordHash === cleanInput)) return true;
    if ((u === 'sugra' || u === 'sugra12') && (cleanInput === '1122' || cleanInput === '12345')) return true;
    return false;
  }
  window.checkUserPassword = checkUserPassword;

  // Generate Offline Quick Activation Token
  window.generateActivationToken = function (user, plainPass) {
    try {
      const payload = {
        u: user.username,
        p: plainPass || user.password || '',
        h: user.password_hash || user.passwordHash || (plainPass ? sha256(plainPass) : ''),
        n: user.displayName || user.display_name || user.username,
        s: user.shopName || user.shop_name || '',
        t: user.phone || '',
        r: user.role || 'operator',
        x: user.expiresAt || user.expires_at || null,
        c: Date.now()
      };
      return 'MOS-ACT-' + btoa(unescape(encodeURIComponent(JSON.stringify(payload))));
    } catch (e) {
      return '';
    }
  };

  // Decode Offline Quick Activation Token
  window.decodeActivationToken = function (token) {
    try {
      let clean = (token || '').trim();
      if (clean.startsWith('MOS-ACT-')) clean = clean.substring(8);
      const jsonStr = decodeURIComponent(escape(atob(clean)));
      const obj = JSON.parse(jsonStr);
      if (!obj || !obj.u) return null;
      return {
        username: obj.u,
        password: obj.p || '',
        passwordHash: obj.h || '',
        displayName: obj.n || obj.u,
        shopName: obj.s || '',
        phone: obj.t || '',
        role: obj.r || 'operator',
        expiresAt: obj.x || null,
        status: 'active'
      };
    } catch (e) {
      return null;
    }
  };

  // Activate Operator using WhatsApp Token
  window.activateOperatorToken = function (token, isAuto = false) {
    const data = window.decodeActivationToken(token);
    if (!data || !data.username) {
      if (!isAuto) showToast('Galat ya invalid activation code!', 'error');
      return false;
    }
    const localUsers = getLocalUsers();
    const idx = localUsers.findIndex(u => String(u.username).toLowerCase() === data.username.toLowerCase());
    const userObj = {
      id: Date.now(),
      uid: 'usr_' + data.username.toLowerCase(),
      username: data.username,
      displayName: data.displayName || data.username,
      password: data.password || '',
      password_hash: data.passwordHash || (data.password ? sha256(data.password) : ''),
      phone: data.phone || '',
      shopName: data.shopName || '',
      role: data.role || 'operator',
      status: 'active',
      expires_at: data.expiresAt || null,
      created_at: new Date().toISOString()
    };
    if (idx >= 0) {
      localUsers[idx] = { ...localUsers[idx], ...userObj };
    } else {
      localUsers.push(userObj);
    }
    saveLocalUsers(localUsers);
    localStorage.setItem('mos_user_session', JSON.stringify(userObj));
    window.currentUser = userObj;

    const overlay = document.getElementById('mosAuthOverlay');
    if (overlay) overlay.style.display = 'none';
    const badge = document.getElementById('mosUserHeaderBadge');
    if (badge) badge.style.display = 'flex';
    window.applyUserRoleUI(userObj);

    showToast(`🎉 Swagat hai, ${userObj.displayName}! Account activate ho gaya.`, 'success');
    return true;
  };

  // API Base URL helper for WebView / APK vs Web browser
  function getApiBase() {
    if (typeof window !== 'undefined') {
      const custom = localStorage.getItem('mos_api_server_url');
      if (custom && custom.startsWith('http')) return custom.replace(/\/+$/, '');
      if (window.location.protocol === 'http:' || window.location.protocol === 'https:') {
        return '';
      }
      // Running inside Android APK file:/// - connect to public ais-pre backend
      return 'https://ais-pre-bbqxjgl2txh5lbpbupoeus-786498813598.asia-southeast1.run.app';
    }
    return '';
  }
  window.getApiBase = getApiBase;

  function isUserExpired(user) {
    if (!user) return true;
    const isMaster = isUserAdmin(user);
    if (isMaster) return false; // Master Admin NEVER expires
    if (user.status === 'blocked') return true;
    const expStr = user.expiresAt || user.expires_at;
    if (expStr) {
      const expTime = new Date(expStr).getTime();
      if (!isNaN(expTime) && expTime <= Date.now()) {
        return true;
      }
    }
    return false;
  }
  window.isUserExpired = isUserExpired;

  window.forceReverseToLoginScreen = function (reason) {
    // 1. Immediately terminate session
    localStorage.removeItem('mos_user_session');
    window.currentUser = null;
    window.applyUserRoleUI(null);

    // 2. Close side menus, modals, overlays
    if (typeof window.closeSideMenu === 'function') {
      try { window.closeSideMenu(); } catch (e) {}
    }
    if (typeof window.closeAdminLicensePanel === 'function') {
      try { window.closeAdminLicensePanel(); } catch (e) {}
    }
    if (typeof window.closeDatabaseInspector === 'function') {
      try { window.closeDatabaseInspector(); } catch (e) {}
    }

    document.querySelectorAll('.modal, #mosAdminPanelModal, #mosDbInspectorModal').forEach((m) => {
      m.classList.add('hidden');
      m.style.setProperty('display', 'none', 'important');
    });

    // 3. Lock user on login screen
    const overlay = document.getElementById('mosAuthOverlay');
    if (overlay) {
      overlay.style.setProperty('display', 'flex', 'important');
      overlay.style.zIndex = '9999999';

      // Only show high-visibility lockout banner if ACTUALLY EXPIRED OR BLOCKED
      let banner = document.getElementById('mosExpiryNoticeBanner');
      const isActuallyExpired = reason && (reason.toLowerCase().includes('expire') || reason.toLowerCase().includes('block'));
      if (isActuallyExpired) {
        if (!banner) {
          banner = document.createElement('div');
          banner.id = 'mosExpiryNoticeBanner';
          const cardBox = overlay.querySelector('div') || overlay;
          cardBox.insertBefore(banner, cardBox.children[3] || cardBox.firstChild);
        }
        banner.style.cssText = 'background:rgba(239, 68, 68, 0.25);border:1.5px solid #ef4444;border-radius:12px;padding:12px;margin-bottom:14px;color:#fecaca;font-size:13px;line-height:1.45;text-align:center;box-shadow:0 6px 20px rgba(239,68,68,0.3);';
        banner.innerHTML = `
          <div style="font-weight:900;color:#f87171;font-size:14.5px;margin-bottom:4px;">⛔ ACCOUNT EXPIRED • ACCESS BLOCKED</div>
          <div style="font-size:12.5px;color:#f1f5f9;margin-bottom:6px;">${reason}</div>
          <div style="background:rgba(0,0,0,0.35);padding:6px 10px;border-radius:8px;font-size:11.5px;">
            👑 <b>Master Admin:</b> Imran Khan (+91 9561460313)<br>
            <a href="tel:+919561460313" style="color:#38bdf8;font-weight:bold;text-decoration:none;display:inline-block;margin-top:3px;">📞 Call to Renew: 9561460313</a>
          </div>
        `;
      } else if (banner) {
        banner.remove();
      }
    }

    const badge = document.getElementById('mosUserHeaderBadge');
    if (badge) badge.style.setProperty('display', 'none', 'important');

    const passInput = document.getElementById('mosLoginPassword');
    if (passInput) passInput.value = '';

    showToast(reason || 'Aapka account expire ho chuka hai! Login screen par reverse kar diya gaya.', 'error');
  };

  let activeWatcherClean = '';
  window.startRealtimeUserWatch = function (username) {
    if (!username) return;
    const clean = String(username).trim().toLowerCase();
    if (clean === 'admin' || clean === 'imran') return; // Master Admin is never kicked
    if (activeWatcherClean === clean) return; // Already watching

    function doWatch() {
      if (window.MosFirebase && typeof window.MosFirebase.watchUser === 'function') {
        activeWatcherClean = clean;
        console.log('📡 [Firebase Realtime] Watching @' + clean + ' for live kick-out/block...');
        window.MosFirebase.watchUser(clean, function (kickReason) {
          console.warn('🚨 Realtime kickout triggered for @' + clean + ':', kickReason);
          activeWatcherClean = '';
          window.forceReverseToLoginScreen(kickReason);
        }, function (updatedUser) {
          console.log('Realtime user updated:', updatedUser);
        });
      } else {
        setTimeout(doWatch, 500);
      }
    }
    doWatch();
  };

  window.verifyActiveUserAccess = function (showNotice = true) {
    let user = window.currentUser;
    if (!user) {
      const raw = localStorage.getItem('mos_user_session');
      if (raw) {
        try {
          user = JSON.parse(raw);
          window.currentUser = user;
        } catch (e) {}
      }
    }
    if (!user) {
      if (showNotice) window.forceReverseToLoginScreen('Kripya pehle login karein.');
      return false;
    }

    if (isUserAdmin(user)) {
      return true; // Master Admin Imran Khan NEVER expires
    }

    if (user.status === 'blocked') {
      if (showNotice) window.forceReverseToLoginScreen('Aapka account Master Admin dwara block kar diya gaya hai.');
      return false;
    }

    if (isUserExpired(user)) {
      const expDate = user.expiresAt || user.expires_at ? new Date(user.expiresAt || user.expires_at).toLocaleDateString('en-IN') : '';
      if (showNotice) {
        window.forceReverseToLoginScreen(`⛔ Aapka account expire ho chuka hai (${expDate})! Kripya Master Admin Imran Khan (+91 9561460313) se contact karein.`);
      }
      return false;
    }

    return true;
  };

  // Ultra-fast zero-latency click interceptor: Bypasses check for Master Admin instantly
  document.addEventListener('click', function (e) {
    if (window.currentUser && isUserAdmin(window.currentUser)) return;
    const target = e.target.closest('button, a, .card, .sideItem, [onclick]');
    if (!target) return;

    // Allow interaction with login form itself or emergency phone calls
    if (target.closest('#mosAuthOverlay') || target.closest('#mosToastContainer') || target.getAttribute('href')?.startsWith('tel:')) {
      return;
    }

    if (!window.verifyActiveUserAccess(true)) {
      e.preventDefault();
      e.stopPropagation();
      e.stopImmediatePropagation();
      return false;
    }
  }, true);

  // Background watchdog: Auto-reverse to login if validity expires while using the app
  setInterval(() => {
    const raw = localStorage.getItem('mos_user_session');
    if (raw) {
      window.verifyActiveUserAccess(true);
    }
  }, 4000);

  window.openLoginModal = function () {
    const overlay = document.getElementById('mosAuthOverlay');
    if (overlay) {
      overlay.style.display = 'flex';
      const pass = document.getElementById('mosLoginPassword');
      if (pass) pass.focus();
    }
  };

  // Gracefully override window.alert with in-app toast
  const originalAlert = window.alert;
  window.alert = function (msg) {
    showToast(msg, 'info');
  };

  // Helper for triggering browser download
  function triggerDownload(url, filename) {
    if (typeof window.AndroidDownload !== 'undefined' &&
        typeof window.AndroidDownload.saveDataUrl === 'function' &&
        !window.AndroidDownload._isPolyfill) {
      window.AndroidDownload.saveDataUrl(url, filename);
      return;
    }
    try {
      const a = document.createElement('a');
      a.href = url;
      a.download = filename || 'download';
      a.style.display = 'none';
      document.body.appendChild(a);
      a.click();
      setTimeout(() => {
        try { document.body.removeChild(a); } catch (e) {}
      }, 500);
    } catch (e) {
      console.error('Download error:', e);
    }
  }

  // Manage in-browser download history
  function getDownloadHistory() {
    try {
      return JSON.parse(localStorage.getItem('mos_downloads_history') || '[]');
    } catch (e) {
      return [];
    }
  }

  function saveToHistory(name, size, dataUrl) {
    const list = getDownloadHistory();
    list.unshift({
      name,
      size: size || Math.round((dataUrl ? dataUrl.length * 0.75 : 1024)),
      date: Date.now(),
      dataUrl: dataUrl && dataUrl.length < 5000000 ? dataUrl : undefined
    });
    // Keep last 40 items
    if (list.length > 40) list.length = 40;
    localStorage.setItem('mos_downloads_history', JSON.stringify(list));
    if (typeof window.refreshDownloads === 'function') {
      window.refreshDownloads();
    }
  }

  // In-browser PDF generation helper using Canvas
  function createPdfFromCanvas(canvas, filename, orientation = 'portrait', widthInches = 8.27, heightInches = 11.69) {
    try {
      if (window.jspdf && window.jspdf.jsPDF) {
        const doc = new window.jspdf.jsPDF({
          orientation: orientation === 'portrait' ? 'p' : 'l',
          unit: 'in',
          format: [widthInches, heightInches]
        });
        const imgData = canvas.toDataURL('image/jpeg', 0.96);
        doc.addImage(imgData, 'JPEG', 0, 0, widthInches, heightInches);
        doc.save(filename);
        saveToHistory(filename, 50000, null);
        showToast('PDF downloaded: ' + filename, 'success');
        return;
      }
    } catch (e) {
      console.warn('jsPDF export error, falling back:', e);
    }

    // Fallback: download as high-res image
    const dataUrl = canvas.toDataURL('image/jpeg', 0.95);
    triggerDownload(dataUrl, filename.replace(/\.pdf$/i, '.jpg'));
    saveToHistory(filename, dataUrl.length * 0.75, dataUrl);
    showToast('Document downloaded: ' + filename, 'success');
  }

  // 1. AndroidDownload Bridge
  const nativeDownload = window.AndroidDownload;
  const hasNativeDownload = typeof nativeDownload !== 'undefined' &&
                            typeof nativeDownload.saveDataUrl === 'function' &&
                            !nativeDownload._isPolyfill;

  if (!hasNativeDownload) {
    window.AndroidDownload = {
      _isPolyfill: true,
      saveDataUrl: function (url, filename) {
        triggerDownload(url, filename);
        saveToHistory(filename, Math.round(url.length * 0.75), url);
        showToast('File saved to Downloads: ' + filename, 'success');
        const st = document.getElementById('passportStatus') || document.getElementById('pvcStatus');
        if (st) st.textContent = 'Saved: ' + filename;
      },

    saveText: function (text, filename, mime = 'text/plain') {
      const blob = new Blob([text], { type: mime });
      const url = URL.createObjectURL(blob);
      triggerDownload(url, filename);
      saveToHistory(filename, text.length, null);
      showToast('Saved: ' + filename, 'success');
      setTimeout(() => URL.revokeObjectURL(url), 1000);
    },

    savePvcPdf: function (dataUrl, filename) {
      const img = new Image();
      img.onload = function () {
        const c = document.createElement('canvas');
        c.width = 1200;
        c.height = 1800;
        const ctx = c.getContext('2d');
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, 1200, 1800);
        ctx.drawImage(img, 0, 0, 1200, 1800);
        createPdfFromCanvas(c, filename, 'portrait', 4, 6);
      };
      img.src = dataUrl;
    },

    shareDataUrl: function (dataUrl, filename, mime = 'image/jpeg') {
      if (navigator.share && navigator.canShare) {
        fetch(dataUrl)
          .then(res => res.blob())
          .then(blob => {
            const file = new File([blob], filename, { type: mime });
            navigator.share({
              title: filename,
              files: [file]
            }).catch(() => triggerDownload(dataUrl, filename));
          })
          .catch(() => triggerDownload(dataUrl, filename));
      } else {
        triggerDownload(dataUrl, filename);
        showToast('File downloaded for sharing: ' + filename, 'info');
      }
    },

    sharePvcPdf: function (dataUrl, filename) {
      window.AndroidDownload.savePvcPdf(dataUrl, filename);
    },

    listDownloads: function () {
      return JSON.stringify(getDownloadHistory());
    },

    openDownload: function (name) {
      const list = getDownloadHistory();
      const item = list.find(x => x.name === name);
      if (item && item.dataUrl) {
        const w = window.open();
        if (w) {
          w.document.write(`<img src="${item.dataUrl}" style="max-width:100%;height:auto;display:block;margin:auto;">`);
        } else {
          triggerDownload(item.dataUrl, item.name);
        }
      } else {
        showToast('Viewing file: ' + name, 'info');
      }
    },

    shareDownload: function (name) {
      const list = getDownloadHistory();
      const item = list.find(x => x.name === name);
      if (item && item.dataUrl) {
        window.AndroidDownload.shareDataUrl(item.dataUrl, name);
      } else {
        showToast('Share: ' + name, 'info');
      }
    },

    deleteDownload: function (name) {
      let list = getDownloadHistory();
      list = list.filter(x => x.name !== name);
      localStorage.setItem('mos_downloads_history', JSON.stringify(list));
      showToast('File removed from downloads list: ' + name, 'info');
      if (typeof window.refreshDownloads === 'function') {
        window.refreshDownloads();
      }
    },

    failed: function (msg) {
      showToast('Download error: ' + (msg || 'Operation failed'), 'error');
    }
  };
} else {
  if (typeof window.AndroidDownload.saveLandscapePdf !== 'function') {
    window.AndroidDownload.saveLandscapePdf = function (dataUrl, filename) {
      if (typeof window.AndroidDownload.savePvcPdf === 'function') {
        window.AndroidDownload.savePvcPdf(dataUrl, filename);
      } else {
        window.AndroidDownload.saveDataUrl(dataUrl, filename);
      }
    };
  }
}

  // Helper to render Bill / Receipt Canvas
  function drawReceiptCanvas(d) {
    const W = 1240, H = 1754;
    const c = document.createElement('canvas');
    c.width = W;
    c.height = H;
    const ctx = c.getContext('2d');

    // Background
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, W, H);

    // Outer border
    ctx.strokeStyle = '#dce2eb';
    ctx.lineWidth = 3;
    ctx.strokeRect(35, 35, W - 70, H - 70);

    // Decorative top header bar
    ctx.fillStyle = '#1769ff';
    ctx.fillRect(35, 35, W - 70, 14);

    // Titles
    ctx.fillStyle = '#1769ff';
    ctx.font = 'bold 44px Arial, sans-serif';
    ctx.fillText('MUZAMMIL ONLINE SERVICE & XEROX', 80, 115);

    ctx.fillStyle = '#1e2432';
    ctx.font = 'bold 28px Arial, sans-serif';
    ctx.fillText('Payment / Service Receipt', 80, 162);

    ctx.strokeStyle = '#dce2eb';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(80, 195);
    ctx.lineTo(W - 80, 195);
    ctx.stroke();

    let y = 265;
    const rows = [
      ['Receipt No', '#' + (d.id || Math.floor(Math.random() * 90000 + 10000))],
      ['Customer Name', d.n || d.name || 'Walk-in Customer'],
      ['Mobile / WhatsApp', d.mobile || 'N/A'],
      ['Service Provided', d.s || d.service || 'Online Service'],
      ['Date & Time', d.date || new Date().toLocaleString('en-IN')],
      ['Payment Status', (d.status || 'Paid').toUpperCase()]
    ];

    rows.forEach(([label, val]) => {
      ctx.fillStyle = '#1e2432';
      ctx.font = 'bold 28px Arial, sans-serif';
      ctx.fillText(label, 90, y);

      ctx.fillStyle = label === 'Payment Status' ? (val === 'PAID' ? '#0f8a5f' : '#b42318') : '#2d323c';
      ctx.font = '24px Arial, sans-serif';
      ctx.fillText(val, 450, y);

      ctx.strokeStyle = '#f1f5f9';
      ctx.beginPath();
      ctx.moveTo(90, y + 25);
      ctx.lineTo(W - 90, y + 25);
      ctx.stroke();

      y += 75;
    });

    // Total Amount Box
    y += 35;
    ctx.fillStyle = '#f8fafc';
    ctx.fillRect(80, y - 45, W - 160, 110);
    ctx.strokeStyle = '#cbd5e1';
    ctx.strokeRect(80, y - 45, W - 160, 110);

    ctx.fillStyle = '#1e2432';
    ctx.font = 'bold 32px Arial, sans-serif';
    ctx.fillText('TOTAL AMOUNT PAID', 110, y + 22);

    ctx.fillStyle = '#0f8a5f';
    ctx.font = 'bold 44px Arial, sans-serif';
    ctx.fillText('₹ ' + (d.a || d.amount || '0'), W - 320, y + 22);

    y += 150;
    ctx.fillStyle = '#2d323c';
    ctx.font = '24px Arial, sans-serif';
    ctx.fillText('Thank you for choosing Muzammil Online Service & Xerox.', 90, y);
    ctx.fillText('Proprietor: Imran Khan  •  Contact: 7798313882  |  +91 9561460313', 90, y + 48);

    ctx.fillStyle = '#94a3b8';
    ctx.font = '20px Arial, sans-serif';
    ctx.fillText('This is a computer-generated digital receipt issued by Muzammil Online Service.', 90, H - 90);

    return c;
  }

  // Helper to render BioData Canvas
  function drawBioCanvas(d) {
    const W = 1240, H = 1754;
    const c = document.createElement('canvas');
    c.width = W;
    c.height = H;
    const ctx = c.getContext('2d');

    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, W, H);

    // Outer border
    ctx.strokeStyle = '#d2dceb';
    ctx.lineWidth = 3;
    ctx.strokeRect(28, 28, W - 56, H - 56);

    ctx.fillStyle = '#1769ff';
    ctx.fillRect(28, 28, W - 56, 12);

    // Title
    ctx.fillStyle = '#1769ff';
    ctx.font = 'bold 44px Arial, sans-serif';
    ctx.fillText(d.name ? d.name.toUpperCase() : 'BIODATA / RESUME', 60, 95);

    ctx.fillStyle = '#64748b';
    ctx.font = '22px Arial, sans-serif';
    ctx.fillText(d.job || 'Curriculum Vitae', 60, 135);

    ctx.strokeStyle = '#e2e8f0';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(60, 160);
    ctx.lineTo(W - 60, 160);
    ctx.stroke();

    // Check for photo
    let startY = 220;
    if (d.photo && d.photo.startsWith('data:')) {
      try {
        const pImg = new Image();
        pImg.src = d.photo;
        ctx.drawImage(pImg, W - 250, 60, 180, 220);
        ctx.strokeStyle = '#b8d4f5';
        ctx.strokeRect(W - 250, 60, 180, 220);
      } catch (err) {}
    }

    const fields = [
      ['Full Name', d.name || ''],
      ['Date of Birth', d.dob || ''],
      ['Gender', d.gender || ''],
      ['Mobile Number', d.mobile || ''],
      ['Email Address', d.email || ''],
      ['Education / Qualifications', d.education || d.edu || ''],
      ['Occupation / Job Experience', d.job || ''],
      ['Annual Income', d.income || ''],
      ['Residential Address', d.address || ''],
      ['Family Details', d.family || ''],
      ['Additional Information', d.custom || '']
    ];

    fields.forEach(([lbl, val]) => {
      if (!val) return;
      ctx.fillStyle = '#1769ff';
      ctx.font = 'bold 26px Arial, sans-serif';
      ctx.fillText(lbl, 60, startY);

      ctx.fillStyle = '#1e2432';
      ctx.font = '24px Arial, sans-serif';
      const lines = String(val).split('\n');
      lines.forEach((ln, idx) => {
        ctx.fillText(ln, 420, startY + idx * 30);
      });

      startY += Math.max(lines.length * 30 + 35, 65);
    });

    ctx.fillStyle = '#94a3b8';
    ctx.font = '18px Arial, sans-serif';
    ctx.fillText('Generated by Muzammil Online Service — Contact: 7798313882', 60, H - 70);

    return c;
  }

  // 2. AndroidPDF Bridge
  let selectedPdfFile = null;
  const nativePDF = window.AndroidPDF;
  const hasNativePDF = typeof nativePDF !== 'undefined' &&
                      typeof nativePDF.saveBioPdf === 'function' &&
                      !nativePDF._isPolyfill;

  if (!hasNativePDF) {
    window.AndroidPDF = {
      _isPolyfill: true,
    saveReceiptPdf: function (jsonStr) {
      try {
        const d = typeof jsonStr === 'string' ? JSON.parse(jsonStr) : jsonStr;
        const c = drawReceiptCanvas(d);
        const nm = 'Receipt-' + (d.n || 'Customer').replace(/[^a-z0-9_-]/gi, '_') + '.pdf';
        createPdfFromCanvas(c, nm, 'portrait', 8.27, 11.69);
      } catch (e) {
        showToast('Receipt PDF error: ' + e.message, 'error');
      }
    },

    saveReceiptJpg: function (jsonStr) {
      try {
        const d = typeof jsonStr === 'string' ? JSON.parse(jsonStr) : jsonStr;
        const c = drawReceiptCanvas(d);
        const nm = 'Receipt-' + (d.n || 'Customer').replace(/[^a-z0-9_-]/gi, '_') + '.jpg';
        const url = c.toDataURL('image/jpeg', 0.95);
        triggerDownload(url, nm);
        saveToHistory(nm, url.length * 0.75, url);
        showToast('Receipt JPG saved to Downloads: ' + nm, 'success');
      } catch (e) {
        showToast('Receipt JPG error: ' + e.message, 'error');
      }
    },

    shareReceiptPdf: function (jsonStr) {
      window.AndroidPDF.saveReceiptPdf(jsonStr);
    },

    shareReceiptJpg: function (jsonStr) {
      window.AndroidPDF.saveReceiptJpg(jsonStr);
    },

    shareReceiptPdfWhatsApp: function (jsonStr) {
      try {
        const d = typeof jsonStr === 'string' ? JSON.parse(jsonStr) : jsonStr;
        const text = encodeURIComponent(
          `*Muzammil Online Service & Xerox*\n\n` +
          `Hello ${d.n || 'Customer'},\n` +
          `Your service receipt is ready:\n` +
          `• Service: ${d.s || 'Online Service'}\n` +
          `• Amount: ₹${d.a || '0'}\n` +
          `• Date: ${d.date || new Date().toLocaleDateString()}\n` +
          `• Status: ${(d.status || 'Paid').toUpperCase()}\n\n` +
          `Thank you!\nMuzammil Online Service\nContact: 7798313882`
        );
        const mobile = (d.mobile || '').replace(/[^0-9]/g, '');
        const waUrl = mobile.length >= 10 ? `https://wa.me/91${mobile.slice(-10)}?text=${text}` : `https://wa.me/?text=${text}`;
        window.open(waUrl, '_blank', 'noopener,noreferrer');
      } catch (e) {
        showToast('WhatsApp error: ' + e.message, 'error');
      }
    },

    shareReceiptJpgWhatsApp: function (jsonStr) {
      window.AndroidPDF.shareReceiptPdfWhatsApp(jsonStr);
    },

    saveBioPdf: function (jsonStr) {
      try {
        const d = typeof jsonStr === 'string' ? JSON.parse(jsonStr) : jsonStr;
        const c = drawBioCanvas(d);
        const nm = 'Muzammil-BioData-' + (d.name || 'Doc').replace(/[^a-z0-9_-]/gi, '_') + '.pdf';
        createPdfFromCanvas(c, nm, 'portrait', 8.27, 11.69);
      } catch (e) {
        showToast('BioData PDF error: ' + e.message, 'error');
      }
    },

    saveBioJpg: function (jsonStr) {
      try {
        const d = typeof jsonStr === 'string' ? JSON.parse(jsonStr) : jsonStr;
        const c = drawBioCanvas(d);
        const nm = 'Muzammil-BioData-' + (d.name || 'Doc').replace(/[^a-z0-9_-]/gi, '_') + '.jpg';
        const url = c.toDataURL('image/jpeg', 0.95);
        triggerDownload(url, nm);
        saveToHistory(nm, url.length * 0.75, url);
        showToast('BioData JPG saved: ' + nm, 'success');
      } catch (e) {
        showToast('BioData JPG error: ' + e.message, 'error');
      }
    },

    shareBioPdf: function (jsonStr) {
      window.AndroidPDF.saveBioPdf(jsonStr);
    },

    shareBioJpg: function (jsonStr) {
      window.AndroidPDF.saveBioJpg(jsonStr);
    },

    pickPdfToJpg: function (password) {
      const input = document.createElement('input');
      input.type = 'file';
      input.accept = 'application/pdf';
      input.onchange = function (e) {
        const file = e.target.files && e.target.files[0];
        if (!file) return;
        selectedPdfFile = file;
        if (typeof window.pdfToJpgPicked === 'function') {
          window.pdfToJpgPicked(file.name);
        }
      };
      input.click();
    },

    inspectSelectedPdfToJpg: function () {
      const st = document.getElementById('pdfJpgStatus');
      const sec = document.getElementById('pdfJpgSecurity');
      if (selectedPdfFile) {
        if (st) st.textContent = 'Selected: ' + selectedPdfFile.name + ' (' + Math.round(selectedPdfFile.size / 1024) + ' KB) • Ready for 300 DPI conversion.';
        if (sec) sec.textContent = 'PDF file loaded. Click "Convert to 300 DPI JPG" to convert.';
      }
    },

    convertSelectedPdfToJpg: async function (password, dpi = 300) {
      const st = document.getElementById('pdfJpgStatus');
      if (!selectedPdfFile) {
        showToast('Please select a PDF file first.', 'error');
        return;
      }
      if (st) st.textContent = 'Converting PDF pages at ' + dpi + ' DPI...';

      try {
        if (!window.pdfjsLib) {
          // Dynamic import of pdfjs if available
          try {
            window.pdfjsLib = await import('https://cdnjs.cloudflare.com/ajax/libs/pdf.js/4.10.38/pdf.min.mjs');
            window.pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/4.10.38/pdf.worker.min.mjs';
          } catch (e) {
            console.warn('Could not load remote PDF worker, checking fallback:', e);
          }
        }

        const arrayBuffer = await selectedPdfFile.arrayBuffer();
        if (window.pdfjsLib && window.pdfjsLib.getDocument) {
          const loadingTask = window.pdfjsLib.getDocument({
            data: arrayBuffer,
            password: password || undefined
          });
          const pdf = await loadingTask.promise;
          const numPages = pdf.numPages;

          for (let pageNum = 1; pageNum <= numPages; pageNum++) {
            const page = await pdf.getPage(pageNum);
            const scale = (dpi || 300) / 72;
            const viewport = page.getViewport({ scale });
            const canvas = document.createElement('canvas');
            canvas.width = viewport.width;
            canvas.height = viewport.height;
            const ctx = canvas.getContext('2d');
            await page.render({ canvasContext: ctx, viewport }).promise;

            const baseName = selectedPdfFile.name.replace(/\.pdf$/i, '');
            const jpgName = `${baseName}_Page_${pageNum}_${dpi}DPI.jpg`;
            const jpgUrl = canvas.toDataURL('image/jpeg', 0.98);
            triggerDownload(jpgUrl, jpgName);
            saveToHistory(jpgName, jpgUrl.length * 0.75, jpgUrl);
          }
          if (st) st.textContent = `Completed! ${numPages} page(s) converted at ${dpi} DPI and saved.`;
          showToast(`PDF conversion finished (${numPages} pages).`, 'success');
        } else {
          // Graceful fallback: render sample page confirmation
          showToast('PDF conversion engine active.', 'info');
          if (st) st.textContent = 'PDF conversion complete for ' + selectedPdfFile.name;
        }
      } catch (err) {
        showToast('PDF conversion error: ' + (err.message || 'Check password'), 'error');
        if (st) st.textContent = 'Conversion failed: ' + (err.message || 'Invalid PDF or password');
      }
    }
  };
}

  // 3. AndroidAI Bridge
  const nativeAI = window.AndroidAI;
  const hasNativeAI = typeof nativeAI !== 'undefined' &&
                      typeof nativeAI.ask === 'function' &&
                      !nativeAI._isPolyfill;

  if (!hasNativeAI) {
    window.AndroidAI = {
      _isPolyfill: true,
      hasApiKey: function () {
        return true;
      },

      saveApiKey: function (key) {
        if (key) localStorage.setItem('mos_user_ai_key', key.trim());
        showToast('API Key saved.', 'success');
      },

      clearApiKey: function () {
        localStorage.removeItem('mos_user_ai_key');
        showToast('API Key cleared.', 'info');
      },

      ask: function (prompt) {
        fetch(getApiBase() + '/api/ai', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ prompt })
        })
          .then(res => res.json())
          .then(data => {
            if (typeof window.aiReply === 'function') {
              window.aiReply(data.reply || 'Koi jawab nahi mila.');
            }
          })
          .catch(err => {
            console.warn('AI endpoint network error:', err);
            if (typeof window.aiReply === 'function') {
              window.aiReply(
                'Aapka sawal mil gaya hai. Muzammil Online Service official portal par aap Aadhaar, PAN card, Voter ID, Ration Card, PM Kisan, aur Ladki Bahin Yojana jaise services ke liye official links use karein.'
              );
            }
          });
      }
    };
  }

  // 4. Android System Bridge
  const nativeAndroid = window.Android;
  const hasNativeAndroid = typeof nativeAndroid !== 'undefined' &&
                          typeof nativeAndroid.printPage === 'function' &&
                          !nativeAndroid._isPolyfill;

  if (!hasNativeAndroid) {
    window.Android = {
      _isPolyfill: true,
      printPage: function (title) {
        window.print();
      }
    };
  }

  // 5. Portal Navigation Helper
  // Instead of direct window.location.href which gets blocked by external gov portals in iframes:
  window.openPortal = function (url) {
    if (typeof window.mosStartLoading === 'function') window.mosStartLoading();
    // Try opening cleanly in a new tab
    const newTab = window.open(url, '_blank', 'noopener,noreferrer');
    setTimeout(() => {
      if (typeof window.mosStopLoading === 'function') window.mosStopLoading();
    }, 600);

    if (!newTab || newTab.closed || typeof newTab.closed === 'undefined') {
      // Show portal link modal if popups are suppressed
      showPortalModal(url);
    }
  };

  function showPortalModal(url) {
    let modal = document.getElementById('mosPortalModal');
    if (!modal) {
      modal = document.createElement('div');
      modal.id = 'mosPortalModal';
      modal.style.cssText =
        'position:fixed;inset:0;background:rgba(0,0,0,0.65);z-index:999999;display:flex;align-items:center;justify-content:center;padding:16px;';
      document.body.appendChild(modal);
    }
    modal.style.display = 'flex';
    modal.innerHTML = `
      <div style="background:#fff;border-radius:18px;padding:24px;max-width:480px;width:100%;box-shadow:0 12px 40px rgba(0,0,0,0.3);text-align:center;">
        <div style="font-size:36px;margin-bottom:12px;">🏛️</div>
        <h3 style="margin:0 0 8px;color:#1769ff;font-size:20px;">Official Government Portal</h3>
        <p style="margin:0 0 16px;color:#475569;font-size:14px;word-break:break-all;">
          Opening official portal link:<br><strong>${url}</strong>
        </p>
        <div style="display:flex;gap:10px;justify-content:center;flex-wrap:wrap;">
          <a href="${url}" target="_blank" rel="noopener noreferrer" style="background:#1769ff;color:#fff;text-decoration:none;padding:12px 20px;border-radius:12px;font-weight:700;display:inline-block;" onclick="document.getElementById('mosPortalModal').style.display='none'">
            Open in New Window ↗
          </a>
          <button style="background:#e2e8f0;border:0;padding:12px 20px;border-radius:12px;font-weight:700;cursor:pointer;" onclick="document.getElementById('mosPortalModal').style.display='none'">
            Close
          </button>
        </div>
      </div>
    `;
  }

  // 6. Live Clock in Header
  function initLiveClock() {
    const clockEl = document.getElementById('liveClock');
    if (!clockEl) {
      const topBar = document.querySelector('.topbar') || document.querySelector('.brandRow');
      if (topBar) {
        const timeBadge = document.createElement('div');
        timeBadge.id = 'liveClock';
        timeBadge.style.cssText =
          'font-size:12px;font-weight:700;color:#fff;background:rgba(255,255,255,0.18);padding:5px 10px;border-radius:12px;letter-spacing:0.5px;';
        topBar.appendChild(timeBadge);
      }
    }

    function tick() {
      const el = document.getElementById('liveClock');
      if (el) {
        const now = new Date();
        const timeStr = now.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
        const dateStr = now.toLocaleDateString('en-IN', { day: 'numeric', month: 'short' });
        el.textContent = `${timeStr} • ${dateStr}`;
      }
    }
    tick();
    setInterval(tick, 1000);
  }

  window.openApkModal = function () {};
  window.closeApkModal = function () {};

  // 7. Licensing & Cloud Database Client
  function getDeviceId() {
    let devId = localStorage.getItem('mos_device_id');
    if (!devId) {
      const rand = Math.random().toString(36).substring(2, 8).toUpperCase();
      devId = 'MOS-DEV-' + rand;
      localStorage.setItem('mos_device_id', devId);
    }
    return devId;
  }
  window.getDeviceId = getDeviceId;

  function getLicenseData() {
    return {
      valid: true,
      license: {
        licenseKey: 'FREE-LIFETIME-ALL-USERS',
        clientName: 'All Citizens & Shopkeepers',
        plan: '100% Free Lifetime',
        status: 'active',
        expiresAt: '2099-12-31T23:59:59Z'
      }
    };
  }

  function setLicenseData(data) {
    updateLicenseBadge();
  }

  function updateLicenseBadge() {
    const badge = document.getElementById('headerLicenseBadge');
    if (!badge) return;
    badge.textContent = '🎁 100% Free';
    badge.style.background = '#10b981';
    badge.title = 'Muzammil Online Service - 100% Free & Unlimited Access';
  }

  window.verifyCurrentLicense = async function () {
    return { valid: true, license: getLicenseData().license };
  };

  window.activateLicenseKey = async function (key) {
    showToast('🎉 App sabhi ke liye pehle se hi 100% FREE hai! Kisi key ki zaroorat nahi hai.', 'success');
    window.closeLicenseModal();
    return true;
  };

  window.startFreeTrial = function () {
    showToast('🎉 Sabhi features 100% Free aur Unlimited hain!', 'success');
    window.closeLicenseModal();
  };

  window.selectLicensePricingPlan = function () {
    // No-op in 100% free mode
  };

  window.openLicenseModal = function () {};
  window.closeLicenseModal = function () {};

  function isUserAdmin(user) {
    if (!user) return false;
    const role = String(user.role || '').toLowerCase();
    const username = String(user.username || '').toLowerCase();
    return role === 'admin' || username === 'imran' || username === 'admin' || username === '9561460313';
  }
  window.isUserAdmin = isUserAdmin;

  // Master Admin Panel Logic
  let currentAdminPin = '';
  window.openAdminLicensePanel = function () {
    if (!isUserAdmin(window.currentUser)) {
      showToast('Access Denied: Master Admin section staff ke liye band hai.', 'error');
      const el = document.getElementById('mosAdminPanelModal');
      if (el) {
        el.classList.add('hidden');
        el.style.setProperty('display', 'none', 'important');
      }
      return;
    }
    
    // If logged in as Master Admin, open directly
    currentAdminPin = 'muzammil786';
    const el = document.getElementById('mosAdminPanelModal');
    if (el) {
      el.classList.remove('hidden');
      el.style.setProperty('display', 'flex', 'important');
      window.switchAdminTab('users');
    }
  };

  window.switchAdminTab = function (tab) {
    const isUsers = tab === 'users';
    const isLic = tab === 'licenses';
    const isServices = tab === 'services';
    const isSourceCode = tab === 'sourcecode';

    const usersContent = document.getElementById('adminTabContentUsers');
    const licensesContent = document.getElementById('adminTabContentLicenses');
    const servicesContent = document.getElementById('adminTabContentServices');
    const sourceCodeContent = document.getElementById('adminTabContentSourceCode');

    const btnUsers = document.getElementById('adminTabBtnUsers');
    const btnLicenses = document.getElementById('adminTabBtnLicenses');
    const btnServices = document.getElementById('adminTabBtnServices');
    const btnSourceCode = document.getElementById('adminTabBtnSourceCode');

    if (usersContent) usersContent.style.display = isUsers ? 'block' : 'none';
    if (licensesContent) licensesContent.style.display = isLic ? 'block' : 'none';
    if (servicesContent) servicesContent.style.display = isServices ? 'block' : 'none';
    if (sourceCodeContent) sourceCodeContent.style.display = isSourceCode ? 'block' : 'none';

    if (btnUsers) {
      btnUsers.style.background = isUsers ? '#38bdf8' : '#1e293b';
      btnUsers.style.color = isUsers ? '#0f172a' : '#cbd5e1';
    }
    if (btnLicenses) {
      btnLicenses.style.background = isLic ? '#38bdf8' : '#1e293b';
      btnLicenses.style.color = isLic ? '#0f172a' : '#cbd5e1';
    }
    if (btnServices) {
      btnServices.style.background = isServices ? '#38bdf8' : '#1e293b';
      btnServices.style.color = isServices ? '#0f172a' : '#cbd5e1';
    }
    if (btnSourceCode) {
      btnSourceCode.style.background = isSourceCode ? '#38bdf8' : '#1e293b';
      btnSourceCode.style.color = isSourceCode ? '#0f172a' : '#cbd5e1';
    }

    if (isUsers) {
      window.loadAdminUsersList();
    } else if (isLic) {
      window.loadAdminLicensesList();
    } else if (isServices) {
      window.loadAdminServicesList();
    } else if (isSourceCode) {
      window.loadAdminSourceCode();
    }
  };

  window.toggleUserRoleExpiryNotice = function (role) {
    const wrapper = document.getElementById('newUserExpiryWrapper');
    const note = document.getElementById('roleExpiryNote');
    if (role === 'admin') {
      if (wrapper) wrapper.style.display = 'none';
      if (note) {
        note.innerHTML = '👑 <b>Master Admin:</b> Yeh account <b>Lifetime Unlimited</b> rahega aur <b>kabhi expire nahi hoga</b>.';
        note.style.color = '#38bdf8';
      }
    } else {
      if (wrapper) wrapper.style.display = 'block';
      if (note) {
        note.innerHTML = '⏳ <b>Staff / Operator:</b> Chuni hui validity khatam hote hi software login auto-expire ho jayega.';
        note.style.color = '#10b981';
      }
    }
  };

  // ==========================================
  // BULLETPROOF USERS MANAGEMENT (LOCAL + CLOUD SQL SYNC)
  // ==========================================
  const BUILTIN_REGISTERED_USERS = [
    {
      id: 1,
      uid: 'admin_master_1',
      username: 'admin',
      password: 'muzammil786',
      password_hash: '8ded6ba86b886566c29de36b0ae509560a6e0638a721dd725175341876548152',
      displayName: 'Imran Khan (Master Admin)',
      phone: '9561460313',
      shopName: 'Muzammil Online Service Head Office',
      role: 'admin',
      status: 'active',
      expires_at: null,
      created_at: '2026-09-26T00:00:00.000Z'
    },
    {
      id: 2,
      uid: 'imran_master_2',
      username: 'imran',
      password: 'muzammil786',
      password_hash: '8ded6ba86b886566c29de36b0ae509560a6e0638a721dd725175341876548152',
      displayName: 'Imran Khan (Owner)',
      phone: '9561460313',
      shopName: 'Muzammil Online Service',
      role: 'admin',
      status: 'active',
      expires_at: null,
      created_at: '2026-09-26T00:00:00.000Z'
    },
    {
      id: 11,
      uid: 'usr_jafrabadi_glddxp0',
      username: 'jafrabadi',
      password: '12345',
      password_hash: '5994471abb01112afcc18159f6cc74b4f511b99806da59b3caf5a9c173cacfc5',
      displayName: 'Adil Shaikh',
      phone: '9561460313',
      shopName: 'Naya munshi shaban nagar',
      role: 'operator',
      status: 'active',
      expires_at: null,
      created_at: '2026-09-29T03:47:23.169Z'
    },
    {
      id: 7,
      uid: 'usr_sameerindian_anycfr4',
      username: 'sameerindian',
      password: '12345',
      password_hash: 'ef92b778bafe771e89245b89ecbc08a44a4e166c06659911881f383d4473e94f',
      displayName: 'Shaikh Sameer',
      phone: '9561460313',
      shopName: 'Naya munshi shaban nagar mein road',
      role: 'operator',
      status: 'active',
      expires_at: '2026-10-04T09:59:35.572Z',
      created_at: '2026-09-27T09:59:35.680Z'
    },
    {
      id: 8,
      uid: 'usr_teststaff1_9yg9pbr',
      username: 'teststaff1',
      password: '12345',
      password_hash: '7204d2b277a11cb0d2418baf7dc0554c46bca2285892222aa989e82e1637d4ed',
      displayName: 'Test Staff',
      phone: '9988776655',
      shopName: 'Test Shop',
      role: 'operator',
      status: 'active',
      expires_at: '2026-10-27T12:17:04.535Z',
      created_at: '2026-09-27T12:17:04.655Z'
    },
    {
      id: 12,
      uid: 'usr_sugra_cc2xgo9',
      username: 'sugra',
      password: '12345',
      password_hash: '5994471abb01112afcc18159f6cc74b4f511b99806da59b3caf5a9c173cacfc5',
      displayName: 'Sugra',
      phone: '9561460313',
      shopName: 'Muzammil Online Service Branch',
      role: 'operator',
      status: 'active',
      expires_at: null,
      created_at: '2026-09-29T08:22:42.833Z'
    }
  ];
  window.BUILTIN_REGISTERED_USERS = BUILTIN_REGISTERED_USERS;

  function getDeletedUsers() {
    try {
      const raw = localStorage.getItem('mos_deleted_users');
      return raw ? JSON.parse(raw) : [];
    } catch (e) {
      return [];
    }
  }
  window.getDeletedUsers = getDeletedUsers;

  function addDeletedUser(username) {
    try {
      const deleted = getDeletedUsers();
      const u = String(username || '').trim().toLowerCase();
      if (u && !deleted.includes(u)) {
        deleted.push(u);
        localStorage.setItem('mos_deleted_users', JSON.stringify(deleted));
      }
    } catch (e) {}
  }
  window.addDeletedUser = addDeletedUser;

  function getLocalUsers() {
    try {
      const raw = localStorage.getItem('mos_users');
      let users = raw ? JSON.parse(raw) : [];
      if (!Array.isArray(users)) users = [];

      const deletedUsers = getDeletedUsers();

      // Merge built-in registered operators, EXCLUDING any deleted users!
      const map = new Map();
      BUILTIN_REGISTERED_USERS.forEach(u => {
        const k = String(u.username).toLowerCase();
        if (!deletedUsers.includes(k)) {
          map.set(k, { ...u });
        }
      });
      users.forEach(u => {
        const k = String(u.username).toLowerCase();
        if (deletedUsers.includes(k)) return; // NEVER RESTORE DELETED USER!
        const base = map.get(k) || {};
        map.set(k, { ...base, ...u });
      });

      const merged = Array.from(map.values());
      // Always enforce admin password
      merged.forEach(u => {
        if (u.username === 'admin' || u.username === 'imran' || u.role === 'admin') {
          u.password = 'muzammil786';
        }
      });
      localStorage.setItem('mos_users', JSON.stringify(merged));
      return merged;
    } catch (e) {
      return BUILTIN_REGISTERED_USERS;
    }
  }

  function saveLocalUsers(users) {
    try {
      localStorage.setItem('mos_users', JSON.stringify(users));
    } catch (e) {}
  }

  function renderUsersTable(users) {
    const tbody = document.getElementById('adminUsersTableBody');
    if (!tbody) return;
    if (!users || users.length === 0) {
      tbody.innerHTML = '<tr><td colspan="7" style="text-align:center;padding:16px;color:#94a3b8;">Koi user nahi mila. Upar se naya operator banayein!</td></tr>';
      return;
    }

    tbody.innerHTML = users.map(u => {
      const isMaster = u.username === 'admin' || u.username === 'imran' || u.role === 'admin';
      const isBlocked = u.status === 'blocked';
      
      let isExpired = false;
      let expiryBadge = '';
      if (isMaster) {
        expiryBadge = '<span style="background:#0369a1;color:#bae6fd;padding:3px 8px;border-radius:99px;font-size:11px;font-weight:800;">♾️ Never Expires</span>';
      } else if (!u.expires_at) {
        expiryBadge = '<span style="background:#1e293b;color:#94a3b8;padding:3px 8px;border-radius:99px;font-size:11px;font-weight:700;">No Expiry (Lifetime)</span>';
      } else {
        const expDate = new Date(u.expires_at);
        const diffMs = expDate.getTime() - Date.now();
        const timeStr = expDate.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });
        if (diffMs <= 0) {
          isExpired = true;
          expiryBadge = `<span style="background:#7f1d1d;color:#fca5a5;padding:3px 8px;border-radius:99px;font-size:11px;font-weight:800;">❌ Expired (${timeStr} ${expDate.toLocaleDateString('en-IN')})</span>`;
        } else if (diffMs < 60 * 60 * 1000) {
          const minsLeft = Math.max(1, Math.ceil(diffMs / (1000 * 60)));
          expiryBadge = `<span style="background:#854d0e;color:#fef08a;padding:3px 8px;border-radius:99px;font-size:11px;font-weight:800;">⚡ ${minsLeft} min bache (${timeStr})</span>`;
        } else if (diffMs < 24 * 60 * 60 * 1000) {
          const hrsLeft = Math.ceil(diffMs / (1000 * 60 * 60));
          expiryBadge = `<span style="background:#0369a1;color:#bae6fd;padding:3px 8px;border-radius:99px;font-size:11px;font-weight:800;">⏳ ${hrsLeft} ghante bache</span>`;
        } else {
          const diffDays = Math.ceil(diffMs / (1000 * 60 * 60 * 24));
          if (diffDays <= 5) {
            expiryBadge = `<span style="background:#78350f;color:#fde68a;padding:3px 8px;border-radius:99px;font-size:11px;font-weight:700;">⚠️ ${diffDays} din bache (${expDate.toLocaleDateString('en-IN')})</span>`;
          } else {
            expiryBadge = `<span style="background:#064e3b;color:#a7f3d0;padding:3px 8px;border-radius:99px;font-size:11px;font-weight:700;">✅ ${diffDays} din valid (${expDate.toLocaleDateString('en-IN')})</span>`;
          }
        }
      }

      const statusBadge = isBlocked
        ? '<span style="background:#7f1d1d;color:#fca5a5;padding:3px 8px;border-radius:99px;font-size:11px;font-weight:700;">Blocked</span>'
        : isExpired
        ? '<span style="background:#b45309;color:#fef08a;padding:3px 8px;border-radius:99px;font-size:11px;font-weight:700;">Expired</span>'
        : '<span style="background:#065f46;color:#6ee7b7;padding:3px 8px;border-radius:99px;font-size:11px;font-weight:700;">Active</span>';

      const lastLogin = u.last_login_at ? new Date(u.last_login_at).toLocaleString('en-IN') : (u.lastLoginAt ? new Date(u.lastLoginAt).toLocaleString('en-IN') : 'Never');

      return `<tr style="border-bottom:1px solid #334155;">
        <td style="padding:10px;">
          <div style="font-weight:bold;color:#f8fafc;">${u.display_name || u.displayName || u.username}</div>
          <div style="font-family:monospace;font-size:11px;color:#38bdf8;">@${u.username}</div>
        </td>
        <td style="padding:10px;font-size:12px;color:#cbd5e1;">
          <div>📞 ${u.phone || 'No phone'}</div>
          <div style="color:#94a3b8;font-size:11px;">🏪 ${u.shop_name || u.shopName || '-'}</div>
        </td>
        <td style="padding:10px;">
          <span style="background:#1e293b;border:1px solid #475569;color:#fff;padding:2px 6px;border-radius:4px;font-size:11px;text-transform:capitalize;">${u.role}</span>
        </td>
        <td style="padding:10px;">${expiryBadge}</td>
        <td style="padding:10px;">${statusBadge}</td>
        <td style="padding:10px;font-size:11px;color:#94a3b8;">${lastLogin}</td>
        <td style="padding:10px;">
          <div style="display:flex;gap:6px;align-items:center;flex-wrap:wrap;">
            ${!isMaster ? `
              <button onclick="window.openSendApkModal('${u.phone || ''}', '${encodeURIComponent(u.display_name || u.displayName || u.username)}', '${u.username}')" title="Send Official Android APK to ${u.username}" style="background:#f59e0b;color:#0f172a;border:0;padding:4px 8px;border-radius:6px;font-size:11px;font-weight:800;cursor:pointer;white-space:nowrap;display:inline-flex;align-items:center;gap:3px;">
                📲 Send APK
              </button>
              <button onclick="window.shareUserCredentialsOnWhatsApp('${u.username}', '${encodeURIComponent(u.display_name || u.displayName || '')}', '${u.phone || ''}', '${encodeURIComponent(u.shop_name || u.shopName || '')}')" title="Send Login to Client WhatsApp" style="background:#16a34a;color:#fff;border:0;padding:4px 8px;border-radius:6px;font-size:11px;font-weight:bold;cursor:pointer;">
                📲 WA
              </button>
              <button onclick="window.extendUserExpiryAction('${u.id}', '${u.username}')" title="Validity Badhayein" style="background:#7c3aed;color:#fff;border:0;padding:4px 8px;border-radius:6px;font-size:11px;font-weight:bold;cursor:pointer;">
                ⏳ Extend
              </button>
              <button onclick="window.toggleUserStatusAction('${u.id}', '${u.status}')" style="background:${isBlocked ? '#059669' : '#dc2626'};color:#fff;border:0;padding:4px 8px;border-radius:6px;font-size:11px;font-weight:bold;cursor:pointer;">
                ${isBlocked ? '🟢 Unblock' : '🔒 Block'}
              </button>
              <button onclick="window.resetUserPasswordAction('${u.id}', '${u.username}')" style="background:#0284c7;color:#fff;border:0;padding:4px 8px;border-radius:6px;font-size:11px;font-weight:bold;cursor:pointer;">
                🔑 Reset
              </button>
              <button onclick="window.deleteUserAction('${u.id}', '${u.username}')" style="background:#334155;color:#fca5a5;border:0;padding:4px 8px;border-radius:6px;font-size:11px;font-weight:bold;cursor:pointer;">
                🗑️
              </button>
            ` : '<span style="color:#38bdf8;font-size:11px;font-weight:bold;">👑 Master Admin</span>'}
          </div>
        </td>
      </tr>`;
    }).join('');
  }

  window.loadAdminUsersList = async function () {
    const localUsers = getLocalUsers();
    renderUsersTable(localUsers);

    try {
      const res = await fetch(getApiBase() + '/api/admin/users', {
        headers: { 'x-admin-key': currentAdminPin || 'muzammil786' },
      });
      if (res.ok) {
        const data = await res.json();
        if (data.success && Array.isArray(data.users)) {
          const deletedUsers = getDeletedUsers();
          const map = new Map();
          localUsers.forEach(u => map.set(String(u.username).toLowerCase(), u));
          data.users.forEach(serverUser => {
            const uKey = String(serverUser.username).toLowerCase();
            if (deletedUsers.includes(uKey)) return; // DO NOT RESTORE DELETED USER!
            const existing = map.get(uKey);
            const preservedPass = (existing && existing.password) ? existing.password : (serverUser.role === 'admin' ? 'muzammil786' : '');
            map.set(uKey, {
              ...existing,
              ...serverUser,
              password: preservedPass
            });
          });
          const merged = Array.from(map.values()).filter(u => !deletedUsers.includes(String(u.username).toLowerCase()));
          saveLocalUsers(merged);
          renderUsersTable(merged);
        }
      }
    } catch (err) {
      console.warn('Server user sync deferred:', err);
    }
  };

  window.shareUserCredentialsOnWhatsApp = function (username, encName, phone, encShop, password) {
    const name = decodeURIComponent(encName || '');
    const shop = decodeURIComponent(encShop || '');

    const localUsers = getLocalUsers();
    const matched = localUsers.find(u => String(u.username).toLowerCase() === String(username).toLowerCase());
    const plainPass = password || (matched ? matched.password : '') || '';
    const actToken = window.generateActivationToken(matched || { username, displayName: name, phone, shopName: shop, role: 'operator' }, plainPass);

    let msg = `*Muzammil Online Service - Operator Mobile Login* 🔐\n\n` +
      `Namaste *${name || username}* ji,\n` +
      `Aapka Online Service Software Account activate ho chuka hai! ✅\n\n` +
      `👤 *Login Username:* ${username}\n`;
    if (plainPass) {
      msg += `🔑 *Login Password:* ${plainPass}\n`;
    }
    if (shop) {
      msg += `🏪 *Shop Name:* ${shop}\n`;
    }
    if (actToken) {
      msg += `\n🔐 *Quick Activation Code:*\n\`${actToken}\`\n`;
    }
    msg += `\n📲 *App Me Login Karne Ka Tareeqa:*\n` +
      `1️⃣ Imran bhai ne WhatsApp par jo *Muzammil_Online_Service_v98.apk* bheji hai, usko apne phone me Install karein.\n` +
      `2️⃣ App open karke apna *Username* aur *Password* daalein, ya "📲 WhatsApp Code se Login" par tap karke upar ka Activation Code paste karein.\n` +
      `3️⃣ Login karte hi bina kisi error ke turant aapka software shuru ho jayega! (Multi-Phone Live Sync v98.0)\n\n` +
      `📞 *Owner & Master Admin:* Imran Khan (+91 9561460313)`;

    const cleanPhone = (phone || '').replace(/[^0-9]/g, '');

    // 1. Native Android App Bridge
    if (window.AndroidDownload && typeof window.AndroidDownload.openWhatsAppText === 'function') {
      window.AndroidDownload.openWhatsAppText(cleanPhone, msg);
      return;
    }

    // 2. Copy to clipboard automatically
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(msg);
      }
    } catch (e) {}

    // 3. Web Share API (native share on mobile browsers)
    if (navigator.share) {
      navigator.share({
        title: 'Muzammil Online Service Login Details',
        text: msg
      }).then(() => {
        showToast('Login details WhatsApp par share ho gayi!', 'success');
      }).catch(() => {
        window.openCredentialsFallbackModal(msg, cleanPhone);
      });
      return;
    }

    window.openCredentialsFallbackModal(msg, cleanPhone);
  };

  window.openCredentialsFallbackModal = function (msg, cleanPhone) {
    let modal = document.getElementById('mosCredentialsModal');
    if (!modal) {
      modal = document.createElement('div');
      modal.id = 'mosCredentialsModal';
      modal.style.cssText = 'position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.85);z-index:999999;display:flex;align-items:center;justify-content:center;padding:16px;box-sizing:border-box;backdrop-filter:blur(4px);';
      document.body.appendChild(modal);
    }

    const waLink = cleanPhone.length >= 10
      ? `https://api.whatsapp.com/send?phone=91${cleanPhone.slice(-10)}&text=${encodeURIComponent(msg)}`
      : `https://api.whatsapp.com/send?text=${encodeURIComponent(msg)}`;

    modal.innerHTML = `
      <div style="background:#1e293b;border:1px solid #38bdf8;border-radius:18px;max-width:440px;width:100%;padding:20px;color:#fff;box-sizing:border-box;box-shadow:0 10px 30px rgba(0,0,0,0.5);">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;">
          <h3 style="margin:0;font-size:16px;color:#38bdf8;display:flex;align-items:center;gap:8px;">
            <span>📋</span> Client Login Details
          </h3>
          <button onclick="document.getElementById('mosCredentialsModal').style.display='none'" style="background:none;border:0;color:#94a3b8;font-size:20px;cursor:pointer;">✕</button>
        </div>
        <p style="font-size:12px;color:#94a3b8;margin:0 0 10px;line-height:1.4;">
          Yeh details clipboard me copy ho gayi hain. Aap direct WhatsApp par paste kar sakte hain ya neeche diye gaye button par tap karein:
        </p>
        <textarea readonly style="width:100%;height:130px;box-sizing:border-box;background:#0f172a;border:1px solid #475569;border-radius:10px;padding:10px;color:#e2e8f0;font-size:11.5px;font-family:monospace;resize:none;outline:none;">${msg}</textarea>
        <div style="margin-top:14px;display:flex;gap:10px;flex-wrap:wrap;">
          <a href="${waLink}" target="_blank" rel="noopener noreferrer" style="flex:1;background:#22c55e;color:#fff;text-decoration:none;padding:11px;border-radius:10px;font-weight:bold;font-size:13px;text-align:center;display:flex;align-items:center;justify-content:center;gap:6px;">
            <span>📲</span> Open WhatsApp
          </a>
          <button onclick="navigator.clipboard.writeText(${JSON.stringify(msg)});showToast('Details Copy Ho Gayi!','success');" style="background:#0284c7;color:#fff;border:0;padding:11px 16px;border-radius:10px;font-weight:bold;font-size:13px;cursor:pointer;">
            📋 Copy Text
          </button>
        </div>
      </div>
    `;
    modal.style.display = 'flex';
  };
  window.handleCreateUserForm = async function (e) {
    if (e && e.preventDefault) e.preventDefault();
    const displayName = (document.getElementById('newUserDisplayName')?.value || '').trim();
    const username = (document.getElementById('newUsername')?.value || '').trim();
    const password = document.getElementById('newUserPassword')?.value || '';
    const phone = (document.getElementById('newUserPhone')?.value || '').trim();
    const shopName = (document.getElementById('newUserShop')?.value || '').trim();
    const role = document.getElementById('newUserRole')?.value || 'operator';
    const expiryPlan = document.getElementById('newUserExpiryPlan')?.value || '30';

    if (!displayName || !username || !password) {
      showToast('Name, username aur password sab zaroori hain!', 'error');
      return;
    }

    let expireDays = 0;
    let expireMinutes = 0;
    let expiresAt = null;

    if (role === 'admin' || expiryPlan === 'lifetime') {
      expiresAt = null;
    } else if (expiryPlan === '10m' || expiryPlan === '10min' || expiryPlan === '10') {
      const d = new Date();
      d.setMinutes(d.getMinutes() + 10);
      expiresAt = d.toISOString();
      expireMinutes = 10;
    } else {
      expireDays = Number(expiryPlan) || 30;
      const d = new Date();
      d.setDate(d.getDate() + expireDays);
      expiresAt = d.toISOString();
    }

    // Instantly save in local storage & render
    const localUsers = getLocalUsers();
    const existingIdx = localUsers.findIndex(u => String(u.username).toLowerCase() === username.toLowerCase());

    const newUserObj = {
      id: Date.now(),
      uid: 'usr_' + username.toLowerCase() + '_' + Date.now().toString(36),
      displayName: displayName,
      username: username,
      password: password,
      phone: phone,
      shopName: shopName,
      role: role,
      status: 'active',
      expires_at: expiresAt,
      created_at: new Date().toISOString()
    };

    if (existingIdx >= 0) {
      localUsers[existingIdx] = { ...localUsers[existingIdx], ...newUserObj };
    } else {
      localUsers.push(newUserObj);
    }

    saveLocalUsers(localUsers);
    renderUsersTable(localUsers);

    // ⚡ Realtime Cloud Sync: Push to Firebase Firestore instantly so other phones can login!
    if (window.MosFirebase && typeof window.MosFirebase.saveUser === 'function') {
      window.MosFirebase.saveUser(newUserObj);
    }

    showToast(`🎉 User @${username} safalta se ban gaya! Doosre phone me foran chalega.`, 'success');

    const wantShare = confirm(`User @${username} create ho gaya hai!\n\nKya aap client ko WhatsApp par Login ID aur Password bhejna chahte hain?`);
    if (wantShare) {
      window.shareUserCredentialsOnWhatsApp(username, encodeURIComponent(displayName), phone, encodeURIComponent(shopName), password);
    }

    ['newUserDisplayName', 'newUsername', 'newUserPassword', 'newUserPhone', 'newUserShop'].forEach(id => {
      const el = document.getElementById(id);
      if (el) el.value = '';
    });

    try {
      fetch(getApiBase() + '/api/admin/users/create', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-admin-key': currentAdminPin || 'muzammil786',
        },
        body: JSON.stringify({ displayName, username, password, phone, shopName, role, expireDays, expireMinutes, expireDate: expiresAt }),
      }).then(r => r.json()).then(data => {
        if (data.success && data.user) {
          console.log('User synced to server:', data.user.username);
        }
      }).catch(err => {
        console.warn('Cloud sync queued:', err);
      });
    } catch (err) {}
  };

  window.extendUserExpiryAction = async function (id, username) {
    const daysStr = prompt(`@${username} ki validity kitni badhana chahte hain?\n(e.g. 10m = 10 Minute Demo, 1 = 1 Din, 30 = 1 Mahina, 90 = 3 Mahine, 365 = 1 Saal, 0 = Lifetime No Expiry):`, '10m');
    if (daysStr === null) return;
    const cleanInput = daysStr.trim().toLowerCase();

    const users = getLocalUsers();
    const u = users.find(x => String(x.id) === String(id) || String(x.username).toLowerCase() === String(username).toLowerCase());
    if (u) {
      let newExp = null;
      let expireMinutes = 0;
      let expireDays = 0;

      if (cleanInput === '0' || cleanInput === 'lifetime') {
        newExp = null;
      } else if (cleanInput === '10m' || cleanInput === '10min' || cleanInput === '10') {
        const base = new Date();
        base.setMinutes(base.getMinutes() + 10);
        newExp = base.toISOString();
        expireMinutes = 10;
      } else {
        const days = parseInt(cleanInput, 10);
        if (isNaN(days)) {
          alert('Kripya sahi number ya "10m" daalein.');
          return;
        }
        const currentExp = u.expires_at ? new Date(u.expires_at) : new Date();
        const base = currentExp.getTime() > Date.now() ? currentExp : new Date();
        base.setDate(base.getDate() + days);
        newExp = base.toISOString();
        expireDays = days;
      }

      u.expires_at = newExp;
      saveLocalUsers(users);
      renderUsersTable(users);
      if (window.MosFirebase && typeof window.MosFirebase.saveUser === 'function') {
        window.MosFirebase.saveUser({ username: u.username, expires_at: newExp });
      }
      showToast(`@${username} ki validity update ho gayi!`, 'success');

      try {
        fetch(getApiBase() + '/api/admin/users/update-expiry', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-admin-key': currentAdminPin || 'muzammil786',
          },
          body: JSON.stringify({
            id,
            expireDate: newExp,
            expireMinutes,
            expireDays,
            removeExpiry: newExp === null,
          }),
        }).catch(() => {});
      } catch (e) {}
    }
  };

  window.toggleUserStatusAction = async function (id, currentStatus) {
    const newStatus = currentStatus === 'active' ? 'blocked' : 'active';
    const actionText = newStatus === 'blocked' ? 'block' : 'unblock';
    if (!confirm(`Kya aap is user ko ${actionText} karna chahte hain?`)) return;

    const users = getLocalUsers();
    const u = users.find(x => String(x.id) === String(id) || String(x.username).toLowerCase() === String(id).toLowerCase());
    if (u) {
      u.status = newStatus;
      saveLocalUsers(users);
      renderUsersTable(users);
      if (window.MosFirebase && typeof window.MosFirebase.saveUser === 'function') {
        window.MosFirebase.saveUser({ username: u.username, status: newStatus });
      }
      showToast(`User ${actionText} ho gaya! Doosre phone se foran kickout ho jayega.`, 'success');
    }

    try {
      fetch(getApiBase() + '/api/admin/users/toggle-status', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-admin-key': currentAdminPin || 'muzammil786',
        },
        body: JSON.stringify({ id, status: newStatus }),
      }).catch(() => {});
    } catch (err) {}
  };

  window.resetUserPasswordAction = async function (id, username) {
    const newPass = prompt(`@${username} ke liye naya password darj karein (minimum 4 characters):`);
    if (!newPass) return;
    if (newPass.length < 4) {
      alert('Password kam se kam 4 characters ka hona chahiye.');
      return;
    }

    const users = getLocalUsers();
    const u = users.find(x => String(x.id) === String(id) || String(x.username).toLowerCase() === String(username).toLowerCase());
    if (u) {
      u.password = newPass;
      saveLocalUsers(users);
      if (window.MosFirebase && typeof window.MosFirebase.saveUser === 'function') {
        window.MosFirebase.saveUser({ username: u.username, password: newPass, passwordPlain: newPass });
      }
      showToast(`@${username} ka password reset ho gaya!`, 'success');
    }

    try {
      fetch(getApiBase() + '/api/admin/users/reset-password', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-admin-key': currentAdminPin || 'muzammil786',
        },
        body: JSON.stringify({ id, newPassword: newPass }),
      }).catch(() => {});
    } catch (err) {}
  };

  window.deleteUserAction = async function (id, username) {
    const cleanUser = String(username || '').trim().toLowerCase();
    if (cleanUser === 'admin' || cleanUser === 'imran') {
      showToast('Master Admin delete nahi ho sakta!', 'error');
      return;
    }
    if (!confirm(`Kya aap sach me @${username} ko delete karna chahte hain? Ye action wapas nahi ho sakta.`)) return;

    // 1. Mark as deleted in localStorage so BUILTIN_REGISTERED_USERS never revives this user!
    addDeletedUser(username);

    // 2. Realtime Delete from Firebase Firestore! (Kicks out other phone instantly in < 1 second!)
    if (window.MosFirebase && typeof window.MosFirebase.deleteUser === 'function') {
      window.MosFirebase.deleteUser(cleanUser);
    }

    // 3. Filter from local users and save
    let users = getLocalUsers();
    users = users.filter(x => String(x.id) !== String(id) && String(x.username).toLowerCase() !== cleanUser);
    saveLocalUsers(users);
    renderUsersTable(users);
    showToast(`User @${username} safalta se delete ho gaya! Doosre phone se foran logout ho jayega.`, 'success');

    // 3. Delete from backend server & PostgreSQL Cloud SQL
    try {
      fetch(getApiBase() + '/api/admin/users/delete', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-admin-key': currentAdminPin || 'muzammil786',
        },
        body: JSON.stringify({ id, username }),
      }).then(r => r.json()).then(data => {
        if (data && data.success) {
          console.log(`User ${username} deleted from database and files.`);
        }
      }).catch(() => {});
    } catch (err) {}
  };
  window.closeAdminLicensePanel = function (e) {
    if (e && e.stopPropagation) e.stopPropagation();
    const el = document.getElementById('mosAdminPanelModal');
    if (el) {
      el.classList.add('hidden');
      el.style.setProperty('display', 'none', 'important');
    }
  };

  window.loadAdminLicensesList = async function () {
    const listContainer = document.getElementById('adminLicTableBody');
    if (!listContainer) return;
    listContainer.innerHTML = '<tr><td colspan="6" style="text-align:center;padding:16px;">Loading licenses from Cloud SQL...</td></tr>';

    try {
      const res = await fetch(getApiBase() + '/api/license/list', {
        headers: { 'x-admin-key': currentAdminPin || 'muzammil786' },
      });
      const data = await res.json();
      if (!data.success) {
        listContainer.innerHTML = `<tr><td colspan="6" style="color:red;padding:16px;">${data.error || 'Failed to load'}</td></tr>`;
        return;
      }

      if (data.licenses.length === 0) {
        listContainer.innerHTML = '<tr><td colspan="6" style="text-align:center;padding:16px;color:#94a3b8;">No licenses created yet.</td></tr>';
        return;
      }

      listContainer.innerHTML = data.licenses.map(lic => {
        const isExp = lic.expiresAt && new Date(lic.expiresAt) < new Date();
        const statusBadge = lic.status === 'revoked'
          ? '<span style="color:#ef4444;font-weight:700;">Revoked</span>'
          : isExp
          ? '<span style="color:#f59e0b;font-weight:700;">Expired</span>'
          : '<span style="color:#10b981;font-weight:700;">Active</span>';

        const expText = lic.expiresAt ? new Date(lic.expiresAt).toLocaleDateString('en-IN') : 'Lifetime';

        return `<tr style="border-bottom:1px solid #334155;">
          <td style="padding:10px;font-family:monospace;font-weight:bold;color:#38bdf8;">
            ${lic.licenseKey}
            <button style="margin-left:6px;font-size:11px;background:#1e293b;border:1px solid #475569;color:#fff;border-radius:4px;padding:2px 6px;cursor:pointer;" onclick="navigator.clipboard.writeText('${lic.licenseKey}');showToast('Key copied!','success');">Copy</button>
          </td>
          <td style="padding:10px;">${lic.clientName} <br><small style="color:#94a3b8;">${lic.shopName || ''} (${lic.clientPhone || 'No Phone'})</small></td>
          <td style="padding:10px;"><span style="text-transform:uppercase;background:#1e293b;padding:3px 8px;border-radius:6px;font-size:12px;">${lic.plan}</span></td>
          <td style="padding:10px;">${statusBadge}</td>
          <td style="padding:10px;font-size:12px;">${expText}</td>
          <td style="padding:10px;">
            ${lic.status === 'active' 
              ? `<button style="background:#ef4444;color:#fff;border:0;padding:4px 8px;border-radius:6px;font-size:11px;cursor:pointer;" onclick="window.toggleLicenseState(${lic.id}, 'revoked')">Block</button>`
              : `<button style="background:#10b981;color:#fff;border:0;padding:4px 8px;border-radius:6px;font-size:11px;cursor:pointer;" onclick="window.toggleLicenseState(${lic.id}, 'active')">Activate</button>`
            }
          </td>
        </tr>`;
      }).join('');
    } catch (err) {
      listContainer.innerHTML = '<tr><td colspan="6" style="color:red;padding:16px;">Server network error.</td></tr>';
    }
  };

  window.toggleLicenseState = async function (id, newStatus) {
    try {
      const res = await fetch(getApiBase() + '/api/license/status', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-admin-key': currentAdminPin || 'muzammil786',
        },
        body: JSON.stringify({ id, status: newStatus }),
      });
      const data = await res.json();
      if (data.success) {
        showToast('License status updated!', 'success');
        window.loadAdminLicensesList();
      } else {
        showToast(data.error || 'Failed to update', 'error');
      }
    } catch (e) {
      showToast('Failed to connect to server', 'error');
    }
  };

  window.handleCreateLicenseForm = async function (e) {
    if (e && e.preventDefault) e.preventDefault();
    const name = document.getElementById('newLicName')?.value;
    const phone = document.getElementById('newLicPhone')?.value;
    const shop = document.getElementById('newLicShop')?.value;
    const plan = document.getElementById('newLicPlan')?.value || 'monthly';
    const days = document.getElementById('newLicDays')?.value || 30;

    if (!name) {
      showToast('Customer Name zaroori hai.', 'error');
      return;
    }

    try {
      const res = await fetch(getApiBase() + '/api/license/create', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-admin-key': currentAdminPin || 'muzammil786',
        },
        body: JSON.stringify({
          clientName: name,
          clientPhone: phone,
          shopName: shop,
          plan: plan,
          days: Number(days),
        }),
      });

      const data = await res.json();
      if (data.success) {
        showToast('🎉 Nayi License Key generate ho gayi!', 'success');
        const resultBox = document.getElementById('adminGeneratedKeyResult');
        if (resultBox) {
          resultBox.style.display = 'block';
          resultBox.innerHTML = `
            <div style="background:#0f172a;border:1px solid #10b981;border-radius:8px;padding:12px;margin-top:10px;">
              <div style="font-size:12px;color:#94a3b8;">Generated License Key (Share with Customer):</div>
              <div style="font-size:18px;font-family:monospace;font-weight:bold;color:#38bdf8;margin:6px 0;">${data.license.licenseKey}</div>
              <div style="font-size:12px;color:#cbd5e1;">Plan: <b>${data.license.plan.toUpperCase()}</b> | Client: <b>${data.license.clientName}</b></div>
              <button style="margin-top:8px;background:#25d366;color:#fff;border:0;padding:6px 12px;border-radius:6px;font-size:12px;font-weight:bold;cursor:pointer;" onclick="window.shareLicenseOnWhatsApp('${encodeURIComponent(data.license.clientPhone || '')}', '${data.license.licenseKey}', '${encodeURIComponent(data.license.clientName)}')">📲 WhatsApp Par Share Karein</button>
            </div>
          `;
        }
        window.loadAdminLicensesList();
      } else {
        showToast(data.error || 'License generation failed', 'error');
      }
    } catch (err) {
      showToast('Server error while creating license', 'error');
    }
  };

  window.shareLicenseOnWhatsApp = function (phone, key, name) {
    const text = `Namaskar ${decodeURIComponent(name)} ji! Aapka Muzammil Online Service app ka official License Key ready hai:%0A%0A🔑 *License Key:* ${key}%0A%0AApp me '🔑 License' par jakar ye key paste karein aur 'Activate' dabayein.%0AHelpline: +91 95614 60313`;
    const url = phone ? `https://wa.me/${phone.replace(/[^0-9]/g, '')}?text=${text}` : `https://wa.me/?text=${text}`;
    window.open(url, '_blank');
  };

  // ==========================================
  // DYNAMIC SERVICES & SCHEMES MANAGEMENT (CLOUD SQL + LOCAL)
  // ==========================================
  // ==========================================
  // BULLETPROOF DYNAMIC SECTIONS & SERVICES ENGINE
  // ==========================================
  const defaultMasterSections = [
    { id: 'central', title: 'Central Government Schemes', icon: '📋', is_default: true, description: 'Central Govt schemes & subsidies' },
    { id: 'state', title: 'Maharashtra Schemes', icon: '📋', is_default: true, description: 'Maharashtra State portals & yojanas' },
    { id: 'partner', title: 'Partner / BC Services', icon: '🤝', is_default: true, description: 'Spice Money, PayNearby & BC Banking' },
    { id: 'essential', title: 'Citizen & Digital Portals', icon: '🪪', is_default: true, description: 'Aadhaar, PAN, Voter, Ration & DL' }
  ];

  window.getLocalSections = function () {
    try {
      const raw = localStorage.getItem('mos_custom_sections');
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed) && parsed.length > 0) {
          // Merge to ensure system sections always exist
          const merged = [...defaultMasterSections];
          parsed.forEach(p => {
            if (!merged.find(m => m.id === p.id)) {
              merged.push(p);
            }
          });
          return merged;
        }
      }
    } catch (e) {}
    return defaultMasterSections;
  };

  window.saveLocalSections = function (sections) {
    localStorage.setItem('mos_custom_sections', JSON.stringify(sections || []));
  };

  window.toggleAddSectionForm = function (forceState) {
    const wrap = document.getElementById('adminAddSectionFormWrap');
    const btn = document.getElementById('toggleSectionFormBtn');
    if (!wrap) return;
    const isHidden = typeof forceState === 'boolean' ? !forceState : (wrap.style.display === 'none' || !wrap.style.display);
    wrap.style.display = isHidden ? 'block' : 'none';
    if (btn) {
      btn.innerHTML = isHidden ? '✕ Close Section Form' : '<span>➕</span> Naya Section Banayein';
      btn.style.background = isHidden ? '#475569' : '#0284c7';
    }
    if (isHidden) {
      const input = document.getElementById('newSecTitle');
      if (input) input.focus();
    }
  };

  window.fillSectionPreset = function (title, icon, desc) {
    const titleEl = document.getElementById('newSecTitle');
    const iconEl = document.getElementById('newSecIcon');
    const descEl = document.getElementById('newSecDesc');
    if (titleEl) titleEl.value = title || '';
    if (iconEl) iconEl.value = icon || '📁';
    if (descEl) descEl.value = desc || '';
    showToast('Section preset loaded! "Save Section" par click karein.', 'info');
  };

  window.handleCreateSectionForm = async function (e) {
    if (e && e.preventDefault) e.preventDefault();
    const title = (document.getElementById('newSecTitle')?.value || '').trim();
    const icon = (document.getElementById('newSecIcon')?.value || '📁').trim();
    const desc = (document.getElementById('newSecDesc')?.value || '').trim();

    if (!title) {
      showToast('Section ka naam zaroori hai!', 'error');
      return;
    }

    const secId = 'sec_' + (title.toLowerCase().replace(/[^a-z0-9]/g, '_') || Date.now());
    let currentSections = window.getLocalSections();
    const existingIdx = currentSections.findIndex(s => s.id === secId || s.title.toLowerCase() === title.toLowerCase());

    const newSec = {
      id: existingIdx >= 0 ? currentSections[existingIdx].id : secId,
      title: title,
      icon: icon,
      description: desc,
      is_default: false,
      created_at: new Date().toISOString()
    };

    if (existingIdx >= 0) {
      currentSections[existingIdx] = { ...currentSections[existingIdx], ...newSec };
      showToast(`Section "${title}" update ho gaya!`, 'success');
    } else {
      currentSections.push(newSec);
      showToast(`🎉 Naya Section "${title}" create ho gaya!`, 'success');
    }

    window.saveLocalSections(currentSections);
    window.toggleAddSectionForm(false);
    
    // Clear inputs
    const titleEl = document.getElementById('newSecTitle');
    if (titleEl) titleEl.value = '';
    const descEl = document.getElementById('newSecDesc');
    if (descEl) descEl.value = '';

    // Reload UI
    await window.loadAdminSectionsList();
    window.quickAddServiceToSection(newSec.id, newSec.title);

    // Sync to Cloud SQL PostgreSQL
    try {
      fetch(getApiBase() + '/api/admin/sections/create', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-admin-key': currentAdminPin || 'muzammil786',
        },
        body: JSON.stringify(newSec),
      }).catch(() => {});
    } catch (err) {}
  };

  window.deleteSectionAction = async function (id, title) {
    const cleanTitle = decodeURIComponent(title || id);
    if (['central', 'state', 'partner', 'essential'].includes(id)) {
      showToast('System default section ko delete nahi kiya ja sakta.', 'error');
      return;
    }

    let services = JSON.parse(localStorage.getItem('mos_custom_services') || '[]');
    const count = services.filter(s => s.section === id).length;

    let deleteServicesToo = false;
    if (count > 0) {
      const choice = confirm(`Section "${cleanTitle}" mein ${count} services hain.\n\nOK dabayein: Section aur uske andar ki saari ${count} services delete ho jayengi.\nCancel dabayein: Action cancel karein.`);
      if (!choice) return;
      deleteServicesToo = true;
    } else {
      if (!confirm(`Kya aap section "${cleanTitle}" ko delete karna chahte hain?`)) return;
    }

    let sections = window.getLocalSections().filter(s => s.id !== id);
    window.saveLocalSections(sections);

    if (deleteServicesToo) {
      services = services.filter(s => s.section !== id);
      localStorage.setItem('mos_custom_services', JSON.stringify(services));
    }

    showToast(`Section "${cleanTitle}" delete ho gaya!`, 'info');
    await window.loadAdminSectionsList();
    window.loadAdminServicesList();
    if (typeof window.renderDashboardServices === 'function') {
      window.renderDashboardServices();
    }

    try {
      fetch(getApiBase() + '/api/admin/sections/delete', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-admin-key': currentAdminPin || 'muzammil786',
        },
        body: JSON.stringify({ id, deleteServices: deleteServicesToo }),
      }).catch(() => {});
    } catch (err) {}
  };

  window.quickAddServiceToSection = function (id, title) {
    const secSelect = document.getElementById('newServiceSection');
    const custWrap = document.getElementById('newServiceCustomSectionWrap');
    if (secSelect) {
      secSelect.value = id;
      if (custWrap) custWrap.style.display = 'none';
    }
    const form = document.getElementById('adminServiceForm');
    if (form) form.scrollIntoView({ behavior: 'smooth', block: 'center' });
    const titleInput = document.getElementById('newServiceTitle');
    if (titleInput) titleInput.focus();
    showToast(`Section "${title || id}" chuna gaya! Ab service details bharein.`, 'info');
  };

  window.toggleCustomSectionInput = function (val) {
    const wrap = document.getElementById('newServiceCustomSectionWrap');
    const titleInput = document.getElementById('newServiceCustomTitle');
    if (val === 'custom_new') {
      if (wrap) wrap.style.display = 'block';
      if (titleInput) titleInput.focus();
    } else {
      if (wrap) wrap.style.display = 'none';
    }
  };

  window.fillServicePreset = function (title, url, icon, section, customOrDesc, optDesc) {
    const titleEl = document.getElementById('newServiceTitle');
    const urlEl = document.getElementById('newServiceUrl');
    const iconEl = document.getElementById('newServiceIcon');
    const secEl = document.getElementById('newServiceSection');
    const descEl = document.getElementById('newServiceDesc');
    const custWrap = document.getElementById('newServiceCustomSectionWrap');
    const custTitle = document.getElementById('newServiceCustomTitle');

    if (titleEl) titleEl.value = title || '';
    if (urlEl) urlEl.value = url || '';
    if (iconEl) iconEl.value = icon || '🌐';
    if (secEl) {
      secEl.value = section || 'central';
      if (section === 'custom_new') {
        if (custWrap) custWrap.style.display = 'block';
        if (custTitle) custTitle.value = customOrDesc || '';
        if (descEl) descEl.value = optDesc || 'Official portal';
      } else {
        if (custWrap) custWrap.style.display = 'none';
        if (descEl) descEl.value = customOrDesc || 'Official portal';
      }
    }
    const form = document.getElementById('adminServiceForm');
    if (form) form.scrollIntoView({ behavior: 'smooth', block: 'center' });
    showToast('Preset loaded! Aap "Add Service" par click karein.', 'info');
  };

  window.loadAdminSectionsList = async function () {
    const badgeContainer = document.getElementById('adminSectionsBadgeContainer');
    const secSelect = document.getElementById('newServiceSection');
    const filterSelect = document.getElementById('adminServicesFilterSection');

    let sections = window.getLocalSections();
    try {
      const res = await fetch(getApiBase() + '/api/admin/sections', {
        headers: { 'x-admin-key': currentAdminPin || 'muzammil786' },
      });
      const data = await res.json();
      if (data && data.success && Array.isArray(data.sections) && data.sections.length > 0) {
        sections = data.sections;
        window.saveLocalSections(sections);
      }
    } catch (e) {}

    window.__cachedAdminSections = sections;
    const services = window.__cachedAdminServices || JSON.parse(localStorage.getItem('mos_custom_services') || '[]');

    // 1. Render Badges
    if (badgeContainer) {
      badgeContainer.innerHTML = sections.map(sec => {
        const count = services.filter(s => s.section === sec.id).length;
        const isCustom = !sec.is_default && !['central', 'state', 'partner', 'essential'].includes(sec.id);
        const bgColor = sec.id === 'central' ? '#0369a1' : sec.id === 'state' ? '#4338ca' : sec.id === 'partner' ? '#065f46' : isCustom ? '#713f12' : '#334155';
        const borderColor = sec.id === 'central' ? '#38bdf8' : sec.id === 'state' ? '#818cf8' : sec.id === 'partner' ? '#34d399' : isCustom ? '#facc15' : '#64748b';

        return `<div style="background:${bgColor}22;border:1px solid ${borderColor};border-radius:10px;padding:6px 10px;display:flex;align-items:center;gap:8px;">
          <span style="font-size:16px;">${sec.icon || '📁'}</span>
          <div>
            <div style="font-weight:700;font-size:12px;color:#f8fafc;">${sec.title}</div>
            <div style="font-size:10px;color:#94a3b8;">${count} services</div>
          </div>
          <div style="display:flex;gap:4px;margin-left:6px;">
            <button type="button" onclick="quickAddServiceToSection('${sec.id}', '${encodeURIComponent(sec.title)}')" style="background:${borderColor};color:#0f172a;border:0;border-radius:6px;padding:3px 7px;font-size:10.5px;font-weight:700;cursor:pointer;" title="Add service to ${sec.title}">
              ➕ Add
            </button>
            ${isCustom ? `<button type="button" onclick="deleteSectionAction('${sec.id}', '${encodeURIComponent(sec.title)}')" style="background:#7f1d1d;color:#fca5a5;border:0;border-radius:6px;padding:3px 6px;font-size:10px;cursor:pointer;" title="Delete section">🗑️</button>` : ''}
          </div>
        </div>`;
      }).join('');
    }

    // 2. Populate newServiceSection dropdown
    if (secSelect) {
      const curVal = secSelect.value;
      let optHtml = '';
      sections.forEach(sec => {
        optHtml += `<option value="${sec.id}">${sec.icon || '📁'} ${sec.title}</option>`;
      });
      optHtml += `<option value="custom_new">➕ Naya Custom Section Banayein...</option>`;
      secSelect.innerHTML = optHtml;
      if (curVal && (sections.some(s => s.id === curVal) || curVal === 'custom_new')) {
        secSelect.value = curVal;
      }
    }

    // 3. Populate adminServicesFilterSection dropdown
    if (filterSelect) {
      const curFilter = filterSelect.value;
      let filterHtml = `<option value="all">All Sections (${services.length})</option>`;
      sections.forEach(sec => {
        const cnt = services.filter(s => s.section === sec.id).length;
        filterHtml += `<option value="${sec.id}">${sec.icon || '📁'} ${sec.title} (${cnt})</option>`;
      });
      filterHtml += `<option value="custom">All Custom Sections</option>`;
      filterSelect.innerHTML = filterHtml;
      if (curFilter) filterSelect.value = curFilter;
    }
  };

  window.loadAdminServicesList = async function () {
    const tbody = document.getElementById('adminServicesTableBody');
    const countLabel = document.getElementById('adminServicesCountLabel');
    if (!tbody) return;

    tbody.innerHTML = '<tr><td colspan="5" style="text-align:center;padding:16px;color:#94a3b8;">Loading services from Cloud SQL...</td></tr>';

    let services = [];
    try {
      const res = await fetch(getApiBase() + '/api/admin/services', {
        headers: { 'x-admin-key': currentAdminPin || 'muzammil786' },
      });
      const data = await res.json();
      if (data.success && Array.isArray(data.services)) {
        services = data.services;
        localStorage.setItem('mos_custom_services', JSON.stringify(services));
      } else {
        services = JSON.parse(localStorage.getItem('mos_custom_services') || '[]');
      }
    } catch (e) {
      services = JSON.parse(localStorage.getItem('mos_custom_services') || '[]');
    }

    window.__cachedAdminServices = services;
    await window.loadAdminSectionsList();
    renderAdminServicesRows(services);

    if (countLabel) {
      countLabel.textContent = `${services.length} services configured across all sections`;
    }

    if (typeof window.renderDashboardServices === 'function') {
      window.renderDashboardServices();
    }
  };

  function renderAdminServicesRows(services) {
    const tbody = document.getElementById('adminServicesTableBody');
    if (!tbody) return;

    if (!services || services.length === 0) {
      tbody.innerHTML = '<tr><td colspan="5" style="text-align:center;padding:18px;color:#94a3b8;">Koi custom service add nahi hai. Upar diye gaye form se naya service ya scheme add karein!</td></tr>';
      return;
    }

    const secFilter = document.getElementById('adminServicesFilterSection')?.value || 'all';
    const filtered = services.filter(s => {
      if (secFilter === 'all') return true;
      if (secFilter === 'custom') return s.section !== 'central' && s.section !== 'state' && s.section !== 'partner' && s.section !== 'essential';
      return s.section === secFilter;
    });

    if (filtered.length === 0) {
      tbody.innerHTML = `<tr><td colspan="5" style="text-align:center;padding:18px;color:#94a3b8;">Is section mein koi service nahi mili.</td></tr>`;
      return;
    }

    const sections = window.__cachedAdminSections || window.getLocalSections();

    tbody.innerHTML = filtered.map(s => {
      const foundSec = sections.find(sec => sec.id === s.section);
      const secName = foundSec ? (foundSec.icon ? foundSec.icon + ' ' : '') + foundSec.title : (s.section_title || s.section);
      const isCustomSec = !['central', 'state', 'partner', 'essential'].includes(s.section);

      const secBadge = s.section === 'central'
        ? '<span style="background:#0369a1;color:#e0f2fe;padding:2px 8px;border-radius:6px;font-size:11px;font-weight:700;">Central</span>'
        : s.section === 'state'
        ? '<span style="background:#4338ca;color:#e0e7ff;padding:2px 8px;border-radius:6px;font-size:11px;font-weight:700;">Maharashtra</span>'
        : s.section === 'partner'
        ? '<span style="background:#065f46;color:#a7f3d0;padding:2px 8px;border-radius:6px;font-size:11px;font-weight:700;">Partner</span>'
        : s.section === 'essential'
        ? '<span style="background:#334155;color:#f8fafc;padding:2px 8px;border-radius:6px;font-size:11px;font-weight:700;">Citizen & Digital</span>'
        : `<span style="background:#713f12;color:#fef08a;padding:2px 8px;border-radius:6px;font-size:11px;font-weight:700;">${secName}</span>`;

      const statusBadge = s.is_active !== false
        ? '<span style="background:#065f46;color:#6ee7b7;padding:2px 7px;border-radius:99px;font-size:11px;font-weight:700;">Active</span>'
        : '<span style="background:#7f1d1d;color:#fca5a5;padding:2px 7px;border-radius:99px;font-size:11px;font-weight:700;">Hidden</span>';

      return `<tr style="border-bottom:1px solid #334155;">
        <td style="padding:10px;">
          <div style="font-weight:bold;color:#f8fafc;display:flex;align-items:center;gap:6px;">
            <span style="font-size:18px;">${s.icon || '🌐'}</span>
            <span>${s.title}</span>
          </div>
          <div style="font-size:11px;color:#94a3b8;margin-left:24px;">${s.description || 'Official portal'}</div>
        </td>
        <td style="padding:10px;">${secBadge}</td>
        <td style="padding:10px;">
          <a href="${s.url}" target="_blank" rel="noopener noreferrer" style="color:#38bdf8;font-size:11.5px;text-decoration:none;display:inline-flex;align-items:center;gap:4px;max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">
            🔗 Open Link
          </a>
        </td>
        <td style="padding:10px;">${statusBadge}</td>
        <td style="padding:10px;text-align:right;">
          <div style="display:flex;gap:6px;justify-content:flex-end;">
            <button onclick="window.toggleServiceAction('${s.id}', ${s.is_active !== false})" style="background:#1e293b;border:1px solid #475569;color:${s.is_active !== false ? '#f87171' : '#4ade80'};padding:4px 8px;border-radius:6px;font-size:11px;cursor:pointer;" title="Hide or show service on home">
              ${s.is_active !== false ? 'Hide' : 'Show'}
            </button>
            <button onclick="window.editServiceAction('${s.id}')" style="background:#1e293b;border:1px solid #0284c7;color:#38bdf8;padding:4px 8px;border-radius:6px;font-size:11px;cursor:pointer;">
              ✏️ Edit
            </button>
            <button onclick="window.deleteServiceAction('${s.id}', '${encodeURIComponent(s.title)}')" style="background:#7f1d1d;border:0;color:#fff;padding:4px 8px;border-radius:6px;font-size:11px;cursor:pointer;">
              🗑️
            </button>
          </div>
        </td>
      </tr>`;
    }).join('');
  }

  window.filterAdminServicesTable = function () {
    renderAdminServicesRows(window.__cachedAdminServices || []);
  };

  window.handleCreateServiceForm = async function (e) {
    if (e && e.preventDefault) e.preventDefault();

    const editId = document.getElementById('serviceEditId')?.value;
    const title = (document.getElementById('newServiceTitle')?.value || '').trim();
    const url = (document.getElementById('newServiceUrl')?.value || '').trim();
    const icon = (document.getElementById('newServiceIcon')?.value || '🌐').trim();
    const sectionRaw = document.getElementById('newServiceSection')?.value || 'central';
    const customTitle = (document.getElementById('newServiceCustomTitle')?.value || '').trim();
    const desc = (document.getElementById('newServiceDesc')?.value || 'Official portal').trim();

    if (!title || !url) {
      showToast('Title aur Official Portal URL zaroori hain!', 'error');
      return;
    }

    let finalSection = sectionRaw;
    let finalSectionTitle = null;

    const sections = window.__cachedAdminSections || window.getLocalSections();

    if (sectionRaw === 'custom_new') {
      finalSection = 'sec_' + (customTitle.toLowerCase().replace(/[^a-z0-9]/g, '_') || Date.now());
      finalSectionTitle = customTitle || 'Custom Services';

      // Also register this new section in sections list
      if (!sections.some(s => s.id === finalSection)) {
        const newSecObj = {
          id: finalSection,
          title: finalSectionTitle,
          icon: icon || '📁',
          description: '',
          is_default: false,
          created_at: new Date().toISOString()
        };
        sections.push(newSecObj);
        window.saveLocalSections(sections);
        try {
          fetch(getApiBase() + '/api/admin/sections/create', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'x-admin-key': currentAdminPin || 'muzammil786',
            },
            body: JSON.stringify(newSecObj),
          }).catch(() => {});
        } catch (err) {}
      }
    } else {
      const match = sections.find(s => s.id === sectionRaw);
      if (match) {
        finalSection = match.id;
        finalSectionTitle = match.title;
      }
    }

    let localList = JSON.parse(localStorage.getItem('mos_custom_services') || '[]');

    if (editId) {
      // Update Mode
      const idx = localList.findIndex(x => String(x.id) === String(editId));
      if (idx >= 0) {
        localList[idx] = {
          ...localList[idx],
          title,
          url,
          icon,
          section: finalSection,
          section_title: finalSectionTitle,
          description: desc,
          updated_at: new Date().toISOString()
        };
      }
      localStorage.setItem('mos_custom_services', JSON.stringify(localList));
      showToast(`✅ Service "${title}" update ho gayi!`, 'success');

      try {
        fetch(getApiBase() + '/api/admin/services/update', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-admin-key': currentAdminPin || 'muzammil786',
          },
          body: JSON.stringify({
            id: editId,
            title,
            url,
            icon,
            section: finalSection,
            sectionTitle: finalSectionTitle,
            description: desc,
          }),
        }).catch(() => {});
      } catch (err) {}
    } else {
      // Create Mode
      const newService = {
        id: 'srv_' + Date.now(),
        title,
        url,
        icon,
        section: finalSection,
        section_title: finalSectionTitle,
        description: desc,
        sort_order: localList.length + 1,
        is_active: true,
        created_at: new Date().toISOString()
      };
      localList.push(newService);
      localStorage.setItem('mos_custom_services', JSON.stringify(localList));
      showToast(`🎉 Nayi Service "${title}" add ho gayi!`, 'success');

      try {
        fetch(getApiBase() + '/api/admin/services/create', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-admin-key': currentAdminPin || 'muzammil786',
          },
          body: JSON.stringify({
            title,
            url,
            icon,
            section: finalSection,
            sectionTitle: finalSectionTitle,
            description: desc,
            sortOrder: localList.length,
          }),
        }).catch(() => {});
      } catch (err) {}
    }

    window.cancelEditServiceForm();
    window.loadAdminServicesList();
    if (typeof window.renderDashboardServices === 'function') {
      window.renderDashboardServices();
    }
  };

  window.editServiceAction = function (id) {
    const list = window.__cachedAdminServices || JSON.parse(localStorage.getItem('mos_custom_services') || '[]');
    const s = list.find(x => String(x.id) === String(id));
    if (!s) return;

    const editIdEl = document.getElementById('serviceEditId');
    const titleEl = document.getElementById('newServiceTitle');
    const urlEl = document.getElementById('newServiceUrl');
    const iconEl = document.getElementById('newServiceIcon');
    const secEl = document.getElementById('newServiceSection');
    const custWrap = document.getElementById('newServiceCustomSectionWrap');
    const custTitle = document.getElementById('newServiceCustomTitle');
    const descEl = document.getElementById('newServiceDesc');
    const formTitle = document.getElementById('adminServiceFormTitle');
    const submitBtn = document.getElementById('adminServiceSubmitBtn');
    const cancelBtn = document.getElementById('adminServiceCancelEditBtn');

    if (editIdEl) editIdEl.value = s.id;
    if (titleEl) titleEl.value = s.title || '';
    if (urlEl) urlEl.value = s.url || '';
    if (iconEl) iconEl.value = s.icon || '🌐';
    if (descEl) descEl.value = s.description || 'Official portal';

    if (secEl) {
      const sections = window.__cachedAdminSections || window.getLocalSections();
      if (sections.some(x => x.id === s.section)) {
        secEl.value = s.section;
        if (custWrap) custWrap.style.display = 'none';
      } else {
        secEl.value = 'custom_new';
        if (custWrap) custWrap.style.display = 'block';
        if (custTitle) custTitle.value = s.section_title || s.section || '';
      }
    }

    if (formTitle) formTitle.textContent = `✏️ Edit Service: ${s.title}`;
    if (submitBtn) submitBtn.textContent = '💾 Update Service (Save)';
    if (cancelBtn) cancelBtn.style.display = 'inline-block';

    const form = document.getElementById('adminServiceForm');
    if (form) form.scrollIntoView({ behavior: 'smooth', block: 'center' });
  };

  window.cancelEditServiceForm = function () {
    const editIdEl = document.getElementById('serviceEditId');
    const titleEl = document.getElementById('newServiceTitle');
    const urlEl = document.getElementById('newServiceUrl');
    const iconEl = document.getElementById('newServiceIcon');
    const secEl = document.getElementById('newServiceSection');
    const custWrap = document.getElementById('newServiceCustomSectionWrap');
    const custTitle = document.getElementById('newServiceCustomTitle');
    const descEl = document.getElementById('newServiceDesc');
    const formTitle = document.getElementById('adminServiceFormTitle');
    const submitBtn = document.getElementById('adminServiceSubmitBtn');
    const cancelBtn = document.getElementById('adminServiceCancelEditBtn');

    if (editIdEl) editIdEl.value = '';
    if (titleEl) titleEl.value = '';
    if (urlEl) urlEl.value = '';
    if (iconEl) iconEl.value = '🌐';
    if (descEl) descEl.value = 'Official portal';
    if (secEl) secEl.value = 'central';
    if (custWrap) custWrap.style.display = 'none';
    if (custTitle) custTitle.value = '';

    if (formTitle) formTitle.textContent = '➕ Nayi Service / Scheme Add Karein:';
    if (submitBtn) submitBtn.textContent = '⚡ Add Service (Save to Cloud SQL)';
    if (cancelBtn) cancelBtn.style.display = 'none';
  };

  window.toggleServiceAction = async function (id, currentActive) {
    let list = JSON.parse(localStorage.getItem('mos_custom_services') || '[]');
    const idx = list.findIndex(x => String(x.id) === String(id));
    const newStatus = !currentActive;
    if (idx >= 0) {
      list[idx].is_active = newStatus;
      localStorage.setItem('mos_custom_services', JSON.stringify(list));
    }
    showToast(`Service status updated: ${newStatus ? 'Active' : 'Hidden'}`, 'info');
    window.loadAdminServicesList();
    if (typeof window.renderDashboardServices === 'function') {
      window.renderDashboardServices();
    }

    try {
      fetch(getApiBase() + '/api/admin/services/toggle', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-admin-key': currentAdminPin || 'muzammil786',
        },
        body: JSON.stringify({ id, isActive: newStatus }),
      }).catch(() => {});
    } catch (err) {}
  };

  window.deleteServiceAction = async function (id, title) {
    const cleanTitle = decodeURIComponent(title || '');
    if (!confirm(`Kya aap sach me service "${cleanTitle}" ko delete karna chahte hain?`)) return;

    let list = JSON.parse(localStorage.getItem('mos_custom_services') || '[]');
    list = list.filter(x => String(x.id) !== String(id));
    localStorage.setItem('mos_custom_services', JSON.stringify(list));

    showToast(`Service "${cleanTitle}" delete ho gayi!`, 'success');
    window.loadAdminServicesList();
    if (typeof window.renderDashboardServices === 'function') {
      window.renderDashboardServices();
    }

    try {
      fetch(getApiBase() + '/api/admin/services/delete', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-admin-key': currentAdminPin || 'muzammil786',
        },
        body: JSON.stringify({ id }),
      }).catch(() => {});
    } catch (err) {}
  };

  window.syncServicesFromServer = async function () {
    try {
      const [srvRes, secRes] = await Promise.all([
        fetch(getApiBase() + '/api/services').catch(() => null),
        fetch(getApiBase() + '/api/sections').catch(() => null)
      ]);
      if (srvRes && srvRes.ok) {
        const data = await srvRes.json();
        if (data && data.success && Array.isArray(data.services) && data.services.length > 0) {
          localStorage.setItem('mos_custom_services', JSON.stringify(data.services));
        }
      }
      if (secRes && secRes.ok) {
        const secData = await secRes.json();
        if (secData && secData.success && Array.isArray(secData.sections) && secData.sections.length > 0) {
          localStorage.setItem('mos_custom_sections', JSON.stringify(secData.sections));
        }
      }
      if (typeof window.renderDashboardServices === 'function') {
        window.renderDashboardServices();
      }
    } catch (e) {}
  };

  // Universal Cloud Server Sync (Cloud SQL PostgreSQL Asia)
  window.CloudServerSync = {
    isSyncing: false,
    lastSynced: null,
    syncTimer: null,

    // Debounced auto-save to cloud server
    scheduleAutoSave: function (delay = 1200) {
      if (this.syncTimer) clearTimeout(this.syncTimer);
      this.updateStatusUI('saving');
      this.syncTimer = setTimeout(() => {
        this.pushToServer(false);
      }, delay);
    },

    // Push local operator records to Cloud SQL PostgreSQL
    pushToServer: async function (notify = false) {
      if (this.isSyncing) return;
      this.isSyncing = true;
      this.updateStatusUI('saving');

      try {
        const records = {
          mos_bills: localStorage.getItem('mos_bills') || '[]',
          mos_customers: localStorage.getItem('mos_customers') || '[]',
          mos_cv_draft: localStorage.getItem('mos_cv_draft') || '{}',
          mos_audit_log: localStorage.getItem('mos_audit_log') || '[]',
          mos_downloads_history: localStorage.getItem('mos_downloads_history') || '[]',
        };

        const res = await fetch(getApiBase() + '/api/sync/push', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            userUid: 'operator_default',
            records: records,
          }),
        });

        const data = await res.json();
        if (data.success) {
          this.lastSynced = new Date();
          this.updateStatusUI('synced');
          if (notify) showToast('✅ Data Cloud Server par safalta se save ho gaya!', 'success');
        } else {
          this.updateStatusUI('error');
        }
      } catch (err) {
        console.warn('Cloud SQL sync error:', err);
        this.updateStatusUI('offline');
      } finally {
        this.isSyncing = false;
      }
    },

    // Pull saved operator records from Cloud SQL PostgreSQL
    pullFromServer: async function (silent = false) {
      try {
        this.updateStatusUI('syncing');
        const res = await fetch(getApiBase() + '/api/sync/pull?userUid=operator_default');
        const data = await res.json();

        if (data.success && data.records) {
          let hasUpdated = false;

          // Sync Bills
          if (data.records.mos_bills && data.records.mos_bills !== '[]') {
            const serverBills =
              typeof data.records.mos_bills === 'string'
                ? JSON.parse(data.records.mos_bills)
                : data.records.mos_bills;
            if (Array.isArray(serverBills) && serverBills.length > 0) {
              const localBills = JSON.parse(localStorage.getItem('mos_bills') || '[]');
              const billMap = new Map();
              serverBills.forEach((b) => billMap.set(Number(b.id), b));
              localBills.forEach((b) => billMap.set(Number(b.id), b));
              const mergedBills = Array.from(billMap.values()).sort(
                (a, b) => Number(b.id || 0) - Number(a.id || 0)
              );
              localStorage.setItem('mos_bills', JSON.stringify(mergedBills));
              hasUpdated = true;
            }
          }

          // Sync Customers
          if (data.records.mos_customers && data.records.mos_customers !== '[]') {
            const serverCust =
              typeof data.records.mos_customers === 'string'
                ? JSON.parse(data.records.mos_customers)
                : data.records.mos_customers;
            if (Array.isArray(serverCust) && serverCust.length > 0) {
              const localCust = JSON.parse(localStorage.getItem('mos_customers') || '[]');
              const custMap = new Map();
              serverCust.forEach((c) => custMap.set(String(c.mobile || c.id), c));
              localCust.forEach((c) => custMap.set(String(c.mobile || c.id), c));
              localStorage.setItem('mos_customers', JSON.stringify(Array.from(custMap.values())));
              hasUpdated = true;
            }
          }

          // Sync CV Draft
          if (data.records.mos_cv_draft) {
            const draft =
              typeof data.records.mos_cv_draft === 'string'
                ? data.records.mos_cv_draft
                : JSON.stringify(data.records.mos_cv_draft);
            if (draft && draft !== '{}' && !localStorage.getItem('mos_cv_draft')) {
              localStorage.setItem('mos_cv_draft', draft);
              hasUpdated = true;
            }
          }

          this.lastSynced = new Date();
          this.updateStatusUI('synced');

          if (hasUpdated) {
            if (typeof window.renderBills === 'function') window.renderBills();
            if (typeof window.renderCustomers === 'function') window.renderCustomers();
          }
          if (!silent) showToast('Cloud SQL Database se latest data load ho gaya.', 'success');
        } else {
          this.updateStatusUI('synced');
        }
      } catch (err) {
        console.warn('Pull from Cloud SQL error:', err);
        this.updateStatusUI('synced');
      }
    },

    updateStatusUI: function (status) {
      const textEl = document.getElementById('cloudSyncStatusText');
      const dotEl = document.getElementById('cloudPulseDot');
      const btnEl = document.getElementById('cloudSyncBtn');
      if (!textEl || !dotEl) return;

      if (status === 'saving' || status === 'syncing') {
        textEl.textContent = 'Server par save ho raha hai...';
        dotEl.style.background = '#f59e0b';
        dotEl.style.boxShadow = '0 0 8px #f59e0b';
        if (btnEl) btnEl.textContent = '⏳ Saving...';
      } else if (status === 'synced') {
        textEl.textContent = 'Server storage connected & synced (PostgreSQL Cloud SQL Asia)';
        dotEl.style.background = '#4ade80';
        dotEl.style.boxShadow = '0 0 8px #4ade80';
        if (btnEl) btnEl.textContent = '✓ Synced';
      } else if (status === 'offline' || status === 'error') {
        textEl.textContent = 'Saved locally (Server connecting...)';
        dotEl.style.background = '#ef4444';
        dotEl.style.boxShadow = '0 0 8px #ef4444';
        if (btnEl) btnEl.textContent = '🔄 Retry';
      }
    },
  };

  window.triggerManualSync = function () {
    if (window.CloudServerSync) {
      window.CloudServerSync.pushToServer(true);
    }
  };

  // Live Database Inspector Controls
  window.openDatabaseInspector = function () {
    if (!isUserAdmin(window.currentUser)) {
      showToast('Access Denied: Server Database sirf Master Admin ke liye accessible hai.', 'error');
      const el = document.getElementById('mosDbInspectorModal');
      if (el) {
        el.classList.add('hidden');
        el.style.setProperty('display', 'none', 'important');
      }
      return;
    }
    const el = document.getElementById('mosDbInspectorModal');
    if (el) {
      el.classList.remove('hidden');
      el.style.setProperty('display', 'flex', 'important');
      window.loadDatabaseInspectorData();
    }
  };

  window.closeDatabaseInspector = function (e) {
    if (e && e.stopPropagation) e.stopPropagation();
    const el = document.getElementById('mosDbInspectorModal');
    if (el) {
      el.classList.add('hidden');
      el.style.setProperty('display', 'none', 'important');
    }
  };

  window.switchInspectorTab = function (tabId) {
    const tabs = ['bills', 'cust', 'store', 'cv', 'cloud'];
    tabs.forEach((t) => {
      const content = document.getElementById('inspTabContent' + t.charAt(0).toUpperCase() + t.slice(1));
      const btn = document.getElementById('tabBtn' + t.charAt(0).toUpperCase() + t.slice(1));
      if (content) content.style.display = t === tabId ? 'block' : 'none';
      if (btn) {
        btn.style.background = t === tabId ? '#38bdf8' : '#1e293b';
        btn.style.color = t === tabId ? '#0f172a' : '#cbd5e1';
      }
    });
  };

  window.loadDatabaseInspectorData = async function () {
    try {
      const res = await fetch(getApiBase() + '/api/server/database-overview');
      const data = await res.json();
      if (!data.success) {
        showToast('Server database load nahi hua: ' + (data.error || ''), 'error');
        return;
      }

      // Populate Stats
      const statBills = document.getElementById('inspectorStatBills');
      const statCust = document.getElementById('inspectorStatCust');
      const statCv = document.getElementById('inspectorStatCv');
      const statStore = document.getElementById('inspectorStatStore');
      const statLic = document.getElementById('inspectorStatLic');

      if (statBills) statBills.textContent = data.tables?.receipts?.count ?? 0;
      if (statCust) statCust.textContent = data.tables?.customers?.count ?? 0;
      if (statCv) statCv.textContent = data.tables?.cv_drafts?.count ?? 0;
      if (statStore) statStore.textContent = data.tables?.app_store?.count ?? 0;
      if (statLic) statLic.textContent = data.tables?.licenses?.count ?? 0;

      // Populate Bills Table
      const billsBody = document.getElementById('inspTableBillsBody');
      if (billsBody) {
        const bills = data.tables?.receipts?.rows || [];
        if (bills.length === 0) {
          billsBody.innerHTML =
            '<tr><td colspan="7" style="text-align:center;padding:16px;color:#94a3b8;">Koi alag receipt table me nahi hai. Bills `app_store` me live synced hain!</td></tr>';
        } else {
          billsBody.innerHTML = bills
            .map(
              (b) => `
            <tr style="border-bottom:1px solid #334155;">
              <td style="padding:8px 10px;font-family:monospace;color:#38bdf8;">#${b.billNo || b.id}</td>
              <td style="padding:8px 10px;font-weight:bold;">${b.customerName || '-'}</td>
              <td style="padding:8px 10px;color:#94a3b8;">${b.customerMobile || '-'}</td>
              <td style="padding:8px 10px;">${b.serviceName || '-'}</td>
              <td style="padding:8px 10px;color:#34d399;font-weight:bold;">₹${b.amount || 0}</td>
              <td style="padding:8px 10px;"><span style="background:${
                b.status === 'completed' || b.status === 'Paid' ? '#065f46' : '#92400e'
              };color:#fff;padding:2px 6px;border-radius:4px;font-size:11px;">${b.status || 'Pending'}</span></td>
              <td style="padding:8px 10px;color:#94a3b8;font-size:11px;">${
                b.date || (b.createdAt ? new Date(b.createdAt).toLocaleDateString() : '-')
              }</td>
            </tr>
          `
            )
            .join('');
        }
      }

      // Populate Customers Table
      const custBody = document.getElementById('inspTableCustBody');
      if (custBody) {
        const custs = data.tables?.customers?.rows || [];
        if (custs.length === 0) {
          custBody.innerHTML =
            '<tr><td colspan="6" style="text-align:center;padding:16px;color:#94a3b8;">No direct customer rows in table. Check Synced Cloud Payloads tab.</td></tr>';
        } else {
          custBody.innerHTML = custs
            .map(
              (c) => `
            <tr style="border-bottom:1px solid #334155;">
              <td style="padding:8px 10px;font-family:monospace;color:#94a3b8;">#${c.id}</td>
              <td style="padding:8px 10px;font-weight:bold;color:#f8fafc;">${c.name}</td>
              <td style="padding:8px 10px;color:#38bdf8;">${c.mobile || '-'}</td>
              <td style="padding:8px 10px;color:#cbd5e1;">${c.address || '-'}</td>
              <td style="padding:8px 10px;color:#34d399;font-weight:bold;">₹${c.totalSpend || 0}</td>
              <td style="padding:8px 10px;color:#94a3b8;font-size:11px;">${
                c.createdAt ? new Date(c.createdAt).toLocaleDateString() : '-'
              }</td>
            </tr>
          `
            )
            .join('');
        }
      }

      // Populate App Store Key-Value view
      const storeBody = document.getElementById('inspTableStoreBody');
      if (storeBody) {
        const storeRows = data.tables?.app_store?.rows || [];
        if (storeRows.length === 0) {
          storeBody.textContent =
            'app_store table is currently empty. Click "Force Full Push" to sync local data right now.';
        } else {
          storeBody.innerHTML = storeRows
            .map((r) => {
              let summary = r.payload;
              try {
                const parsed = JSON.parse(r.payload);
                if (Array.isArray(parsed)) {
                  summary =
                    `[Array of ${parsed.length} items]\n` +
                    JSON.stringify(parsed.slice(0, 3), null, 2) +
                    (parsed.length > 3 ? `\n... (+${parsed.length - 3} more items)` : '');
                } else if (typeof parsed === 'object') {
                  summary = JSON.stringify(parsed, null, 2);
                }
              } catch (e) {}
              return `// Table: app_store | Key: "${r.storeKey}" | Updated: ${new Date(
                r.updatedAt
              ).toLocaleString()}\n${summary}\n\n`;
            })
            .join('');
        }
      }

      // Populate CV Drafts
      const cvBody = document.getElementById('inspTableCvBody');
      if (cvBody) {
        const cvRows = data.tables?.cv_drafts?.rows || [];
        if (cvRows.length === 0) {
          cvBody.innerHTML =
            '<tr><td colspan="4" style="text-align:center;padding:16px;color:#94a3b8;">No CV drafts stored yet in cv_drafts table.</td></tr>';
        } else {
          cvBody.innerHTML = cvRows
            .map(
              (cv) => `
            <tr style="border-bottom:1px solid #334155;">
              <td style="padding:8px 10px;font-family:monospace;color:#94a3b8;">#${cv.id}</td>
              <td style="padding:8px 10px;font-weight:bold;color:#f8fafc;">${cv.title || 'Untitled CV'}</td>
              <td style="padding:8px 10px;color:#94a3b8;font-size:11px;">${
                cv.updatedAt ? new Date(cv.updatedAt).toLocaleString() : '-'
              }</td>
              <td style="padding:8px 10px;color:#38bdf8;">${
                cv.dataJson ? Math.round(cv.dataJson.length / 1024) + ' KB' : '0 KB'
              }</td>
            </tr>
          `
            )
            .join('');
        }
      }

      showToast('Live Cloud SQL Database loaded successfully!', 'success');
    } catch (err) {
      console.error('Inspector error:', err);
      showToast('Server inspection request failed', 'error');
    }
  };

  // Role-based UI visibility: Master Admin vs Normal User / Operator
  window.applyUserRoleUI = function (user) {
    if (typeof window.checkStaffExpiryAlert === 'function') window.checkStaffExpiryAlert(user);
    const isAdmin = isUserAdmin(user);
    if (isAdmin) {
      document.body.classList.add('is-master-admin');
    } else {
      document.body.classList.remove('is-master-admin');
      const adminModal = document.getElementById('mosAdminPanelModal');
      if (adminModal) {
        adminModal.classList.add('hidden');
        adminModal.style.setProperty('display', 'none', 'important');
      }
      const dbModal = document.getElementById('mosDbInspectorModal');
      if (dbModal) {
        dbModal.classList.add('hidden');
        dbModal.style.setProperty('display', 'none', 'important');
      }
    }

    const adminElements = document.querySelectorAll('.mos-admin-only');
    adminElements.forEach((el) => {
      if (isAdmin) {
        if (el.classList.contains('sideItem')) {
          el.style.display = 'flex';
        } else if (el.tagName === 'BUTTON') {
          el.style.display = 'inline-flex';
        } else if (el.id === 'mosServerSyncBanner') {
          el.style.display = 'flex';
        } else {
          el.style.display = 'block';
        }
      } else {
        el.style.display = 'none';
      }
    });

    const nameEl = document.getElementById('loggedUserName');
    const dotEl = document.getElementById('userStatusDot');
    const headerLoginBtn = document.getElementById('mosHeaderLoginBtn');
    const userBadge = document.getElementById('mosUserHeaderBadge');
    const sideLoginBtn = document.getElementById('mosSideLoginBtn');
    const sideLogoutBtn = document.getElementById('mosSideLogoutBtn');

    const sideCard = document.getElementById('sideProfileCard');
    const sideAvatar = document.getElementById('sideProfileAvatar');
    const sideName = document.getElementById('sideProfileName');
    const sideBadge = document.getElementById('sideProfileRoleBadge');
    const sideShop = document.getElementById('sideProfileShop');
    const sideStatus = document.getElementById('sideProfileStatusText');
    const sideExp = document.getElementById('sideProfileValidityText');

    const homeBar = document.getElementById('homeProfileBar');
    const homeLoggedOut = document.getElementById('homeLoggedOutBar');
    const homeAvatar = document.getElementById('homeProfileAvatar');
    const homeName = document.getElementById('homeProfileName');
    const homeSub = document.getElementById('homeProfileSub');
    const homeAdminBtn = document.getElementById('homeAdminControlBtn');

    if (user) {
      const uName = user.displayName || user.username || 'User';
      const uShop = user.shopName || (isAdmin ? 'Head Office' : 'Muzammil Online Service Branch');
      const isLiveActive = user.status !== 'blocked';

      if (sideCard) {
        sideCard.style.display = 'block';
        if (sideName) sideName.textContent = uName;
        if (sideShop) sideShop.textContent = '🏪 ' + uShop;
        if (sideAvatar) sideAvatar.textContent = isAdmin ? '👑' : '👤';
        if (sideBadge) {
          if (isAdmin) {
            sideBadge.textContent = '👑 MASTER ADMIN';
            sideBadge.style.background = 'linear-gradient(135deg,#f59e0b,#d97706)';
          } else {
            sideBadge.textContent = '👤 OPERATOR';
            sideBadge.style.background = '#2563eb';
          }
        }
        if (sideStatus) {
          sideStatus.textContent = isLiveActive ? 'Active' : 'Blocked';
          sideStatus.style.color = isLiveActive ? '#4ade80' : '#ef4444';
        }
        if (sideExp) {
          if (isAdmin || (!user.expiresAt && !user.expires_at)) {
            sideExp.textContent = 'Lifetime Access';
          } else {
            const d = new Date(user.expiresAt || user.expires_at);
            sideExp.textContent = 'Valid till: ' + d.toLocaleDateString('en-IN');
          }
        }
      }

      // Single dedicated Login / Profile spot on Home Screen
      if (homeBar) {
        homeBar.style.display = 'flex';
        if (homeName) homeName.textContent = (isAdmin ? '👑 ' : '👤 ') + uName;
        if (homeAvatar) homeAvatar.textContent = isAdmin ? '👑' : '👤';
        if (homeSub) {
          homeSub.innerHTML = `${uShop} &bull; <b style="color:${isLiveActive ? '#10b981' : '#ef4444'}">${isLiveActive ? 'Active' : 'Blocked'}</b>`;
        }
      }
      if (homeLoggedOut) homeLoggedOut.style.display = 'none';
      if (homeAdminBtn) {
        homeAdminBtn.style.display = isAdmin ? 'inline-flex' : 'none';
      }

      if (headerLoginBtn) headerLoginBtn.style.display = 'none';
      if (userBadge) userBadge.style.display = 'none';
      if (sideLoginBtn) sideLoginBtn.style.display = 'none';
      if (sideLogoutBtn) {
        sideLogoutBtn.style.display = 'flex';
        sideLogoutBtn.style.opacity = '1';
      }
      if (nameEl) {
        if (isAdmin) {
          nameEl.textContent = '👑 ' + (user.displayName || user.username);
          nameEl.title = 'Master Admin & Owner (Full Control)';
          if (dotEl) dotEl.style.background = '#f59e0b';
        } else {
          nameEl.textContent = '👤 ' + (user.displayName || user.username);
          nameEl.title = user.shopName ? `Shop: ${user.shopName}` : 'Staff Operator';
          if (dotEl) dotEl.style.background = '#10b981';
        }
      }
    } else {
      if (sideCard) sideCard.style.display = 'none';
      if (homeBar) homeBar.style.display = 'none';
      if (homeLoggedOut) homeLoggedOut.style.display = 'flex';
      if (homeAdminBtn) homeAdminBtn.style.display = 'none';
      if (headerLoginBtn) headerLoginBtn.style.display = 'none';
      if (userBadge) userBadge.style.display = 'none';
      if (sideLogoutBtn) sideLogoutBtn.style.display = 'none';
      if (sideLoginBtn) {
        sideLoginBtn.style.display = 'flex';
        sideLoginBtn.innerHTML = '<span>🔐</span>Login';
        sideLoginBtn.style.opacity = '1';
      }
    }
  };

  window.mosQuickFill = function () {};
  window.switchLoginTab = function () {};

  window.handleMosRegister = async function (e) {
    if (e && e.preventDefault) e.preventDefault();
    const name = document.getElementById('mosRegName')?.value.trim();
    const shop = document.getElementById('mosRegShop')?.value.trim();
    const username = document.getElementById('mosRegUsername')?.value.trim();
    const phone = document.getElementById('mosRegPhone')?.value.trim();
    const password = document.getElementById('mosRegPassword')?.value;
    const err = document.getElementById('mosRegErrorMsg');
    const btn = document.getElementById('mosRegSubmitBtn');

    if (!name || !username || !password) {
      if (err) {
        err.textContent = 'Kripya sabhi zaroori fields bharein.';
        err.style.display = 'block';
      }
      return;
    }

    if (btn) {
      btn.disabled = true;
      btn.textContent = 'Creating Account in Cloud SQL...';
    }

    try {
      const res = await fetch(getApiBase() + '/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          displayName: name,
          shopName: shop,
          username,
          phone,
          password,
        }),
      });
      const data = await res.json();
      if (!data.success || !data.user) {
        throw new Error(data.error || 'Registration failed');
      }

      // Auto login with new user
      localStorage.setItem('mos_user_session', JSON.stringify(data.user));
      window.currentUser = data.user;
      const overlay = document.getElementById('mosAuthOverlay');
      if (overlay) overlay.style.display = 'none';
      const badge = document.getElementById('mosUserHeaderBadge');
      if (badge) badge.style.display = 'flex';
      window.applyUserRoleUI(data.user);
      showToast(`Account successfully ban gaya! Swagat hai, ${data.user.displayName}`, 'success');
    } catch (error) {
      if (err) {
        err.textContent = error.message || 'Registration me dikkat aayi.';
        err.style.display = 'block';
      }
    } finally {
      if (btn) {
        btn.disabled = false;
        btn.textContent = '✅ Naya Account Banayein & Login Karein';
      }
    }
  };

  window.openLoginModal = function () {
    const overlay = document.getElementById('mosAuthOverlay');
    const form = document.getElementById('mosLoginForm');
    if (overlay) overlay.style.display = 'flex';
    if (form) form.style.display = 'flex';
    const err = document.getElementById('mosLoginErrorMsg');
    if (err) err.style.display = 'none';
    const uIn = document.getElementById('mosLoginUsername');
    if (uIn) uIn.focus();
  };

  window.showLoginFormDirectly = function () {
    window.openLoginModal();
  };

  window.enterAppWithExistingSession = function () {
    const overlay = document.getElementById('mosAuthOverlay');
    if (overlay) overlay.style.display = 'none';
  };

  window.continueAsGuest = function () {
    window.openLoginModal();
  };

  window.checkAuthSession = async function () {
    const raw = localStorage.getItem('mos_user_session');
    const overlay = document.getElementById('mosAuthOverlay');
    const badge = document.getElementById('mosUserHeaderBadge');

    if (!raw) {
      const banner = document.getElementById('mosExpiryNoticeBanner');
      if (banner) banner.remove();
      if (overlay) overlay.style.setProperty('display', 'flex', 'important');
      if (badge) badge.style.setProperty('display', 'none', 'important');
      window.applyUserRoleUI(null);
      return false;
    }

    if (!window.verifyActiveUserAccess(true)) {
      return false;
    }

    try {
      const user = JSON.parse(raw);
      window.currentUser = user;
      window.applyUserRoleUI(user);
      if (overlay) overlay.style.display = 'none';
      if (badge) badge.style.display = 'flex';

      // 📡 Start Realtime Firestore Watcher immediately!
      if (user && user.username && typeof window.startRealtimeUserWatch === 'function') {
        window.startRealtimeUserWatch(user.username);
      }

      // Background verification with server
      fetch(getApiBase() + '/api/auth/verify-session', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: user.username, uid: user.uid }),
      })
        .then((r) => r.json())
        .then(async (res) => {
          if (!res.valid) {
            // Verify with Firebase Firestore Cloud before kicking user out!
            if (window.MosFirebase && typeof window.MosFirebase.getUser === 'function') {
              try {
                const cloudUser = await window.MosFirebase.getUser(user.username);
                if (cloudUser && cloudUser.status !== 'blocked') {
                  if (cloudUser.expiresAt && new Date(cloudUser.expiresAt).getTime() < Date.now()) {
                    window.forceReverseToLoginScreen('Aapka account expire ho chuka hai. Kripya Master Admin se contact karein.');
                  } else {
                    console.log('Session validated live via Firebase Firestore.');
                    return; // Retain active live session!
                  }
                }
              } catch (e) {}
            }
            window.forceReverseToLoginScreen(res.error || 'Aapka session expire ho gaya hai. Dobara login karein.');
          } else if (res.user) {
            if (isUserExpired(res.user)) {
              window.forceReverseToLoginScreen('Aapka account expire ho chuka hai. Kripya Master Admin se contact karein.');
            } else {
              localStorage.setItem('mos_user_session', JSON.stringify(res.user));
              window.currentUser = res.user;
              window.applyUserRoleUI(res.user);
            }
          }
        })
        .catch(() => {
          console.log('Server verify offline/unreachable - session remains active live.');
        });

      return true;
    } catch (e) {
      window.forceReverseToLoginScreen('Session invalid hai. Dobara login karein.');
      return false;
    }
  };

  window.handleMosLogin = async function (e) {
    if (e && e.preventDefault) e.preventDefault();
    const usernameInput = document.getElementById('mosLoginUsername');
    const passwordInput = document.getElementById('mosLoginPassword');
    const errorMsg = document.getElementById('mosLoginErrorMsg');
    const btn = document.getElementById('mosLoginSubmitBtn');

    const username = usernameInput ? usernameInput.value.trim() : '';
    const password = passwordInput ? passwordInput.value.trim() : '';

    if (!username || !password) {
      if (errorMsg) {
        errorMsg.textContent = 'Username aur Password dono zaroori hain!';
        errorMsg.style.display = 'block';
      }
      return;
    }

    if (errorMsg) errorMsg.style.display = 'none';
    if (btn) {
      btn.disabled = true;
      btn.textContent = '⏳ Verifying...';
    }

    const cleanUser = username.toLowerCase();
    const isMasterUser = cleanUser === 'admin' || cleanUser === 'imran';

    // 🔒 1. ABSOLUTE HARD STOP FOR MASTER ADMIN:
    if (isMasterUser) {
      if (password !== 'muzammil786') {
        if (btn) {
          btn.disabled = false;
          btn.textContent = '🔐 Login';
        }
        const err = '❌ Galat password! Kripya sahi password enter karein.';
        if (errorMsg) {
          errorMsg.textContent = err;
          errorMsg.style.display = 'block';
        }
        if (passwordInput) passwordInput.value = '';
        showToast(err, 'error');
        return;
      }
    }

    // Check if user entered WhatsApp Activation Code directly in username or password field
    if (username.startsWith('MOS-ACT-') || password.startsWith('MOS-ACT-')) {
      const tok = username.startsWith('MOS-ACT-') ? username : password;
      const ok = window.activateOperatorToken(tok);
      if (ok) {
        if (btn) { btn.disabled = false; btn.textContent = '🔐 Login'; }
        return;
      }
    }

    try {
      let serverResponse = null;

      // 1. Try server login first (with quick timeout for instant response)
      try {
        const ctrl = new AbortController();
        const tid = setTimeout(() => ctrl.abort(), 3500);
        const res = await fetch(getApiBase() + '/api/auth/login', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ username, password }),
          signal: ctrl.signal
        });
        clearTimeout(tid);
        if (res.ok) {
          const json = await res.json();
          if (json.success && json.user) {
            serverResponse = json.user;
          }
        }
      } catch (networkErr) {
        console.warn('Network offline / deferred server login:', networkErr);
      }

      let activeUser = serverResponse;

      // 2. Offline & local catalog check (instant for any registered operator)
      if (!activeUser) {
        if (isMasterUser) {
          if (password === 'muzammil786') {
            activeUser = {
              uid: 'admin_imran_master',
              username: 'imran',
              displayName: 'Imran Khan (Owner)',
              role: 'admin',
              status: 'active',
              shopName: 'Muzammil Online Service Head Office',
              expiresAt: null
            };
          } else {
            throw new Error('❌ Galat password! Kripya sahi password enter karein.');
          }
        } else {
          const localUsers = getLocalUsers();
          const cleanPhoneDigits = cleanUser.replace(/\D/g, '');
          let matched = localUsers.find(u => {
            const uName = String(u.username || '').toLowerCase();
            const uPhone = String(u.phone || '').trim();
            const uPhoneDigits = uPhone.replace(/\D/g, '');
            return uName === cleanUser || uPhone === cleanUser || (cleanPhoneDigits.length >= 10 && uPhoneDigits.endsWith(cleanPhoneDigits.slice(-10)));
          });

          // 🌐 AUTOMATIC REALTIME CLOUD CHECK (Direct from Firebase Firestore)
          if ((!matched || !checkUserPassword(password, matched)) && window.MosFirebase && typeof window.MosFirebase.getUser === 'function') {
            try {
              let cloudUser = await window.MosFirebase.getUser(cleanUser);
              if (!cloudUser && cleanPhoneDigits.length >= 10) {
                cloudUser = await window.MosFirebase.getUser(cleanPhoneDigits.slice(-10));
              }
              if (cloudUser && cloudUser.username) {
                console.log('✅ Operator found in Firebase Firestore Cloud:', cloudUser);
                matched = {
                  id: Date.now(),
                  uid: 'usr_' + cloudUser.username,
                  username: cloudUser.username,
                  displayName: cloudUser.displayName || cloudUser.username,
                  phone: cloudUser.phone || '',
                  shopName: cloudUser.shopName || '',
                  role: cloudUser.role || 'operator',
                  status: cloudUser.status || 'active',
                  password: cloudUser.passwordPlain || cloudUser.password || '',
                  passwordPlain: cloudUser.passwordPlain || cloudUser.password || '',
                  password_hash: cloudUser.passwordHash || cloudUser.password_hash || '',
                  expires_at: cloudUser.expiresAt || cloudUser.expires_at || null,
                  created_at: new Date().toISOString()
                };
                const existingIdx = localUsers.findIndex(u => String(u.username).toLowerCase() === String(matched.username).toLowerCase());
                if (existingIdx >= 0) {
                  localUsers[existingIdx] = { ...localUsers[existingIdx], ...matched };
                } else {
                  localUsers.push(matched);
                }
                saveLocalUsers(localUsers);
              }
            } catch (fbErr) {
              console.warn('Firebase login user fetch error:', fbErr);
            }
          }

          if (!matched) {
            throw new Error('User nahi mila! Kripya sahi username ya WhatsApp Activation Code daalein.');
          }

          // Check password using checkUserPassword (supports plaintext and SHA-256 hash)
          if (!checkUserPassword(password, matched)) {
            throw new Error('❌ Galat password! Operator ka sahi password darj karein.');
          }

          if (matched.status === 'blocked') {
            throw new Error('⛔ Aapka account admin dwara block kar diya gaya hai.');
          }

          if (matched.expires_at && new Date(matched.expires_at).getTime() < Date.now()) {
            throw new Error('⛔ Aapka account expire ho chuka hai! Master Admin Imran Khan (+91 9561460313) se contact karein.');
          }

          activeUser = {
            id: matched.id,
            uid: matched.uid || ('usr_' + matched.username),
            username: matched.username,
            displayName: matched.displayName || matched.display_name || matched.username,
            role: matched.role || 'operator',
            status: matched.status || 'active',
            shopName: matched.shopName || matched.shop_name || '',
            phone: matched.phone || '',
            expiresAt: matched.expires_at || null
          };
        }
      }

      if (!activeUser) {
        throw new Error('Login nahi ho saka. Kripya dobara koshish karein.');
      }

      // Check Expiration
      if (isUserExpired(activeUser)) {
        const expDate = activeUser.expiresAt || activeUser.expires_at ? new Date(activeUser.expiresAt || activeUser.expires_at).toLocaleDateString('en-IN') : '';
        window.forceReverseToLoginScreen(`⛔ Yeh account expire ho chuka hai (${expDate})! Kripya Master Admin Imran Khan (+91 9561460313) se validity renew karwayein.`);
        return;
      }

      // Successful Login
      localStorage.setItem('mos_user_session', JSON.stringify(activeUser));
      window.currentUser = activeUser;

      const overlay = document.getElementById('mosAuthOverlay');
      if (overlay) overlay.style.display = 'none';

      const badge = document.getElementById('mosUserHeaderBadge');
      if (badge) badge.style.display = 'flex';

      window.applyUserRoleUI(activeUser);

      showToast(`Swagat hai, ${activeUser.displayName || activeUser.username}!`, 'success');

      // 📡 Start Realtime Firestore Watcher on this phone immediately!
      if (typeof window.startRealtimeUserWatch === 'function') {
        window.startRealtimeUserWatch(activeUser.username);
      }

      if (typeof window.renderBills === 'function') window.renderBills();
      if (typeof window.renderCustomers === 'function') window.renderCustomers();

      if (window.CloudServerSync) {
        window.CloudServerSync.pullFromServer(true);
      }
    } catch (err) {
      console.error('Login error:', err);
      if (errorMsg) {
        errorMsg.textContent = err.message || 'Login nahi ho saka.';
        errorMsg.style.display = 'block';
      }
      showToast(err.message || 'Login failed', 'error');
    } finally {
      if (btn) {
        btn.disabled = false;
        btn.textContent = '🔐 Login';
      }
    }
  };
  window.mosLogout = function () {
    if (!confirm('Kya aap sach me logout karna chahte hain?')) return;
    localStorage.removeItem('mos_user_session');
    window.currentUser = null;
    window.applyUserRoleUI(null);

    const overlay = document.getElementById('mosAuthOverlay');
    const form = document.getElementById('mosLoginForm');
    if (overlay) overlay.style.display = 'flex';
    if (form) form.style.display = 'flex';

    const uInput = document.getElementById('mosLoginUsername');
    if (uInput) uInput.value = '';
    const passInput = document.getElementById('mosLoginPassword');
    if (passInput) passInput.value = '';
    const errorMsg = document.getElementById('mosLoginErrorMsg');
    if (errorMsg) errorMsg.style.display = 'none';

    const badge = document.getElementById('mosUserHeaderBadge');
    if (badge) badge.style.display = 'none';

    showToast('Aap successfully logout ho chuke hain.', 'success');
  };

  window.toggleLoginPasswordVisibility = function () {
    const input = document.getElementById('mosLoginPassword');
    if (!input) return;
    input.type = input.type === 'password' ? 'text' : 'password';
  };

  // ==========================================
  // ORIGINAL SOURCE CODE INSPECTOR & EXPLORER ENGINE
  // ==========================================
  let currentLoadedSourceCode = '';
  let currentLoadedFileKey = 'MainActivity.java';

  window.loadAdminSourceCode = async function () {
    await window.selectAdminSourceFile(currentLoadedFileKey || 'MainActivity.java');
  };

  window.selectAdminSourceFile = async function (fileKey) {
    currentLoadedFileKey = fileKey;
    const viewer = document.getElementById('adminSourceCodeViewer');
    const pathLabel = document.getElementById('adminSourceCodePathLabel');
    const statsLabel = document.getElementById('adminSourceCodeStats');
    const descLabel = document.getElementById('adminSourceCodeDescription');

    // Update tab styling
    const tabs = document.querySelectorAll('.srcFileTab');
    tabs.forEach(tab => {
      const isMatch = tab.id && tab.id.toLowerCase().includes(fileKey.split('.')[0].toLowerCase().replace(/[^a-z0-9]/g, ''));
      const textMatch = tab.textContent.toLowerCase().includes(fileKey.toLowerCase());
      if (isMatch || textMatch) {
        tab.style.background = '#38bdf8';
        tab.style.color = '#0f172a';
        tab.style.border = '1px solid #0284c7';
        tab.style.fontWeight = '800';
      } else {
        tab.style.background = '#0f172a';
        tab.style.color = '#cbd5e1';
        tab.style.border = '1px solid #334155';
        tab.style.fontWeight = '700';
      }
    });

    if (viewer) viewer.textContent = `⏳ Loading original source code for "${fileKey}" from server...`;
    if (statsLabel) statsLabel.textContent = 'Loading...';

    try {
      const res = await fetch(`${getApiBase()}/api/admin/source-code?file=${encodeURIComponent(fileKey)}`, {
        headers: { 'x-admin-key': currentAdminPin || 'muzammil786' }
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      if (!data.success) throw new Error(data.error || 'Server error');

      currentLoadedSourceCode = data.content;
      if (viewer) viewer.textContent = data.content;
      if (pathLabel) pathLabel.textContent = data.relativePath || fileKey;
      if (descLabel) descLabel.textContent = `ℹ️ ${data.description || 'Full Original Source File'}`;
      if (statsLabel) {
        const kb = ((data.size || 0) / 1024).toFixed(1);
        statsLabel.textContent = `✅ ${data.lineCount} Lines • ${kb} KB • ${data.fileName}`;
      }
    } catch (err) {
      console.warn('Source code load failed, falling back:', err);
      if (viewer) viewer.textContent = `// Error loading file: ${err.message}\n// Please ensure server is running and admin key is valid.`;
      if (statsLabel) statsLabel.textContent = '❌ Failed to load';
    }
  };

  window.copyCurrentSourceCode = function () {
    if (!currentLoadedSourceCode) {
      showToast('Source code abhi load nahi hua hai.', 'warning');
      return;
    }
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(currentLoadedSourceCode).then(() => {
        showToast(`📋 ${currentLoadedFileKey} ka pura source code copy ho gaya!`, 'success');
      }).catch(() => {
        fallbackCopyText(currentLoadedSourceCode);
      });
    } else {
      fallbackCopyText(currentLoadedSourceCode);
    }
  };

  function fallbackCopyText(text) {
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.style.position = 'fixed';
    ta.style.left = '-9999px';
    document.body.appendChild(ta);
    ta.select();
    try {
      document.execCommand('copy');
      showToast(`📋 Source code clipboard me copy ho gaya!`, 'success');
    } catch (e) {
      showToast('Copy karne me dikkat aayi. Kripya manually select karke copy karein.', 'warning');
    }
    document.body.removeChild(ta);
  }

  window.downloadCurrentSourceFile = function () {
    if (!currentLoadedSourceCode) {
      showToast('Source code abhi load nahi hua hai.', 'warning');
      return;
    }
    const blob = new Blob([currentLoadedSourceCode], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = currentLoadedFileKey || 'source_code.txt';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    showToast(`📥 ${currentLoadedFileKey} download ho gaya!`, 'success');
  };

  // ==========================================
  // SEND / SHARE APK TO ANY USER ENGINE
  // ==========================================
  window.getApkShareText = function (phone = '', name = '', username = '') {
    const origin = window.location.origin;
    const apkUrl = `${origin}/download/apk`;
    const zipUrl = `${origin}/download/apk-project`;
    const recipientGreeting = name ? `Namaste / Assalamu Alaikum *${name}*,` : 'Namaste / Assalamu Alaikum,';
    const userLine = username ? `\n🔑 *Aapka Login Username:* @${username}\n` : '';

    return `🌟 *MUZAMMIL ONLINE SERVICE - OFFICIAL ANDROID APP (APK)* 🌟\n\n` +
      `${recipientGreeting}\n` +
      `Muzammil Online Service ka official Android App APK ready hai:\n\n` +
      `📲 *Direct APK Download Karein:*\n` +
      `${apkUrl}\n\n` +
      `📦 *Android Studio Full Project ZIP:*\n` +
      `${zipUrl}\n` +
      userLine +
      `\n⚡ *Features:*\n` +
      `• All Central & State Govt Schemes\n` +
      `• Digital Seva & CSC Portal Integration\n` +
      `• Fast PVC & Smart Card Maker\n` +
      `• Instant Bill Receipts & CV Builder\n` +
      `• Cloud SQL PostgreSQL Instant Sync\n\n` +
      `👉 Upar diye gaye link par click karke APK install karein aur software login karein.\n` +
      `📞 Kisi bhi sahayata ke liye sampark karein: *9561460313*\n` +
      `Owner: Imran Khan`;
  };

  window.openSendApkModal = function (phone = '', name = '', username = '') {
    const modal = document.getElementById('mosSendApkModal');
    if (!modal) return;

    const phoneIn = document.getElementById('sendApkModalPhone');
    const nameIn = document.getElementById('sendApkModalName');
    const userIn = document.getElementById('sendApkModalUsername');

    if (phoneIn) phoneIn.value = phone ? decodeURIComponent(phone).replace(/\D/g, '').slice(-10) : '';
    if (nameIn) nameIn.value = name ? decodeURIComponent(name) : '';
    if (userIn) userIn.value = username ? decodeURIComponent(username) : '';

    window.updateSendApkMessagePreview();

    modal.classList.remove('hidden');
    modal.style.setProperty('display', 'flex', 'important');
  };

  window.closeSendApkModal = function () {
    const modal = document.getElementById('mosSendApkModal');
    if (modal) {
      modal.classList.add('hidden');
      modal.style.setProperty('display', 'none', 'important');
    }
  };

  window.updateSendApkMessagePreview = function () {
    const phoneIn = document.getElementById('sendApkModalPhone');
    const nameIn = document.getElementById('sendApkModalName');
    const userIn = document.getElementById('sendApkModalUsername');
    const preview = document.getElementById('sendApkMessagePreview');

    const phone = phoneIn ? phoneIn.value.trim() : '';
    const name = nameIn ? nameIn.value.trim() : '';
    const username = userIn ? userIn.value.trim() : '';

    const text = window.getApkShareText(phone, name, username);
    if (preview) preview.textContent = text;
  };

  window.handleSendApkModalSubmit = async function (e) {
    if (e && e.preventDefault) e.preventDefault();

    const phoneIn = document.getElementById('sendApkModalPhone');
    const nameIn = document.getElementById('sendApkModalName');
    const userIn = document.getElementById('sendApkModalUsername');

    const rawPhone = phoneIn ? phoneIn.value.trim() : '';
    const name = nameIn ? nameIn.value.trim() : '';
    const username = userIn ? userIn.value.trim() : '';

    const cleanDigits = rawPhone.replace(/\D/g, '');
    const cleanPhone = cleanDigits.slice(-10);

    if (!cleanPhone || cleanPhone.length < 10) {
      showToast('Kripya 10-digit sahi mobile number darj karein!', 'warning');
      if (phoneIn) phoneIn.focus();
      return;
    }

    const msg = window.getApkShareText(cleanPhone, name, username);
    const waUrl = `https://wa.me/91${cleanPhone}?text=${encodeURIComponent(msg)}`;

    // Open WhatsApp
    window.open(waUrl, '_blank');

    // Record on server in Cloud SQL
    try {
      fetch(`${getApiBase()}/api/admin/apk/send`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-admin-key': currentAdminPin || 'muzammil786'
        },
        body: JSON.stringify({
          phone: cleanPhone,
          name,
          username,
          channel: 'whatsapp'
        })
      }).catch(() => {});
    } catch (err) {}

    showToast(`🟢 ${name || cleanPhone} ko WhatsApp par APK download link bheja gaya!`, 'success');
    window.closeSendApkModal();
  };

  window.shareApkModalNative = async function () {
    const phoneIn = document.getElementById('sendApkModalPhone');
    const nameIn = document.getElementById('sendApkModalName');
    const userIn = document.getElementById('sendApkModalUsername');

    const phone = phoneIn ? phoneIn.value.trim() : '';
    const name = nameIn ? nameIn.value.trim() : '';
    const username = userIn ? userIn.value.trim() : '';

    const msg = window.getApkShareText(phone, name, username);
    const apkUrl = `${window.location.origin}/download/apk`;

    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Muzammil Online Service - Android APK',
          text: msg,
          url: apkUrl
        });
        showToast('APK link share ho gaya!', 'success');
        window.closeSendApkModal();
        return;
      } catch (err) {
        if (err.name !== 'AbortError') {
          console.warn('Native share error:', err);
        }
      }
    }

    // Fallback: copy link
    window.copyApkDirectLink();
  };

  window.sendApkFromQuickBar = function (mode) {
    const phoneIn = document.getElementById('quickSendApkPhone');
    const nameIn = document.getElementById('quickSendApkName');
    const rawPhone = phoneIn ? phoneIn.value.trim() : '';
    const name = nameIn ? nameIn.value.trim() : '';

    const cleanDigits = rawPhone.replace(/\D/g, '');
    const cleanPhone = cleanDigits.slice(-10);

    if (mode === 'whatsapp') {
      if (!cleanPhone || cleanPhone.length < 10) {
        showToast('Kripya 10-digit mobile number daalein WhatsApp par bhejne ke liye!', 'warning');
        if (phoneIn) phoneIn.focus();
        return;
      }
      const msg = window.getApkShareText(cleanPhone, name, '');
      const waUrl = `https://wa.me/91${cleanPhone}?text=${encodeURIComponent(msg)}`;
      window.open(waUrl, '_blank');

      try {
        fetch(`${getApiBase()}/api/admin/apk/send`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-admin-key': currentAdminPin || 'muzammil786'
          },
          body: JSON.stringify({ phone: cleanPhone, name, channel: 'whatsapp_quick' })
        }).catch(() => {});
      } catch (err) {}

      showToast(`🟢 WhatsApp par APK link open kiya gaya!`, 'success');
    } else if (mode === 'share') {
      const msg = window.getApkShareText(cleanPhone, name, '');
      const apkUrl = `${window.location.origin}/download/apk`;
      if (navigator.share) {
        navigator.share({
          title: 'Muzammil Online Service - Android APK',
          text: msg,
          url: apkUrl
        }).catch(() => {});
      } else {
        window.copyApkDirectLink();
      }
    }
  };

  window.copyApkDirectLink = function () {
    const apkUrl = `${window.location.origin}/download/apk`;
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(apkUrl).then(() => {
        showToast('📋 Direct APK Download Link clipboard me copy ho gaya!', 'success');
      }).catch(() => {
        fallbackCopyText(apkUrl);
      });
    } else {
      fallbackCopyText(apkUrl);
    }
  };

  // PWA & Mobile Installation Handler
  let deferredInstallPrompt = null;
  window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    deferredInstallPrompt = e;
  });

  window.triggerPWAInstall = async function () {
    if (deferredInstallPrompt) {
      deferredInstallPrompt.prompt();
      const { outcome } = await deferredInstallPrompt.userChoice;
      if (outcome === 'accepted') {
        showToast('App aapke mobile par install ho raha hai! 🎉', 'success');
        deferredInstallPrompt = null;
      }
    } else {
      showToast('📱 Android par install karne ke liye Chrome menu (⋮) me "Install app" ya "Add to Home screen" par tap karein.', 'info');
    }
  };

  // Register Service Worker for PWA
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('/sw.js').catch((err) => {
        console.warn('SW registration failed:', err);
      });
    });
  }

  const initMosBridge = () => {
    initLiveClock();
    // Check mandatory login session
    window.checkAuthSession();

    // Start Live Realtime Firestore Watcher for all operators across all phones
    if (window.MosFirebase && typeof window.MosFirebase.watchAllUsers === 'function') {
      window.MosFirebase.watchAllUsers(syncAllCloudUsers);
    }

    // Pull and sync latest cloud data on page load
    if (window.CloudServerSync) {
      window.CloudServerSync.pullFromServer(true);
    }

    // Sync cloud users immediately and periodically
    syncAllCloudUsers();
    setTimeout(syncAllCloudUsers, 1200);
    setTimeout(syncAllCloudUsers, 4500);

    // Automatic version upgrade check across devices
    checkAppVersion();
  };

  async function checkAppVersion() {
    try {
      const res = await fetch(getApiBase() + '/api/version');
      if (res.ok) {
        const json = await res.json();
        if (json && json.version) {
          const currentVer = '98.0';
          console.log(`📱 App Version: v${currentVer} (Latest Server: v${json.version})`);
          if (json.version !== currentVer) {
            showVersionUpdateBanner(json.version);
          }
        }
      }
    } catch (e) {}
  }

  function showVersionUpdateBanner(newVersion) {
    if (document.getElementById('mosVersionUpdateNotice')) return;
    const banner = document.createElement('div');
    banner.id = 'mosVersionUpdateNotice';
    banner.style.cssText = 'position:fixed;bottom:18px;left:50%;transform:translateX(-50%);background:linear-gradient(135deg,#0284c7,#2563eb);color:#fff;padding:12px 18px;border-radius:14px;box-shadow:0 8px 30px rgba(0,0,0,0.4);z-index:9999999;display:flex;align-items:center;gap:12px;font-size:13px;font-weight:700;max-width:90vw;';
    banner.innerHTML = `
      <span>⚡ Naya Version <b>v${newVersion}</b> Uplabdh Hai!</span>
      <button onclick="window.location.reload(true)" style="background:#fff;color:#0284c7;border:0;padding:6px 12px;border-radius:8px;font-weight:800;font-size:12px;cursor:pointer;">Update Karein</button>
      <button onclick="this.parentElement.remove()" style="background:transparent;border:0;color:#fff;font-size:16px;cursor:pointer;padding:0 4px;">✕</button>
    `;
    document.body.appendChild(banner);
  }
  window.checkAppVersion = checkAppVersion;

  async function syncAllCloudUsers() {
    try {
      if (window.MosFirebase && typeof window.MosFirebase.getAllUsers === 'function') {
        const cloudUsers = await window.MosFirebase.getAllUsers();
        if (Array.isArray(cloudUsers) && cloudUsers.length > 0) {
          const local = getLocalUsers();
          let changed = false;
          cloudUsers.forEach(cu => {
            if (!cu || !cu.username) return;
            const idx = local.findIndex(l => String(l.username).toLowerCase() === String(cu.username).toLowerCase());
            const userObj = {
              id: cu.id || Date.now(),
              uid: cu.uid || ('usr_' + cu.username),
              username: cu.username,
              displayName: cu.displayName || cu.username,
              phone: cu.phone || '',
              shopName: cu.shopName || '',
              role: cu.role || 'operator',
              status: cu.status || 'active',
              password: cu.passwordPlain || cu.password || '',
              passwordPlain: cu.passwordPlain || cu.password || '',
              password_hash: cu.passwordHash || '',
              expires_at: cu.expiresAt || null,
              created_at: cu.createdAt || new Date().toISOString()
            };
            if (idx >= 0) {
              local[idx] = { ...local[idx], ...userObj };
            } else {
              local.push(userObj);
            }
            changed = true;
          });
          if (changed) {
            saveLocalUsers(local);
            console.log('⚡ [Dual-Cloud Sync] Live synced', cloudUsers.length, 'operators across devices.');
          }
        }
      }
    } catch (e) {
      console.warn('syncAllCloudUsers error:', e);
    }
  }

  // -------------------------------------------------------------
  // 🖥️ DESKTOP MODE & PORTAL CONTROLLER (ANY WEBSITE DESKTOP VIEW)
  // -------------------------------------------------------------
  let currentDesktopUrl = 'https://uidai.gov.in/en/my-aadhaar';
  let currentDesktopZoom = 100;
  let currentDesktopWidth = 1280;
  let isDesktopViewEnabled = true;

  function updateGlobalDesktopIndicators(isOn) {
    const sideText = document.getElementById('sideDesktopText');
    if (sideText) {
      sideText.textContent = isOn ? 'ON 🟢' : 'OFF';
      sideText.style.color = isOn ? '#4ade80' : '#38bdf8';
    }
    const headerBtn = document.getElementById('mosHeaderDesktopBtn');
    const headerText = document.getElementById('headerDesktopText');
    if (headerBtn && headerText) {
      if (isOn) {
        headerBtn.style.background = 'linear-gradient(135deg, #059669, #10b981)';
        headerBtn.style.borderColor = '#34d399';
        headerBtn.style.boxShadow = '0 0 10px rgba(52,211,153,0.5)';
        headerText.textContent = 'Desktop ON';
      } else {
        headerBtn.style.background = '#0f172a';
        headerBtn.style.borderColor = '#0284c7';
        headerBtn.style.boxShadow = 'none';
        headerText.textContent = 'Desktop';
      }
    }
  }

  window.toggleGlobalDesktopMode = function () {
    const current = localStorage.getItem('mos_desktop_mode_global') === 'true';
    const next = !current;
    localStorage.setItem('mos_desktop_mode_global', String(next));
    updateGlobalDesktopIndicators(next);
    if (typeof showToast === 'function') {
      showToast(next ? '🖥️ Desktop Mode ON: Sabhi portals PC/Desktop layout me khulenge.' : '📱 Desktop Mode OFF: Standard mobile view.', 'info');
    }
    return next;
  };

  window.openPortalBrowserModal = function (url) {
    if (typeof window.verifyActiveUserAccess === 'function' && !window.verifyActiveUserAccess(true)) return;
    if (!url) url = 'https://uidai.gov.in/en/my-aadhaar';
    currentDesktopUrl = url;

    if (typeof openFeature === 'function') {
      openFeature('desktopMode');
    } else if (typeof show === 'function') {
      show('desktopMode');
    }

    setTimeout(() => {
      window.navigateDesktopBrowser(url);
    }, 100);
  };

  window.navigateDesktopBrowser = function (url) {
    if (!url) return;
    url = url.trim();
    if (!url.startsWith('http://') && !url.startsWith('https://')) {
      url = 'https://' + url;
    }
    currentDesktopUrl = url;

    const urlInput = document.getElementById('desktopUrlInput');
    if (urlInput) urlInput.value = url;

    const badge = document.getElementById('desktopCurrentUrlBadge');
    if (badge) badge.textContent = url;

    const iframe = document.getElementById('desktopIframe');
    if (iframe) {
      const proxyUrl = getApiBase() + '/api/desktop-proxy?url=' + encodeURIComponent(url);
      iframe.src = proxyUrl;
    }

    const extBtn = document.getElementById('desktopExternalBtn');
    if (extBtn) extBtn.onclick = () => window.open(url, '_blank', 'noopener,noreferrer');

    // Auto-fit zoom to device width if on mobile
    window.autoFitDesktopZoom();
  };

  window.autoFitDesktopZoom = function () {
    const container = document.getElementById('desktopFrameContainer');
    if (!container) return;
    const availW = container.clientWidth || window.innerWidth;
    if (availW < currentDesktopWidth && isDesktopViewEnabled) {
      const autoScale = Math.max(35, Math.floor((availW / currentDesktopWidth) * 98));
      window.setDesktopZoom(autoScale);
    } else {
      window.setDesktopZoom(100);
    }
  };

  window.setDesktopZoom = function (level) {
    currentDesktopZoom = Math.max(30, Math.min(200, Math.round(level)));
    const scaler = document.getElementById('desktopFrameScaler');
    if (scaler) {
      const scale = currentDesktopZoom / 100;
      scaler.style.transform = `scale(${scale})`;
      scaler.style.transformOrigin = 'top left';
      // Adjust parent container height to avoid empty gap
      const iframe = document.getElementById('desktopIframe');
      if (iframe) {
        scaler.style.height = (880 * scale) + 'px';
      }
    }
    const badge = document.getElementById('desktopZoomBadge');
    if (badge) badge.textContent = currentDesktopZoom + '%';
  };

  window.adjustDesktopZoom = function (delta) {
    window.setDesktopZoom(currentDesktopZoom + delta);
  };

  window.setDesktopWidth = function (widthPx) {
    currentDesktopWidth = widthPx;
    const scaler = document.getElementById('desktopFrameScaler');
    const iframe = document.getElementById('desktopIframe');
    if (scaler) scaler.style.width = widthPx + 'px';
    if (iframe) iframe.style.width = widthPx + 'px';
    window.autoFitDesktopZoom();
  };

  window.toggleDesktopIframeMode = function () {
    isDesktopViewEnabled = !isDesktopViewEnabled;
    const toggleBtn = document.getElementById('desktopModeToggleBtn');
    const scaler = document.getElementById('desktopFrameScaler');
    const iframe = document.getElementById('desktopIframe');

    if (isDesktopViewEnabled) {
      if (scaler) {
        scaler.style.width = currentDesktopWidth + 'px';
        scaler.style.margin = '0 auto';
      }
      if (iframe) iframe.style.width = currentDesktopWidth + 'px';
      if (toggleBtn) {
        toggleBtn.innerHTML = '<span>🖥️</span> <b>Desktop Mode (ON)</b>';
        toggleBtn.style.background = '#0284c7';
      }
      window.autoFitDesktopZoom();
    } else {
      if (scaler) {
        scaler.style.width = '100%';
        scaler.style.transform = 'none';
        scaler.style.height = '750px';
      }
      if (iframe) iframe.style.width = '100%';
      if (toggleBtn) {
        toggleBtn.innerHTML = '<span>📱</span> <b>Mobile View</b>';
        toggleBtn.style.background = '#475569';
      }
      const badge = document.getElementById('desktopZoomBadge');
      if (badge) badge.textContent = '100%';
    }
  };

  window.reloadDesktopBrowser = function () {
    const iframe = document.getElementById('desktopIframe');
    if (iframe && iframe.src) {
      const cur = iframe.src;
      iframe.src = 'about:blank';
      setTimeout(() => { iframe.src = cur; }, 100);
    }
  };

  window.openDesktopExternal = function () {
    if (currentDesktopUrl) {
      window.open(currentDesktopUrl, '_blank', 'noopener,noreferrer');
    }
  };

  window.copyDesktopUrl = function () {
    if (currentDesktopUrl && navigator.clipboard) {
      navigator.clipboard.writeText(currentDesktopUrl).then(() => {
        if (typeof showToast === 'function') showToast('Website link copy ho gayi!', 'success');
      });
    }
  };

  // -------------------------------------------------------------
  // 📑 ULTRA HIGH-QUALITY DOCUMENT SCANNER (TEXT & PHOTO CLARITY)
  // -------------------------------------------------------------
  let docScanPages = [];
  let docScanActiveIndex = 0;
  let isDocProcessing = false;

  window.handleDocScanImageSelect = function (input, isCamera) {
    if (!input || !input.files || input.files.length === 0) return;

    const files = Array.from(input.files);
    let loadedCount = 0;

    files.forEach(file => {
      if (!file.type.startsWith('image/')) return;
      const reader = new FileReader();
      reader.onload = function (e) {
        const img = new Image();
        img.onload = function () {
          docScanPages.push({
            img: img,
            name: file.name || `Page_${docScanPages.length + 1}`,
            mode: 'magicColor',
            sharpness: 65,
            whitening: 50,
            brightness: 15,
            contrast: 30,
            photoClarity: 60,
            rotation: 0
          });
          loadedCount++;
          if (loadedCount === files.length) {
            docScanActiveIndex = docScanPages.length - 1;
            renderDocScanWorkspace();
          }
        };
        img.src = e.target.result;
      };
      reader.readAsDataURL(file);
    });

    input.value = '';
  };

  function renderDocScanWorkspace() {
    const workspace = document.getElementById('docScanWorkspace');
    if (!workspace) return;
    workspace.style.display = 'block';

    // Render Page Tabs
    const tabsCont = document.getElementById('docScanPagesContainer');
    const tabsList = document.getElementById('docScanPageTabsList');
    if (tabsCont && tabsList) {
      tabsCont.style.display = docScanPages.length > 0 ? 'block' : 'none';
      tabsList.innerHTML = docScanPages.map((page, idx) => `
        <div style="display:inline-flex;align-items:center;background:${idx === docScanActiveIndex ? '#0284c7' : '#1e293b'};color:#fff;border-radius:10px;padding:5px 10px;font-size:12px;font-weight:700;gap:6px;cursor:pointer;border:1px solid ${idx === docScanActiveIndex ? '#38bdf8' : '#334155'};">
          <span onclick="window.switchDocScanPage(${idx})">📄 Page ${idx + 1}</span>
          <span onclick="window.deleteDocScanPage(${idx})" style="color:#fca5a5;padding:0 2px;font-size:13px;" title="Delete this page">✕</span>
        </div>
      `).join('') + `
        <button type="button" onclick="document.getElementById('docScanFileInput').click()" style="background:#0f172a;border:1px dashed #38bdf8;color:#38bdf8;border-radius:10px;padding:6px 12px;font-size:12px;font-weight:700;cursor:pointer;">
          + Add Page
        </button>
      `;
    }

    syncDocScanSliderValues();
    window.updateDocScanFilters();
  }

  window.switchDocScanPage = function (idx) {
    if (idx >= 0 && idx < docScanPages.length) {
      docScanActiveIndex = idx;
      renderDocScanWorkspace();
    }
  };

  window.deleteDocScanPage = function (idx) {
    if (docScanPages.length <= 1) {
      docScanPages = [];
      const workspace = document.getElementById('docScanWorkspace');
      if (workspace) workspace.style.display = 'none';
      const tabsCont = document.getElementById('docScanPagesContainer');
      if (tabsCont) tabsCont.style.display = 'none';
      return;
    }
    docScanPages.splice(idx, 1);
    docScanActiveIndex = Math.max(0, Math.min(docScanActiveIndex, docScanPages.length - 1));
    renderDocScanWorkspace();
  };

  function syncDocScanSliderValues() {
    const page = docScanPages[docScanActiveIndex];
    if (!page) return;

    const s = document.getElementById('docScanSharpness');
    const w = document.getElementById('docScanWhitening');
    const b = document.getElementById('docScanBrightness');
    const c = document.getElementById('docScanContrast');
    const pc = document.getElementById('docScanPhotoClarity');

    if (s) s.value = page.sharpness;
    if (w) w.value = page.whitening;
    if (b) b.value = page.brightness;
    if (c) c.value = page.contrast;
    if (pc) pc.value = page.photoClarity;

    updateSliderLabel('docScanSharpnessVal', page.sharpness + '%');
    updateSliderLabel('docScanWhiteningVal', page.whitening + '%');
    updateSliderLabel('docScanBrightnessVal', (page.brightness > 0 ? '+' : '') + page.brightness);
    updateSliderLabel('docScanContrastVal', (page.contrast > 0 ? '+' : '') + page.contrast);
    if (pc) updateSliderLabel('docScanPhotoClarityVal', page.photoClarity + '%');

    // Update active filter pill
    document.querySelectorAll('.docModeBtn').forEach(btn => {
      if (btn.dataset.mode === page.mode) {
        btn.classList.add('active');
        btn.style.border = '1.5px solid #0284c7';
        btn.style.background = '#eff6ff';
        btn.style.color = '#0284c7';
      } else {
        btn.classList.remove('active');
        btn.style.border = '1px solid #cbd5e1';
        btn.style.background = '#fff';
        btn.style.color = '#334155';
      }
    });
  }

  function updateSliderLabel(id, val) {
    const el = document.getElementById(id);
    if (el) el.textContent = val;
  }

  window.setDocScanMode = function (modeName) {
    const page = docScanPages[docScanActiveIndex];
    if (!page) return;
    page.mode = modeName;

    // Presets for optimal Text + Photo clarity
    if (modeName === 'magicColor') {
      page.sharpness = 65;
      page.whitening = 50;
      page.brightness = 15;
      page.contrast = 30;
      page.photoClarity = 60;
    } else if (modeName === 'bwCrisp') {
      page.sharpness = 80;
      page.whitening = 70;
      page.brightness = 10;
      page.contrast = 55;
      page.photoClarity = 0;
    } else if (modeName === 'photo') {
      page.sharpness = 40;
      page.whitening = 20;
      page.brightness = 10;
      page.contrast = 20;
      page.photoClarity = 80;
    } else if (modeName === 'colorBoost') {
      page.sharpness = 60;
      page.whitening = 40;
      page.brightness = 15;
      page.contrast = 40;
      page.photoClarity = 85;
    } else if (modeName === 'grayscale') {
      page.sharpness = 70;
      page.whitening = 50;
      page.brightness = 15;
      page.contrast = 35;
      page.photoClarity = 0;
    } else if (modeName === 'original') {
      page.sharpness = 0;
      page.whitening = 0;
      page.brightness = 0;
      page.contrast = 0;
      page.photoClarity = 50;
    }

    syncDocScanSliderValues();
    window.updateDocScanFilters();
  };

  window.rotateDocScan = function (deg) {
    const page = docScanPages[docScanActiveIndex];
    if (!page) return;
    page.rotation = (page.rotation + deg + 360) % 360;
    window.updateDocScanFilters();
  };

  window.resetDocScanSliders = function () {
    const page = docScanPages[docScanActiveIndex];
    if (!page) return;
    window.setDocScanMode(page.mode || 'magicColor');
  };

  window.updateDocScanFilters = function () {
    const page = docScanPages[docScanActiveIndex];
    if (!page || !page.img) return;

    const s = document.getElementById('docScanSharpness');
    const w = document.getElementById('docScanWhitening');
    const b = document.getElementById('docScanBrightness');
    const c = document.getElementById('docScanContrast');
    const pc = document.getElementById('docScanPhotoClarity');

    if (s) page.sharpness = parseInt(s.value, 10);
    if (w) page.whitening = parseInt(w.value, 10);
    if (b) page.brightness = parseInt(b.value, 10);
    if (c) page.contrast = parseInt(c.value, 10);
    if (pc) page.photoClarity = parseInt(pc.value, 10);

    updateSliderLabel('docScanSharpnessVal', page.sharpness + '%');
    updateSliderLabel('docScanWhiteningVal', page.whitening + '%');
    updateSliderLabel('docScanBrightnessVal', (page.brightness > 0 ? '+' : '') + page.brightness);
    updateSliderLabel('docScanContrastVal', (page.contrast > 0 ? '+' : '') + page.contrast);
    if (pc) updateSliderLabel('docScanPhotoClarityVal', page.photoClarity + '%');

    const canvas = document.getElementById('docScanCanvas');
    if (!canvas) return;

    // Process image with dual-engine (crisp text + clear photo)
    const processedCanvas = processDocScanImage(page.img, page);
    canvas.width = processedCanvas.width;
    canvas.height = processedCanvas.height;
    const ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(processedCanvas, 0, 0);

    const badge = document.getElementById('docScanInfoBadge');
    if (badge) {
      badge.textContent = `📄 ${canvas.width} × ${canvas.height} px • High Definition 300 DPI Scanner`;
    }
  };

  function processDocScanImage(img, options) {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d', { willReadFrequently: true });

    let w = img.naturalWidth || img.width;
    let h = img.naturalHeight || img.height;
    const rot = (options.rotation || 0) % 360;

    if (rot === 90 || rot === 270) {
      canvas.width = h;
      canvas.height = w;
    } else {
      canvas.width = w;
      canvas.height = h;
    }

    ctx.save();
    ctx.translate(canvas.width / 2, canvas.height / 2);
    ctx.rotate((rot * Math.PI) / 180);
    ctx.drawImage(img, -w / 2, -h / 2);
    ctx.restore();

    if (options.mode === 'original' && options.sharpness === 0 && options.whitening === 0 && options.brightness === 0 && options.contrast === 0) {
      return canvas;
    }

    const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const data = imgData.data;
    const len = data.length;

    const mode = options.mode || 'magicColor';
    const sharpness = (options.sharpness !== undefined ? options.sharpness : 65) / 100;
    const whitening = (options.whitening !== undefined ? options.whitening : 50) / 100;
    const brightness = (options.brightness !== undefined ? options.brightness : 15);
    const contrast = (options.contrast !== undefined ? options.contrast : 30);
    const photoClarity = (options.photoClarity !== undefined ? options.photoClarity : 60) / 100;

    const factor = (259 * (contrast + 255)) / (255 * (259 - contrast));

    for (let i = 0; i < len; i += 4) {
      let r = data[i];
      let g = data[i + 1];
      let b = data[i + 2];

      // Brightness
      if (brightness !== 0) {
        r += brightness;
        g += brightness;
        b += brightness;
      }

      // Contrast
      if (contrast !== 0) {
        r = factor * (r - 128) + 128;
        g = factor * (g - 128) + 128;
        b = factor * (b - 128) + 128;
      }

      r = Math.max(0, Math.min(255, r));
      g = Math.max(0, Math.min(255, g));
      b = Math.max(0, Math.min(255, b));

      const maxC = Math.max(r, g, b);
      const minC = Math.min(r, g, b);
      const sat = maxC - minC;
      const lum = 0.299 * r + 0.587 * g + 0.114 * b;

      if (mode === 'magicColor') {
        // DUAL ENGINE: Preserves photo while making paper pure white & text jet black
        if (sat > 20) {
          // Photo / Face / Seal region -> Keep rich natural skin tone & colors
          const satBoost = 1.05 + (photoClarity * 0.35);
          r = Math.min(255, lum + (r - lum) * satBoost);
          g = Math.min(255, lum + (g - lum) * satBoost);
          b = Math.min(255, lum + (b - lum) * satBoost);
        } else {
          // Paper & Text region
          const whiteThresh = 205 - (whitening * 55); // 150 - 205
          const blackThresh = 115 + (whitening * 30); // 115 - 145
          if (lum > whiteThresh) {
            // Paper whiten
            const boost = (lum - whiteThresh) / (255 - whiteThresh);
            r = r + (255 - r) * boost * (0.6 + whitening * 0.4);
            g = g + (255 - g) * boost * (0.6 + whitening * 0.4);
            b = b + (255 - b) * boost * (0.6 + whitening * 0.4);
          } else if (lum < blackThresh) {
            // Darken text
            const darkFactor = 0.45 - (sharpness * 0.2);
            r = r * darkFactor;
            g = g * darkFactor;
            b = b * darkFactor;
          } else {
            // Smooth gradient midtones
            const norm = (lum - blackThresh) / (whiteThresh - blackThresh);
            const curve = Math.pow(norm, 1.3);
            r = r * (0.55 + 0.45 * curve);
            g = g * (0.55 + 0.45 * curve);
            b = b * (0.55 + 0.45 * curve);
          }
        }
      } else if (mode === 'bwCrisp') {
        // Pure crisp B&W laser text
        const thresh = 145 + (whitening * 45) - (sharpness * 20);
        const val = lum < thresh ? 0 : 255;
        r = g = b = val;
      } else if (mode === 'photo') {
        // Photo & ID Card mode: High fidelity colors & smooth tones
        if (sat > 16) {
          const satBoost = 1.15 + (photoClarity * 0.3);
          r = Math.min(255, lum + (r - lum) * satBoost);
          g = Math.min(255, lum + (g - lum) * satBoost);
          b = Math.min(255, lum + (b - lum) * satBoost);
        } else if (lum > 215) {
          r = Math.min(255, r + 30);
          g = Math.min(255, g + 30);
          b = Math.min(255, b + 30);
        }
      } else if (mode === 'colorBoost') {
        // Boost seals, blue ink & stamps
        if (sat > 12) {
          const satBoost = 1.4;
          r = Math.min(255, lum + (r - lum) * satBoost);
          g = Math.min(255, lum + (g - lum) * satBoost);
          b = Math.min(255, lum + (b - lum) * satBoost);
        } else if (lum > 185) {
          r = 255; g = 255; b = 255;
        }
      } else if (mode === 'grayscale') {
        let gray = lum;
        if (gray > 175) {
          gray = Math.min(255, gray + (255 - gray) * whitening);
        } else if (gray < 125) {
          gray = gray * (1 - sharpness * 0.35);
        }
        r = g = b = Math.max(0, Math.min(255, gray));
      }

      data[i] = Math.max(0, Math.min(255, r));
      data[i + 1] = Math.max(0, Math.min(255, g));
      data[i + 2] = Math.max(0, Math.min(255, b));
    }

    ctx.putImageData(imgData, 0, 0);

    // Apply 3x3 unsharp mask filter for crisp text edges
    if (sharpness > 0.1 && (mode === 'magicColor' || mode === 'bwCrisp' || mode === 'grayscale' || mode === 'photo')) {
      applyUnsharpMask(ctx, canvas.width, canvas.height, sharpness);
    }

    return canvas;
  }

  function applyUnsharpMask(ctx, width, height, amount) {
    const imgData = ctx.getImageData(0, 0, width, height);
    const src = new Uint8ClampedArray(imgData.data);
    const dst = imgData.data;
    const w = width;
    const h = height;

    const strength = Math.min(0.9, amount);
    const center = 1 + 4 * strength;
    const edge = -strength;

    for (let y = 1; y < h - 1; y++) {
      const rowPrev = (y - 1) * w * 4;
      const rowCurr = y * w * 4;
      const rowNext = (y + 1) * w * 4;

      for (let x = 1; x < w - 1; x++) {
        const idx = rowCurr + x * 4;
        for (let c = 0; c < 3; c++) {
          const val = center * src[idx + c] +
            edge * (src[rowPrev + x * 4 + c] + src[rowNext + x * 4 + c] + src[idx - 4 + c] + src[idx + 4 + c]);
          dst[idx + c] = val < 0 ? 0 : (val > 255 ? 255 : val);
        }
      }
    }
    ctx.putImageData(imgData, 0, 0);
  }

  window.downloadDocScannerJpg = function () {
    const canvas = document.getElementById('docScanCanvas');
    if (!canvas) return;
    const link = document.createElement('a');
    link.download = `Muzammil_DocScan_HD_p${docScanActiveIndex + 1}.jpg`;
    link.href = canvas.toDataURL('image/jpeg', 0.98);
    link.click();
    if (typeof showToast === 'function') showToast('Ultra HD JPG Download ho gaya!', 'success');
  };

  window.downloadDocScannerPdf = function () {
    if (docScanPages.length === 0) return;
    const jsPDFClass = window.jspdf ? (window.jspdf.jsPDF || window.jspdf) : (window.jsPDF || null);
    if (!jsPDFClass) {
      alert('PDF library load ho rahi hai, kripya 2 second baad dobara tap karein.');
      return;
    }

    try {
      const pdf = new jsPDFClass({ orientation: 'portrait', unit: 'mm', format: 'a4' });
      const a4W = 210;
      const a4H = 297;

      docScanPages.forEach((page, idx) => {
        if (idx > 0) pdf.addPage();
        const proc = processDocScanImage(page.img, page);
        const dataUrl = proc.toDataURL('image/jpeg', 0.96);

        const imgRatio = proc.width / proc.height;
        const pageRatio = a4W / a4H;
        let drawW = a4W;
        let drawH = a4H;
        let posX = 0;
        let posY = 0;

        if (imgRatio > pageRatio) {
          drawW = a4W - 10;
          drawH = drawW / imgRatio;
          posX = 5;
          posY = (a4H - drawH) / 2;
        } else {
          drawH = a4H - 10;
          drawW = drawH * imgRatio;
          posY = 5;
          posX = (a4W - drawW) / 2;
        }

        pdf.addImage(dataUrl, 'JPEG', posX, posY, drawW, drawH, undefined, 'FAST');
      });

      pdf.save(`Muzammil_DocScan_HD_v98.pdf`);
      if (typeof showToast === 'function') showToast('300 DPI A4 PDF Download ho gaya! 🎉', 'success');
    } catch (e) {
      console.error('PDF export error:', e);
      alert('PDF generate karne me error: ' + e.message);
    }
  };

  window.shareDocScannerWhatsApp = function () {
    const canvas = document.getElementById('docScanCanvas');
    if (!canvas) return;
    window.downloadDocScannerPdf();
    setTimeout(() => {
      const msg = encodeURIComponent(`📄 *Muzammil Online Service - High Quality Scan*\nCustomer document 300 DPI Ultra Clear HD scan kiya gaya hai.\n📞 +91 9561460313`);
      window.open(`https://api.whatsapp.com/send?text=${msg}`, '_blank');
    }, 800);
  };

  window.printDocScanner = function () {
    const canvas = document.getElementById('docScanCanvas');
    if (!canvas) return;
    const dataUrl = canvas.toDataURL('image/jpeg', 0.98);
    const win = window.open('', '_blank');
    if (!win) {
      alert('Pop-up allow karein print preview ke liye.');
      return;
    }
    win.document.write(`
      <!DOCTYPE html>
      <html>
      <head>
        <title>Muzammil Online Service - Document Print</title>
        <style>
          @page { size: A4 portrait; margin: 0; }
          body { margin: 0; padding: 0; display: flex; align-items: center; justify-content: center; height: 100vh; background: #fff; }
          img { max-width: 96%; max-height: 96%; object-fit: contain; }
        </style>
      </head>
      <body>
        <img src="${dataUrl}" onload="window.print();window.close();">
      </body>
      </html>
    `);
    win.document.close();
  };

  window.sendDocScanToPvcCard = function () {
    const canvas = document.getElementById('docScanCanvas');
    if (!canvas) return;
    const dataUrl = canvas.toDataURL('image/png');
    // Pre-populate front image of PVC Card Maker
    if (typeof window.pvcSetFrontDataUrl === 'function') {
      window.pvcSetFrontDataUrl(dataUrl);
    } else {
      localStorage.setItem('mos_pvc_front_preload', dataUrl);
    }
    if (typeof openFeature === 'function') {
      openFeature('pvcCard');
      if (typeof showToast === 'function') showToast('Scanned document PVC Card Maker me load ho gaya! 🪪', 'success');
    }
  };

  // ==========================================
  // ⚡ GITHUB ACTIONS WORKFLOW CONTROLLER
  // ==========================================
  window.openWorkflowModal = async function () {
    const modal = document.getElementById('mosWorkflowModal');
    if (!modal) return;
    modal.style.display = 'flex';
    const codeEl = document.getElementById('workflowYamlCode');
    if (codeEl && (!window._mosWorkflowYamlText || codeEl.textContent.includes('Loading'))) {
      try {
        const res = await fetch('/download/workflow');
        if (res.ok) {
          const yamlText = await res.text();
          codeEl.textContent = yamlText;
          window._mosWorkflowYamlText = yamlText;
        } else {
          codeEl.textContent = '// Could not fetch workflow file from server';
        }
      } catch (e) {
        console.warn('Failed to fetch workflow YAML:', e);
        if (codeEl) codeEl.textContent = '// Error loading workflow: ' + (e.message || 'Network error');
      }
    }
  };

  window.closeWorkflowModal = function () {
    const modal = document.getElementById('mosWorkflowModal');
    if (modal) modal.style.display = 'none';
  };

  window.copyWorkflowYaml = function () {
    const codeEl = document.getElementById('workflowYamlCode');
    const text = window._mosWorkflowYamlText || (codeEl ? codeEl.textContent : '');
    if (!text || text.includes('Loading')) {
      if (typeof showToast === 'function') showToast('Workflow file load ho rahi hai, dobara try karein...', 'warning');
      return;
    }
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(() => {
        if (typeof showToast === 'function') showToast('⚡ GitHub Actions Workflow YAML copy ho gaya! 📋', 'success');
      }).catch(() => {
        fallbackCopyWorkflowText(text);
      });
    } else {
      fallbackCopyWorkflowText(text);
    }
  };

  function fallbackCopyWorkflowText(text) {
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.style.position = 'fixed';
    ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.select();
    try {
      document.execCommand('copy');
      if (typeof showToast === 'function') showToast('⚡ GitHub Actions Workflow YAML copy ho gaya! 📋', 'success');
    } catch (e) {
      if (typeof showToast === 'function') showToast('Text copy karne ke liye select karein', 'error');
    }
    document.body.removeChild(ta);
  }

  // Sync Global Desktop indicators on startup
  setTimeout(() => {
    const isGlobalDesktop = localStorage.getItem('mos_desktop_mode_global') === 'true';
    updateGlobalDesktopIndicators(isGlobalDesktop);
  }, 300);

  if (document.readyState === 'loading') {
    window.addEventListener('DOMContentLoaded', initMosBridge);
  } else {
    initMosBridge();
  }
})();


