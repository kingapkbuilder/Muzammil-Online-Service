import { initializeApp } from 'firebase/app';
import {
  getFirestore,
  doc,
  setDoc,
  getDoc,
  deleteDoc,
  collection,
  getDocs,
  onSnapshot,
  Firestore,
  Unsubscribe
} from 'firebase/firestore';

const firebaseConfig = {
  projectId: "isentropic-guard-7smzh",
  appId: "1:921992138219:web:ab821123fe534cbc0b9dae",
  apiKey: "AIzaSyCt3NGwK1PnEYEQGmTErg-s_bEUpSNZXyo",
  authDomain: "isentropic-guard-7smzh.firebaseapp.com",
  firestoreDatabaseId: "ai-studio-muzammilonlinese-ab4b6a22-51fb-4956-9a68-432f8cad9d34",
  storageBucket: "isentropic-guard-7smzh.firebasestorage.app",
  messagingSenderId: "921992138219"
};

let db: Firestore | null = null;
let currentWatcherUnsub: Unsubscribe | null = null;

export function initFirebase() {
  if (db) return db;
  try {
    const app = initializeApp({
      apiKey: firebaseConfig.apiKey,
      authDomain: firebaseConfig.authDomain,
      projectId: firebaseConfig.projectId,
      storageBucket: firebaseConfig.storageBucket,
      messagingSenderId: firebaseConfig.messagingSenderId,
      appId: firebaseConfig.appId
    });
    db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
    console.log('⚡ Firebase Realtime Sync Initialized with database:', firebaseConfig.firestoreDatabaseId);
    return db;
  } catch (err) {
    console.warn('Firebase init error:', err);
    return null;
  }
}

export async function saveUserToCloud(user: any): Promise<boolean> {
  const firestore = initFirebase();
  if (!firestore || !user || !user.username) return false;
  const username = String(user.username).trim().toLowerCase();
  try {
    const payload = {
      username: username,
      displayName: user.displayName || user.display_name || user.username,
      phone: user.phone || '',
      shopName: user.shopName || user.shop_name || '',
      role: user.role || 'operator',
      status: user.status || 'active',
      passwordPlain: user.password || user.passwordPlain || '',
      passwordHash: user.password_hash || user.passwordHash || '',
      expiresAt: user.expires_at || user.expiresAt || null,
      updatedAt: new Date().toISOString()
    };
    await setDoc(doc(firestore, 'users', username), payload, { merge: true });
    console.log(`✅ [Firebase Cloud] User @${username} saved successfully.`);
    return true;
  } catch (e) {
    console.warn('Firebase save user error:', e);
    return false;
  }
}

export async function deleteUserFromCloud(username: string): Promise<boolean> {
  const firestore = initFirebase();
  if (!firestore || !username) return false;
  const clean = String(username).trim().toLowerCase();
  try {
    await deleteDoc(doc(firestore, 'users', clean));
    console.log(`🗑️ [Firebase Cloud] User @${clean} deleted.`);
    return true;
  } catch (e) {
    console.warn('Firebase delete user error:', e);
    return false;
  }
}

export async function getUserFromCloud(username: string): Promise<any | null> {
  const firestore = initFirebase();
  if (!firestore || !username) return null;
  const clean = String(username).trim().toLowerCase();
  try {
    const snap = await getDoc(doc(firestore, 'users', clean));
    if (snap.exists()) {
      return snap.data();
    }
    return null;
  } catch (e) {
    console.warn('Firebase get user error:', e);
    return null;
  }
}

export async function getAllUsersFromCloud(): Promise<any[]> {
  const firestore = initFirebase();
  if (!firestore) return [];
  try {
    const snap = await getDocs(collection(firestore, 'users'));
    const list: any[] = [];
    snap.forEach(d => list.push(d.data()));
    return list;
  } catch (e) {
    console.warn('Firebase get all users error:', e);
    return [];
  }
}

export function startUserRealtimeWatch(
  username: string,
  onKickOut: (reason: string) => void,
  onUpdate?: (data: any) => void
): () => void {
  const firestore = initFirebase();
  if (!firestore || !username) return () => {};
  const clean = String(username).trim().toLowerCase();
  if (clean === 'admin' || clean === 'imran') return () => {};

  if (currentWatcherUnsub) {
    currentWatcherUnsub();
    currentWatcherUnsub = null;
  }

  try {
    console.log(`📡 [Firebase Realtime] Listening to @${clean} changes...`);
    currentWatcherUnsub = onSnapshot(
      doc(firestore, 'users', clean),
      (snap) => {
        if (!snap.exists()) {
          console.warn(`🚨 [Firebase Realtime] User @${clean} was DELETED by admin!`);
          onKickOut('User account has been deleted by Master Admin Imran Khan.');
          return;
        }
        const data = snap.data();
        if (data.status === 'blocked') {
          console.warn(`🚨 [Firebase Realtime] User @${clean} was BLOCKED!`);
          onKickOut('Aapka account Master Admin dwara block kar diya gaya hai.');
          return;
        }
        if (data.expiresAt) {
          const expTime = new Date(data.expiresAt).getTime();
          if (expTime < Date.now()) {
            console.warn(`🚨 [Firebase Realtime] User @${clean} validity EXPIRED!`);
            onKickOut('Aapka account plan expire ho chuka hai. Validity extend karayein.');
            return;
          }
        }
        if (onUpdate) {
          onUpdate(data);
        }
      },
      (err) => {
        console.warn('Realtime watcher listener error:', err);
      }
    );
  } catch (err) {
    console.warn('Failed to start realtime watcher:', err);
  }

  return () => {
    if (currentWatcherUnsub) {
      currentWatcherUnsub();
      currentWatcherUnsub = null;
    }
  };
}

// Expose on global window object for web-bridge.js and all scripts
const MosFirebase = {
  init: initFirebase,
  saveUser: saveUserToCloud,
  deleteUser: deleteUserFromCloud,
  getUser: getUserFromCloud,
  getAllUsers: getAllUsersFromCloud,
  watchUser: startUserRealtimeWatch,
};

(window as any).MosFirebase = MosFirebase;
export default MosFirebase;
