import express from 'express';
import cors from 'cors';
import path from 'path';
import fs from 'fs';
import crypto from 'crypto';
import { Pool } from 'pg';
import { initializeApp as initFirebaseApp } from 'firebase/app';
import { getFirestore, doc, setDoc, deleteDoc } from 'firebase/firestore';

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors({ origin: '*' }));
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Realtime Firebase Firestore Cloud Database
let firestoreDb: any = null;
try {
  const firebaseConfig = {
    projectId: "isentropic-guard-7smzh",
    appId: "1:921992138219:web:ab821123fe534cbc0b9dae",
    apiKey: "AIzaSyCt3NGwK1PnEYEQGmTErg-s_bEUpSNZXyo",
    authDomain: "isentropic-guard-7smzh.firebaseapp.com",
    firestoreDatabaseId: "ai-studio-muzammilonlinese-ab4b6a22-51fb-4956-9a68-432f8cad9d34",
    storageBucket: "isentropic-guard-7smzh.firebasestorage.app",
    messagingSenderId: "921992138219"
  };
  const fbApp = initFirebaseApp(firebaseConfig);
  firestoreDb = getFirestore(fbApp, firebaseConfig.firestoreDatabaseId);
  console.log('⚡ Firebase Realtime Sync connected in server.ts');
} catch (e) {
  console.warn('Backend Firebase init error:', e);
}

async function syncUserToFirestore(user: any) {
  if (!firestoreDb || !user || !user.username) return;
  const username = String(user.username).trim().toLowerCase();
  try {
    await setDoc(doc(firestoreDb, 'users', username), {
      username: username,
      displayName: user.displayName || user.display_name || user.username,
      phone: user.phone || '',
      shopName: user.shopName || user.shop_name || '',
      role: user.role || 'operator',
      status: user.status || 'active',
      passwordPlain: user.password || user.passwordPlain || '',
      passwordHash: user.password_hash || user.passwordHash || '',
      expiresAt: user.expires_at || user.expiresAt || null,
      updatedAt: new Date().toISOString()
    }, { merge: true });
    console.log(`[Firestore Backend Sync] User @${username} synced in realtime.`);
  } catch (e) {
    console.warn('Firestore sync user error:', e);
  }
}

async function deleteUserFromFirestore(username: string) {
  if (!firestoreDb || !username) return;
  const clean = String(username).trim().toLowerCase();
  try {
    await deleteDoc(doc(firestoreDb, 'users', clean));
    console.log(`[Firestore Backend Sync] User @${clean} deleted in realtime.`);
  } catch (e) {
    console.warn('Firestore delete user error:', e);
  }
}

// Cloud SQL Database Connection Pool
const pool = new Pool({
  host: process.env.SQL_HOST,
  user: process.env.SQL_USER,
  password: process.env.SQL_PASSWORD,
  database: process.env.SQL_DB_NAME,
  max: 10,
  idleTimeoutMillis: 30000,
});

function hashPassword(password: string): string {
  return crypto.createHash('sha256').update(password).digest('hex');
}

function isMasterAdmin(username: string): boolean {
  const u = (username || '').toLowerCase();
  return u === 'admin' || u === 'imran' || u === '9561460313';
}

function getFallbackUsersFromFile(): any[] {
  try {
    const candidates = [
      path.join(process.cwd(), 'data', 'users.json'),
      path.join(process.cwd(), 'public', 'users.json'),
      path.join(process.cwd(), 'android', 'app', 'src', 'main', 'assets', 'users.json'),
    ];
    for (const p of candidates) {
      if (fs.existsSync(p)) {
        const raw = fs.readFileSync(p, 'utf8');
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    }
  } catch (e) {
    console.warn('Error reading fallback users from file:', e);
  }
  return [];
}

async function syncUsersToFile(extraUser?: any) {
  try {
    let rows: any[] = [];
    try {
      const q = await pool.query('SELECT * FROM users ORDER BY id ASC');
      rows = q.rows;
    } catch (e) {
      rows = getFallbackUsersFromFile();
    }
    if (extraUser && !rows.some(u => String(u.username).toLowerCase() === String(extraUser.username).toLowerCase())) {
      rows.push(extraUser);
    }
    const cleanUsers = rows.map(u => ({
      id: u.id,
      uid: u.uid || `usr_${u.username}`,
      username: u.username,
      display_name: u.display_name || u.displayName || u.username,
      phone: u.phone,
      shop_name: u.shop_name || u.shopName,
      role: u.role || 'operator',
      status: u.status || 'active',
      password: u.password || (u.role === 'admin' ? 'muzammil786' : undefined),
      password_hash: u.password_hash || (u.password ? hashPassword(u.password) : undefined),
      expires_at: u.role === 'admin' ? null : u.expires_at,
      created_at: u.created_at || new Date().toISOString()
    }));

    const targets = [
      path.join(process.cwd(), 'data', 'users.json'),
      path.join(process.cwd(), 'public', 'users.json'),
      path.join(process.cwd(), 'android', 'app', 'src', 'main', 'assets', 'users.json')
    ];
    const jsonStr = JSON.stringify(cleanUsers, null, 2);
    for (const t of targets) {
      try {
        const dir = path.dirname(t);
        if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
        fs.writeFileSync(t, jsonStr, 'utf8');
      } catch (err) {}
    }
  } catch (err) {
    console.error('syncUsersToFile error:', err);
  }
}

// Direct Firebase Firestore Dual-Cloud Sync Helper (Guarantees multi-device login across all phones)
async function syncUserToFirestore(user: any) {
  if (!user || !user.username) return;
  const username = String(user.username).trim().toLowerCase();
  const apiKey = 'AIzaSyCt3NGwK1PnEYEQGmTErg-s_bEUpSNZXyo';
  const dbId = 'ai-studio-muzammilonlinese-ab4b6a22-51fb-4956-9a68-432f8cad9d34';
  const url = `https://firestore.googleapis.com/v1/projects/isentropic-guard-7smzh/databases/${dbId}/documents/users/${username}?key=${apiKey}`;

  const fields: Record<string, any> = {
    username: { stringValue: username },
    displayName: { stringValue: user.display_name || user.displayName || user.username },
    phone: { stringValue: user.phone || '' },
    shopName: { stringValue: user.shop_name || user.shopName || '' },
    role: { stringValue: user.role || 'operator' },
    status: { stringValue: user.status || 'active' },
    updatedAt: { stringValue: new Date().toISOString() }
  };
  if (user.password) fields.passwordPlain = { stringValue: String(user.password) };
  if (user.password_hash || user.passwordHash) fields.passwordHash = { stringValue: String(user.password_hash || user.passwordHash) };
  if (user.expires_at || user.expiresAt) {
    fields.expiresAt = { stringValue: new Date(user.expires_at || user.expiresAt).toISOString() };
  } else {
    fields.expiresAt = { nullValue: null };
  }

  try {
    await fetch(url, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ fields })
    });
    console.log(`📡 [Dual-Cloud Sync] Pushed @${username} to Firebase Firestore`);
  } catch (e) {
    console.warn('Firestore REST push error:', e);
  }
}

async function deleteUserFromFirestore(username: string) {
  if (!username) return;
  const clean = String(username).trim().toLowerCase();
  const apiKey = 'AIzaSyCt3NGwK1PnEYEQGmTErg-s_bEUpSNZXyo';
  const dbId = 'ai-studio-muzammilonlinese-ab4b6a22-51fb-4956-9a68-432f8cad9d34';
  const url = `https://firestore.googleapis.com/v1/projects/isentropic-guard-7smzh/databases/${dbId}/documents/users/${clean}?key=${apiKey}`;
  try {
    await fetch(url, { method: 'DELETE' });
    console.log(`📡 [Dual-Cloud Sync] Deleted @${clean} from Firebase Firestore`);
  } catch (e) {}
}

// -------------------------------------------------------------
// AUTH & USERS API (CLOUD SQL POSTGRESQL + PERSISTENT OFFLINE BACKEND)
// -------------------------------------------------------------

// Public directory of registered operators for multi-device sync
app.get('/api/auth/public-users', async (req, res) => {
  try {
    let users: any[] = [];
    try {
      const q = await pool.query(
        "SELECT id, uid, username, display_name, phone, shop_name, role, status, expires_at, password_hash FROM users WHERE status != 'blocked' ORDER BY id ASC"
      );
      users = q.rows;
    } catch (e) {
      users = getFallbackUsersFromFile();
    }
    const safe = users.map(u => ({
      id: u.id,
      uid: u.uid || `usr_${u.username}`,
      username: u.username,
      displayName: u.display_name || u.displayName || u.username,
      phone: u.phone,
      shopName: u.shop_name || u.shopName,
      role: u.role || 'operator',
      status: u.status || 'active',
      expiresAt: (u.role === 'admin' || isMasterAdmin(u.username)) ? null : (u.expires_at || u.expiresAt),
      passwordHash: (u.role === 'admin' || isMasterAdmin(u.username)) ? null : (u.password_hash || u.passwordHash),
      hasPlainPassword: !!u.password
    }));
    res.json({ success: true, users: safe });
  } catch (err: any) {
    res.json({ success: true, users: [] });
  }
});

// 1. Unified Login Endpoint with Instant Database + JSON Fallback
app.post('/api/auth/login', async (req, res) => {
  const { username, password } = req.body || {};
  if (!username || !password) {
    return res.status(400).json({ success: false, error: 'Username aur password zaroori hain' });
  }

  const cleanUser = String(username).trim();
  const inputHash = hashPassword(String(password));
  const isMaster = isMasterAdmin(cleanUser);

  let dbUser: any = null;

  try {
    // 1. Query PostgreSQL by username first
    let result = await pool.query(
      `SELECT * FROM users WHERE LOWER(username) = LOWER($1) LIMIT 1`,
      [cleanUser]
    );
    // 2. If not found by username, query by phone
    if (result.rows.length === 0) {
      result = await pool.query(
        `SELECT * FROM users WHERE phone = $1 ORDER BY id DESC LIMIT 1`,
        [cleanUser]
      );
    }
    if (result.rows.length > 0) {
      dbUser = result.rows[0];
    }
  } catch (dbErr) {
    console.warn('Database query error in login, falling back to file catalog:', dbErr);
  }

  // 3. Fallback to file users catalog if not found in DB or DB down
  if (!dbUser) {
    const fileUsers = getFallbackUsersFromFile();
    const matched = fileUsers.find(
      u => String(u.username).toLowerCase() === cleanUser.toLowerCase() || String(u.phone).trim() === cleanUser
    );
    if (matched) {
      dbUser = matched;
    }
  }

  // Master Admin fallback if still not found
  if (!dbUser && isMaster && password === 'muzammil786') {
    const masterUser = {
      uid: 'admin_imran_master',
      username: 'admin',
      displayName: 'Imran Khan (Master Admin)',
      role: 'admin',
      status: 'active',
      shopName: 'Muzammil Online Service Head Office',
      expiresAt: null,
    };
    return res.json({ success: true, user: masterUser });
  }

  if (!dbUser) {
    return res.status(401).json({ success: false, error: 'Invalid username ya password. Kripya sahi details darj karein.' });
  }

  const isDbAdmin = dbUser.role === 'admin' || isMasterAdmin(dbUser.username);

  // STRICT MASTER ADMIN PASSWORD CHECK
  if (isMaster || isDbAdmin) {
    if (password !== 'muzammil786') {
      return res.status(401).json({ success: false, error: '❌ Galat password! Kripya sahi password enter karein.' });
    }
  } else {
    // OPERATOR PASSWORD CHECK (accepts plain password or SHA-256 hash)
    const expectedHash = dbUser.password_hash;
    const expectedPlain = dbUser.password;
    const passMatches = (expectedPlain && expectedPlain === password) ||
                        (expectedHash && (expectedHash === inputHash || expectedHash === password));
    if (!passMatches) {
      return res.status(401).json({ success: false, error: '❌ Galat password! Kripya sahi password enter karein.' });
    }
  }

  // Blocked check
  if (dbUser.status === 'blocked') {
    return res.status(403).json({ success: false, error: 'Aapka account admin dwara block kar diya gaya hai.' });
  }

  // Expiration check for operators
  if (!isDbAdmin && (dbUser.expires_at || dbUser.expiresAt)) {
    const expDate = new Date(dbUser.expires_at || dbUser.expiresAt);
    if (expDate.getTime() < Date.now()) {
      return res.status(403).json({
        success: false,
        error: `Aapka account expire ho chuka hai (${expDate.toLocaleDateString('en-IN')}). Kripya Master Admin (Imran Khan: 9561460313) se contact karein.`,
      });
    }
  }

  // Update last_login_at in DB asynchronously
  try {
    if (dbUser.id) {
      pool.query(`UPDATE users SET last_login_at = NOW() WHERE id = $1`, [dbUser.id]).catch(() => {});
    }
  } catch (e) {}

  const safeUser = {
    id: dbUser.id,
    uid: dbUser.uid || `usr_${dbUser.username}`,
    username: dbUser.username,
    displayName: dbUser.display_name || dbUser.displayName || dbUser.username,
    phone: dbUser.phone,
    shopName: dbUser.shop_name || dbUser.shopName,
    role: dbUser.role || 'operator',
    status: dbUser.status || 'active',
    expiresAt: isDbAdmin ? null : (dbUser.expires_at || dbUser.expiresAt),
  };

  return res.json({ success: true, user: safeUser });
});

// 2. Session verification
app.post('/api/auth/verify-session', async (req, res) => {
  const { username, uid } = req.body || {};
  if (!username && !uid) {
    return res.json({ valid: false, error: 'No session' });
  }

  if (isMasterAdmin(username)) {
    return res.json({
      valid: true,
      user: {
        uid: uid || 'admin_master_1',
        username: 'admin',
        displayName: 'Imran Khan (Master Admin)',
        role: 'admin',
        status: 'active',
        expiresAt: null, // Master Admin NEVER expires
      },
    });
  }

  try {
    const result = await pool.query(
      `SELECT * FROM users WHERE (uid = $1 OR LOWER(username) = LOWER($2)) LIMIT 1`,
      [uid || '', username || '']
    );

    if (result.rows.length === 0) {
      return res.json({ valid: false, error: 'User nahi mila' });
    }

    const u = result.rows[0];
    if (u.status === 'blocked') {
      return res.json({ valid: false, error: 'Account blocked' });
    }

    // Check expiration for staff
    if (u.role !== 'admin' && u.expires_at) {
      const expDate = new Date(u.expires_at);
      if (expDate.getTime() < Date.now()) {
        return res.json({
          valid: false,
          error: `Aapka account expire ho chuka hai (${expDate.toLocaleDateString('en-IN')}). Contact Master Admin.`,
        });
      }
    }

    return res.json({
      valid: true,
      user: {
        id: u.id,
        uid: u.uid,
        username: u.username,
        displayName: u.display_name,
        phone: u.phone,
        shopName: u.shop_name,
        role: u.role,
        status: u.status,
        expiresAt: u.role === 'admin' ? null : u.expires_at,
      },
    });
  } catch (e: any) {
    return res.json({ valid: true }); // Graceful fallback
  }
});

// 3. Admin: List All Users & Operators with Expiry info
app.get('/api/admin/users', async (req, res) => {
  const adminKey = req.headers['x-admin-key'];
  if (adminKey !== 'muzammil786') {
    return res.status(403).json({ success: false, error: 'Unauthorized: Admin key required' });
  }

  try {
    const result = await pool.query(
      `SELECT id, uid, username, display_name, phone, shop_name, role, status, created_at, last_login_at, expires_at 
       FROM users ORDER BY id DESC`
    );
    res.json({ success: true, users: result.rows });
  } catch (err: any) {
    console.error('List users error:', err);
    res.status(500).json({ success: false, error: err.message });
  }
});

// 4. Admin: Create New User / Operator with Expiry Option
app.post('/api/admin/users/create', async (req, res) => {
  const adminKey = req.headers['x-admin-key'];
  if (adminKey !== 'muzammil786') {
    return res.status(403).json({ success: false, error: 'Unauthorized: Admin key required' });
  }

  const { displayName, username, password, phone, shopName, role, expireDays, expireDate } = req.body || {};

  if (!displayName || !username || !password) {
    return res.status(400).json({ success: false, error: 'Name, username aur password sab zaroori hain' });
  }

  const cleanUser = String(username).trim();
  const passwordHash = hashPassword(String(password));
  const userRole = role === 'admin' ? 'admin' : 'operator';

  // Calculate Expiry Date:
  // If user is Admin -> expires_at is ALWAYS null (Master Admin never expires)
  let calculatedExpiresAt: string | null = null;
  if (userRole !== 'admin') {
    if (expireDate) {
      calculatedExpiresAt = new Date(expireDate).toISOString();
    } else if (req.body.expireMinutes && Number(req.body.expireMinutes) > 0) {
      const d = new Date();
      d.setMinutes(d.getMinutes() + Number(req.body.expireMinutes));
      calculatedExpiresAt = d.toISOString();
    } else if (expireDays && Number(expireDays) > 0) {
      const d = new Date();
      d.setDate(d.getDate() + Number(expireDays));
      calculatedExpiresAt = d.toISOString();
    }
  }

  try {
    const exists = await pool.query(`SELECT id FROM users WHERE LOWER(username) = LOWER($1) LIMIT 1`, [cleanUser]);
    if (exists.rows.length > 0) {
      return res.status(400).json({ success: false, error: 'Yeh username pehle se exist karta hai.' });
    }

    const uid = 'usr_' + cleanUser + '_' + Math.random().toString(36).substring(2, 9);
    const insertRes = await pool.query(
      `INSERT INTO users (uid, username, display_name, password_hash, phone, shop_name, role, status, created_at, expires_at)
       VALUES ($1, $2, $3, $4, $5, $6, $7, 'active', NOW(), $8)
       RETURNING id, uid, username, display_name, phone, shop_name, role, status, created_at, expires_at`,
      [uid, cleanUser, displayName, passwordHash, phone || null, shopName || null, userRole, calculatedExpiresAt]
    );

    const newUser = insertRes.rows[0];
    await syncUsersToFile({ ...newUser, password });
    await syncUserToFirestore({ ...newUser, password });
    res.json({ success: true, user: newUser });
  } catch (err: any) {
    console.error('Create user error:', err);
    res.status(500).json({ success: false, error: err.message });
  }
});

// 5. Admin: Update User Expiry / Status / Password
app.post('/api/admin/users/update-expiry', async (req, res) => {
  const adminKey = req.headers['x-admin-key'];
  if (adminKey !== 'muzammil786') {
    return res.status(403).json({ success: false, error: 'Unauthorized' });
  }

  const { id, expireDays, expireDate, removeExpiry } = req.body || {};
  if (!id) return res.status(400).json({ success: false, error: 'User ID zaroori hai' });

  try {
    let expVal: string | null = null;
    if (removeExpiry) {
      expVal = null;
    } else if (expireDate) {
      expVal = new Date(expireDate).toISOString();
    } else if (req.body.expireMinutes && Number(req.body.expireMinutes) > 0) {
      const d = new Date();
      d.setMinutes(d.getMinutes() + Number(req.body.expireMinutes));
      expVal = d.toISOString();
    } else if (expireDays && Number(expireDays) > 0) {
      const d = new Date();
      d.setDate(d.getDate() + Number(expireDays));
      expVal = d.toISOString();
    }

    await pool.query(`UPDATE users SET expires_at = $1 WHERE id = $2`, [expVal, id]);
    await syncUsersToFile();
    try {
      const q = await pool.query('SELECT username FROM users WHERE id = $1', [id]);
      if (q.rows[0]) {
        await syncUserToFirestore({ username: q.rows[0].username, expires_at: expVal });
      }
    } catch (e) {}
    res.json({ success: true, message: 'User expiry updated' });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 6. Admin: Toggle User Status
app.post('/api/admin/users/toggle-status', async (req, res) => {
  const adminKey = req.headers['x-admin-key'];
  if (adminKey !== 'muzammil786') {
    return res.status(403).json({ success: false, error: 'Unauthorized' });
  }
  const { id, status } = req.body || {};
  try {
    await pool.query(`UPDATE users SET status = $1 WHERE id = $2`, [status, id]);
    await syncUsersToFile();
    try {
      const q = await pool.query('SELECT username FROM users WHERE id = $1', [id]);
      if (q.rows[0]) {
        await syncUserToFirestore({ username: q.rows[0].username, status });
      }
    } catch (e) {}
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 7. Admin: Reset Password
app.post('/api/admin/users/reset-password', async (req, res) => {
  const adminKey = req.headers['x-admin-key'];
  if (adminKey !== 'muzammil786') {
    return res.status(403).json({ success: false, error: 'Unauthorized' });
  }
  const { id, newPassword } = req.body || {};
  if (!newPassword || newPassword.length < 4) {
    return res.status(400).json({ success: false, error: 'Password min 4 chars' });
  }
  try {
    const hash = hashPassword(newPassword);
    await pool.query(`UPDATE users SET password_hash = $1 WHERE id = $2`, [hash, id]);
    await syncUsersToFile();
    try {
      const q = await pool.query('SELECT username FROM users WHERE id = $1', [id]);
      if (q.rows[0]) {
        await syncUserToFirestore({ username: q.rows[0].username, password: newPassword, password_hash: hash });
      }
    } catch (e) {}
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 8. Admin: Delete User (Supports ID, UID, and Username)
app.post('/api/admin/users/delete', async (req, res) => {
  const adminKey = req.headers['x-admin-key'];
  if (adminKey !== 'muzammil786') {
    return res.status(403).json({ success: false, error: 'Unauthorized' });
  }
  const { id, username } = req.body || {};
  if (!id && !username) {
    return res.status(400).json({ success: false, error: 'User ID ya Username zaroori hai' });
  }

  const cleanUser = String(username || '').trim().toLowerCase();
  // Protect Master Admin from deletion
  if (cleanUser === 'admin' || cleanUser === 'imran' || cleanUser === '9561460313') {
    return res.status(400).json({ success: false, error: 'Master Admin ko delete nahi kiya ja sakta' });
  }

  try {
    let numId = Number(id);
    if (isNaN(numId) || !numId) numId = -1;

    await pool.query(
      `DELETE FROM users WHERE (id = $1 OR LOWER(username) = LOWER($2) OR uid = $3) AND LOWER(username) NOT IN ('admin', 'imran')`,
      [numId, cleanUser, String(id || '')]
    );

    // Also remove from static json files immediately
    let fileUsers = getFallbackUsersFromFile();
    fileUsers = fileUsers.filter(u => {
      const matchId = numId > 0 && Number(u.id) === numId;
      const matchUser = cleanUser && String(u.username).toLowerCase() === cleanUser;
      const matchUid = id && String(u.uid) === String(id);
      return !matchId && !matchUser && !matchUid;
    });

    const targets = [
      path.join(process.cwd(), 'data', 'users.json'),
      path.join(process.cwd(), 'public', 'users.json'),
      path.join(process.cwd(), 'android', 'app', 'src', 'main', 'assets', 'users.json')
    ];
    for (const t of targets) {
      try {
        fs.writeFileSync(t, JSON.stringify(fileUsers, null, 2), 'utf8');
      } catch (e) {}
    }

    await syncUsersToFile();
    await deleteUserFromFirestore(cleanUser);
    res.json({ success: true, message: 'User deleted successfully' });
  } catch (err: any) {
    console.error('Delete user error:', err);
    res.status(500).json({ success: false, error: err.message });
  }
});

// 9. Admin: Manual Trigger to Sync Database to File
app.post('/api/admin/users/sync-offline', async (req, res) => {
  const adminKey = req.headers['x-admin-key'];
  if (adminKey !== 'muzammil786') {
    return res.status(403).json({ success: false, error: 'Unauthorized' });
  }
  try {
    await syncUsersToFile();
    res.json({ success: true, message: 'All users synced to offline files' });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// -------------------------------------------------------------
// DATABASE OVERVIEW & SYNC
// -------------------------------------------------------------
app.get('/api/server/database-overview', async (req, res) => {
  try {
    const receiptsCount = await pool.query('SELECT count(*) FROM receipts');
    const customersCount = await pool.query('SELECT count(*) FROM customers');
    const cvCount = await pool.query('SELECT count(*) FROM cv_drafts');
    const appStoreCount = await pool.query('SELECT count(*) FROM app_store');
    const licensesCount = await pool.query('SELECT count(*) FROM licenses');
    const usersCount = await pool.query('SELECT count(*) FROM users');

    const recentBills = await pool.query('SELECT * FROM receipts ORDER BY id DESC LIMIT 20');
    const recentCustomers = await pool.query('SELECT * FROM customers ORDER BY id DESC LIMIT 20');
    const recentCv = await pool.query('SELECT * FROM cv_drafts ORDER BY id DESC LIMIT 20');
    const appStoreRows = await pool.query('SELECT * FROM app_store LIMIT 20');

    res.json({
      success: true,
      tables: {
        receipts: { count: Number(receiptsCount.rows[0].count), rows: recentBills.rows },
        customers: { count: Number(customersCount.rows[0].count), rows: recentCustomers.rows },
        cv_drafts: { count: Number(cvCount.rows[0].count), rows: recentCv.rows },
        app_store: { count: Number(appStoreCount.rows[0].count), rows: appStoreRows.rows },
        licenses: { count: Number(licensesCount.rows[0].count) },
        users: { count: Number(usersCount.rows[0].count) },
      },
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.post('/api/sync/push', async (req, res) => {
  const { userUid, records } = req.body || {};
  try {
    if (records) {
      for (const [key, val] of Object.entries(records)) {
        await pool.query(
          `INSERT INTO app_store (user_uid, store_key, payload, updated_at) 
           VALUES ($1, $2, $3, NOW()) 
           ON CONFLICT (user_uid, store_key) 
           DO UPDATE SET payload = $3, updated_at = NOW()`,
          [userUid || 'operator_default', key, typeof val === 'string' ? val : JSON.stringify(val)]
        ).catch(() => {});
      }
    }
    res.json({ success: true });
  } catch (err: any) {
    res.json({ success: false, error: err.message });
  }
});

app.get('/api/sync/pull', async (req, res) => {
  const { userUid } = req.query;
  try {
    const rows = await pool.query(`SELECT store_key, payload FROM app_store WHERE user_uid = $1`, [
      userUid || 'operator_default',
    ]);
    const records: Record<string, any> = {};
    rows.rows.forEach((r) => {
      records[r.store_key] = r.payload;
    });
    res.json({ success: true, records });
  } catch (err: any) {
    res.json({ success: false, error: err.message });
  }
});

// -------------------------------------------------------------
// DYNAMIC SERVICES MANAGEMENT (MASTER ADMIN & PUBLIC LIST)
// Backed by Cloud SQL PostgreSQL app_store for persistence
// -------------------------------------------------------------

async function getStoredServices(): Promise<any[]> {
  try {
    const res = await pool.query(
      'SELECT payload FROM app_store WHERE store_key = $1 AND user_uid = $2 ORDER BY id DESC LIMIT 1',
      ['custom_services', 'global_master_admin']
    );
    if (res.rows.length > 0 && res.rows[0].payload) {
      return JSON.parse(res.rows[0].payload);
    }
  } catch (err: any) {
    console.warn('getStoredServices error:', err.message);
  }
  return [];
}

async function saveStoredServices(services: any[]): Promise<boolean> {
  try {
    const payload = JSON.stringify(services);
    const existing = await pool.query(
      'SELECT id FROM app_store WHERE store_key = $1 AND user_uid = $2 LIMIT 1',
      ['custom_services', 'global_master_admin']
    );
    if (existing.rows.length > 0) {
      await pool.query(
        'UPDATE app_store SET payload = $1, updated_at = NOW() WHERE id = $2',
        [payload, existing.rows[0].id]
      );
    } else {
      await pool.query(
        'INSERT INTO app_store (user_uid, store_key, payload, updated_at) VALUES ($1, $2, $3, NOW())',
        ['global_master_admin', 'custom_services', payload]
      );
    }
    return true;
  } catch (err: any) {
    console.error('saveStoredServices error:', err.message);
    return false;
  }
}

// 1. Public list of active custom services (for home screen & all users)
app.get('/api/services', async (req, res) => {
  try {
    const all = await getStoredServices();
    const active = all.filter(s => s.is_active !== false);
    res.json({ success: true, services: active });
  } catch (err: any) {
    res.json({ success: true, services: [] });
  }
});

// 2. Admin list of all services (active + inactive)
app.get('/api/admin/services', async (req, res) => {
  const adminKey = req.headers['x-admin-key'];
  if (adminKey !== 'muzammil786') {
    return res.status(403).json({ success: false, error: 'Unauthorized: Admin key required' });
  }
  try {
    const all = await getStoredServices();
    res.json({ success: true, services: all });
  } catch (err: any) {
    res.json({ success: true, services: [] });
  }
});

// 3. Admin create custom service
app.post('/api/admin/services/create', async (req, res) => {
  const adminKey = req.headers['x-admin-key'];
  if (adminKey !== 'muzammil786') {
    return res.status(403).json({ success: false, error: 'Unauthorized: Admin key required' });
  }
  const { title, url, icon, section, sectionTitle, description, sortOrder } = req.body || {};
  if (!title || !url) {
    return res.status(400).json({ success: false, error: 'Title aur URL zaroori hain' });
  }
  try {
    const all = await getStoredServices();
    const newService = {
      id: 'srv_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      title: String(title).trim(),
      url: String(url).trim(),
      icon: (icon || '🌐').trim(),
      section: (section || 'central').trim(),
      section_title: sectionTitle ? String(sectionTitle).trim() : null,
      description: description ? String(description).trim() : 'Official portal',
      sort_order: Number(sortOrder) || all.length + 1,
      is_active: true,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };
    all.push(newService);
    await saveStoredServices(all);
    res.json({ success: true, service: newService });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 4. Admin update custom service
app.post('/api/admin/services/update', async (req, res) => {
  const adminKey = req.headers['x-admin-key'];
  if (adminKey !== 'muzammil786') {
    return res.status(403).json({ success: false, error: 'Unauthorized: Admin key required' });
  }
  const { id, title, url, icon, section, sectionTitle, description, sortOrder, isActive } = req.body || {};
  if (!id) return res.status(400).json({ success: false, error: 'Service ID zaroori hai' });
  try {
    const all = await getStoredServices();
    const idx = all.findIndex(s => String(s.id) === String(id));
    if (idx === -1) {
      return res.status(404).json({ success: false, error: 'Service nahi mili' });
    }
    all[idx] = {
      ...all[idx],
      title: title !== undefined ? String(title).trim() : all[idx].title,
      url: url !== undefined ? String(url).trim() : all[idx].url,
      icon: icon !== undefined ? String(icon).trim() : all[idx].icon,
      section: section !== undefined ? String(section).trim() : all[idx].section,
      section_title: sectionTitle !== undefined ? (sectionTitle ? String(sectionTitle).trim() : null) : all[idx].section_title,
      description: description !== undefined ? (description ? String(description).trim() : 'Official portal') : all[idx].description,
      sort_order: sortOrder !== undefined ? Number(sortOrder) : all[idx].sort_order,
      is_active: isActive !== undefined ? Boolean(isActive) : all[idx].is_active,
      updated_at: new Date().toISOString(),
    };
    await saveStoredServices(all);
    res.json({ success: true, service: all[idx] });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 5. Admin toggle service status
app.post('/api/admin/services/toggle', async (req, res) => {
  const adminKey = req.headers['x-admin-key'];
  if (adminKey !== 'muzammil786') {
    return res.status(403).json({ success: false, error: 'Unauthorized: Admin key required' });
  }
  const { id, isActive } = req.body || {};
  if (!id) return res.status(400).json({ success: false, error: 'Service ID zaroori hai' });
  try {
    const all = await getStoredServices();
    const idx = all.findIndex(s => String(s.id) === String(id));
    if (idx >= 0) {
      all[idx].is_active = Boolean(isActive);
      all[idx].updated_at = new Date().toISOString();
      await saveStoredServices(all);
    }
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 6. Admin delete service
app.post('/api/admin/services/delete', async (req, res) => {
  const adminKey = req.headers['x-admin-key'];
  if (adminKey !== 'muzammil786') {
    return res.status(403).json({ success: false, error: 'Unauthorized: Admin key required' });
  }
  const { id } = req.body || {};
  if (!id) return res.status(400).json({ success: false, error: 'Service ID zaroori hai' });
  try {
    let all = await getStoredServices();
    all = all.filter(s => String(s.id) !== String(id));
    await saveStoredServices(all);
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// -------------------------------------------------------------
// DYNAMIC SECTIONS MANAGEMENT (MASTER ADMIN & PUBLIC LIST)
// Backed by Cloud SQL PostgreSQL app_store for persistence
// -------------------------------------------------------------

const defaultSystemSections = [
  { id: 'central', title: 'Central Government Schemes', icon: '📋', is_default: true, description: 'Central Govt schemes & subsidies' },
  { id: 'state', title: 'Maharashtra Schemes', icon: '📋', is_default: true, description: 'Maharashtra State portals & yojanas' },
  { id: 'partner', title: 'Partner / BC Services', icon: '🤝', is_default: true, description: 'Spice Money, PayNearby & BC Banking' },
  { id: 'essential', title: 'Citizen & Digital Portals', icon: '🪪', is_default: true, description: 'Aadhaar, PAN, Voter, Ration & DL' }
];

async function getStoredSections(): Promise<any[]> {
  try {
    const res = await pool.query(
      'SELECT payload FROM app_store WHERE store_key = $1 AND user_uid = $2 ORDER BY id DESC LIMIT 1',
      ['custom_sections', 'global_master_admin']
    );
    if (res.rows.length > 0 && res.rows[0].payload) {
      const parsed = JSON.parse(res.rows[0].payload);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
  } catch (err: any) {
    console.warn('getStoredSections error:', err.message);
  }
  return defaultSystemSections;
}

async function saveStoredSections(sections: any[]): Promise<boolean> {
  try {
    const payload = JSON.stringify(sections);
    const existing = await pool.query(
      'SELECT id FROM app_store WHERE store_key = $1 AND user_uid = $2 LIMIT 1',
      ['custom_sections', 'global_master_admin']
    );
    if (existing.rows.length > 0) {
      await pool.query(
        'UPDATE app_store SET payload = $1, updated_at = NOW() WHERE id = $2',
        [payload, existing.rows[0].id]
      );
    } else {
      await pool.query(
        'INSERT INTO app_store (user_uid, store_key, payload, updated_at) VALUES ($1, $2, $3, NOW())',
        ['global_master_admin', 'custom_sections', payload]
      );
    }
    return true;
  } catch (err: any) {
    console.error('saveStoredSections error:', err.message);
    return false;
  }
}

// 7. Public list of sections
app.get('/api/sections', async (req, res) => {
  try {
    const sections = await getStoredSections();
    res.json({ success: true, sections });
  } catch (err: any) {
    res.json({ success: true, sections: defaultSystemSections });
  }
});

// 8. Admin list of sections
app.get('/api/admin/sections', async (req, res) => {
  const adminKey = req.headers['x-admin-key'];
  if (adminKey !== 'muzammil786') {
    return res.status(403).json({ success: false, error: 'Unauthorized: Admin key required' });
  }
  try {
    const sections = await getStoredSections();
    res.json({ success: true, sections });
  } catch (err: any) {
    res.json({ success: true, sections: defaultSystemSections });
  }
});

// 9. Admin create / update custom section
app.post('/api/admin/sections/create', async (req, res) => {
  const adminKey = req.headers['x-admin-key'];
  if (adminKey !== 'muzammil786') {
    return res.status(403).json({ success: false, error: 'Unauthorized: Admin key required' });
  }
  const { id, title, icon, description } = req.body || {};
  if (!title) {
    return res.status(400).json({ success: false, error: 'Section title zaroori hai' });
  }
  try {
    let sections = await getStoredSections();
    const secId = id || ('sec_' + (title.toLowerCase().replace(/[^a-z0-9]/g, '_') || Date.now()));
    const existingIdx = sections.findIndex(s => s.id === secId);
    const secObj = {
      id: secId,
      title: title.trim(),
      icon: (icon || '🌐').trim(),
      description: (description || '').trim(),
      is_default: false,
      updated_at: new Date().toISOString()
    };
    if (existingIdx >= 0) {
      sections[existingIdx] = { ...sections[existingIdx], ...secObj };
    } else {
      sections.push({ ...secObj, created_at: new Date().toISOString() });
    }
    await saveStoredSections(sections);
    res.json({ success: true, section: secObj, sections });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 10. Admin delete custom section
app.post('/api/admin/sections/delete', async (req, res) => {
  const adminKey = req.headers['x-admin-key'];
  if (adminKey !== 'muzammil786') {
    return res.status(403).json({ success: false, error: 'Unauthorized: Admin key required' });
  }
  const { id, deleteServices } = req.body || {};
  if (!id) return res.status(400).json({ success: false, error: 'Section ID zaroori hai' });
  if (['central', 'state', 'partner', 'essential'].includes(id)) {
    return res.status(400).json({ success: false, error: 'System default section delete nahi kiya ja sakta' });
  }
  try {
    let sections = await getStoredSections();
    sections = sections.filter(s => s.id !== id);
    await saveStoredSections(sections);

    if (deleteServices) {
      let services = await getStoredServices();
      services = services.filter(s => s.section !== id);
      await saveStoredServices(services);
    }
    res.json({ success: true, sections });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 11. Admin: View Original Source Code Files & File List
app.get('/api/admin/source-code/list', async (req, res) => {
  const adminKey = req.headers['x-admin-key'];
  if (adminKey !== 'muzammil786') {
    return res.status(403).json({ success: false, error: 'Unauthorized: Admin key required' });
  }
  const files = [
    { key: 'MainActivity.java', path: 'android/app/src/main/java/com/muzammil/onlineservice/MainActivity.java', category: 'Android Native', desc: 'Native Android WebView bridge, download manager, camera/media permissions & file sharing', icon: '☕' },
    { key: 'AndroidManifest.xml', path: 'android/app/src/main/AndroidManifest.xml', category: 'Android Native', desc: 'Android permissions, intent filters, FileProvider & hardware acceleration', icon: '📱' },
    { key: 'app-build.gradle', path: 'android/app/build.gradle.kts', category: 'Android Gradle', desc: 'Android app module Gradle configuration, compileSdk 34, dependencies', icon: '🐘' },
    { key: 'project-build.gradle', path: 'android/build.gradle.kts', category: 'Android Gradle', desc: 'Android root project Gradle buildscript & plugins', icon: '🐘' },
    { key: 'settings.gradle', path: 'android/settings.gradle.kts', category: 'Android Gradle', desc: 'Gradle project name & repository configuration', icon: '🐘' },
    { key: 'strings.xml', path: 'android/app/src/main/res/values/strings.xml', category: 'Android Resources', desc: 'App name, provider authorities & native string resources', icon: '🏷️' },
    { key: 'file_paths.xml', path: 'android/app/src/main/res/xml/file_paths.xml', category: 'Android Resources', desc: 'FileProvider paths for PDF, image & APK sharing', icon: '📁' },
    { key: 'styles.xml', path: 'android/app/src/main/res/values/styles.xml', category: 'Android Resources', desc: 'Android App native theme & splash screen styles', icon: '🎨' },
    { key: 'index.html', path: 'index.html', category: 'Frontend Web/App', desc: 'Full responsive Web/App UI, Master Admin Hub, Passport & PVC Makers, Offline Engine', icon: '🌐' },
    { key: 'web-bridge.js', path: 'public/web-bridge.js', category: 'Frontend Web/App', desc: 'Android JavaScript Interface bridge, Cloud SQL sync, authentication & storage engine', icon: '⚙️' },
    { key: 'server.ts', path: 'server.ts', category: 'Backend & Cloud SQL', desc: 'Express TypeScript server, Cloud SQL PostgreSQL database API & license engine', icon: '🚀' },
    { key: 'package.json', path: 'package.json', category: 'Config & Build', desc: 'Node.js dependencies, scripts & metadata configuration', icon: '📦' }
  ];

  const enriched = files.map(f => {
    const abs = path.join(process.cwd(), f.path);
    const exists = fs.existsSync(abs);
    let size = 0;
    let lines = 0;
    if (exists) {
      try {
        const stat = fs.statSync(abs);
        size = stat.size;
        const txt = fs.readFileSync(abs, 'utf8');
        lines = txt.split('\n').length;
      } catch (e) {}
    }
    return { ...f, exists, size, lines };
  });

  res.json({ success: true, files: enriched });
});

app.get('/api/admin/source-code', async (req, res) => {
  const adminKey = req.headers['x-admin-key'];
  if (adminKey !== 'muzammil786') {
    return res.status(403).json({ success: false, error: 'Unauthorized: Admin key required' });
  }
  const fileKey = (req.query.file as string) || 'MainActivity.java';
  const fileMap: Record<string, { path: string; desc: string }> = {
    'MainActivity.java': {
      path: 'android/app/src/main/java/com/muzammil/onlineservice/MainActivity.java',
      desc: 'Native Android WebView bridge, download manager, camera/media permissions & file sharing'
    },
    'AndroidManifest.xml': {
      path: 'android/app/src/main/AndroidManifest.xml',
      desc: 'Android permissions, intent filters, FileProvider & hardware acceleration'
    },
    'app-build.gradle': {
      path: fs.existsSync(path.join(process.cwd(), 'android/app/build.gradle.kts')) ? 'android/app/build.gradle.kts' : 'android/app/build.gradle',
      desc: 'Android app module Gradle configuration, compileSdk 34, dependencies'
    },
    'project-build.gradle': {
      path: fs.existsSync(path.join(process.cwd(), 'android/build.gradle.kts')) ? 'android/build.gradle.kts' : 'android/build.gradle',
      desc: 'Android root project Gradle buildscript & plugins'
    },
    'settings.gradle': {
      path: fs.existsSync(path.join(process.cwd(), 'android/settings.gradle.kts')) ? 'android/settings.gradle.kts' : 'android/settings.gradle',
      desc: 'Android project settings, repositories & root project definition'
    },
    'strings.xml': {
      path: 'android/app/src/main/res/values/strings.xml',
      desc: 'Android app string resources & metadata'
    },
    'file_paths.xml': {
      path: 'android/app/src/main/res/xml/file_paths.xml',
      desc: 'FileProvider paths for PDF, image & APK sharing'
    },
    'styles.xml': {
      path: 'android/app/src/main/res/values/styles.xml',
      desc: 'Android App native theme & splash screen styles'
    },
    'index.html': {
      path: 'index.html',
      desc: 'Full responsive Web/App UI, Master Admin Hub, Passport & PVC Makers'
    },
    'web-bridge.js': {
      path: 'public/web-bridge.js',
      desc: 'Android JavaScript Interface bridge, Cloud SQL sync, authentication & storage engine'
    },
    'server.ts': {
      path: 'server.ts',
      desc: 'Express TypeScript server, Cloud SQL PostgreSQL database API & license engine'
    },
    'package.json': {
      path: 'package.json',
      desc: 'Node.js package dependencies, build scripts and configurations'
    }
  };

  const item = fileMap[fileKey];
  let targetAbs = '';
  let desc = 'Project Source File';
  if (item) {
    targetAbs = path.join(process.cwd(), item.path);
    desc = item.desc;
  } else {
    // Check if safe custom path requested
    const safeRel = path.normalize(fileKey).replace(/^(\.\.[\/\\])+/, '');
    if (safeRel.includes('node_modules') || safeRel.includes('.env')) {
      return res.status(403).json({ success: false, error: 'Access forbidden to this directory' });
    }
    targetAbs = path.join(process.cwd(), safeRel);
  }

  if (!fs.existsSync(targetAbs) || fs.statSync(targetAbs).isDirectory()) {
    return res.status(404).json({ success: false, error: 'File not found on server' });
  }
  const content = fs.readFileSync(targetAbs, 'utf8');
  res.json({
    success: true,
    fileKey,
    fileName: path.basename(targetAbs),
    relativePath: path.relative(process.cwd(), targetAbs),
    description: desc,
    size: content.length,
    lineCount: content.split('\n').length,
    content
  });
});

// 12. Admin: Send APK to User & Track APK Dispatches
app.post('/api/admin/apk/send', async (req, res) => {
  const adminKey = req.headers['x-admin-key'];
  if (adminKey !== 'muzammil786') {
    return res.status(403).json({ success: false, error: 'Unauthorized: Admin key required' });
  }
  const { phone, name, username, notes, channel } = req.body || {};
  if (!phone && !username) {
    return res.status(400).json({ success: false, error: 'Recipient phone or username is required' });
  }

  const record = {
    id: 'apk_dispatch_' + Date.now(),
    phone: phone ? String(phone).trim() : '',
    name: name ? String(name).trim() : '',
    username: username ? String(username).trim() : '',
    notes: notes ? String(notes).trim() : '',
    channel: channel || 'whatsapp',
    apkVersion: 'v95',
    downloadUrl: '/download/apk',
    sentAt: new Date().toISOString()
  };

  try {
    let shares: any[] = [];
    if (pool) {
      const q = await pool.query("SELECT store_value FROM app_store WHERE user_uid = 'global_master_admin' AND store_key = 'apk_shares' LIMIT 1;");
      if (q.rows.length > 0 && Array.isArray(q.rows[0].store_value)) {
        shares = q.rows[0].store_value;
      }
      shares.unshift(record);
      if (shares.length > 200) shares = shares.slice(0, 200);
      await pool.query(
        "INSERT INTO app_store (user_uid, store_key, store_value, updated_at) VALUES ('global_master_admin', 'apk_shares', $1, CURRENT_TIMESTAMP) ON CONFLICT (user_uid, store_key) DO UPDATE SET store_value = EXCLUDED.store_value, updated_at = CURRENT_TIMESTAMP;",
        [JSON.stringify(shares)]
      );
    }
  } catch (err) {
    console.warn('Saving APK share record to DB failed, proceeding:', err);
  }

  res.json({
    success: true,
    message: 'APK dispatch recorded successfully',
    record
  });
});

app.get('/api/admin/apk/shares', async (req, res) => {
  const adminKey = req.headers['x-admin-key'];
  if (adminKey !== 'muzammil786') {
    return res.status(403).json({ success: false, error: 'Unauthorized: Admin key required' });
  }
  try {
    if (pool) {
      const q = await pool.query("SELECT store_value FROM app_store WHERE user_uid = 'global_master_admin' AND store_key = 'apk_shares' LIMIT 1;");
      if (q.rows.length > 0 && Array.isArray(q.rows[0].store_value)) {
        return res.json({ success: true, shares: q.rows[0].store_value });
      }
    }
  } catch (err) {}
  res.json({ success: true, shares: [] });
});

// Static files with strict cache control for HTML, Service Worker, and scripts
app.use((req, res, next) => {
  if (req.path === '/' || req.path.endsWith('.html') || req.path.endsWith('sw.js') || req.path.endsWith('web-bridge.js')) {
    res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate, max-age=0');
    res.setHeader('Pragma', 'no-cache');
    res.setHeader('Expires', '0');
  }
  next();
});

app.use(express.static(path.join(process.cwd(), 'public'), {
  setHeaders: (res, filePath) => {
    if (filePath.endsWith('.html') || filePath.endsWith('sw.js') || filePath.endsWith('web-bridge.js')) {
      res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate, max-age=0');
      res.setHeader('Pragma', 'no-cache');
      res.setHeader('Expires', '0');
    }
  }
}));
app.use(express.static(path.join(process.cwd())));

// Direct APK Download Handler (application/vnd.android.package-archive)
app.get([
  '/download/apk',
  '/download/Muzammil_Online_Service.apk',
  '/download/Muzammil_Online_Service_v96.apk',
  '/download/Muzammil_Online_Service_v95.apk',
  '/download/Muzammil_Online_Service_v90.apk',
  '/Muzammil_Online_Service.apk',
  '/Muzammil_Online_Service_v96.apk',
  '/Muzammil_Online_Service_v95.apk',
  '/Muzammil_Online_Service_v90.apk',
  '/:filename([A-Za-z0-9_-]+\\.apk)'
], (req: any, res: any) => {
  const reqName = req.params.filename || 'Muzammil_Online_Service_v96.apk';
  const candidates = [
    path.join(process.cwd(), 'public', reqName),
    path.join(process.cwd(), reqName),
    path.join(process.cwd(), 'public', 'Muzammil_Online_Service_v96.apk'),
    path.join(process.cwd(), 'Muzammil_Online_Service_v96.apk'),
    path.join(process.cwd(), 'public', 'Muzammil_Online_Service_v95.apk'),
    path.join(process.cwd(), 'Muzammil_Online_Service_v95.apk'),
    path.join(process.cwd(), 'public', 'Muzammil_Online_Service_v90.apk'),
    path.join(process.cwd(), 'Muzammil_Online_Service_v90.apk'),
    path.join(process.cwd(), 'public', 'Muzammil_Online_Service_v96_APK_PROJECT.zip'),
    path.join(process.cwd(), 'Muzammil_Online_Service_v96_APK_PROJECT.zip'),
  ];
  for (const p of candidates) {
    if (fs.existsSync(p)) {
      res.setHeader('Content-Type', 'application/vnd.android.package-archive');
      res.setHeader('Content-Disposition', `attachment; filename="Muzammil_Online_Service_v96.apk"`);
      return res.sendFile(p);
    }
  }
  res.status(404).send('APK file not found');
});

// Explicit Guaranteed ZIP Download Handler (forces attachment download)
app.get([
  '/download/apk-project',
  '/download/full-project',
  '/download/project',
  '/download-latest-zip',
  '/Muzammil_Online_Service_v96_FULL_PROJECT.zip',
  '/Muzammil_Online_Service_v96_APK_PROJECT.zip',
  '/Muzammil_Online_Service_v95_FULL_PROJECT.zip',
  '/Muzammil_Online_Service_v95_APK_PROJECT.zip',
  '/Muzammil_Online_Service_v90_APK_PROJECT.zip',
  '/Muzammil_Online_Service_v89_APK_PROJECT.zip',
  '/Muzammil_Online_Service_v88_APK_PROJECT.zip',
  '/Muzammil_Online_Service_v87_APK_PROJECT.zip',
  '/Muzammil_Online_Service_v85_APK_PROJECT.zip',
  '/:filename([A-Za-z0-9_-]+\\.zip)'
], (req: any, res: any) => {
  const reqName = req.params.filename || 'Muzammil_Online_Service_v96_FULL_PROJECT.zip';
  const candidates = [
    path.join(process.cwd(), 'public', reqName),
    path.join(process.cwd(), 'dist', reqName),
    path.join(process.cwd(), reqName),
    path.join(process.cwd(), 'public', 'Muzammil_Online_Service_v96_FULL_PROJECT.zip'),
    path.join(process.cwd(), 'Muzammil_Online_Service_v96_FULL_PROJECT.zip'),
    path.join(process.cwd(), 'public', 'Muzammil_Online_Service_v96_APK_PROJECT.zip'),
    path.join(process.cwd(), 'Muzammil_Online_Service_v96_APK_PROJECT.zip'),
    path.join(process.cwd(), 'public', 'Muzammil_Online_Service_v95_FULL_PROJECT.zip'),
    path.join(process.cwd(), 'Muzammil_Online_Service_v95_FULL_PROJECT.zip'),
    path.join(process.cwd(), 'public', 'Muzammil_Online_Service_v90_APK_PROJECT.zip'),
    path.join(process.cwd(), 'Muzammil_Online_Service_v90_APK_PROJECT.zip'),
  ];
  for (const p of candidates) {
    if (fs.existsSync(p)) {
      res.setHeader('Content-Type', 'application/zip');
      res.setHeader('Content-Disposition', `attachment; filename="${path.basename(p)}"`);
      return res.sendFile(p);
    }
  }
  res.status(404).send('ZIP file not found');
});

// Explicit Guaranteed Workflow YAML Download Handler
app.get([
  '/download/workflow',
  '/download/main.yml',
  '/download/build-apk.yml',
  '/download/workflow.yml',
  '/.github/workflows/main.yml'
], (req: any, res: any) => {
  const candidates = [
    path.join(process.cwd(), '.github', 'workflows', 'main.yml'),
    path.join(process.cwd(), 'public', 'main.yml'),
    path.join(process.cwd(), 'public', 'build-apk.yml'),
  ];
  for (const p of candidates) {
    if (fs.existsSync(p)) {
      res.setHeader('Content-Type', 'text/yaml; charset=utf-8');
      res.setHeader('Content-Disposition', `attachment; filename="main.yml"`);
      return res.sendFile(p);
    }
  }
  res.status(404).send('Workflow file not found');
});

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', time: new Date().toISOString(), version: '96.0.0' });
});

// App fallback
app.get('*', (req, res) => {
  res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate, max-age=0');
  res.setHeader('Pragma', 'no-cache');
  res.setHeader('Expires', '0');
  const indexPath = path.join(process.cwd(), 'index.html');
  if (fs.existsSync(indexPath)) {
    res.sendFile(indexPath);
  } else {
    res.status(404).send('Not Found');
  }
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Server running on port ${PORT} with Cloud SQL backend`);
});
