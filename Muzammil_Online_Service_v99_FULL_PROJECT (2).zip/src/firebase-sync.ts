import { initializeApp } from 'firebase/app';
import {
  initializeFirestore,
  setLogLevel,
  doc,
  setDoc,
  getDoc,
  deleteDoc,
  collection,
  getDocs,
  query,
  where,
  onSnapshot,
  Firestore,
  Unsubscribe
} from 'firebase/firestore';

const firebaseConfig = {
  projectId: "isentropic-guard-7smzh",
  appId: "1:921992138219:web:ab821123fe534cbc0b9dae",
  apiKey: "AIzaSyCt3NGwK1PnEYEQGmTErg-s_bEUpSNZXyo",
  authDomain: "isentropic-guard-7smzh.firebaseapp.com",
  firestoreDatabaseId: "ai-studio-muzammilonlinese-ab4b6a22-51fb-4956-9a68-432f8cad9d34",
  storageBucket: "isentropic-guard-7smzh.firebasestorage.app",
  messagingSenderId: "921992138219"
};

export const APP_CURRENT_VERSION = '98.0';
export const APP_BUILD_NUMBER = 98;

try {
  setLogLevel('silent');
} catch (e) {}

let db: Firestore | null = null;
let currentWatcherUnsub: Unsubscribe | null = null;
let globalUsersWatcherUnsub: Unsubscribe | null = null;

export function initFirebase() {
  if (db) return db;
  try {
    try {
      setLogLevel('silent');
    } catch (e) {}
    const app = initializeApp({
      apiKey: firebaseConfig.apiKey,
      authDomain: firebaseConfig.authDomain,
      projectId: firebaseConfig.projectId,
      storageBucket: firebaseConfig.storageBucket,
      messagingSenderId: firebaseConfig.messagingSenderId,
      appId: firebaseConfig.appId
    });
    db = initializeFirestore(app, {
      experimentalAutoDetectLongPolling: true
    }, firebaseConfig.firestoreDatabaseId);
    console.log('⚡ Firebase Realtime Sync Initialized with database:', firebaseConfig.firestoreDatabaseId);
    return db;
  } catch (err) {
    console.warn('Firebase init error:', err);
    return null;
  }
}

export async function saveUserToCloud(user: any): Promise<boolean> {
  const firestore = initFirebase();
  if (!firestore || !user || !user.username) return false;
  const username = String(user.username).trim().toLowerCase();
  try {
    const payload = {
      username: username,
      displayName: user.displayName || user.display_name || user.username,
      phone: user.phone ? String(user.phone).trim() : '',
      shopName: user.shopName || user.shop_name || '',
      role: user.role || 'operator',
      status: user.status || 'active',
      passwordPlain: user.password || user.passwordPlain || '',
      passwordHash: user.password_hash || user.passwordHash || '',
      expiresAt: user.expires_at || user.expiresAt || null,
      updatedAt: new Date().toISOString()
    };
    await setDoc(doc(firestore, 'users', username), payload, { merge: true });
    console.log(`✅ [Firebase Cloud] User @${username} saved successfully.`);
    return true;
  } catch (e) {
    console.warn('Firebase save user error:', e);
    return false;
  }
}

export async function deleteUserFromCloud(username: string): Promise<boolean> {
  const firestore = initFirebase();
  if (!firestore || !username) return false;
  const clean = String(username).trim().toLowerCase();
  try {
    await deleteDoc(doc(firestore, 'users', clean));
    console.log(`🗑️ [Firebase Cloud] User @${clean} deleted.`);
    return true;
  } catch (e) {
    console.warn('Firebase delete user error:', e);
    return false;
  }
}

export async function getUserFromCloud(queryKey: string): Promise<any | null> {
  const firestore = initFirebase();
  if (!firestore || !queryKey) return null;
  const raw = String(queryKey).trim();
  const clean = raw.toLowerCase();
  const digitsOnly = raw.replace(/\D/g, '');

  try {
    // 1. Direct document ID lookup (username)
    const snap = await getDoc(doc(firestore, 'users', clean));
    if (snap.exists()) {
      return snap.data();
    }

    // 2. Query by phone if numeric or provided
    if (raw) {
      const qPhone = query(collection(firestore, 'users'), where('phone', '==', raw));
      const phoneSnap = await getDocs(qPhone);
      if (!phoneSnap.empty) {
        return phoneSnap.docs[0].data();
      }
    }

    // 3. Query with digitsOnly if 10-digit phone
    if (digitsOnly && digitsOnly.length >= 10) {
      const tenDigits = digitsOnly.slice(-10);
      const allUsers = await getAllUsersFromCloud();
      const found = allUsers.find(u => {
        const uPhoneDigits = String(u.phone || '').replace(/\D/g, '');
        return uPhoneDigits === digitsOnly || uPhoneDigits.endsWith(tenDigits);
      });
      if (found) return found;
    }

    // 4. Query by exact username field
    const qUser = query(collection(firestore, 'users'), where('username', '==', clean));
    const userSnap = await getDocs(qUser);
    if (!userSnap.empty) {
      return userSnap.docs[0].data();
    }

    return null;
  } catch (e) {
    console.warn('Firebase get user error:', e);
    return null;
  }
}

export async function getAllUsersFromCloud(): Promise<any[]> {
  const firestore = initFirebase();
  if (!firestore) return [];
  try {
    const snap = await getDocs(collection(firestore, 'users'));
    const list: any[] = [];
    snap.forEach(d => list.push(d.data()));
    return list;
  } catch (e) {
    console.warn('Firebase get all users error:', e);
    return [];
  }
}

// Multi-phone Realtime Universal Sync:
// Keeps all operators synced to localStorage on ANY device in real time!
export function startGlobalUsersRealtimeSync(onUsersUpdate?: (users: any[]) => void): () => void {
  const firestore = initFirebase();
  if (!firestore) return () => {};

  if (globalUsersWatcherUnsub) {
    globalUsersWatcherUnsub();
    globalUsersWatcherUnsub = null;
  }

  try {
    console.log('📡 [Firebase Cloud] Subscribing to live operators collection across devices...');
    globalUsersWatcherUnsub = onSnapshot(
      collection(firestore, 'users'),
      (snap) => {
        const cloudUsers: any[] = [];
        snap.forEach(d => {
          const u = d.data();
          if (u && u.username) {
            cloudUsers.push({
              id: u.id || ('u_' + u.username),
              uid: 'usr_' + u.username,
              username: u.username,
              displayName: u.displayName || u.username,
              phone: u.phone || '',
              shopName: u.shopName || '',
              role: u.role || 'operator',
              status: u.status || 'active',
              password: u.passwordPlain || u.password || '',
              passwordPlain: u.passwordPlain || u.password || '',
              password_hash: u.passwordHash || u.password_hash || '',
              expires_at: u.expiresAt || u.expires_at || null,
              created_at: u.updatedAt || new Date().toISOString()
            });
          }
        });

        // Store into local storage for instant multi-phone offline & online login
        try {
          if (typeof localStorage !== 'undefined' && cloudUsers.length > 0) {
            let existing: any[] = [];
            try {
              const cur = localStorage.getItem('mos_users');
              if (cur) existing = JSON.parse(cur);
            } catch (e) {}

            const mergedMap = new Map();
            existing.forEach(u => {
              if (u && u.username) mergedMap.set(String(u.username).toLowerCase(), u);
            });
            cloudUsers.forEach(u => {
              mergedMap.set(String(u.username).toLowerCase(), u);
            });
            const merged = Array.from(mergedMap.values());
            localStorage.setItem('mos_users', JSON.stringify(merged));
            console.log(`⚡ [Firebase Realtime] Live synced ${cloudUsers.length} operators to this device!`);
          }
        } catch (e) {
          console.warn('Sync to localStorage error:', e);
        }

        if (onUsersUpdate) {
          onUsersUpdate(cloudUsers);
        }
      },
      (err) => {
        console.warn('Realtime collection watcher error:', err);
      }
    );
  } catch (err) {
    console.warn('Failed to start global users realtime sync:', err);
  }

  return () => {
    if (globalUsersWatcherUnsub) {
      globalUsersWatcherUnsub();
      globalUsersWatcherUnsub = null;
    }
  };
}

export function startUserRealtimeWatch(
  username: string,
  onKickOut: (reason: string) => void,
  onUpdate?: (data: any) => void
): () => void {
  const firestore = initFirebase();
  if (!firestore || !username) return () => {};
  const clean = String(username).trim().toLowerCase();
  if (clean === 'admin' || clean === 'imran') return () => {};

  if (currentWatcherUnsub) {
    currentWatcherUnsub();
    currentWatcherUnsub = null;
  }

  try {
    console.log(`📡 [Firebase Realtime] Listening to @${clean} changes...`);
    currentWatcherUnsub = onSnapshot(
      doc(firestore, 'users', clean),
      (snap) => {
        if (!snap.exists()) {
          console.warn(`🚨 [Firebase Realtime] User @${clean} was DELETED by admin!`);
          onKickOut('User account has been deleted by Master Admin Imran Khan.');
          return;
        }
        const data = snap.data();
        if (data.status === 'blocked') {
          console.warn(`🚨 [Firebase Realtime] User @${clean} was BLOCKED!`);
          onKickOut('Aapka account Master Admin dwara block kar diya gaya hai.');
          return;
        }
        if (data.expiresAt) {
          const expTime = new Date(data.expiresAt).getTime();
          if (expTime < Date.now()) {
            console.warn(`🚨 [Firebase Realtime] User @${clean} validity EXPIRED!`);
            onKickOut('Aapka account plan expire ho chuka hai. Validity extend karayein.');
            return;
          }
        }
        if (onUpdate) {
          onUpdate(data);
        }
      },
      (err) => {
        console.warn('Realtime watcher listener error:', err);
      }
    );
  } catch (err) {
    console.warn('Failed to start realtime watcher:', err);
  }

  return () => {
    if (currentWatcherUnsub) {
      currentWatcherUnsub();
      currentWatcherUnsub = null;
    }
  };
}

// Expose on global window object for web-bridge.js and all scripts
const MosFirebase = {
  version: APP_CURRENT_VERSION,
  build: APP_BUILD_NUMBER,
  init: initFirebase,
  saveUser: saveUserToCloud,
  deleteUser: deleteUserFromCloud,
  getUser: getUserFromCloud,
  getAllUsers: getAllUsersFromCloud,
  watchUser: startUserRealtimeWatch,
  watchAllUsers: startGlobalUsersRealtimeSync
};

(window as any).MosFirebase = MosFirebase;
export default MosFirebase;
