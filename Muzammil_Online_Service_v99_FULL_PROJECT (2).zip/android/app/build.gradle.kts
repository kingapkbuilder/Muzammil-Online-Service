plugins { id("com.android.application") }
android {
    namespace="com.muzammil.onlineservice"
    compileSdk=35
    defaultConfig {
        applicationId="com.muzammil.onlineservice"
        minSdk=24
        targetSdk=35
        versionCode = 99
        versionName = "99.0.0"
    }
}


dependencies {
    implementation("androidx.core:core:1.15.0")
    implementation("com.tom-roush:pdfbox-android:2.0.27.0")
}
