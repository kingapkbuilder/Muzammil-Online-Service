plugins {
    id("com.android.application")
    kotlin("android")
}

android {
    namespace = "com.muzammil.onlineservice"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.muzammil.onlineservice"
        minSdk = 24
        targetSdk = 35
        versionCode = 2
        versionName = "1.1"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}
