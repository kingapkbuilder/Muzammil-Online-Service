Muzammil Online Service v75 FINAL FIXED

PVC live-preview upload fix:
- Uses FileReader data URLs instead of Blob URLs for Android WebView reliability.
- Shows actual loaded image dimensions.
- Explicit image load/read errors.
- Forces 1200x1800 live-preview canvas dimensions.
- Preserves fixed 4x6 portrait page and 8.5x5.5 cm card frames.
