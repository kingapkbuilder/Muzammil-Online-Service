Muzammil Online Service v68 - Final Fixed Build

Fixes:
- PVC Card 4x6 portrait canvas: 1200x1800 px at 300 DPI.
- Two PVC cards stacked top/bottom, each 8.5 x 5.5 cm.
- Drag, zoom, corner-handle resize and slider controls for each card.
- Full PVC preview modal.
- PVC JPG download.
- PVC 4x6 PDF download with exact 4x6 inch PDF page.
- PVC JPG/PDF sharing through Android FileProvider.
- PDF to JPG converter with 120-400 DPI selection and password-protected PDF support.
- Better wrong-password message.
- Downloads list with Open and Share.
- Single-feature navigation keeps one main section open at a time.
- APK workflow rebuilt around the actual Gradle Android project.
- Android version bumped to 6.8 / versionCode 68.
