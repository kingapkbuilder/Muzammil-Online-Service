Muzammil Online Service v60
Passport Photo Maker:
- Color Grade & Beauty toggle
- Small live 35x45 mm preview appears only while Color Grade & Beauty is open
- Preview updates live with grading/beauty sliders
- Closing Color Grade & Beauty hides the mini preview
- Existing background controls remain collapsible
- Output remains 1800x1200 px, 300 DPI, 6x4 inch landscape, 8 copies
