Muzammil Online Service - Passport Photo v58

Compact Background section with minimize/maximize toggle.
Color Grade & Beauty stays behind its own ON/OFF toggle.
Passport output remains fixed at 1800x1200 px (6x4 inch landscape) for 300 DPI printing.
JPG export uses high JPEG quality and Print uses fixed 6x4 inch page CSS.
Kept background removal, background colors, Court Professional, tap/drag, zoom, 4x6 8-copy JPG/print, Auto Grade and Auto Beauty.
Version 5.8.
