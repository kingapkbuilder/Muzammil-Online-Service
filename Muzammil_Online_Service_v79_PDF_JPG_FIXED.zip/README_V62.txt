Muzammil Online Service v62
Passport Photo Maker synchronized preview + Curves.
- Main 35x45 mm editor preview and Color Grade & Beauty mini preview use the exact same crop, zoom, drag position, background removal/background color and grading pipeline.
- Both previews update together while grading, zooming, dragging and background changes are made.
- Added Curves control with live curve graph and tonal curve adjustment.
- Curves is included in Natural reset and Auto Grade.
- Final 4x6 landscape sheet remains 1800x1200 px, 300 DPI target, 8 copies.
- Existing crop, zoom, tap-drag, background removal, court professional, New Project and JPG export retained.
