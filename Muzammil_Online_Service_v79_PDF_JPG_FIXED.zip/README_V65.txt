Muzammil Online Service v6.5 / versionCode 65

PVC Card 4x6 Portrait improvements:
- Card Adjust section for Card 1 (Upar) and Card 2 (Neeche)
- Separate Zoom, X, Y controls
- Touch/mouse drag directly on the 4x6 layout preview
- Center and Reset controls
- Dedicated full card Preview modal showing both cards individually
- Adjustments are preserved in Download JPG and Print output
- Existing 1200x1800 px / 300 DPI / 4x6 portrait / 8.5x5.5 cm card layout retained
