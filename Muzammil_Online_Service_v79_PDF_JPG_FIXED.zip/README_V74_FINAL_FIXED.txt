Muzammil Online Service v74 FINAL FIXED

PVC upload/live preview fix:
- Reliable object-URL image loading for JPG/PNG/WebP.
- Explicit loading, loaded and error status for Card 1 and Card 2.
- Live preview updates immediately after successful upload.
- Empty card frames show an upload placeholder instead of a blank canvas.
- Existing 4x6 portrait and fixed 8.5x5.5 cm card layout preserved.
