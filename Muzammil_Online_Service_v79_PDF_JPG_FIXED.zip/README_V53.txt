Muzammil Online Service v53
Passport Photo Smart Background Removal improved:
- multi-point border sampling
- adjustable Smart Remove tolerance
- connected-region removal
- edge feathering to reduce halos
- existing crop/zoom/drag/background/court professional preserved
Note: this is an offline color-based smart remover, not AI segmentation. Complex hair/background patterns may still require manual editing.
