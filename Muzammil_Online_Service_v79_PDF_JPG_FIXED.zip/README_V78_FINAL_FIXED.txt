Muzammil Online Service v78 FINAL FIXED

Critical root-cause fix:
- Fixed a literal \n embedded after the PVC layout comment.
- This previously commented out `const PVC`, causing PVC render and all PVC controls to fail at runtime.
- Card upload, live preview, zoom, move, crop, frame, guides, snap and enhance can now execute.
- 4x6 portrait: 1200x1800 px @ 300 DPI.
- Fixed PVC card: 8.5 x 5.5 cm.
- JavaScript syntax validated with Node.js.
