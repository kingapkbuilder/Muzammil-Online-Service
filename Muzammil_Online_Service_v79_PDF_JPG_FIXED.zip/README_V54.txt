Muzammil Online Service - Passport Photo Maker v54 / 5.4

Adds Color Grade + Beauty controls to Passport Photo Maker:
- Auto Color Grade
- Auto Beauty
- Brightness, Contrast, Saturation, Warmth
- Highlights, Shadows, Sharpness
- Skin Smooth, Face Light, Skin Tone
- Reset / Natural controls
- Existing background removal, plain colors, Court Professional, tap-drag, zoom, 4x6 8-copy JPG/print retained.

Official/court photo edits are optional; Natural/Reset is available.
