Muzammil Online Service v77 FINAL FIXED

Critical PVC live-preview fix:
- Uploaded Card 1/Card 2 images are now drawn directly to the live 1200x1800 canvas.
- v76's export-only image rendering condition was corrected.
- Move/Zoom/Crop/Enhance and sliders update the same live canvas.
- DOM preview remains as a fallback but is behind the canvas.
- Export uses the same image positioning.
- 4x6 inch portrait, 1200x1800 px, fixed 8.5x5.5 cm cards preserved.
