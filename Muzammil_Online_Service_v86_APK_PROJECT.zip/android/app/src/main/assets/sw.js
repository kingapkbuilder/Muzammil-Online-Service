// Muzammil Online Service - Cache Purge Service Worker
self.addEventListener('install', (event) => {
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) => Promise.all(keys.map((k) => caches.delete(k))))
  );
  self.clients.claim();
});

self.addEventListener('fetch', (event) => {
  // Always network-first, no stale HTML caching
  event.respondWith(fetch(event.request).catch(() => caches.match(event.request)));
});
