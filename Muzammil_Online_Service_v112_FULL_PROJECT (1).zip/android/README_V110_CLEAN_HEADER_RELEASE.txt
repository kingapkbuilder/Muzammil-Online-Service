v110 Release Notes (Build 110):
1. Duplicate Menu & 3-Dot Removal:
   - On the local app page (file:///android_asset/index.html), nativeTopBar is kept GONE.
   - Removed the duplicate bell button and crowded badges from header actions.
   - Preserved only a single 3-dot options menu (⋮) in the header and the main navigation menu (☰) in the bottom navigation bar.
2. Crystal-Clear Branding:
   - "Muzammil Online Service & Xerox" prominently displayed with high-contrast text and a distinctive Xerox badge.
   - Responsive scaling prevents text wrapping and clipping on mobile devices.
3. Version 110 Upgrades:
   - Updated server API, APK download endpoints, and GitHub Actions CI/CD pipeline to v110.0 (Build 110).
