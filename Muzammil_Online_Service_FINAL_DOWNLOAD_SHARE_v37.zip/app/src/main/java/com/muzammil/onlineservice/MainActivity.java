package com.muzammil.onlineservice;

import android.os.Build;
import android.content.pm.PackageManager;
import android.Manifest;
import android.app.Activity;
import android.app.DownloadManager;
import android.content.Context;
import android.database.Cursor;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.view.Gravity;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.ValueCallback;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;
import android.webkit.JavascriptInterface;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import android.content.Intent;
import android.net.Uri;
import android.os.Environment;
import android.provider.Settings;
import android.widget.Toast;
import androidx.core.content.FileProvider;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;

public class MainActivity extends Activity {
    private SharedPreferences prefs;
    private final ExecutorService aiExecutor = Executors.newSingleThreadExecutor();
    private WebView w;
    private ValueCallback<Uri[]> uploadCallback;
    private static final int FILE_PICKER = 4101;
    private TextView clock;
    private TextView translateButton;
    private ViewGroup nativeTopBar;
    private ViewGroup nativeClockRow;
    private android.view.View nativeProgressTrack;
    private android.view.View nativeProgressFill;
    private String originalPortalUrl = null;
    private FrameLayout splashOverlay;
    private long splashStartTime;
    private static final long SPLASH_MIN_MS = 1800;
    private final android.os.Handler clockHandler = new android.os.Handler();
    private final Runnable clockRunnable = new Runnable() {
        @Override public void run() {
            if (clock != null) {
                clock.setText(new SimpleDateFormat("EEEE, dd MMM yyyy\nhh:mm:ss a", Locale.ENGLISH).format(new Date()));
            }
            clockHandler.postDelayed(this, 1000);
        }
    };


    private void requestRuntimePermissions() {
        if (Build.VERSION.SDK_INT < 23) return;
        ArrayList<String> needed = new ArrayList<>();
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.CAMERA);
        }
        if (Build.VERSION.SDK_INT >= 33) {
            if (checkSelfPermission(Manifest.permission.READ_MEDIA_IMAGES) != PackageManager.PERMISSION_GRANTED) {
                needed.add(Manifest.permission.READ_MEDIA_IMAGES);
            }
        } else if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.READ_EXTERNAL_STORAGE);
        }
        if (!needed.isEmpty()) requestPermissions(needed.toArray(new String[0]), 5102);
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);

        prefs = getSharedPreferences("mos_settings", MODE_PRIVATE);
        if (android.os.Build.VERSION.SDK_INT >= 23 && android.os.Build.VERSION.SDK_INT <= 28 &&
            checkSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE") != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.WRITE_EXTERNAL_STORAGE"}, 5101);
        }

        requestRuntimePermissions();

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.WHITE);

        // Professional app startup/loading screen
        splashStartTime = System.currentTimeMillis();
        splashOverlay = new FrameLayout(this);
        splashOverlay.setBackgroundColor(Color.rgb(23, 105, 255));

        android.widget.LinearLayout splashContent = new android.widget.LinearLayout(this);
        splashContent.setOrientation(android.widget.LinearLayout.VERTICAL);
        splashContent.setGravity(Gravity.CENTER_HORIZONTAL);
        splashContent.setPadding(dp(24), dp(40), dp(24), dp(30));

        ImageView splashLogo = new ImageView(this);
        splashLogo.setImageResource(com.muzammil.onlineservice.R.drawable.muzammil_app_icon);
        splashLogo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        android.widget.LinearLayout.LayoutParams logoLp =
                new android.widget.LinearLayout.LayoutParams(dp(150), dp(150));
        logoLp.bottomMargin = dp(24);
        splashContent.addView(splashLogo, logoLp);

        TextView splashName = new TextView(this);
        splashName.setText("Imran Khan");
        splashName.setTextColor(Color.WHITE);
        splashName.setTextSize(25);
        splashName.setGravity(Gravity.CENTER);
        splashName.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        splashContent.addView(splashName,
                new android.widget.LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView splashMobile = new TextView(this);
        splashMobile.setText("Mobile : 9561460313");
        splashMobile.setTextColor(Color.WHITE);
        splashMobile.setAlpha(0.92f);
        splashMobile.setTextSize(17);
        splashMobile.setGravity(Gravity.CENTER);
        android.widget.LinearLayout.LayoutParams mobileLp =
                new android.widget.LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        mobileLp.topMargin = dp(8);
        splashContent.addView(splashMobile, mobileLp);

        TextView splashTitle = new TextView(this);
        splashTitle.setText("Muzammil Online Service");
        splashTitle.setTextColor(Color.WHITE);
        splashTitle.setTextSize(15);
        splashTitle.setGravity(Gravity.CENTER);
        splashTitle.setAlpha(0.82f);
        android.widget.LinearLayout.LayoutParams titleLp =
                new android.widget.LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        titleLp.topMargin = dp(28);
        splashContent.addView(splashTitle, titleLp);

        TextView splashLoading = new TextView(this);
        splashLoading.setText("Loading...");
        splashLoading.setTextColor(Color.WHITE);
        splashLoading.setTextSize(14);
        splashLoading.setGravity(Gravity.CENTER);
        splashLoading.setAlpha(0.75f);
        android.widget.LinearLayout.LayoutParams loadingLp =
                new android.widget.LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        loadingLp.topMargin = dp(16);
        splashContent.addView(splashLoading, loadingLp);

        FrameLayout.LayoutParams splashContentLp =
                new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT);
        splashContentLp.gravity = Gravity.CENTER;
        splashOverlay.addView(splashContent, splashContentLp);

        w = new WebView(this);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setLoadsImagesAutomatically(true);
        s.setBlockNetworkImage(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setTextZoom(100);
        s.setDisplayZoomControls(false);
        s.setUseWideViewPort(false);
        s.setLoadWithOverviewMode(false);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);

        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(w, true);

        w.addJavascriptInterface(new AIBridge(), "AndroidAI");
        w.addJavascriptInterface(new DownloadBridge(), "AndroidDownload");
        w.addJavascriptInterface(new PdfBridge(), "AndroidPDF");

        w.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String u = request != null && request.getUrl() != null ? request.getUrl().toString() : "";
                if (!u.contains("translate.google.com/translate")) originalPortalUrl = u;
                view.evaluateJavascript("window.mosStartLoading&&mosStartLoading();", null);
                return false;
            }
            @Override public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                if (url != null && !url.contains("translate.google.com/translate") && !url.startsWith("file:///android_asset/")) {
                    originalPortalUrl = url;
                }
                setNativeProgress(8);
                view.evaluateJavascript("window.mosStartLoading&&mosStartLoading();", null);
                super.onPageStarted(view, url, favicon);
            }
            @Override public void onPageFinished(WebView view, String url) {
                setNativeProgress(100);
                view.evaluateJavascript("document.documentElement.style.webkitTapHighlightColor='transparent'; window.mosLoadingProgress&&mosLoadingProgress(100); setTimeout(function(){window.mosStopLoading&&mosStopLoading()},180);", null);
                injectDownloadBridge(view);
                hideSplashWhenReady();
            }
        });

        w.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int progress) {
                setNativeProgress(progress);
                view.evaluateJavascript("window.mosLoadingProgress&&mosLoadingProgress(" + progress + ");", null);
            }
            @Override public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback, FileChooserParams fileChooserParams) {
                if (uploadCallback != null) uploadCallback.onReceiveValue(null);
                uploadCallback = filePathCallback;
                try {
                    Intent i = fileChooserParams.createIntent();
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    startActivityForResult(i, FILE_PICKER);
                    return true;
                } catch (Exception e) {
                    uploadCallback = null;
                    Toast.makeText(MainActivity.this, "File picker open nahi hua", Toast.LENGTH_SHORT).show();
                    return false;
                }
            }
        });

        w.setDownloadListener(new DownloadListener() {
            @Override public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimetype, long contentLength) {
                try {
                    DownloadManager.Request req = new DownloadManager.Request(Uri.parse(url));
                    if (mimetype != null && !mimetype.isEmpty()) req.setMimeType(mimetype);
                    req.addRequestHeader("User-Agent", userAgent != null ? userAgent : s.getUserAgentString());
                    String cookie = CookieManager.getInstance().getCookie(url);
                    if (cookie != null && !cookie.isEmpty()) req.addRequestHeader("Cookie", cookie);
                    String filename = URLUtil.guessFileName(url, contentDisposition, mimetype);
                    req.setTitle(filename);
                    req.setDescription("Muzammil Online Service");
                    req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    req.setAllowedOverMetered(true);
                    req.setAllowedOverRoaming(true);
                    req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, filename);
                    ((DownloadManager)getSystemService(Context.DOWNLOAD_SERVICE)).enqueue(req);
                    Toast.makeText(MainActivity.this, "Download started: " + filename, Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Download start nahi hua", Toast.LENGTH_LONG).show();
                }
            }
        });

        // Native top bar: red Chrome-style progress line + live clock + Marathi -> English button.
        // This layer stays visible above every WebView/portal page.
        nativeTopBar = new FrameLayout(this);
        nativeTopBar.setBackgroundColor(Color.rgb(15, 45, 100));
        nativeTopBar.setVisibility(android.view.View.VISIBLE);
        nativeTopBar.setElevation(14f);

        nativeProgressTrack = new android.view.View(this);
        nativeProgressTrack.setBackgroundColor(Color.rgb(126, 18, 18));
        FrameLayout.LayoutParams trackLp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(4));
        trackLp.gravity = Gravity.TOP;
        nativeTopBar.addView(nativeProgressTrack, trackLp);

        nativeProgressFill = new android.view.View(this);
        nativeProgressFill.setBackgroundColor(Color.rgb(255, 32, 32));
        FrameLayout.LayoutParams fillLp = new FrameLayout.LayoutParams(0, dp(4));
        fillLp.gravity = Gravity.TOP | Gravity.LEFT;
        nativeTopBar.addView(nativeProgressFill, fillLp);

        nativeClockRow = new android.widget.LinearLayout(this);
        ((android.widget.LinearLayout) nativeClockRow).setOrientation(android.widget.LinearLayout.HORIZONTAL);
        ((android.widget.LinearLayout) nativeClockRow).setGravity(Gravity.CENTER_VERTICAL);
        ((android.widget.LinearLayout) nativeClockRow).setPadding(dp(4), dp(3), dp(4), dp(2));
        FrameLayout.LayoutParams rowLp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(45));
        rowLp.gravity = Gravity.TOP;
        rowLp.topMargin = dp(3);
        nativeTopBar.addView(nativeClockRow, rowLp);

        clock = new TextView(this);
        clock.setTextColor(Color.WHITE);
        clock.setTextSize(15);
        clock.setGravity(Gravity.CENTER);
        clock.setTypeface(null, android.graphics.Typeface.BOLD);
        clock.setText("--:--:-- --");
        android.widget.LinearLayout.LayoutParams clockRowLp = new android.widget.LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f);
        ((android.widget.LinearLayout) nativeClockRow).addView(clock, clockRowLp);

        android.widget.Button translateBtn = new android.widget.Button(this);
        translateButton = translateBtn;
        translateButton.setText("मराठी → English");
        translateButton.setTextColor(Color.WHITE);
        translateButton.setTextSize(11);
        translateButton.setGravity(Gravity.CENTER);
        translateButton.setTypeface(null, Typeface.BOLD);
        translateButton.setAllCaps(false);
        translateButton.setPadding(dp(6), 0, dp(6), 0);
        translateButton.setMinHeight(0);
        translateButton.setMinWidth(0);
        translateButton.setBackgroundColor(Color.rgb(25, 82, 150));
        translateButton.setContentDescription("Marathi to English translation");
        translateButton.setOnClickListener(v -> translateCurrentPage());
        android.widget.LinearLayout.LayoutParams trLp = new android.widget.LinearLayout.LayoutParams(dp(126), dp(40));
        trLp.leftMargin = dp(4);
        trLp.rightMargin = dp(2);
        ((android.widget.LinearLayout) nativeClockRow).addView(translateButton, trLp);

        FrameLayout.LayoutParams webLp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        webLp.topMargin = dp(48);
        root.addView(w, webLp);
        FrameLayout.LayoutParams topLp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48));
        topLp.gravity = Gravity.TOP;
        root.addView(nativeTopBar, topLp);
        // Keep splash above the WebView and clock until the app is ready.
        root.addView(splashOverlay,
                new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT));
        splashOverlay.bringToFront();

        setContentView(root);
        
        requestCameraAndStoragePermissions();
clockHandler.post(clockRunnable);
        w.loadUrl("file:///android_asset/index.html");
    }



    private void hideSplashWhenReady() {
        if (splashOverlay == null) return;
        long elapsed = System.currentTimeMillis() - splashStartTime;
        long delay = Math.max(0, SPLASH_MIN_MS - elapsed);
        clockHandler.postDelayed(new Runnable() {
            @Override public void run() {
                if (splashOverlay != null) {
                    splashOverlay.animate()
                            .alpha(0f)
                            .setDuration(250)
                            .withEndAction(new Runnable() {
                                @Override public void run() {
                                    if (splashOverlay != null) {
                                        splashOverlay.setVisibility(android.view.View.GONE);
                                    }
                                    if (nativeTopBar != null) nativeTopBar.bringToFront();
                                }
                            }).start();
                }
            }
        }, delay);
    }

    // Handles JavaScript/blob/data downloads that Android WebView's DownloadListener does not receive.
    private void injectDownloadBridge(WebView view) {
        String js =
            "(function(){" +
            "if(window.__mosDownloadHook)return;window.__mosDownloadHook=true;" +
            "document.addEventListener('click',function(ev){" +
            "var a=ev.target.closest?ev.target.closest('a'):null;if(!a)return;" +
            "var u=a.href||a.getAttribute('href')||'';var n=a.getAttribute('download')||'';" +
            "if(!/^blob:|^data:/i.test(u))return;" +
            "ev.preventDefault();ev.stopPropagation();" +
            "if(/^data:/i.test(u)){AndroidDownload.saveDataUrl(u,n);}" +
            "else{fetch(u).then(function(r){return r.blob()}).then(function(b){" +
            "var fr=new FileReader();fr.onloadend=function(){AndroidDownload.saveBase64(fr.result,n,b.type||'application/octet-stream');};fr.readAsDataURL(b);" +
            "}).catch(function(e){AndroidDownload.failed(String(e));});}" +
            "},true);})();";
        view.evaluateJavascript(js, null);
    }

    public class DownloadBridge {
        @JavascriptInterface public void saveDataUrl(String dataUrl, String filename) {
            try {
                int comma=dataUrl.indexOf(',');
                String meta=comma>0?dataUrl.substring(0,comma):"";
                String payload=comma>0?dataUrl.substring(comma+1):dataUrl;
                String mime="application/octet-stream";
                java.util.regex.Matcher mm=java.util.regex.Pattern.compile("data:([^;]+)",java.util.regex.Pattern.CASE_INSENSITIVE).matcher(meta);
                if(mm.find()) mime=mm.group(1);
                boolean b64=meta.toLowerCase(Locale.ENGLISH).contains(";base64");
                byte[] bytes=b64?Base64.decode(payload,Base64.DEFAULT):java.net.URLDecoder.decode(payload,"UTF-8").getBytes(StandardCharsets.UTF_8);
                mime = detectRealMime(bytes, mime);
                saveToDownloads(bytes,safeFileName(filename,mime),mime);
            } catch(Exception e){ failed(e.toString()); }
        }
        @JavascriptInterface public void saveBase64(String dataUrl,String filename,String mime) {
            try {
                int comma=dataUrl.indexOf(',');
                String payload=comma>0?dataUrl.substring(comma+1):dataUrl;
                byte[] bytes=Base64.decode(payload,Base64.DEFAULT);

                String actualMime = (mime == null || mime.trim().isEmpty())
                        ? "application/octet-stream" : mime;

                // Detect the real file type from the bytes. Some government portals
                // incorrectly label generated PDFs as text/plain.
                if (bytes.length >= 4 && bytes[0] == 0x25 && bytes[1] == 0x50 && bytes[2] == 0x44 && bytes[3] == 0x46) {
                    actualMime = "application/pdf";
                } else if (bytes.length >= 8 &&
                        (bytes[0] & 0xFF) == 0x89 && bytes[1] == 0x50 && bytes[2] == 0x4E &&
                        bytes[3] == 0x47 && bytes[4] == 0x0D && bytes[5] == 0x0A &&
                        bytes[6] == 0x1A && bytes[7] == 0x0A) {
                    actualMime = "image/png";
                } else if (bytes.length >= 3 &&
                        (bytes[0] & 0xFF) == 0xFF && (bytes[1] & 0xFF) == 0xD8 && (bytes[2] & 0xFF) == 0xFF) {
                    actualMime = "image/jpeg";
                }

                saveToDownloads(bytes,safeFileName(filename,actualMime),actualMime);
            } catch(Exception e){ failed(e.toString()); }
        }
        @JavascriptInterface public String listDownloads() {
            try {
                JSONArray arr = new JSONArray();
                if (android.os.Build.VERSION.SDK_INT >= 29) {
                    String[] proj = new String[]{MediaStore.Downloads._ID, MediaStore.Downloads.DISPLAY_NAME, MediaStore.Downloads.MIME_TYPE, MediaStore.Downloads.SIZE, MediaStore.Downloads.DATE_ADDED};
                    try (Cursor c = getContentResolver().query(MediaStore.Downloads.EXTERNAL_CONTENT_URI, proj, null, null, MediaStore.Downloads.DATE_ADDED + " DESC")) {
                        if (c != null) while (c.moveToNext()) {
                            JSONObject o = new JSONObject();
                            long id=c.getLong(c.getColumnIndexOrThrow(MediaStore.Downloads._ID));
                            o.put("name", c.getString(c.getColumnIndexOrThrow(MediaStore.Downloads.DISPLAY_NAME)));
                            o.put("mime", c.getString(c.getColumnIndexOrThrow(MediaStore.Downloads.MIME_TYPE)));
                            o.put("size", c.getLong(c.getColumnIndexOrThrow(MediaStore.Downloads.SIZE)));
                            o.put("date", c.getLong(c.getColumnIndexOrThrow(MediaStore.Downloads.DATE_ADDED))*1000L);
                            o.put("uri", ContentUris.withAppendedId(MediaStore.Downloads.EXTERNAL_CONTENT_URI,id).toString());
                            arr.put(o);
                        }
                    }
                } else {
                    File dir=Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                    File[] fs=dir.listFiles();
                    if(fs!=null){
                        Arrays.sort(fs,(a,b)->Long.compare(b.lastModified(),a.lastModified()));
                        for(File f:fs){ if(!f.isFile()) continue; JSONObject o=new JSONObject(); o.put("name",f.getName()); o.put("mime",guessMime(f.getName())); o.put("size",f.length()); o.put("date",f.lastModified()); arr.put(o); }
                    }
                }
                return arr.toString();
            } catch(Exception e){ return "[]"; }
        }

        @JavascriptInterface public void shareDownload(String name) {
            runOnUiThread(() -> {
                try {
                    Uri uri=null; String mime="*/*";
                    if(android.os.Build.VERSION.SDK_INT>=29){
                        String[] p={MediaStore.Downloads._ID,MediaStore.Downloads.MIME_TYPE};
                        try(Cursor c=getContentResolver().query(MediaStore.Downloads.EXTERNAL_CONTENT_URI,p,MediaStore.Downloads.DISPLAY_NAME+"=?",new String[]{name},null)){
                            if(c!=null && c.moveToFirst()){
                                long id=c.getLong(c.getColumnIndexOrThrow(MediaStore.Downloads._ID));
                                mime=c.getString(c.getColumnIndexOrThrow(MediaStore.Downloads.MIME_TYPE));
                                uri=ContentUris.withAppendedId(MediaStore.Downloads.EXTERNAL_CONTENT_URI,id);
                            }
                        }
                    } else {
                        File f=new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),name);
                        if(f.exists()){ uri=FileProvider.getUriForFile(MainActivity.this,getPackageName()+".fileprovider",f); mime=guessMime(name); }
                    }
                    if(uri==null){Toast.makeText(MainActivity.this,"File nahi mila",Toast.LENGTH_SHORT).show();return;}
                    Intent s=new Intent(Intent.ACTION_SEND); s.setType(mime==null?"*/*":mime); s.putExtra(Intent.EXTRA_STREAM,uri); s.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION); startActivity(Intent.createChooser(s,"Share file"));
                }catch(Exception e){Toast.makeText(MainActivity.this,"Share nahi hua",Toast.LENGTH_SHORT).show();}
            });
        }

        @JavascriptInterface public void openDownload(String name) {
            runOnUiThread(() -> {
                try {
                    Uri uri=null; String mime="*/*";
                    if(android.os.Build.VERSION.SDK_INT>=29){
                        String[] p={MediaStore.Downloads._ID,MediaStore.Downloads.MIME_TYPE};
                        try(Cursor c=getContentResolver().query(MediaStore.Downloads.EXTERNAL_CONTENT_URI,p,MediaStore.Downloads.DISPLAY_NAME+"=?",new String[]{name},null)){
                            if(c!=null && c.moveToFirst()){ long id=c.getLong(c.getColumnIndexOrThrow(MediaStore.Downloads._ID)); mime=c.getString(c.getColumnIndexOrThrow(MediaStore.Downloads.MIME_TYPE)); uri=ContentUris.withAppendedId(MediaStore.Downloads.EXTERNAL_CONTENT_URI,id); }
                        }
                    } else { File f=new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),name); if(f.exists()){uri=FileProvider.getUriForFile(MainActivity.this,getPackageName()+".fileprovider",f);mime=guessMime(name);} }
                    if(uri==null){Toast.makeText(MainActivity.this,"File nahi mila",Toast.LENGTH_SHORT).show();return;}
                    Intent v=new Intent(Intent.ACTION_VIEW);v.setDataAndType(uri,mime==null?"*/*":mime);v.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(v);
                }catch(Exception e){Toast.makeText(MainActivity.this,"File open nahi hua",Toast.LENGTH_SHORT).show();}
            });
        }

        private String guessMime(String name){String n=name==null?"":name.toLowerCase(Locale.ENGLISH);if(n.endsWith(".pdf"))return "application/pdf";if(n.endsWith(".jpg")||n.endsWith(".jpeg"))return "image/jpeg";if(n.endsWith(".png"))return "image/png";if(n.endsWith(".json"))return "application/json";return "application/octet-stream";}

        @JavascriptInterface public void failed(String message) {
            runOnUiThread(() -> Toast.makeText(MainActivity.this,"Download start nahi hua",Toast.LENGTH_LONG).show());
        }
    }


    private String detectRealMime(byte[] bytes, String fallback) {
        String mime = (fallback == null || fallback.trim().isEmpty())
                ? "application/octet-stream" : fallback;
        if (bytes != null && bytes.length >= 4 &&
                bytes[0] == 0x25 && bytes[1] == 0x50 && bytes[2] == 0x44 && bytes[3] == 0x46) {
            return "application/pdf";
        }
        if (bytes != null && bytes.length >= 8 &&
                (bytes[0] & 0xFF) == 0x89 && bytes[1] == 0x50 && bytes[2] == 0x4E &&
                bytes[3] == 0x47 && bytes[4] == 0x0D && bytes[5] == 0x0A &&
                bytes[6] == 0x1A && bytes[7] == 0x0A) {
            return "image/png";
        }
        if (bytes != null && bytes.length >= 3 &&
                (bytes[0] & 0xFF) == 0xFF && (bytes[1] & 0xFF) == 0xD8 &&
                (bytes[2] & 0xFF) == 0xFF) {
            return "image/jpeg";
        }
        return mime;
    }

    private String safeFileName(String name,String mime) {
        String n=name==null?"":name.trim();
        if(n.isEmpty()||n.equalsIgnoreCase("undefined")||n.equalsIgnoreCase("null")) {
            if("application/pdf".equalsIgnoreCase(mime)) n="Muzammil_Download.pdf";
            else if(mime!=null&&mime.toLowerCase(Locale.ENGLISH).contains("png")) n="Muzammil_Download.png";
            else if(mime!=null&&(mime.toLowerCase(Locale.ENGLISH).contains("jpeg")||mime.toLowerCase(Locale.ENGLISH).contains("jpg"))) n="Muzammil_Download.jpg";
            else n="Muzammil_Download";
        }
        n=n.replaceAll("[\\\\/:*?\"<>|]","_");
        String lower=n.toLowerCase(Locale.ENGLISH);
        if("application/pdf".equalsIgnoreCase(mime)&&!lower.endsWith(".pdf"))n+=".pdf";
        else if(mime!=null&&mime.toLowerCase(Locale.ENGLISH).contains("png")&&!lower.endsWith(".png"))n+=".png";
        else if(mime!=null&&(mime.toLowerCase(Locale.ENGLISH).contains("jpeg")||mime.toLowerCase(Locale.ENGLISH).contains("jpg"))&&!lower.endsWith(".jpg"))n+=".jpg";
        return n;
    }

    private void saveToDownloads(byte[] bytes,String filename,String mime)throws Exception{
        if(bytes==null||bytes.length==0)throw new Exception("empty file");
        if(android.os.Build.VERSION.SDK_INT>=29){
            ContentValues v=new ContentValues();
            v.put(MediaStore.Downloads.DISPLAY_NAME,filename);
            v.put(MediaStore.Downloads.MIME_TYPE,mime);
            v.put(MediaStore.Downloads.IS_PENDING,1);
            v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
            Uri uri=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);
            if(uri==null)throw new Exception("Downloads storage unavailable");
            try(OutputStream os=getContentResolver().openOutputStream(uri)){
                if(os==null)throw new Exception("output unavailable");
                os.write(bytes);
            }
            v.clear();v.put(MediaStore.Downloads.IS_PENDING,0);
            getContentResolver().update(uri,v,null,null);
        }else{
            File dir=Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            if(!dir.exists()&&!dir.mkdirs())throw new Exception("Downloads folder unavailable");
            File file=new File(dir,filename);
            try(OutputStream os=new java.io.FileOutputStream(file)){os.write(bytes);}
            android.media.MediaScannerConnection.scanFile(this,new String[]{file.getAbsolutePath()},new String[]{mime},null);
        }
        runOnUiThread(() -> { Toast.makeText(MainActivity.this,"Download complete: "+filename,Toast.LENGTH_SHORT).show(); runJs("window.refreshDownloads && window.refreshDownloads();"); });
    }



    private void shareSavedDownload(String filename, String mime) {
        runOnUiThread(() -> {
            try {
                Uri uri = null;
                if (Build.VERSION.SDK_INT >= 29) {
                    String[] p = {MediaStore.Downloads._ID, MediaStore.Downloads.MIME_TYPE};
                    try (Cursor c = getContentResolver().query(
                            MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                            p,
                            MediaStore.Downloads.DISPLAY_NAME + "=?",
                            new String[]{filename},
                            MediaStore.Downloads.DATE_ADDED + " DESC")) {
                        if (c != null && c.moveToFirst()) {
                            long id = c.getLong(c.getColumnIndexOrThrow(MediaStore.Downloads._ID));
                            uri = ContentUris.withAppendedId(MediaStore.Downloads.EXTERNAL_CONTENT_URI, id);
                        }
                    }
                } else {
                    File f = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), filename);
                    if (f.exists()) uri = FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".fileprovider", f);
                }

                if (uri == null) {
                    Toast.makeText(MainActivity.this, "File save nahi mila. Pehle Download karein.", Toast.LENGTH_LONG).show();
                    return;
                }

                Intent s = new Intent(Intent.ACTION_SEND);
                s.setType(mime == null ? "*/*" : mime);
                s.putExtra(Intent.EXTRA_STREAM, uri);
                s.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(Intent.createChooser(s, "Share file"));
            } catch (Exception e) {
                Toast.makeText(MainActivity.this, "Share nahi hua: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }

    private String receiptBaseName(JSONObject d) {
        String customer = d.optString("n", "Customer").trim().replaceAll("[\\\\/:*?\"<>|]", "_");
        if (customer.isEmpty()) customer = "Customer";
        String id = d.optString("id", String.valueOf(System.currentTimeMillis())).replaceAll("[^0-9A-Za-z_-]", "_");
        return safeFileName("Receipt-" + customer + "-" + id, "application/pdf").replaceAll("\\.pdf$", "");
    }

    public class PdfBridge {
        @JavascriptInterface public void saveBioPdf(String json) {
            if (!isLocalAppPage()) return;
            try {
                JSONObject d = new JSONObject(json == null ? "{}" : json);
                PdfDocument doc = new PdfDocument();
                Paint title = new Paint(Paint.ANTI_ALIAS_FLAG);
                title.setColor(Color.rgb(23, 105, 255));
                title.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
                title.setTextSize(22);

                Paint head = new Paint(Paint.ANTI_ALIAS_FLAG);
                head.setColor(Color.rgb(23, 105, 255));
                head.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
                head.setTextSize(15);

                Paint body = new Paint(Paint.ANTI_ALIAS_FLAG);
                body.setColor(Color.rgb(30, 36, 50));
                body.setTextSize(11);

                PdfDocument.Page page = null;
                Canvas canvas = null;
                int pageNo = 0;
                float y = 52;
                final float left = 40;
                final float right = 555;
                final float maxText = 500;

                java.util.ArrayList<String> lines = new java.util.ArrayList<>();
                lines.add("NAME|" + d.optString("name", "Bio Data / Resume"));
                lines.add("TEMPLATE|" + d.optString("template", ""));
                lines.add("HEAD|Personal Details");
                lines.add("Date of Birth|" + d.optString("dob", ""));
                lines.add("Gender|" + d.optString("gender", ""));
                lines.add("Mobile / WhatsApp|" + d.optString("mobile", ""));
                lines.add("Email|" + d.optString("email", ""));
                lines.add("Address|" + d.optString("address", ""));
                lines.add("HEAD|Education & Work");
                lines.add("Education|" + d.optString("education", ""));
                lines.add("Occupation|" + d.optString("job", ""));
                lines.add("Income|" + d.optString("income", ""));
                lines.add("HEAD|Additional Details");
                lines.add("Details|" + d.optString("family", ""));
                lines.add("Custom|" + d.optString("custom", ""));
                lines.add("FOOT|Generated with Muzammil Online Service");

                Bitmap photo = null;
                String photoData = d.optString("photo", "");
                if (photoData.startsWith("data:") && photoData.contains(",")) {
                    try {
                        byte[] pb = Base64.decode(photoData.substring(photoData.indexOf(',') + 1), Base64.DEFAULT);
                        photo = BitmapFactory.decodeByteArray(pb, 0, pb.length);
                    } catch (Exception ignored) {}
                }

                for (String line : lines) {
                    String[] parts = line.split("\\|", 2);
                    String type = parts[0];
                    String text = parts.length > 1 ? parts[1] : "";

                    if (page == null || y > 785) {
                        if (page != null) doc.finishPage(page);
                        pageNo++;
                        PdfDocument.PageInfo info = new PdfDocument.PageInfo.Builder(595, 842, pageNo).create();
                        page = doc.startPage(info);
                        canvas = page.getCanvas();
                        y = 45;

                        Paint border = new Paint(Paint.ANTI_ALIAS_FLAG);
                        border.setStyle(Paint.Style.STROKE);
                        border.setColor(Color.rgb(210, 220, 235));
                        border.setStrokeWidth(1);
                        canvas.drawRect(24, 24, 571, 818, border);

                        if (pageNo == 1 && photo != null) {
                            float pw = 100, ph = 120;
                            float scale = Math.min(pw / photo.getWidth(), ph / photo.getHeight());
                            float dw = photo.getWidth() * scale;
                            float dh = photo.getHeight() * scale;
                            float px = 450 + (pw - dw) / 2;
                            float py = 45 + (ph - dh) / 2;
                            canvas.drawBitmap(photo, null, new android.graphics.RectF(px, py, px + dw, py + dh), body);
                            y = 180;
                        }
                    }

                    if ("NAME".equals(type)) {
                        canvas.drawText(text.isEmpty() ? "Bio Data / Resume" : text, left, y, title);
                        y += 30;
                    } else if ("HEAD".equals(type)) {
                        if (y > 760) {
                            doc.finishPage(page);
                            PdfDocument.PageInfo info = new PdfDocument.PageInfo.Builder(595, 842, ++pageNo).create();
                            page = doc.startPage(info);
                            canvas = page.getCanvas();
                            y = 45;
                        }
                        canvas.drawText(text, left, y, head);
                        y += 22;
                        Paint linePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
                        linePaint.setColor(Color.rgb(210, 220, 235));
                        canvas.drawRect(left, y, right, y + 1, linePaint);
                        y += 12;
                    } else if ("FOOT".equals(type)) {
                        Paint foot = new Paint(Paint.ANTI_ALIAS_FLAG);
                        foot.setColor(Color.GRAY);
                        foot.setTextSize(9);
                        canvas.drawText(text, left, Math.min(y + 10, 805), foot);
                        y += 22;
                    } else {
                        String label = parts[0];
                        String value = parts.length > 1 ? parts[1] : "";
                        String full = label + ": " + value;
                        y = drawWrapped(canvas, full, body, left, y, maxText, 17);
                        y += 5;
                    }
                }

                if (page != null) doc.finishPage(page);

                java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
                doc.writeTo(baos);
                doc.close();

                String nm = d.optString("name", "BioData").trim().replaceAll("[\\\\/:*?\"<>|]", "_");
                if (nm.isEmpty()) nm = "BioData";
                saveToDownloads(baos.toByteArray(), safeFileName("Muzammil-" + nm + ".pdf", "application/pdf"), "application/pdf");
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "PDF create nahi hua: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        }

        @JavascriptInterface public void saveReceiptPdf(String json) {
            if (!isLocalAppPage()) return;
            try {
                JSONObject d = new JSONObject(json == null ? "{}" : json);
                PdfDocument doc = new PdfDocument();
                PdfDocument.PageInfo info = new PdfDocument.PageInfo.Builder(595, 842, 1).create();
                PdfDocument.Page page = doc.startPage(info);
                Canvas c = page.getCanvas();

                Paint title = new Paint(Paint.ANTI_ALIAS_FLAG);
                title.setColor(Color.rgb(23,105,255));
                title.setTypeface(Typeface.DEFAULT_BOLD);
                title.setTextSize(25);

                Paint head = new Paint(Paint.ANTI_ALIAS_FLAG);
                head.setColor(Color.rgb(30,36,50));
                head.setTypeface(Typeface.DEFAULT_BOLD);
                head.setTextSize(16);

                Paint body = new Paint(Paint.ANTI_ALIAS_FLAG);
                body.setColor(Color.rgb(45,50,60));
                body.setTextSize(13);

                Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
                line.setColor(Color.rgb(220,226,235));
                line.setStrokeWidth(1);

                c.drawRect(28,28,567,814,line);
                c.drawText("MUZAMMIL ONLINE SERVICE",50,75,title);
                c.drawText("Payment / Service Receipt",50,105,head);
                c.drawLine(50,125,545,125,line);

                float y=165;
                String customer=d.optString("n","");
                String service=d.optString("s","");
                String amount=d.optString("a","");
                String date=d.optString("date","");
                String mobile=d.optString("mobile","");
                String status=d.optString("status","Pending");

                c.drawText("Customer Name",55,y,head); c.drawText(customer,210,y,body); y+=42;
                c.drawText("Mobile / WhatsApp",55,y,head); c.drawText(mobile,210,y,body); y+=42;
                c.drawText("Service",55,y,head); c.drawText(service,210,y,body); y+=42;
                c.drawText("Date",55,y,head); c.drawText(date,210,y,body); y+=42;
                c.drawText("Status",55,y,head); c.drawText(status,210,y,body); y+=55;

                c.drawLine(50,y,545,y,line); y+=45;
                c.drawText("TOTAL AMOUNT",55,y,head);
                Paint amt=new Paint(Paint.ANTI_ALIAS_FLAG);
                amt.setColor(Color.rgb(15,138,95));
                amt.setTypeface(Typeface.DEFAULT_BOLD);
                amt.setTextSize(24);
                c.drawText("Rs. "+amount,390,y,amt);
                y+=70;

                c.drawText("Thank you for using Muzammil Online Service.",55,y,body);
                c.drawText("Imran Khan",55,y+28,body);
                c.drawText("Mobile: 9561460313",55,y+50,body);
                c.drawText("This receipt was generated by the app.",55,775,body);

                doc.finishPage(page);
                java.io.ByteArrayOutputStream baos=new java.io.ByteArrayOutputStream();
                doc.writeTo(baos);
                doc.close();

                String nm=receiptBaseName(d);
                saveToDownloads(baos.toByteArray(), nm+".pdf", "application/pdf");
            } catch(Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this,"Receipt PDF nahi bana: "+e.getMessage(),Toast.LENGTH_LONG).show());
            }
        }

        @JavascriptInterface public void saveReceiptJpg(String json) {
            if (!isLocalAppPage()) return;
            try {
                JSONObject d = new JSONObject(json == null ? "{}" : json);
                final int W = 1240, H = 1754;
                Bitmap bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888);
                Canvas c = new Canvas(bmp);
                c.drawColor(Color.WHITE);

                Paint title=new Paint(Paint.ANTI_ALIAS_FLAG);
                title.setColor(Color.rgb(23,105,255));
                title.setTypeface(Typeface.DEFAULT_BOLD);
                title.setTextSize(44);

                Paint head=new Paint(Paint.ANTI_ALIAS_FLAG);
                head.setColor(Color.rgb(30,36,50));
                head.setTypeface(Typeface.DEFAULT_BOLD);
                head.setTextSize(28);

                Paint body=new Paint(Paint.ANTI_ALIAS_FLAG);
                body.setColor(Color.rgb(45,50,60));
                body.setTextSize(24);

                Paint line=new Paint(Paint.ANTI_ALIAS_FLAG);
                line.setColor(Color.rgb(220,226,235));
                line.setStyle(Paint.Style.STROKE);
                line.setStrokeWidth(3);

                c.drawRect(45,45,1195,1709,line);
                c.drawText("MUZAMMIL ONLINE SERVICE",95,140,title);
                c.drawText("Payment / Service Receipt",95,195,head);

                float y=290;
                String customer=d.optString("n","");
                String service=d.optString("s","");
                String amount=d.optString("a","");
                String date=d.optString("date","");
                String mobile=d.optString("mobile","");
                String status=d.optString("status","Pending");

                c.drawText("Customer Name",100,y,head); c.drawText(customer,430,y,body); y+=75;
                c.drawText("Mobile / WhatsApp",100,y,head); c.drawText(mobile,430,y,body); y+=75;
                c.drawText("Service",100,y,head); c.drawText(service,430,y,body); y+=75;
                c.drawText("Date",100,y,head); c.drawText(date,430,y,body); y+=75;
                c.drawText("Status",100,y,head); c.drawText(status,430,y,body); y+=100;

                c.drawLine(95,y,1145,y,line); y+=80;
                c.drawText("TOTAL AMOUNT",100,y,head);
                Paint amt=new Paint(Paint.ANTI_ALIAS_FLAG);
                amt.setColor(Color.rgb(15,138,95));
                amt.setTypeface(Typeface.DEFAULT_BOLD);
                amt.setTextSize(42);
                c.drawText("Rs. "+amount,850,y,amt);
                y+=115;

                c.drawText("Thank you for using Muzammil Online Service.",100,y,body);
                c.drawText("Imran Khan • 9561460313",100,y+55,body);
                c.drawText("Generated by Muzammil Online Service",100,1625,body);

                java.io.ByteArrayOutputStream baos=new java.io.ByteArrayOutputStream();
                bmp.compress(Bitmap.CompressFormat.JPEG,94,baos);
                bmp.recycle();

                String nm=receiptBaseName(d);
                saveToDownloads(baos.toByteArray(), nm+".jpg", "image/jpeg");
            } catch(Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this,"Receipt JPG nahi bana: "+e.getMessage(),Toast.LENGTH_LONG).show());
            }
        }

        @JavascriptInterface public void shareReceiptPdf(String json) {
            if (!isLocalAppPage()) return;
            try {
                JSONObject d = new JSONObject(json == null ? "{}" : json);
                saveReceiptPdf(json);
                String name = receiptBaseName(d) + ".pdf";
                new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(() -> shareSavedDownload(name, "application/pdf"), 250);
            } catch(Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this,"Receipt PDF share nahi hua.",Toast.LENGTH_LONG).show());
            }
        }

        @JavascriptInterface public void shareReceiptJpg(String json) {
            if (!isLocalAppPage()) return;
            try {
                JSONObject d = new JSONObject(json == null ? "{}" : json);
                saveReceiptJpg(json);
                String name = receiptBaseName(d) + ".jpg";
                new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(() -> shareSavedDownload(name, "image/jpeg"), 250);
            } catch(Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this,"Receipt JPG share nahi hua.",Toast.LENGTH_LONG).show());
            }
        }

        @JavascriptInterface public void shareBioPdf(String json) {
            if (!isLocalAppPage()) return;
            try {
                JSONObject d = new JSONObject(json == null ? "{}" : json);
                saveBioPdf(json);
                String nm=d.optString("name","BioData").trim().replaceAll("[\\\\/:*?\"<>|]","_");
                if(nm.isEmpty()) nm="BioData";
                final String name=safeFileName("Muzammil-"+nm+".pdf","application/pdf");
                new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(() -> shareSavedDownload(name,"application/pdf"),250);
            } catch(Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this,"PDF share nahi hua.",Toast.LENGTH_LONG).show());
            }
        }

        @JavascriptInterface public void shareBioJpg(String json) {
            if (!isLocalAppPage()) return;
            try {
                JSONObject d = new JSONObject(json == null ? "{}" : json);
                saveBioJpg(json);
                String nm=d.optString("name","BioData").trim().replaceAll("[\\\\/:*?\"<>|]","_");
                if(nm.isEmpty()) nm="BioData";
                final String name=safeFileName("Muzammil-"+nm+".jpg","image/jpeg");
                new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(() -> shareSavedDownload(name,"image/jpeg"),250);
            } catch(Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this,"JPG share nahi hua.",Toast.LENGTH_LONG).show());
            }
        }

        @JavascriptInterface public void saveBioJpg(String json) {
            if (!isLocalAppPage()) return;
            try {
                JSONObject d = new JSONObject(json == null ? "{}" : json);
                final int W = 1240;
                final int H = 1754;
                Bitmap bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888);
                Canvas c = new Canvas(bmp);
                c.drawColor(Color.WHITE);

                Paint title = new Paint(Paint.ANTI_ALIAS_FLAG);
                title.setColor(Color.rgb(23,105,255));
                title.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
                title.setTextSize(42);

                Paint head = new Paint(Paint.ANTI_ALIAS_FLAG);
                head.setColor(Color.rgb(23,105,255));
                head.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
                head.setTextSize(28);

                Paint body = new Paint(Paint.ANTI_ALIAS_FLAG);
                body.setColor(Color.rgb(30,36,50));
                body.setTextSize(23);

                Paint border = new Paint(Paint.ANTI_ALIAS_FLAG);
                border.setStyle(Paint.Style.STROKE);
                border.setStrokeWidth(3);
                border.setColor(Color.rgb(210,220,235));
                c.drawRect(28,28,W-28,H-28,border);

                Bitmap photo = null;
                String photoData = d.optString("photo","");
                if(photoData.startsWith("data:") && photoData.contains(",")){
                    try{
                        byte[] pb=Base64.decode(photoData.substring(photoData.indexOf(',')+1),Base64.DEFAULT);
                        photo=BitmapFactory.decodeByteArray(pb,0,pb.length);
                    }catch(Exception ignored){}
                }

                float y=80;
                c.drawText(d.optString("name","Bio Data / Resume"),55,y,title);
                if(photo!=null){
                    float pw=180, ph=210;
                    float scale=Math.min(pw/photo.getWidth(),ph/photo.getHeight());
                    float dw=photo.getWidth()*scale, dh=photo.getHeight()*scale;
                    c.drawBitmap(photo,null,new android.graphics.RectF(W-55-pw+(pw-dw)/2,55+(ph-dh)/2,W-55-pw+(pw-dw)/2+dw,55+(ph-dh)/2+dh),body);
                }
                y=145;
                c.drawText("Template: "+d.optString("template",""),55,y,body);
                y=205;
                String[][] rows={
                    {"Date of Birth",d.optString("dob","")},
                    {"Gender",d.optString("gender","")},
                    {"Mobile",d.optString("mobile","")},
                    {"Email",d.optString("email","")},
                    {"Address",d.optString("address","")}
                };
                c.drawText("Personal Details",55,y,head); y+=48;
                for(String[] row:rows){ y=drawWrapped(c,row[0]+": "+row[1],body,55,y,W-110,34)+12; }

                c.drawText("Education & Work",55,y,head); y+=48;
                String[][] workRows={
                    {"Education",d.optString("education","")},
                    {"Occupation",d.optString("job","")},
                    {"Income",d.optString("income","")}
                };
                for(String[] row:workRows){ y=drawWrapped(c,row[0]+": "+row[1],body,55,y,W-110,34)+12; }

                c.drawText("Additional Details",55,y,head); y+=48;
                y=drawWrapped(c,"Details: "+d.optString("family",""),body,55,y,W-110,34)+12;
                y=drawWrapped(c,"Custom: "+d.optString("custom",""),body,55,y,W-110,34)+20;

                Paint foot=new Paint(Paint.ANTI_ALIAS_FLAG);
                foot.setColor(Color.GRAY); foot.setTextSize(18);
                c.drawText("Generated with Muzammil Online Service",55,Math.min(y+30,H-55),foot);

                java.io.ByteArrayOutputStream baos=new java.io.ByteArrayOutputStream();
                bmp.compress(Bitmap.CompressFormat.JPEG,92,baos);
                bmp.recycle();

                String nm=d.optString("name","BioData").trim().replaceAll("[\\\\/:*?\"<>|]","_");
                if(nm.isEmpty()) nm="BioData";
                saveToDownloads(baos.toByteArray(),safeFileName("Muzammil-"+nm+".jpg","image/jpeg"),"image/jpeg");
            }catch(Exception e){
                runOnUiThread(() -> Toast.makeText(MainActivity.this,"JPG create nahi hua: "+e.getMessage(),Toast.LENGTH_LONG).show());
            }
        }
    }

    private float drawWrapped(Canvas canvas, String text, Paint paint, float x, float y, float maxWidth, float lineHeight) {
        if (text == null) text = "";
        String remaining = text.replace("\r", "");
        if (remaining.isEmpty()) {
            canvas.drawText("", x, y, paint);
            return y + lineHeight;
        }
        while (!remaining.isEmpty()) {
            int count = paint.breakText(remaining, true, maxWidth, null);
            if (count <= 0) count = Math.min(remaining.length(), 1);
            String part = remaining.substring(0, count);
            canvas.drawText(part, x, y, paint);
            y += lineHeight;
            remaining = remaining.substring(count).trim();
        }
        return y;
    }

    private boolean isLocalAppPage() {
        try {
            String u = w == null ? "" : w.getUrl();
            return u != null && u.startsWith("file:///android_asset/");
        } catch (Exception e) { return false; }
    }

    public class AIBridge {
        @JavascriptInterface public boolean hasApiKey() { return isLocalAppPage() && prefs.getString("openai_key", "").trim().length() > 0; }
        @JavascriptInterface public void saveApiKey(String key) {
            if (!isLocalAppPage()) return;
            if (key == null) key = "";
            prefs.edit().putString("openai_key", key.trim()).apply();
        }
        @JavascriptInterface public void clearApiKey() { if (isLocalAppPage()) prefs.edit().remove("openai_key").apply(); }
        @JavascriptInterface public void ask(String prompt) {
            if (!isLocalAppPage()) return;
            final String p = prompt == null ? "" : prompt.trim();
            final String key = prefs.getString("openai_key", "").trim();
            if (key.isEmpty()) {
                runJs("window.aiReply && window.aiReply('API key set nahi hai. AI Bot me OpenAI API key add karein.');");
                return;
            }
            if (p.isEmpty()) return;
            aiExecutor.execute(() -> {
                String answer;
                try { answer = callOpenAI(key, p); }
                catch (Exception e) { answer = "AI connection error: " + (e.getMessage() == null ? "unknown error" : e.getMessage()); }
                final String safe = jsQuote(answer);
                runJs("window.aiReply && window.aiReply(" + safe + ");");
            });
        }
    }

    private void runJs(final String js) {
        runOnUiThread(() -> { if (w != null) w.evaluateJavascript(js, null); });
    }

    private String callOpenAI(String key, String prompt) throws Exception {
        URL url = new URL("https://api.openai.com/v1/responses");
        HttpURLConnection c = (HttpURLConnection) url.openConnection();
        c.setRequestMethod("POST"); c.setDoOutput(true); c.setConnectTimeout(20000); c.setReadTimeout(60000);
        c.setRequestProperty("Authorization", "Bearer " + key);
        c.setRequestProperty("Content-Type", "application/json");
        JSONObject body = new JSONObject();
        body.put("model", "gpt-5.6-luna");
        body.put("input", prompt);
        try (OutputStream os = c.getOutputStream()) { os.write(body.toString().getBytes(StandardCharsets.UTF_8)); }
        int code = c.getResponseCode();
        InputStream stream = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
        String text = readAll(stream);
        if (code < 200 || code >= 300) {
            try { JSONObject er = new JSONObject(text); JSONObject e = er.optJSONObject("error"); throw new Exception(e != null ? e.optString("message", "API error") : "HTTP " + code); }
            catch (org.json.JSONException je) { throw new Exception("HTTP " + code); }
        }
        JSONObject r = new JSONObject(text);
        String out = r.optString("output_text", "");
        if (!out.isEmpty()) return out;
        JSONArray output = r.optJSONArray("output");
        if (output != null) {
            StringBuilder sb = new StringBuilder();
            for (int i=0;i<output.length();i++) {
                JSONObject item=output.optJSONObject(i); JSONArray content=item==null?null:item.optJSONArray("content");
                if(content!=null) for(int j=0;j<content.length();j++){ JSONObject part=content.optJSONObject(j); if(part!=null){ String t=part.optString("text",""); if(!t.isEmpty()){if(sb.length()>0)sb.append("\n");sb.append(t);}}}
            }
            if(sb.length()>0)return sb.toString();
        }
        return "AI ne koi text response nahi diya.";
    }

    private String readAll(InputStream in) throws Exception {
        if (in == null) return "";
        StringBuilder sb=new StringBuilder(); try(BufferedReader br=new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))){String line;while((line=br.readLine())!=null)sb.append(line);}
        return sb.toString();
    }

    private String jsQuote(String s) {
        if(s==null)s=""; return JSONObject.quote(s);
    }


    private void setNativeProgress(int progress) {
        if (nativeProgressFill == null) return;
        final int p = Math.max(0, Math.min(100, progress));
        nativeProgressFill.post(() -> {
            ViewGroup.LayoutParams lp = nativeProgressFill.getLayoutParams();
            lp.width = (int)(nativeProgressTrack.getWidth() * (p / 100f));
            nativeProgressFill.setLayoutParams(lp);
            nativeProgressFill.setVisibility(android.view.View.VISIBLE);
            if (p >= 100) {
                nativeProgressFill.postDelayed(() -> setNativeProgress(0), 350);
            }
        });
    }

    private void translateCurrentPage() {
        if (w == null) return;
        String current = w.getUrl();
        if (current == null || current.isEmpty()) {
            Toast.makeText(this, "Website abhi load nahi hui", Toast.LENGTH_SHORT).show();
            return;
        }
        if (current.contains("translate.google.com/translate") && originalPortalUrl != null) {
            setNativeProgress(12);
            w.loadUrl(originalPortalUrl);
            return;
        }
        if (current.startsWith("file:///android_asset/")) {
            Toast.makeText(this, "Translation button government/other websites ke liye hai.", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            originalPortalUrl = current;
            String target = "https://translate.google.com/translate?sl=auto&tl=en&u=" + Uri.encode(current);
            setNativeProgress(10);
            w.loadUrl(target);
        } catch (Exception e) {
            Toast.makeText(this, "Translation start nahi hui", Toast.LENGTH_SHORT).show();
        }
    }

    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    // Called by the PDF/Bio Data Maker. Android's print dialog supports Save as PDF.
    public void printWebPage(String jobName) {
        try {
            PrintManager pm = (PrintManager)getSystemService(Context.PRINT_SERVICE);
            android.print.PrintDocumentAdapter adapter = w.createPrintDocumentAdapter(jobName == null ? "Muzammil PDF" : jobName);
            pm.print(jobName == null ? "Muzammil PDF" : jobName, adapter, new PrintAttributes.Builder()
                    .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                    .setColorMode(PrintAttributes.COLOR_MODE_COLOR)
                    .setMinMargins(PrintAttributes.Margins.NO_MARGINS).build());
        } catch (Exception e) {
            Toast.makeText(this, "PDF print open nahi hua", Toast.LENGTH_LONG).show();
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_PICKER) {
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null) {
                Uri u = data.getData();
                if (u != null) results = new Uri[]{u};
            }
            if (uploadCallback != null) uploadCallback.onReceiveValue(results);
            uploadCallback = null;
        }
    }

    @Override public void onBackPressed() { if (w != null && w.canGoBack()) w.goBack(); else super.onBackPressed(); }
    @Override protected void onDestroy() {
        clockHandler.removeCallbacks(clockRunnable);
        aiExecutor.shutdownNow();
        if (w != null) { w.stopLoading(); w.loadUrl("about:blank"); w.removeAllViews(); w.destroy(); w = null; }
        super.onDestroy();
    }



    private void requestCameraAndStoragePermissions() {
        java.util.ArrayList<String> permissions = new java.util.ArrayList<>();

        if (Build.VERSION.SDK_INT >= 33) {
            permissions.add(Manifest.permission.READ_MEDIA_IMAGES);
            permissions.add(Manifest.permission.READ_MEDIA_VIDEO);
        } else {
            permissions.add(Manifest.permission.READ_EXTERNAL_STORAGE);
            if (Build.VERSION.SDK_INT <= 28) {
                permissions.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
            }
        }

        permissions.add(Manifest.permission.CAMERA);

        java.util.ArrayList<String> needed = new java.util.ArrayList<>();
        for (String permission : permissions) {
            if (checkSelfPermission(permission) != PackageManager.PERMISSION_GRANTED) {
                needed.add(permission);
            }
        }

        if (!needed.isEmpty()) {
            requestPermissions(needed.toArray(new String[0]), 501);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 501) {
            boolean cameraGranted = checkSelfPermission(Manifest.permission.CAMERA)
                    == PackageManager.PERMISSION_GRANTED;
            boolean mediaGranted;
            if (Build.VERSION.SDK_INT >= 33) {
                mediaGranted =
                        checkSelfPermission(Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED
                        || checkSelfPermission(Manifest.permission.READ_MEDIA_VIDEO) == PackageManager.PERMISSION_GRANTED;
            } else {
                mediaGranted = checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE)
                        == PackageManager.PERMISSION_GRANTED;
            }

            if (cameraGranted && mediaGranted) {
                Toast.makeText(this, "Camera aur storage permission mil gaya.", Toast.LENGTH_SHORT).show();
            }
        }
    }


    // Native CV/Bio Data export helpers.
    private File createCvPdfNative(String title, String body) throws Exception {
        File dir = new File(getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), "CV_BioData");
        if (!dir.exists()) dir.mkdirs();
        String safe = (title == null || title.trim().isEmpty()) ? "CV_BioData" : title.replaceAll("[^a-zA-Z0-9._-]", "_");
        File file = new File(dir, safe + "_" + System.currentTimeMillis() + ".pdf");

        PdfDocument doc = new PdfDocument();
        PdfDocument.PageInfo info = new PdfDocument.PageInfo.Builder(595, 842, 1).create();
        PdfDocument.Page page = doc.startPage(info);
        Canvas canvas = page.getCanvas();
        android.graphics.Paint paint = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        paint.setTextSize(18);
        int y=45;
        for (String line : (body == null ? "" : body).split("\\n")) {
            canvas.drawText(line.length()>70 ? line.substring(0,70) : line, 30, y, paint);
            y += 25;
            if (y > 810) break;
        }
        doc.finishPage(page);
        java.io.FileOutputStream fos = new java.io.FileOutputStream(file);
        doc.writeTo(fos); fos.close(); doc.close();
        return file;
    }

    private File createCvJpgNative(String title, String body) throws Exception {
        File dir = new File(getExternalFilesDir(Environment.DIRECTORY_PICTURES), "CV_BioData");
        if (!dir.exists()) dir.mkdirs();
        String safe = (title == null || title.trim().isEmpty()) ? "CV_BioData" : title.replaceAll("[^a-zA-Z0-9._-]", "_");
        File file = new File(dir, safe + "_" + System.currentTimeMillis() + ".jpg");

        Bitmap bmp = Bitmap.createBitmap(1240, 1754, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bmp);
        canvas.drawColor(android.graphics.Color.WHITE);
        android.graphics.Paint paint = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        paint.setColor(android.graphics.Color.BLACK);
        paint.setTextSize(32);
        int y=65;
        for (String line : (body == null ? "" : body).split("\\n")) {
            canvas.drawText(line.length()>55 ? line.substring(0,55) : line, 45, y, paint);
            y += 42;
            if (y > 1700) break;
        }
        java.io.FileOutputStream fos = new java.io.FileOutputStream(file);
        bmp.compress(Bitmap.CompressFormat.JPEG, 95, fos); fos.close(); bmp.recycle();
        return file;
    }

}
