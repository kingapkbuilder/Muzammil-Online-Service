plugins { id("com.android.application") }
android {
    namespace="com.muzammil.onlineservice"
    compileSdk=35
    defaultConfig {
        applicationId="com.muzammil.onlineservice"
        minSdk=24
        targetSdk=35
        versionCode = 110
        versionName = "110.0.0"
    }

    signingConfigs {
        create("release") {
            val keyFile = file("release.keystore")
            if (keyFile.exists()) {
                storeFile = keyFile
                storePassword = "MuzammilServiceReleaseKey2026!"
                keyAlias = "muzammil_key"
                keyPassword = "MuzammilServiceReleaseKey2026!"
                enableV1Signing = true
                enableV2Signing = true
                enableV3Signing = true
                enableV4Signing = true
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            isDebuggable = false
            val relConfig = signingConfigs.findByName("release")
            if (relConfig?.storeFile?.exists() == true) {
                signingConfig = relConfig
            }
        }
        debug {
            isDebuggable = true
        }
    }
}


dependencies {
    implementation("androidx.core:core:1.15.0")
    implementation("com.tom-roush:pdfbox-android:2.0.27.0")
}
