/**
 * 🎬 PREMIERE STUDIO PRO - MULTILAYER NON-LINEAR VIDEO EDITOR
 * Full-Featured NLE Engine for Muzammil Online Service
 * Adobe Premiere Pro-style Tracks (V3, V2, V1, A1, A2, A3), CTI Playhead,
 * Real-time Canvas Compositing, Lumetri Color, Motion Controls & Export
 */

(function () {
  'use strict';

  // 4K Ultra HD & Broadcast Resolution Presets Dictionary
  const PRESET_RESOLUTIONS = {
    '4k_16_9': { width: 3840, height: 2160, aspect: '16 / 9', label: '4K UHD (3840×2160) 16:9 Landscape' },
    '4k_9_16': { width: 2160, height: 3840, aspect: '9 / 16', label: '4K Vertical UHD (2160×3840) Reels' },
    '4k_1_1': { width: 2160, height: 2160, aspect: '1 / 1', label: '4K Square (2160×2160)' },
    '4k_dci': { width: 4096, height: 2160, aspect: '1.9 / 1', label: '4K Cinema DCI (4096×2160)' },
    '2k_1440p': { width: 2560, height: 1440, aspect: '16 / 9', label: '2K QHD (2560×1440)' },
    '1080p_16_9': { width: 1920, height: 1080, aspect: '16 / 9', label: '1080p Full HD (1920×1080)' },
    '1080p_9_16': { width: 1080, height: 1920, aspect: '9 / 16', label: '1080p Vertical Reels (1080×1920)' },
    '1080p_1_1': { width: 1080, height: 1080, aspect: '1 / 1', label: '1080p Square (1080×1080)' },
    '1080p_4_5': { width: 1080, height: 1350, aspect: '4 / 5', label: 'Social Portrait (1080×1350)' },
    '720p_16_9': { width: 1280, height: 720, aspect: '16 / 9', label: '720p HD (1280×720)' },
    '16:9': { width: 3840, height: 2160, aspect: '16 / 9', label: '4K UHD (3840×2160) 16:9 Landscape' },
    '9:16': { width: 2160, height: 3840, aspect: '9 / 16', label: '4K Vertical UHD (2160×3840) Reels' },
    '1:1': { width: 2160, height: 2160, aspect: '1 / 1', label: '4K Square (2160×2160)' },
    '4:5': { width: 1080, height: 1350, aspect: '4 / 5', label: 'Social Portrait (1080×1350)' }
  };

  // State Management
  const EditorState = {
    isOpen: false,
    fullscreenStudio: false,
    activeLeftTab: 'media',
    resolutionKey: '4k_16_9',
    aspectRatio: '16:9',
    canvasWidth: 3840,
    canvasHeight: 2160,
    fps: 30,
    duration: 15.0, // total timeline sequence duration in seconds
    currentTime: 0.0, // in seconds
    isPlaying: false,
    selectedClipId: null,
    activeTool: 'select', // 'select' (V), 'razor' (C), 'slip' (Y), 'hand' (H)
    zoomPixelsPerSecond: 45, // zoom level
    audioContext: null,
    audioMasterGain: null,
    isChromaEyeDropperActive: false,
    history: [],
    tracks: {
      V3: { name: 'V3 (Titles & Overlays)', visible: true, locked: false, type: 'video' },
      V2: { name: 'V2 (B-Roll & Chroma)', visible: true, locked: false, type: 'video' },
      V1: { name: 'V1 (Main Video Track)', visible: true, locked: false, type: 'video' },
      A1: { name: 'A1 (Main Audio / Dialogue)', muted: false, solo: false, locked: false, volume: 1.0, type: 'audio' },
      A2: { name: 'A2 (Music BGM)', muted: false, solo: false, locked: false, volume: 0.8, type: 'audio' },
      A3: { name: 'A3 (Sound FX / Voiceover)', muted: false, solo: false, locked: false, volume: 1.0, type: 'audio' }
    },
    clips: [], // Array of clip objects
    projectMedia: [], // Library of imported files
    inPoint: 0.0,
    outPoint: 15.0,
    snappingEnabled: true,
    renderQueue: null,
    playheadTimer: null,
    lastFrameTimestamp: 0
  };

  // Helper: Format seconds to SMPTE Timecode (HH:MM:SS:FF)
  function formatSMPTE(seconds, fps = 30) {
    if (isNaN(seconds) || seconds < 0) seconds = 0;
    const totalFrames = Math.floor(seconds * fps);
    const ff = totalFrames % fps;
    const s = Math.floor(seconds) % 60;
    const m = Math.floor(seconds / 60) % 60;
    const h = Math.floor(seconds / 3600);
    const pad = n => String(n).padStart(2, '0');
    return `${pad(h)}:${pad(m)}:${pad(s)}:${pad(ff)}`;
  }

  // Audio Context Initializer
  function getAudioCtx() {
    if (!EditorState.audioContext) {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (AudioCtx) {
        EditorState.audioContext = new AudioCtx();
        EditorState.audioMasterGain = EditorState.audioContext.createGain();
        EditorState.audioMasterGain.connect(EditorState.audioContext.destination);
      }
    }
    if (EditorState.audioContext && EditorState.audioContext.state === 'suspended') {
      EditorState.audioContext.resume().catch(() => {});
    }
    return EditorState.audioContext;
  }

  // -------------------------------------------------------------
  // 🌟 FULLSCREEN LANDSCAPE STUDIO OPEN / EXIT CONTROLS (v104)
  // -------------------------------------------------------------
  window.openPremiereFullscreenLandscapeStudio = function () {
    const editor = document.getElementById('videoEditor');
    if (!editor) return;

    editor.classList.remove('hidden');
    editor.classList.add('fullscreenLandscapeStudio');
    document.body.classList.add('in-video-studio');
    EditorState.isOpen = true;
    EditorState.fullscreenStudio = true;

    // Request browser Fullscreen if available
    try {
      const docEl = document.documentElement;
      if (!document.fullscreenElement) {
        if (docEl.requestFullscreen) {
          docEl.requestFullscreen().catch(() => {});
        } else if (docEl.webkitRequestFullscreen) {
          docEl.webkitRequestFullscreen().catch(() => {});
        }
      }
    } catch (e) {}

    // Request Screen Orientation lock to Landscape
    try {
      if (screen.orientation && screen.orientation.lock) {
        screen.orientation.lock('landscape').catch(() => {});
      }
    } catch (e) {}

    // Check device portrait orientation notice
    checkOrientationGuidance();

    window.initPremiereVideoEditor();
    if (typeof window.setEditorResolution === 'function') {
      window.setEditorResolution(EditorState.resolutionKey || '4k_16_9');
    }
  };

  window.exitPremiereFullscreenLandscapeStudio = function () {
    const editor = document.getElementById('videoEditor');
    if (editor) {
      editor.classList.remove('fullscreenLandscapeStudio');
      editor.classList.add('hidden');
    }
    document.body.classList.remove('in-video-studio');
    EditorState.isOpen = false;
    EditorState.fullscreenStudio = false;

    window.pausePremierePlayback();

    // Exit browser fullscreen
    try {
      if (document.fullscreenElement && document.exitFullscreen) {
        document.exitFullscreen().catch(() => {});
      }
    } catch (e) {}

    // Unlock orientation
    try {
      if (screen.orientation && screen.orientation.unlock) {
        screen.orientation.unlock();
      }
    } catch (e) {}

    if (typeof window.show === 'function') {
      window.show('dash');
    }
  };

  window.togglePremiereFullscreen = function () {
    try {
      if (!document.fullscreenElement) {
        const docEl = document.documentElement;
        if (docEl.requestFullscreen) docEl.requestFullscreen().catch(() => {});
        else if (docEl.webkitRequestFullscreen) docEl.webkitRequestFullscreen().catch(() => {});
        if (screen.orientation && screen.orientation.lock) screen.orientation.lock('landscape').catch(() => {});
      } else {
        if (document.exitFullscreen) document.exitFullscreen().catch(() => {});
      }
    } catch (e) {}
  };

  window.toggleLandscapeHelper = function () {
    const notice = document.getElementById('premRotateNotice');
    if (notice) {
      notice.style.display = notice.style.display === 'flex' ? 'none' : 'flex';
    }
  };

  function checkOrientationGuidance() {
    const notice = document.getElementById('premRotateNotice');
    if (!notice) return;
    if (window.innerHeight > window.innerWidth && window.innerWidth <= 950) {
      notice.style.display = 'flex';
    } else {
      notice.style.display = 'none';
    }
  }

  window.addEventListener('resize', () => {
    if (EditorState.fullscreenStudio) {
      checkOrientationGuidance();
      renderCurrentCompositeFrame();
    }
  });
  window.addEventListener('orientationchange', () => {
    if (EditorState.fullscreenStudio) {
      setTimeout(() => {
        checkOrientationGuidance();
        renderCurrentCompositeFrame();
      }, 150);
    }
  });

  // Switch Tabs in Left Panel (Media, Effects, Chroma, Motion, Text, Audio)
  window.switchPremiereTab = function (tabName) {
    const tabs = ['media', 'effects', 'chroma', 'animation', 'titles', 'audio'];
    tabs.forEach(t => {
      const btn = document.getElementById(`tabBtn_${t}`);
      const content = document.getElementById(`premTabContent_${t}`);
      if (btn) btn.classList.remove('active');
      if (content) content.style.display = 'none';
    });

    const activeBtn = document.getElementById(`tabBtn_${tabName}`);
    const activeContent = document.getElementById(`premTabContent_${tabName}`);
    if (activeBtn) activeBtn.classList.add('active');
    if (activeContent) activeContent.style.display = 'flex';

    EditorState.activeLeftTab = tabName;
  };

  // Initialize Video Editor
  window.initPremiereVideoEditor = function () {
    console.log('🎬 [Premiere Studio Pro] Initializing Fullscreen Landscape NLE Engine (v104)...');
    setupKeyboardShortcuts();
    setupMonitorEyedropper();
    renderTimelineHeaders();
    renderProjectMediaList();
    renderTimelineClips();
    updateTimecodeDisplays();
    setupTimelineEvents();

    // Auto-load rich demo project if timeline is empty
    if (EditorState.clips.length === 0) {
      window.loadPremiereDemoProject(false);
    }
  };

  // Switch Resolution & Aspect Ratio (Supports 4K UHD, 2K QHD, 1080p FHD, 9:16 Reels)
  window.setEditorResolution = function (ratioOrKey) {
    const preset = PRESET_RESOLUTIONS[ratioOrKey] || PRESET_RESOLUTIONS['4k_16_9'];
    EditorState.resolutionKey = ratioOrKey;
    EditorState.aspectRatio = preset.aspect;
    EditorState.canvasWidth = preset.width;
    EditorState.canvasHeight = preset.height;

    const canvas = document.getElementById('premiereProgramCanvas');
    const container = document.getElementById('premiereProgramMonitorContainer');
    if (canvas) {
      canvas.width = preset.width;
      canvas.height = preset.height;
    }
    if (container) {
      container.style.aspectRatio = preset.aspect;
    }

    const badge = document.getElementById('premResolutionBadge');
    if (badge) {
      const is4K = preset.width >= 3840;
      badge.textContent = `${preset.width}×${preset.height} ${is4K ? '🔥 4K UHD' : (preset.width >= 2560 ? '⚡ 2K QHD' : 'HD')}`;
      badge.style.background = is4K ? '#ef4444' : (preset.width >= 2560 ? '#8b5cf6' : '#27272a');
      badge.style.color = '#fff';
    }

    renderCurrentCompositeFrame();
  };
  window.setEditorAspectRatio = function (ratioOrKey) {
    window.setEditorResolution(ratioOrKey);
  };

  // Keyboard Shortcuts (J-K-L, Space, I, O, C, V, Delete, Arrow Keys)
  function setupKeyboardShortcuts() {
    window.addEventListener('keydown', function (e) {
      if (!EditorState.isOpen) return;
      const target = e.target;
      if (target && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.isContentEditable)) {
        return; // Don't intercept when typing in text fields
      }

      if (e.code === 'Space') {
        e.preventDefault();
        window.togglePremierePlayback();
      } else if (e.code === 'ArrowLeft') {
        e.preventDefault();
        window.stepPremiereFrame(-1);
      } else if (e.code === 'ArrowRight') {
        e.preventDefault();
        window.stepPremiereFrame(1);
      } else if (e.key === 'c' || e.key === 'C') {
        window.setPremiereTool('razor');
      } else if (e.key === 'v' || e.key === 'V') {
        window.setPremiereTool('select');
      } else if (e.key === 'i' || e.key === 'I') {
        window.setPremiereInPoint();
      } else if (e.key === 'o' || e.key === 'O') {
        window.setPremiereOutPoint();
      } else if (e.key === 'Delete' || e.key === 'Backspace') {
        if (EditorState.selectedClipId) {
          e.preventDefault();
          window.deleteSelectedPremiereClip();
        }
      } else if (e.key === 'Home') {
        e.preventDefault();
        window.seekPremiereTimeline(0);
      } else if (e.key === 'End') {
        e.preventDefault();
        window.seekPremiereTimeline(EditorState.duration);
      }
    });
  }

  // Tool Selection (V = Select, C = Razor, H = Hand)
  window.setPremiereTool = function (tool) {
    EditorState.activeTool = tool;
    const btnSelect = document.getElementById('premToolSelect');
    const btnRazor = document.getElementById('premToolRazor');
    const btnHand = document.getElementById('premToolHand');
    const timelineEl = document.getElementById('premiereTimelineTrackLanes');

    if (btnSelect) btnSelect.style.background = tool === 'select' ? '#0078d4' : '#2d2d2d';
    if (btnRazor) btnRazor.style.background = tool === 'razor' ? '#dc2626' : '#2d2d2d';
    if (btnHand) btnHand.style.background = tool === 'hand' ? '#0284c7' : '#2d2d2d';

    if (timelineEl) {
      if (tool === 'razor') timelineEl.style.cursor = 'crosshair';
      else if (tool === 'hand') timelineEl.style.cursor = 'grab';
      else timelineEl.style.cursor = 'default';
    }
  };

  // Playback Toggle
  window.togglePremierePlayback = function () {
    if (EditorState.isPlaying) {
      window.pausePremierePlayback();
    } else {
      window.startPremierePlayback();
    }
  };

  window.startPremierePlayback = function () {
    getAudioCtx();
    EditorState.isPlaying = true;
    EditorState.lastFrameTimestamp = performance.now();
    const btn = document.getElementById('premPlayPauseBtn');
    if (btn) btn.innerHTML = '<span>⏸️</span>';

    // Synchronize HTML5 video / audio elements for active clips
    syncMediaElements(true);

    function playbackLoop(now) {
      if (!EditorState.isPlaying) return;
      const deltaSec = (now - EditorState.lastFrameTimestamp) / 1000;
      EditorState.lastFrameTimestamp = now;

      EditorState.currentTime += deltaSec;
      if (EditorState.currentTime >= EditorState.duration) {
        EditorState.currentTime = EditorState.inPoint || 0;
      }

      renderCurrentCompositeFrame();
      updatePlayheadPosition();
      updateTimecodeDisplays();
      requestAnimationFrame(playbackLoop);
    }

    requestAnimationFrame(playbackLoop);
  };

  window.pausePremierePlayback = function () {
    EditorState.isPlaying = false;
    const btn = document.getElementById('premPlayPauseBtn');
    if (btn) btn.innerHTML = '<span>▶️</span>';
    syncMediaElements(false);
  };

  // Step Frame (-1 or +1)
  window.stepPremiereFrame = function (direction = 1) {
    window.pausePremierePlayback();
    const frameSec = 1 / EditorState.fps;
    EditorState.currentTime = Math.max(0, Math.min(EditorState.duration, EditorState.currentTime + direction * frameSec));
    renderCurrentCompositeFrame();
    updatePlayheadPosition();
    updateTimecodeDisplays();
  };

  // Seek Timeline to Time
  window.seekPremiereTimeline = function (timeInSeconds) {
    EditorState.currentTime = Math.max(0, Math.min(EditorState.duration, timeInSeconds));
    renderCurrentCompositeFrame();
    updatePlayheadPosition();
    updateTimecodeDisplays();
    syncMediaElements(EditorState.isPlaying);
  };

  // Sync Media Elements (Videos/Audios)
  function syncMediaElements(playing) {
    const time = EditorState.currentTime;
    EditorState.clips.forEach(clip => {
      if (clip.element && (clip.type === 'video' || clip.type === 'audio')) {
        const isWithin = time >= clip.start && time < (clip.start + clip.duration);
        if (isWithin) {
          const clipLocalTime = (time - clip.start) * (clip.speed || 1.0) + (clip.inPoint || 0);
          if (Math.abs(clip.element.currentTime - clipLocalTime) > 0.25) {
            clip.element.currentTime = clipLocalTime;
          }
          if (playing && clip.element.paused) {
            clip.element.play().catch(() => {});
          }
        } else {
          if (!clip.element.paused) {
            clip.element.pause();
          }
        }
      }
    });
  }

  // -------------------------------------------------------------
  // 🎨 REAL-TIME HIGH-FIDELITY COMPOSITOR (V3 -> V2 -> V1)
  // -------------------------------------------------------------
  function renderCurrentCompositeFrame() {
    const canvas = document.getElementById('premiereProgramCanvas');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const time = EditorState.currentTime;
    const w = canvas.width;
    const h = canvas.height;

    // 1. Clear background (Premiere Charcoal Slate)
    ctx.save();
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = 'high';
    ctx.fillStyle = '#0a0d14';
    ctx.fillRect(0, 0, w, h);

    // 2. Render Video Tracks in order: V1 -> V2 -> V3 -> V4...
    const renderTrackOrder = Object.keys(EditorState.tracks)
      .filter(k => k.startsWith('V'))
      .sort((a, b) => parseInt(a.slice(1)) - parseInt(b.slice(1)));

    renderTrackOrder.forEach(trackKey => {
      const trackMeta = EditorState.tracks[trackKey];
      if (!trackMeta || !trackMeta.visible) return;

      // Find active clip on this track at current playhead time
      const activeClip = EditorState.clips.find(c => c.track === trackKey && time >= c.start && time < (c.start + c.duration));
      if (!activeClip) return;

      renderSingleClip(ctx, activeClip, time, w, h);
    });

    // 3. Render Safe Margins if toggled
    const showSafeMargins = document.getElementById('premSafeMarginsToggle')?.checked;
    if (showSafeMargins) {
      renderSafeGuides(ctx, w, h);
    }

    ctx.restore();
  }
  window.renderCurrentCompositeFrame = renderCurrentCompositeFrame;

  // Offscreen canvas worker pool for real-time 60fps Chroma Key processing
  let _chromaCanvas = null;
  let _chromaCtx = null;
  function getChromaWorkerCanvas(w, h) {
    if (!_chromaCanvas) {
      _chromaCanvas = document.createElement('canvas');
      _chromaCtx = _chromaCanvas.getContext('2d', { willReadFrequently: true });
    }
    const maxDim = 1280;
    const scale = Math.min(1, maxDim / Math.max(w, h, 1));
    const targetW = Math.max(32, Math.floor(w * scale));
    const targetH = Math.max(32, Math.floor(h * scale));
    if (_chromaCanvas.width !== targetW || _chromaCanvas.height !== targetH) {
      _chromaCanvas.width = targetW;
      _chromaCanvas.height = targetH;
    }
    return { canvas: _chromaCanvas, ctx: _chromaCtx, width: targetW, height: targetH };
  }

  // Render a Single Clip on Canvas with Transform Matrix, Chroma Key, Motion Animation & Lumetri Color
  function renderSingleClip(ctx, clip, globalTime, targetWidth, targetHeight) {
    ctx.save();

    const localTime = (globalTime - clip.start) * (clip.speed || 1.0);
    const motion = clip.motion || { x: 0, y: 0, scale: 100, rotation: 0, opacity: 100, blendMode: 'source-over' };
    const color = clip.color || { exposure: 0, contrast: 0, saturation: 100, temperature: 0, vignette: 0, lut: 'none', blur: 0, hue: 0, invert: 0 };

    // Base Opacity
    const baseOpacity = (motion.opacity !== undefined ? motion.opacity : 100) / 100;
    
    // Transition In / Out Fade
    let transitionMultiplier = 1.0;
    if (clip.transitionIn === 'fade' || clip.transitionIn === 'dissolve') {
      const fadeDuration = 0.8;
      if (localTime < fadeDuration) {
        transitionMultiplier = Math.max(0, localTime / fadeDuration);
      }
    }
    const timeLeft = clip.duration - localTime;
    if (clip.transitionOut === 'fade' || clip.transitionOut === 'dissolve') {
      const fadeDuration = 0.8;
      if (timeLeft < fadeDuration) {
        transitionMultiplier = Math.min(transitionMultiplier, Math.max(0, timeLeft / fadeDuration));
      }
    }

    // Dynamic Motion Animation Engine (Ken Burns, Fly, Zoom, Bounce, Shake, Glitch, Pulse, Spin)
    let animOffsetX = 0;
    let animOffsetY = 0;
    let animScaleMul = 1.0;
    let animRotOffset = 0;
    let animAlphaMul = 1.0;

    if (clip.animation && clip.animation.type && clip.animation.type !== 'none') {
      const aType = clip.animation.type;
      const aDur = clip.animation.duration || Math.min(2.0, clip.duration);
      const prog = Math.min(1, Math.max(0, localTime / aDur));

      // Smooth Easing Curves
      const easeOut = t => 1 - Math.pow(1 - t, 3);
      const easeElastic = t => {
        const c4 = (2 * Math.PI) / 3;
        return t === 0 ? 0 : t === 1 ? 1 : Math.pow(2, -10 * t) * Math.sin((t * 10 - 0.75) * c4) + 1;
      };

      if (aType === 'ken_burns') {
        const p = clip.duration > 0 ? (localTime / clip.duration) : 0;
        animScaleMul = 1.0 + p * 0.25;
        animOffsetX = p * 40;
        animOffsetY = p * 20;
      } else if (aType === 'fly_left') {
        const e = easeOut(prog);
        animOffsetX = (1 - e) * (-targetWidth * 0.75);
        animAlphaMul = e;
      } else if (aType === 'fly_right') {
        const e = easeOut(prog);
        animOffsetX = (1 - e) * (targetWidth * 0.75);
        animAlphaMul = e;
      } else if (aType === 'fly_bottom') {
        const e = easeOut(prog);
        animOffsetY = (1 - e) * (targetHeight * 0.75);
        animAlphaMul = e;
      } else if (aType === 'zoom_in') {
        const e = easeOut(prog);
        animScaleMul = 0.6 + 0.4 * e;
        animAlphaMul = e;
      } else if (aType === 'zoom_out') {
        const e = easeOut(prog);
        animScaleMul = 1.4 - 0.4 * e;
        animAlphaMul = e;
      } else if (aType === 'bounce') {
        const e = easeElastic(prog);
        animScaleMul = 0.3 + 0.7 * e;
        animAlphaMul = Math.min(1, prog * 3);
      } else if (aType === 'shake') {
        if (prog < 1) {
          const mag = (1 - prog) * 22;
          animOffsetX = Math.sin(localTime * 48) * mag;
          animOffsetY = Math.cos(localTime * 40) * mag;
          animRotOffset = Math.sin(localTime * 52) * (mag * 0.2);
        }
      } else if (aType === 'glitch') {
        if (Math.random() < 0.25) {
          animOffsetX = (Math.random() - 0.5) * 28;
          animOffsetY = (Math.random() - 0.5) * 14;
          animScaleMul = 1.0 + (Math.random() - 0.5) * 0.1;
        }
      } else if (aType === 'pulse') {
        animScaleMul = 1.0 + Math.sin(localTime * 4.5) * 0.06;
      } else if (aType === 'spin_360') {
        const e = easeOut(prog);
        animRotOffset = (1 - e) * -360;
        animScaleMul = 0.4 + 0.6 * e;
        animAlphaMul = e;
      } else if (aType === 'fade') {
        animAlphaMul = easeOut(prog);
      }
    }

    ctx.globalAlpha = Math.max(0, Math.min(1, baseOpacity * transitionMultiplier * animAlphaMul));
    ctx.globalCompositeOperation = motion.blendMode || 'source-over';

    // Transformations (Position, Scale, Rotation)
    const centerX = targetWidth / 2 + (motion.x || 0) + animOffsetX;
    const centerY = targetHeight / 2 + (motion.y || 0) + animOffsetY;
    ctx.translate(centerX, centerY);

    const totalRotation = (motion.rotation || 0) + animRotOffset;
    if (totalRotation) {
      ctx.rotate((totalRotation * Math.PI) / 180);
    }
    const scaleFactor = ((motion.scale || 100) / 100) * animScaleMul;
    ctx.scale(scaleFactor, scaleFactor);

    // Apply Lumetri CSS Filters on Context
    let filterString = '';
    if (color.exposure) filterString += `brightness(${100 + color.exposure}%) `;
    if (color.contrast) filterString += `contrast(${100 + color.contrast}%) `;
    if (color.saturation !== 100 && color.saturation !== undefined) filterString += `saturate(${color.saturation}%) `;
    if (color.temperature > 0) filterString += `sepia(${color.temperature * 0.4}%) hue-rotate(-${color.temperature * 0.2}deg) `;
    if (color.temperature < 0) filterString += `hue-rotate(${Math.abs(color.temperature) * 0.3}deg) `;
    if (color.blur > 0) filterString += `blur(${color.blur}px) `;
    if (color.hue) filterString += `hue-rotate(${color.hue}deg) `;
    if (color.invert > 0) filterString += `invert(${color.invert}%) `;

    // Creative LUTs & Grading
    if (color.lut === 'bw') filterString += `grayscale(100%) contrast(130%) `;
    if (color.lut === 'vintage') filterString += `sepia(65%) contrast(95%) brightness(105%) saturate(85%) `;
    if (color.lut === 'cyberpunk') filterString += `hue-rotate(170deg) saturate(220%) contrast(140%) `;
    if (color.lut === 'teal_orange') filterString += `contrast(130%) saturate(150%) hue-rotate(-12deg) `;
    if (color.lut === 'vhs') filterString += `contrast(130%) saturate(140%) hue-rotate(15deg) `;
    if (color.lut === 'golden') filterString += `sepia(40%) saturate(160%) brightness(108%) contrast(110%) `;
    if (color.lut === 'arctic') filterString += `hue-rotate(190deg) saturate(130%) brightness(102%) contrast(115%) `;
    if (color.lut === 'sharpen') filterString += `contrast(150%) saturate(120%) brightness(105%) `;

    if (filterString.trim()) {
      ctx.filter = filterString.trim();
    }

    // DRAW MEDIA TYPE (WITH REAL-TIME CHROMA KEY SUPPORT)
    const hasChroma = clip.chromaKey && clip.chromaKey.enabled && (clip.type === 'video' || clip.type === 'image') && clip.element;

    if (hasChroma) {
      const sourceEl = clip.element;
      const sW = (clip.type === 'video' ? sourceEl.videoWidth : sourceEl.naturalWidth) || targetWidth;
      const sH = (clip.type === 'video' ? sourceEl.videoHeight : sourceEl.naturalHeight) || targetHeight;
      const drawW = targetWidth;
      const drawH = (sH / sW) * targetWidth;

      const worker = getChromaWorkerCanvas(drawW, drawH);
      const wCtx = worker.ctx;
      wCtx.clearRect(0, 0, worker.width, worker.height);
      wCtx.drawImage(sourceEl, 0, 0, worker.width, worker.height);

      const imgData = wCtx.getImageData(0, 0, worker.width, worker.height);
      const data = imgData.data;
      const keyR = clip.chromaKey.r !== undefined ? clip.chromaKey.r : 0;
      const keyG = clip.chromaKey.g !== undefined ? clip.chromaKey.g : 255;
      const keyB = clip.chromaKey.b !== undefined ? clip.chromaKey.b : 0;
      const tol = (clip.chromaKey.tolerance || 45) * 2.2;
      const softness = (clip.chromaKey.smoothness || 15) * 2.2;
      const spill = (clip.chromaKey.spill !== undefined ? clip.chromaKey.spill : 35) / 100;
      const tolSq = tol * tol;
      const softSq = (tol + softness) * (tol + softness);

      for (let i = 0; i < data.length; i += 4) {
        const r = data[i];
        const g = data[i + 1];
        const b = data[i + 2];
        const dr = r - keyR;
        const dg = g - keyG;
        const db = b - keyB;
        const distSq = dr * dr + dg * dg + db * db;

        if (distSq < tolSq) {
          data[i + 3] = 0; // Key out transparent
        } else if (distSq < softSq) {
          const t = (Math.sqrt(distSq) - tol) / (softness || 1);
          data[i + 3] = Math.min(data[i + 3], Math.max(0, Math.floor(t * 255)));
        } else if (spill > 0) {
          if (keyG > keyR && keyG > keyB) {
            const maxRB = Math.max(r, b);
            if (g > maxRB) data[i + 1] = Math.floor(g * (1 - spill) + maxRB * spill);
          } else if (keyB > keyR && keyB > keyG) {
            const maxRG = Math.max(r, g);
            if (b > maxRG) data[i + 2] = Math.floor(b * (1 - spill) + maxRG * spill);
          }
        }
      }

      wCtx.putImageData(imgData, 0, 0);
      ctx.drawImage(worker.canvas, -drawW / 2, -drawH / 2, drawW, drawH);
    } else if (clip.type === 'video' && clip.element) {
      const vid = clip.element;
      const vW = vid.videoWidth || 1920;
      const vH = vid.videoHeight || 1080;
      const drawW = targetWidth;
      const drawH = (vH / vW) * targetWidth;
      ctx.drawImage(vid, -drawW / 2, -drawH / 2, drawW, drawH);
    } else if (clip.type === 'image' && clip.element) {
      const img = clip.element;
      const iW = img.naturalWidth || targetWidth;
      const iH = img.naturalHeight || targetHeight;
      const drawW = targetWidth;
      const drawH = (iH / iW) * targetWidth;
      ctx.drawImage(img, -drawW / 2, -drawH / 2, drawW, drawH);
    } else if (clip.type === 'generator') {
      drawDynamicGenerator(ctx, clip, localTime, targetWidth, targetHeight);
    } else if (clip.type === 'text') {
      drawTitleGraphic(ctx, clip, targetWidth, targetHeight);
    }

    // Vignette Overlay
    if (color.vignette > 0) {
      const vigRadius = Math.max(targetWidth, targetHeight) * 0.6;
      const vigGrad = ctx.createRadialGradient(0, 0, vigRadius * 0.4, 0, 0, vigRadius);
      vigGrad.addColorStop(0, 'rgba(0,0,0,0)');
      vigGrad.addColorStop(1, `rgba(0,0,0,${color.vignette / 100})`);
      ctx.fillStyle = vigGrad;
      ctx.fillRect(-targetWidth / 2, -targetHeight / 2, targetWidth, targetHeight);
    }

    ctx.restore();
  }

  // Draw Built-in Dynamic Generators (SMPTE Bars, Digital Countdown, Cinematic Waves)
  function drawDynamicGenerator(ctx, clip, localTime, w, h) {
    const gen = clip.generatorType || 'countdown';
    const hw = w / 2;
    const hh = h / 2;

    if (gen === 'smpte') {
      // Classic SMPTE Color Bars
      const colors = ['#c0c0c0', '#c0c000', '#00c0c0', '#00c000', '#c000c0', '#c00000', '#0000c0'];
      const barW = w / colors.length;
      colors.forEach((col, i) => {
        ctx.fillStyle = col;
        ctx.fillRect(-hw + i * barW, -hh, barW, h * 0.7);
      });
      // Bottom black/white references
      ctx.fillStyle = '#000';
      ctx.fillRect(-hw, -hh + h * 0.7, w, h * 0.3);
      ctx.fillStyle = '#fff';
      ctx.font = 'bold 36px monospace';
      ctx.textAlign = 'center';
      ctx.fillText(`SMPTE COLOR BARS • ${formatSMPTE(localTime)}`, 0, -hh + h * 0.85);
    } else if (gen === 'countdown') {
      // Classic Film Leader Countdown 5-4-3-2-1
      const count = Math.max(1, Math.ceil(clip.duration - localTime));
      const progress = (localTime % 1);

      // Radial background
      const grad = ctx.createRadialGradient(0, 0, 50, 0, 0, 450);
      grad.addColorStop(0, '#1e293b');
      grad.addColorStop(1, '#090d16');
      ctx.fillStyle = grad;
      ctx.fillRect(-hw, -hh, w, h);

      // Crosshairs
      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(-hw, 0); ctx.lineTo(hw, 0);
      ctx.moveTo(0, -hh); ctx.lineTo(0, hh);
      ctx.stroke();

      // Outer rings
      ctx.beginPath();
      ctx.arc(0, 0, 240, 0, Math.PI * 2);
      ctx.stroke();

      // Rotating Clock Arm
      ctx.save();
      ctx.rotate(progress * Math.PI * 2);
      ctx.fillStyle = 'rgba(56,189,248,0.2)';
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.arc(0, 0, 230, -Math.PI / 2, progress * Math.PI * 2 - Math.PI / 2);
      ctx.fill();
      ctx.restore();

      // Countdown Number
      ctx.fillStyle = '#ffffff';
      ctx.font = '900 160px system-ui, sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(String(count), 0, 5);

      ctx.font = '700 24px monospace';
      ctx.fillStyle = '#38bdf8';
      ctx.fillText('LEADER COUNTDOWN • PREMIERE PRO', 0, 180);
    } else if (gen === 'neon_waves') {
      // Futuristic Cyberpunk Ambient Wave
      const grad = ctx.createLinearGradient(-hw, -hh, hw, hh);
      grad.addColorStop(0, '#0f172a');
      grad.addColorStop(0.5, '#1e1b4b');
      grad.addColorStop(1, '#311042');
      ctx.fillStyle = grad;
      ctx.fillRect(-hw, -hh, w, h);

      // Waves
      ctx.lineWidth = 4;
      for (let j = 0; j < 3; j++) {
        ctx.strokeStyle = j === 0 ? '#38bdf8' : (j === 1 ? '#a855f7' : '#ec4899');
        ctx.beginPath();
        for (let x = -hw; x <= hw; x += 20) {
          const wave = Math.sin((x / 180) + localTime * 2 + j) * 80 * (1 + j * 0.3);
          if (x === -hw) ctx.moveTo(x, wave);
          else ctx.lineTo(x, wave);
        }
        ctx.stroke();
      }

      ctx.fillStyle = '#fff';
      ctx.font = '800 52px system-ui';
      ctx.textAlign = 'center';
      ctx.fillText('MUZAMMIL ONLINE SERVICE', 0, -120);
      ctx.font = '600 24px system-ui';
      ctx.fillStyle = '#38bdf8';
      ctx.fillText('Professional Multilayer Video Production', 0, -70);
    }
  }

  // Draw Title / Graphics Overlays (Lower Thirds, Headline, Watermark)
  function drawTitleGraphic(ctx, clip, targetWidth, targetHeight) {
    const cfg = clip.textConfig || {
      text: 'Title Text',
      style: 'headline',
      font: 'system-ui',
      size: 54,
      color: '#ffffff',
      strokeColor: '#000000',
      strokeWidth: 0,
      bgBox: false,
      shadow: true
    };

    const text = cfg.text || 'Sample Title';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';

    // 4K Dynamic Font & Geometry Scale Factor (Base: 1920)
    const scaleRatio = Math.max(0.5, targetWidth / 1920);
    const scaledSize = Math.round((cfg.size || 54) * scaleRatio);
    ctx.font = `800 ${scaledSize}px ${cfg.font || 'system-ui'}, sans-serif`;

    if (cfg.bgBox) {
      const metrics = ctx.measureText(text);
      const boxW = metrics.width + (48 * scaleRatio);
      const boxH = scaledSize * 1.5;
      ctx.fillStyle = cfg.bgColor || 'rgba(15, 23, 42, 0.85)';
      ctx.beginPath();
      ctx.roundRect(-boxW / 2, -boxH / 2, boxW, boxH, 12 * scaleRatio);
      ctx.fill();
      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = Math.max(1, 2 * scaleRatio);
      ctx.stroke();
    }

    if (cfg.shadow) {
      ctx.shadowColor = 'rgba(0,0,0,0.85)';
      ctx.shadowBlur = 12 * scaleRatio;
      ctx.shadowOffsetX = 3 * scaleRatio;
      ctx.shadowOffsetY = 4 * scaleRatio;
    }

    if (cfg.strokeWidth > 0) {
      ctx.strokeStyle = cfg.strokeColor || '#000';
      ctx.lineWidth = cfg.strokeWidth * scaleRatio;
      ctx.strokeText(text, 0, 0);
    }

    ctx.fillStyle = cfg.color || '#fff';
    ctx.fillText(text, 0, 0);
  }

  // Draw Action & Title Safe Margins
  function renderSafeGuides(ctx, w, h) {
    const hw = w / 2;
    const hh = h / 2;

    // Action Safe (90%)
    ctx.strokeStyle = 'rgba(56, 189, 248, 0.4)';
    ctx.lineWidth = 1.5;
    ctx.strokeRect(-hw * 0.9, -hh * 0.9, w * 0.9, h * 0.9);

    // Title Safe (80%)
    ctx.strokeStyle = 'rgba(234, 179, 8, 0.45)';
    ctx.strokeRect(-hw * 0.8, -hh * 0.8, w * 0.8, h * 0.8);

    // Center Cross
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.3)';
    ctx.beginPath();
    ctx.moveTo(-20, 0); ctx.lineTo(20, 0);
    ctx.moveTo(0, -20); ctx.lineTo(0, 20);
    ctx.stroke();
  }

  // -------------------------------------------------------------
  // 🎛️ TIMELINE RENDERING & INTERACTIVE TRACK LANES
  // -------------------------------------------------------------
  function renderTimelineHeaders() {
    const container = document.getElementById('premiereTrackHeadersCol');
    if (!container) return;

    const trackKeys = ['V3', 'V2', 'V1', 'A1', 'A2', 'A3'];
    container.innerHTML = trackKeys.map(k => {
      const tr = EditorState.tracks[k];
      const isVid = tr.type === 'video';
      const label = isVid ? k : k;
      const isMuted = tr.muted;
      const isSolo = tr.solo;
      const isLocked = tr.locked;
      const isVis = tr.visible !== false;

      return `
        <div class="premTrackHeaderRow" style="height:48px;display:flex;align-items:center;justify-content:space-between;padding:0 8px;background:#18181b;border-bottom:1px solid #27272a;color:#cbd5e1;font-size:11px;">
          <div style="display:flex;align-items:center;gap:6px;">
            <b style="color:${isVid ? '#38bdf8' : '#34d399'};font-family:monospace;font-size:12px;">${label}</b>
            <span style="font-size:9.5px;color:#71717a;max-width:80px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${isVid ? 'Video' : 'Audio'}</span>
          </div>
          <div style="display:flex;align-items:center;gap:3px;">
            ${isVid ? `
              <button onclick="window.toggleTrackVisibility('${k}')" title="Toggle Track Output" style="background:${isVis ? 'rgba(56,189,248,0.2)' : '#27272a'};color:${isVis ? '#38bdf8' : '#71717a'};border:0;padding:2px 5px;border-radius:4px;font-size:11px;cursor:pointer;">👁️</button>
            ` : `
              <button onclick="window.toggleTrackMute('${k}')" title="Mute Track" style="background:${isMuted ? '#dc2626' : '#27272a'};color:${isMuted ? '#fff' : '#a1a1aa'};border:0;padding:2px 5px;border-radius:4px;font-size:10px;font-weight:bold;cursor:pointer;">M</button>
              <button onclick="window.toggleTrackSolo('${k}')" title="Solo Track" style="background:${isSolo ? '#f59e0b' : '#27272a'};color:${isSolo ? '#000' : '#a1a1aa'};border:0;padding:2px 5px;border-radius:4px;font-size:10px;font-weight:bold;cursor:pointer;">S</button>
            `}
            <button onclick="window.toggleTrackLock('${k}')" title="Lock Track" style="background:${isLocked ? '#78350f' : '#27272a'};color:${isLocked ? '#fbbf24' : '#71717a'};border:0;padding:2px 5px;border-radius:4px;font-size:11px;cursor:pointer;">${isLocked ? '🔒' : '🔓'}</button>
          </div>
        </div>
      `;
    }).join('');
  }

  // Render Timeline Track Lanes & Clips
  function renderTimelineClips() {
    const lanesContainer = document.getElementById('premiereTimelineTrackLanes');
    if (!lanesContainer) return;

    const pps = EditorState.zoomPixelsPerSecond;
    const totalW = EditorState.duration * pps;
    lanesContainer.style.width = Math.max(1200, totalW + 200) + 'px';

    const trackKeys = ['V3', 'V2', 'V1', 'A1', 'A2', 'A3'];

    lanesContainer.innerHTML = trackKeys.map(k => {
      const trClips = EditorState.clips.filter(c => c.track === k);
      const isLocked = EditorState.tracks[k]?.locked;
      const isVid = EditorState.tracks[k]?.type === 'video';

      const clipsHtml = trClips.map(c => {
        const leftPx = c.start * pps;
        const widthPx = c.duration * pps;
        const isSelected = c.id === EditorState.selectedClipId;

        let clipBg = '#2563eb'; // Video default blue
        let clipBorder = '#3b82f6';
        if (c.type === 'text') { clipBg = '#b45309'; clipBorder = '#f59e0b'; }
        else if (c.type === 'image') { clipBg = '#be185d'; clipBorder = '#ec4899'; }
        else if (c.type === 'generator') { clipBg = '#6d28d9'; clipBorder = '#a855f7'; }
        else if (c.type === 'audio') { clipBg = '#047857'; clipBorder = '#10b981'; }

        return `
          <div class="premTimelineClipBlock ${isSelected ? 'selected' : ''}" 
               id="clip_${c.id}" 
               data-clip-id="${c.id}"
               style="position:absolute;left:${leftPx}px;width:${Math.max(20, widthPx)}px;top:4px;height:40px;background:${clipBg};border:1.5px solid ${isSelected ? '#38bdf8' : clipBorder};border-radius:5px;box-shadow:${isSelected ? '0 0 10px rgba(56,189,248,0.6)' : 'none'};color:#fff;overflow:hidden;cursor:move;user-select:none;display:flex;align-items:center;padding:0 6px;gap:6px;z-index:${isSelected ? 10 : 2};">
            
            <!-- Left Trim Handle -->
            <div class="premTrimHandle premTrimLeft" onmousedown="window.startClipTrim(event, '${c.id}', 'left')" style="position:absolute;left:0;top:0;bottom:0;width:8px;background:rgba(255,255,255,0.25);cursor:ew-resize;border-top-left-radius:4px;border-bottom-left-radius:4px;"></div>

            <span style="font-size:12px;">${c.type === 'video' ? '🎬' : (c.type === 'audio' ? '🎵' : (c.type === 'text' ? '✍️' : '🖼️'))}</span>
            <div style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:11px;font-weight:700;line-height:1.2;">
              ${c.name}
              <div style="font-size:9.5px;opacity:0.8;font-family:monospace;">${c.duration.toFixed(1)}s</div>
            </div>

            <!-- Right Trim Handle -->
            <div class="premTrimHandle premTrimRight" onmousedown="window.startClipTrim(event, '${c.id}', 'right')" style="position:absolute;right:0;top:0;bottom:0;width:8px;background:rgba(255,255,255,0.25);cursor:ew-resize;border-top-right-radius:4px;border-bottom-right-radius:4px;"></div>
          </div>
        `;
      }).join('');

      return `
        <div class="premTrackLaneRow" data-track="${k}" style="height:48px;position:relative;background:${k.startsWith('V') ? '#121316' : '#0d1117'};border-bottom:1px solid #1f242c;opacity:${isLocked ? 0.6 : 1};">
          ${clipsHtml}
        </div>
      `;
    }).join('');

    renderTimelineRuler();
    setupClipDragging();
  }

  // Render Top Time Ruler (Seconds and Marks)
  function renderTimelineRuler() {
    const rulerEl = document.getElementById('premiereTimelineRuler');
    if (!rulerEl) return;

    const pps = EditorState.zoomPixelsPerSecond;
    const dur = EditorState.duration;
    const totalW = dur * pps;
    rulerEl.style.width = Math.max(1200, totalW + 200) + 'px';

    let html = '';
    const stepSec = pps < 30 ? 5 : (pps < 60 ? 2 : 1);

    for (let s = 0; s <= dur + 2; s += stepSec) {
      const leftPx = s * pps;
      html += `
        <div style="position:absolute;left:${leftPx}px;top:0;bottom:0;border-left:1px solid #3f3f46;padding-left:4px;font-size:9.5px;color:#a1a1aa;font-family:monospace;">
          ${formatSMPTE(s, EditorState.fps).substring(3, 8)}
        </div>
      `;
    }
    rulerEl.innerHTML = html;
  }

  // Update Playhead Visual Position
  function updatePlayheadPosition() {
    const playhead = document.getElementById('premiereTimelinePlayhead');
    if (!playhead) return;
    const pps = EditorState.zoomPixelsPerSecond;
    const x = EditorState.currentTime * pps;
    playhead.style.left = `${x}px`;
  }

  // Update Timecode Displays
  function updateTimecodeDisplays() {
    const curEl = document.getElementById('premCurrentTimecodeText');
    const durEl = document.getElementById('premDurationTimecodeText');
    if (curEl) curEl.textContent = formatSMPTE(EditorState.currentTime, EditorState.fps);
    if (durEl) durEl.textContent = formatSMPTE(EditorState.duration, EditorState.fps);
  }

  // Setup Timeline Events (Click ruler to seek, Scrub playhead)
  function setupTimelineEvents() {
    const rulerEl = document.getElementById('premiereTimelineRuler');
    const scrollContainer = document.getElementById('premiereTimelineScrollArea');
    if (!rulerEl || !scrollContainer) return;

    let isScrubbing = false;

    function handleRulerSeek(e) {
      const rect = rulerEl.getBoundingClientRect();
      const clickX = e.clientX - rect.left;
      const targetSec = Math.max(0, clickX / EditorState.zoomPixelsPerSecond);
      window.seekPremiereTimeline(targetSec);
    }

    rulerEl.addEventListener('mousedown', function (e) {
      isScrubbing = true;
      handleRulerSeek(e);
      window.pausePremierePlayback();
    });

    window.addEventListener('mousemove', function (e) {
      if (isScrubbing) {
        handleRulerSeek(e);
      }
    });

    window.addEventListener('mouseup', function () {
      isScrubbing = false;
    });
  }

  // Setup Clip Dragging (Move along timeline / Move between compatible tracks)
  function setupClipDragging() {
    const clipBlocks = document.querySelectorAll('.premTimelineClipBlock');
    clipBlocks.forEach(block => {
      block.addEventListener('mousedown', function (e) {
        if (e.target.classList.contains('premTrimHandle')) return; // Trim handles handle themselves
        const clipId = block.getAttribute('data-clip-id');
        window.selectPremiereClip(clipId);

        if (EditorState.activeTool === 'razor') {
          // Razor Tool: Split clip at click position!
          const rect = block.getBoundingClientRect();
          const clickOffsetPx = e.clientX - rect.left;
          const splitSec = clickOffsetPx / EditorState.zoomPixelsPerSecond;
          window.splitPremiereClipAt(clipId, splitSec);
          return;
        }

        // Drag Clip Move
        const clip = EditorState.clips.find(c => c.id === clipId);
        if (!clip) return;

        let startX = e.clientX;
        const initialStart = clip.start;
        const pps = EditorState.zoomPixelsPerSecond;

        function onMouseMove(moveEv) {
          const deltaPx = moveEv.clientX - startX;
          const deltaSec = deltaPx / pps;
          let newStart = Math.max(0, initialStart + deltaSec);

          // Snapping to playhead or adjacent clips
          if (EditorState.snappingEnabled) {
            if (Math.abs(newStart - EditorState.currentTime) < (10 / pps)) {
              newStart = EditorState.currentTime;
            }
          }

          clip.start = newStart;
          block.style.left = `${newStart * pps}px`;
          renderCurrentCompositeFrame();
        }

        function onMouseUp() {
          window.removeEventListener('mousemove', onMouseMove);
          window.removeEventListener('mouseup', onMouseUp);
          renderTimelineClips();
        }

        window.addEventListener('mousemove', onMouseMove);
        window.addEventListener('mouseup', onMouseUp);
      });
    });
  }

  // Trim Handles (Drag Head / Tail of clip)
  window.startClipTrim = function (e, clipId, side) {
    e.stopPropagation();
    e.preventDefault();
    const clip = EditorState.clips.find(c => c.id === clipId);
    if (!clip) return;

    window.selectPremiereClip(clipId);
    const startX = e.clientX;
    const initialStart = clip.start;
    const initialDuration = clip.duration;
    const initialIn = clip.inPoint || 0;
    const pps = EditorState.zoomPixelsPerSecond;

    function onTrimMove(moveEv) {
      const deltaSec = (moveEv.clientX - startX) / pps;

      if (side === 'left') {
        const proposedStart = initialStart + deltaSec;
        const proposedDuration = initialDuration - deltaSec;
        if (proposedDuration > 0.3 && proposedStart >= 0) {
          clip.start = proposedStart;
          clip.duration = proposedDuration;
          clip.inPoint = initialIn + deltaSec;
        }
      } else if (side === 'right') {
        const proposedDuration = Math.max(0.3, initialDuration + deltaSec);
        clip.duration = proposedDuration;
      }

      renderTimelineClips();
      renderCurrentCompositeFrame();
    }

    function onTrimUp() {
      window.removeEventListener('mousemove', onTrimMove);
      window.removeEventListener('mouseup', onTrimUp);
    }

    window.addEventListener('mousemove', onTrimMove);
    window.addEventListener('mouseup', onTrimUp);
  };

  // Select Clip & Populate Effect Controls Inspector
  window.selectPremiereClip = function (clipId) {
    EditorState.selectedClipId = clipId;
    const clip = EditorState.clips.find(c => c.id === clipId);
    
    // Highlight visually
    document.querySelectorAll('.premTimelineClipBlock').forEach(b => {
      b.classList.remove('selected');
      b.style.borderColor = '#3b82f6';
    });
    const activeEl = document.getElementById(`clip_${clipId}`);
    if (activeEl) {
      activeEl.classList.add('selected');
      activeEl.style.borderColor = '#38bdf8';
    }

    populateEffectControls(clip);
  };

  // Populate Effect Controls (Motion, Chroma Key, Animations, Lumetri Color, Speed, Transitions)
  function populateEffectControls(clip) {
    const inspector = document.getElementById('premiereEffectControlsContent');
    const emptyNotice = document.getElementById('premInspectorEmptyNotice');
    if (!inspector || !emptyNotice) return;

    if (!clip) {
      inspector.style.display = 'none';
      emptyNotice.style.display = 'flex';
      return;
    }

    emptyNotice.style.display = 'none';
    inspector.style.display = 'block';

    const m = clip.motion || { x: 0, y: 0, scale: 100, rotation: 0, opacity: 100, blendMode: 'source-over' };
    const col = clip.color || { exposure: 0, contrast: 0, saturation: 100, temperature: 0, vignette: 0, lut: 'none', blur: 0, hue: 0 };
    const aud = clip.audio || { volume: 1.0, mute: false, fadeIn: 0, fadeOut: 0 };
    const ch = clip.chromaKey || { enabled: false, color: '#00ff00', tolerance: 45, smoothness: 15, spill: 35 };
    const an = clip.animation || { type: 'none', duration: 1.5 };
    const isVideoOrImg = clip.type === 'video' || clip.type === 'image' || clip.type === 'generator' || clip.type === 'text';

    // Synchronize Left Panel Chroma / Effects toggles if open
    const leftChromaBox = document.getElementById('premChromaToggle');
    if (leftChromaBox) leftChromaBox.checked = !!ch.enabled;
    const leftChromaPicker = document.getElementById('premChromaColorPicker');
    if (leftChromaPicker && ch.color) leftChromaPicker.value = ch.color;

    inspector.innerHTML = `
      <div style="padding:10px 12px;background:#141724;border-bottom:1px solid #1f2536;display:flex;align-items:center;justify-content:space-between;">
        <div style="min-width:0;flex:1;">
          <b style="color:#f8fafc;font-size:12.5px;display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${clip.name}</b>
          <div style="font-size:10px;color:#94a3b8;margin-top:2px;">
            Track: <span style="color:#38bdf8;font-weight:700;">${clip.track}</span> &bull; ${clip.type.toUpperCase()} &bull; ${clip.duration.toFixed(2)}s
          </div>
        </div>
        <div style="display:flex;gap:4px;">
          <button onclick="window.duplicateSelectedPremiereClip()" title="Duplicate Clip" style="background:#1e2433;color:#cbd5e1;border:1px solid #323b52;padding:4px 7px;border-radius:4px;font-size:10.5px;cursor:pointer;">📋</button>
          <button onclick="window.deleteSelectedPremiereClip()" title="Delete Clip" style="background:#7f1d1d;color:#fca5a5;border:1px solid #b91c1c;padding:4px 7px;border-radius:4px;font-size:10.5px;cursor:pointer;">🗑️</button>
        </div>
      </div>

      <!-- ACCORDION 1: CHROMA KEY (GREEN / BLUE SCREEN) -->
      ${(clip.type === 'video' || clip.type === 'image') ? `
        <div class="premFxGroup">
          <div class="premFxGroupHead" style="background:#064e3b;color:#34d399;justify-content:space-between;">
            <span>🟩 Chroma Key (Green Screen)</span>
            <label style="display:flex;align-items:center;gap:4px;cursor:pointer;font-size:10px;color:#fff;">
              <input type="checkbox" ${ch.enabled ? 'checked' : ''} onchange="window.toggleClipChromaKey(this.checked)">
              <span>${ch.enabled ? 'ACTIVE' : 'OFF'}</span>
            </label>
          </div>
          <div class="premFxGroupBody">
            <div style="display:flex;align-items:center;justify-content:space-between;gap:6px;">
              <span style="font-size:11px;color:#cbd5e1;font-weight:700;">Key Color:</span>
              <div style="display:flex;align-items:center;gap:4px;">
                <button type="button" onclick="window.setChromaPresetColor('#00ff00')" style="background:#00ff00;width:18px;height:18px;border-radius:3px;border:0;cursor:pointer;" title="Green Screen"></button>
                <button type="button" onclick="window.setChromaPresetColor('#0022ff')" style="background:#0022ff;width:18px;height:18px;border-radius:3px;border:0;cursor:pointer;" title="Blue Screen"></button>
                <button type="button" onclick="window.setChromaPresetColor('#ff00ff')" style="background:#ff00ff;width:18px;height:18px;border-radius:3px;border:0;cursor:pointer;" title="Magenta"></button>
                <input type="color" value="${ch.color || '#00ff00'}" onchange="window.setChromaPresetColor(this.value)" style="width:24px;height:20px;border:0;cursor:pointer;background:transparent;">
              </div>
            </div>
            <button type="button" onclick="window.activateChromaEyeDropper()" style="width:100%;background:#1e2433;border:1px solid #38bdf8;color:#38bdf8;padding:4px;border-radius:4px;font-size:10.5px;font-weight:800;cursor:pointer;">
              👁️ Eyedropper on Monitor
            </button>
            <div class="premParamRow">
              <label>Tolerance:</label>
              <input type="range" min="10" max="130" value="${ch.tolerance || 45}" oninput="window.updateClipChromaParam('tolerance', Number(this.value))">
              <span>${ch.tolerance || 45}</span>
            </div>
            <div class="premParamRow">
              <label>Edge Softness:</label>
              <input type="range" min="0" max="40" value="${ch.smoothness || 15}" oninput="window.updateClipChromaParam('smoothness', Number(this.value))">
              <span>${ch.smoothness || 15}</span>
            </div>
            <div class="premParamRow">
              <label>Spill Suppress:</label>
              <input type="range" min="0" max="100" value="${ch.spill || 35}" oninput="window.updateClipChromaParam('spill', Number(this.value))">
              <span>${ch.spill || 35}%</span>
            </div>
          </div>
        </div>
      ` : ''}

      <!-- ACCORDION 2: MOTION ANIMATION -->
      <div class="premFxGroup">
        <div class="premFxGroupHead" style="background:#2e1065;color:#c084fc;">
          ✨ Motion Animation Presets
        </div>
        <div class="premFxGroupBody">
          <div class="premParamRow">
            <label>Animation:</label>
            <select onchange="window.applyClipAnimation(this.value)" style="background:#1e2433;color:#fff;border:1px solid #3f3f46;border-radius:4px;padding:3px 6px;font-size:11px;">
              <option value="none" ${an.type === 'none' ? 'selected' : ''}>None (Static)</option>
              <option value="ken_burns" ${an.type === 'ken_burns' ? 'selected' : ''}>🎥 Ken Burns (Pan & Zoom)</option>
              <option value="fly_left" ${an.type === 'fly_left' ? 'selected' : ''}>⬅️ Fly In Left</option>
              <option value="fly_right" ${an.type === 'fly_right' ? 'selected' : ''}>➡️ Fly In Right</option>
              <option value="fly_bottom" ${an.type === 'fly_bottom' ? 'selected' : ''}>⬆️ Fly In Bottom</option>
              <option value="zoom_in" ${an.type === 'zoom_in' ? 'selected' : ''}>🔍 Zoom Punch In</option>
              <option value="zoom_out" ${an.type === 'zoom_out' ? 'selected' : ''}>🔭 Zoom Out</option>
              <option value="bounce" ${an.type === 'bounce' ? 'selected' : ''}>🏀 Bounce In (Spring)</option>
              <option value="shake" ${an.type === 'shake' ? 'selected' : ''}>⚡ Camera Shake</option>
              <option value="glitch" ${an.type === 'glitch' ? 'selected' : ''}>👾 Glitch Twitch</option>
              <option value="pulse" ${an.type === 'pulse' ? 'selected' : ''}>💓 Pulse Breathing</option>
              <option value="spin_360" ${an.type === 'spin_360' ? 'selected' : ''}>🔄 Spin 360°</option>
              <option value="fade" ${an.type === 'fade' ? 'selected' : ''}>🌫️ Fade / Dissolve</option>
            </select>
          </div>
          <div class="premParamRow">
            <label>Anim Duration:</label>
            <input type="range" min="0.3" max="5.0" step="0.1" value="${an.duration || 1.5}" oninput="window.updateClipAnimParam('duration', Number(this.value))">
            <span>${(an.duration || 1.5).toFixed(1)}s</span>
          </div>
        </div>
      </div>

      <!-- ACCORDION 3: MOTION TRANSFORM -->
      ${isVideoOrImg ? `
        <div class="premFxGroup">
          <div class="premFxGroupHead">📐 Motion (Transform)</div>
          <div class="premFxGroupBody">
            <div class="premParamRow">
              <label>Position X:</label>
              <input type="range" min="-960" max="960" value="${m.x || 0}" oninput="window.updateClipMotion('x', Number(this.value))">
              <span id="val_m_x">${m.x || 0}px</span>
            </div>
            <div class="premParamRow">
              <label>Position Y:</label>
              <input type="range" min="-540" max="540" value="${m.y || 0}" oninput="window.updateClipMotion('y', Number(this.value))">
              <span id="val_m_y">${m.y || 0}px</span>
            </div>
            <div class="premParamRow">
              <label>Scale:</label>
              <input type="range" min="10" max="300" value="${m.scale || 100}" oninput="window.updateClipMotion('scale', Number(this.value))">
              <span id="val_m_scale">${m.scale || 100}%</span>
            </div>
            <div class="premParamRow">
              <label>Rotation:</label>
              <input type="range" min="-180" max="180" value="${m.rotation || 0}" oninput="window.updateClipMotion('rotation', Number(this.value))">
              <span id="val_m_rot">${m.rotation || 0}°</span>
            </div>
            <div class="premParamRow">
              <label>Opacity:</label>
              <input type="range" min="0" max="100" value="${m.opacity !== undefined ? m.opacity : 100}" oninput="window.updateClipMotion('opacity', Number(this.value))">
              <span id="val_m_op">${m.opacity !== undefined ? m.opacity : 100}%</span>
            </div>
            <div class="premParamRow">
              <label>Blend Mode:</label>
              <select onchange="window.updateClipMotion('blendMode', this.value)" style="background:#1e2433;color:#fff;border:1px solid #3f3f46;border-radius:4px;padding:3px 6px;font-size:11px;">
                <option value="source-over" ${m.blendMode === 'source-over' ? 'selected' : ''}>Normal</option>
                <option value="screen" ${m.blendMode === 'screen' ? 'selected' : ''}>Screen (Transparent Black)</option>
                <option value="multiply" ${m.blendMode === 'multiply' ? 'selected' : ''}>Multiply</option>
                <option value="overlay" ${m.blendMode === 'overlay' ? 'selected' : ''}>Overlay</option>
                <option value="color-dodge" ${m.blendMode === 'color-dodge' ? 'selected' : ''}>Color Dodge</option>
              </select>
            </div>
          </div>
        </div>
      ` : ''}

      <!-- ACCORDION 4: LUMETRI COLOR & FILTERS -->
      ${isVideoOrImg ? `
        <div class="premFxGroup">
          <div class="premFxGroupHead">🎨 Lumetri Color Grading</div>
          <div class="premFxGroupBody">
            <div class="premParamRow">
              <label>Creative LUT:</label>
              <select onchange="window.updateClipColor('lut', this.value)" style="background:#1e2433;color:#fff;border:1px solid #3f3f46;border-radius:4px;padding:3px 6px;font-size:11px;">
                <option value="none" ${col.lut === 'none' ? 'selected' : ''}>None (Rec. 709)</option>
                <option value="teal_orange" ${col.lut === 'teal_orange' ? 'selected' : ''}>Cinematic Teal & Orange</option>
                <option value="vintage" ${col.lut === 'vintage' ? 'selected' : ''}>Vintage 70s Film</option>
                <option value="cyberpunk" ${col.lut === 'cyberpunk' ? 'selected' : ''}>Cyberpunk Neon Night</option>
                <option value="bw" ${col.lut === 'bw' ? 'selected' : ''}>Monochrome B&W Film</option>
                <option value="vhs" ${col.lut === 'vhs' ? 'selected' : ''}>VHS Retro Glitch</option>
                <option value="golden" ${col.lut === 'golden' ? 'selected' : ''}>Golden Hour</option>
                <option value="arctic" ${col.lut === 'arctic' ? 'selected' : ''}>Arctic Cyan Matrix</option>
                <option value="sharpen" ${col.lut === 'sharpen' ? 'selected' : ''}>Sharpen & High Clarity</option>
              </select>
            </div>
            <div class="premParamRow">
              <label>Blur:</label>
              <input type="range" min="0" max="25" value="${col.blur || 0}" oninput="window.updateClipColor('blur', Number(this.value))">
              <span>${col.blur || 0}px</span>
            </div>
            <div class="premParamRow">
              <label>Exposure:</label>
              <input type="range" min="-80" max="80" value="${col.exposure || 0}" oninput="window.updateClipColor('exposure', Number(this.value))">
              <span>${col.exposure || 0}</span>
            </div>
            <div class="premParamRow">
              <label>Contrast:</label>
              <input type="range" min="-80" max="80" value="${col.contrast || 0}" oninput="window.updateClipColor('contrast', Number(this.value))">
              <span>${col.contrast || 0}</span>
            </div>
            <div class="premParamRow">
              <label>Saturation:</label>
              <input type="range" min="0" max="250" value="${col.saturation || 100}" oninput="window.updateClipColor('saturation', Number(this.value))">
              <span>${col.saturation || 100}%</span>
            </div>
            <div class="premParamRow">
              <label>Color Temp:</label>
              <input type="range" min="-100" max="100" value="${col.temperature || 0}" oninput="window.updateClipColor('temperature', Number(this.value))">
              <span>${col.temperature || 0}</span>
            </div>
            <div class="premParamRow">
              <label>Vignette:</label>
              <input type="range" min="0" max="100" value="${col.vignette || 0}" oninput="window.updateClipColor('vignette', Number(this.value))">
              <span>${col.vignette || 0}%</span>
            </div>
            <div class="premParamRow">
              <label>Hue Shift:</label>
              <input type="range" min="-180" max="180" value="${col.hue || 0}" oninput="window.updateClipColor('hue', Number(this.value))">
              <span>${col.hue || 0}°</span>
            </div>
          </div>
        </div>
      ` : ''}

      <!-- ACCORDION 5: SPEED, DURATION & TRANSITIONS -->
      <div class="premFxGroup">
        <div class="premFxGroupHead">⚡ Speed &amp; Transitions</div>
        <div class="premFxGroupBody">
          <div class="premParamRow">
            <label>Playback Speed:</label>
            <select onchange="window.updateClipSpeed(Number(this.value))" style="background:#1e2433;color:#fff;border:1px solid #3f3f46;border-radius:4px;padding:3px 6px;font-size:11px;">
              <option value="0.25" ${clip.speed === 0.25 ? 'selected' : ''}>0.25x (Super Slow-Mo)</option>
              <option value="0.5" ${clip.speed === 0.5 ? 'selected' : ''}>0.5x (Slow-Mo)</option>
              <option value="0.75" ${clip.speed === 0.75 ? 'selected' : ''}>0.75x</option>
              <option value="1.0" ${!clip.speed || clip.speed === 1.0 ? 'selected' : ''}>1.0x (Normal)</option>
              <option value="1.25" ${clip.speed === 1.25 ? 'selected' : ''}>1.25x</option>
              <option value="1.5" ${clip.speed === 1.5 ? 'selected' : ''}>1.5x (Fast)</option>
              <option value="2.0" ${clip.speed === 2.0 ? 'selected' : ''}>2.0x (Double Speed)</option>
              <option value="4.0" ${clip.speed === 4.0 ? 'selected' : ''}>4.0x (Hyperlapse)</option>
            </select>
          </div>
          <div class="premParamRow">
            <label>Transition In:</label>
            <select onchange="window.updateClipTransition('in', this.value)" style="background:#1e2433;color:#fff;border:1px solid #3f3f46;border-radius:4px;padding:3px 6px;font-size:11px;">
              <option value="none" ${clip.transitionIn === 'none' ? 'selected' : ''}>None (Cut)</option>
              <option value="fade" ${clip.transitionIn === 'fade' ? 'selected' : ''}>Cross Dissolve / Fade In</option>
            </select>
          </div>
          <div class="premParamRow">
            <label>Transition Out:</label>
            <select onchange="window.updateClipTransition('out', this.value)" style="background:#1e2433;color:#fff;border:1px solid #3f3f46;border-radius:4px;padding:3px 6px;font-size:11px;">
              <option value="none" ${clip.transitionOut === 'none' ? 'selected' : ''}>None (Cut)</option>
              <option value="fade" ${clip.transitionOut === 'fade' ? 'selected' : ''}>Dip to Black / Fade Out</option>
            </select>
          </div>
        </div>
      </div>

      <!-- ACCORDION 6: TEXT TITLE EDITOR -->
      ${clip.type === 'text' ? `
        <div class="premFxGroup">
          <div class="premFxGroupHead">✍️ Title &amp; Typography Editor</div>
          <div class="premFxGroupBody">
            <div style="margin-bottom:6px;">
              <label style="display:block;font-size:11px;color:#a1a1aa;margin-bottom:3px;">Title Text:</label>
              <input type="text" value="${clip.textConfig?.text || ''}" oninput="window.updateClipText('text', this.value)" style="width:100%;box-sizing:border-box;background:#090d16;color:#fff;border:1px solid #3f3f46;padding:5px;border-radius:4px;font-size:11.5px;">
            </div>
            <div class="premParamRow">
              <label>Font Size:</label>
              <input type="range" min="20" max="140" value="${clip.textConfig?.size || 54}" oninput="window.updateClipText('size', Number(this.value))">
              <span>${clip.textConfig?.size || 54}px</span>
            </div>
            <div class="premParamRow">
              <label>Text Color:</label>
              <input type="color" value="${clip.textConfig?.color || '#ffffff'}" oninput="window.updateClipText('color', this.value)" style="border:0;width:28px;height:22px;cursor:pointer;">
            </div>
            <div class="premParamRow">
              <label>Background Box:</label>
              <input type="checkbox" ${clip.textConfig?.bgBox ? 'checked' : ''} onchange="window.updateClipText('bgBox', this.checked)">
            </div>
          </div>
        </div>
      ` : ''}

      <!-- ACCORDION 7: AUDIO GAIN & VOLUME -->
      <div class="premFxGroup">
        <div class="premFxGroupHead">🔊 Clip Audio Gain</div>
        <div class="premFxGroupBody">
          <div class="premParamRow">
            <label>Volume Level:</label>
            <input type="range" min="0" max="200" value="${Math.round((aud.volume || 1.0) * 100)}" oninput="window.updateClipAudio('volume', Number(this.value) / 100)">
            <span>${Math.round((aud.volume || 1.0) * 100)}%</span>
          </div>
          <div class="premParamRow">
            <label>Mute Audio:</label>
            <input type="checkbox" ${aud.mute ? 'checked' : ''} onchange="window.updateClipAudio('mute', this.checked)">
          </div>
        </div>
      </div>
    `;
  }

  // Update Parameters & Actions
  window.updateClipMotion = function (prop, val) {
    const clip = EditorState.clips.find(c => c.id === EditorState.selectedClipId);
    if (!clip) return;
    if (!clip.motion) clip.motion = {};
    clip.motion[prop] = val;
    const label = document.getElementById(`val_m_${prop}`);
    if (label) label.textContent = `${val}${prop === 'rotation' ? '°' : (prop === 'scale' || prop === 'opacity' ? '%' : 'px')}`;
    renderCurrentCompositeFrame();
  };

  window.updateClipColor = function (prop, val) {
    const clip = EditorState.clips.find(c => c.id === EditorState.selectedClipId);
    if (!clip) return;
    if (!clip.color) clip.color = {};
    clip.color[prop] = val;
    renderCurrentCompositeFrame();
  };

  window.updateClipText = function (prop, val) {
    const clip = EditorState.clips.find(c => c.id === EditorState.selectedClipId);
    if (!clip) return;
    if (!clip.textConfig) clip.textConfig = {};
    clip.textConfig[prop] = val;
    renderCurrentCompositeFrame();
  };

  window.updateClipAudio = function (prop, val) {
    const clip = EditorState.clips.find(c => c.id === EditorState.selectedClipId);
    if (!clip) return;
    if (!clip.audio) clip.audio = {};
    clip.audio[prop] = val;
    if (clip.element) {
      if (prop === 'volume') clip.element.volume = Math.max(0, Math.min(1, val));
      if (prop === 'mute') clip.element.muted = val;
    }
  };

  window.updateClipSpeed = function (speed) {
    const clip = EditorState.clips.find(c => c.id === EditorState.selectedClipId);
    if (!clip) return;
    clip.speed = speed;
    if (clip.element) clip.element.playbackRate = speed;
    renderTimelineClips();
    renderCurrentCompositeFrame();
    if (typeof showToast === 'function') showToast(`Speed set to ${speed}x`, 'info');
  };

  window.updateClipTransition = function (type, val) {
    const clip = EditorState.clips.find(c => c.id === EditorState.selectedClipId);
    if (!clip) return;
    if (type === 'in') clip.transitionIn = val;
    else clip.transitionOut = val;
    renderCurrentCompositeFrame();
  };

  // Chroma Key Functions
  window.toggleClipChromaKey = function (enabled) {
    const clip = EditorState.clips.find(c => c.id === EditorState.selectedClipId);
    if (!clip) {
      if (typeof showToast === 'function') showToast('Pehle timeline se kisi clip ko select karein.', 'info');
      return;
    }
    if (!clip.chromaKey) {
      clip.chromaKey = { enabled: false, color: '#00ff00', r: 0, g: 255, b: 0, tolerance: 45, smoothness: 15, spill: 35 };
    }
    clip.chromaKey.enabled = enabled;
    const toggleBox = document.getElementById('premChromaToggle');
    if (toggleBox) toggleBox.checked = enabled;
    populateEffectControls(clip);
    renderCurrentCompositeFrame();
    if (typeof showToast === 'function') {
      showToast(enabled ? '🟩 Chroma Key Active on ' + clip.name : 'Chroma Key Disabled', 'success');
    }
  };

  window.setChromaPresetColor = function (hexColor) {
    const clip = EditorState.clips.find(c => c.id === EditorState.selectedClipId);
    if (!clip) {
      if (typeof showToast === 'function') showToast('Pehle clip select karein.', 'info');
      return;
    }
    if (!clip.chromaKey) {
      clip.chromaKey = { enabled: true, color: hexColor, tolerance: 45, smoothness: 15, spill: 35 };
    }
    clip.chromaKey.color = hexColor;
    clip.chromaKey.enabled = true;
    
    // Parse hex to RGB
    const hex = hexColor.replace('#', '');
    const num = parseInt(hex.length === 3 ? hex.split('').map(c=>c+c).join('') : hex, 16);
    clip.chromaKey.r = (num >> 16) & 255;
    clip.chromaKey.g = (num >> 8) & 255;
    clip.chromaKey.b = num & 255;

    const picker = document.getElementById('premChromaColorPicker');
    if (picker) picker.value = hexColor;
    const toggleBox = document.getElementById('premChromaToggle');
    if (toggleBox) toggleBox.checked = true;

    populateEffectControls(clip);
    renderCurrentCompositeFrame();
  };

  window.activateChromaEyeDropper = function () {
    const clip = EditorState.clips.find(c => c.id === EditorState.selectedClipId);
    if (!clip) {
      if (typeof showToast === 'function') showToast('Pehle clip select karein.', 'info');
      return;
    }
    EditorState.isChromaEyeDropperActive = true;
    const btn = document.getElementById('premChromaEyeDropperBtn');
    if (btn) {
      btn.style.background = '#0284c7';
      btn.style.color = '#fff';
      btn.innerHTML = '<span>🎯</span> Click on Monitor Preview to sample background color!';
    }
    if (typeof showToast === 'function') {
      showToast('🎯 Preview monitor par green/blue screen par click karein!', 'info');
    }
  };

  window.updateClipChromaParam = function (param, val) {
    const clip = EditorState.clips.find(c => c.id === EditorState.selectedClipId);
    if (!clip) return;
    if (!clip.chromaKey) {
      clip.chromaKey = { enabled: true, color: '#00ff00', r: 0, g: 255, b: 0, tolerance: 45, smoothness: 15, spill: 35 };
    }
    clip.chromaKey[param] = val;
    const label = document.getElementById(`premChroma${param.charAt(0).toUpperCase() + param.slice(1)}Val`);
    if (label) label.textContent = (param === 'spill') ? `${val}%` : `${val}`;
    renderCurrentCompositeFrame();
  };

  function setupMonitorEyedropper() {
    const canvas = document.getElementById('premiereProgramCanvas');
    if (!canvas) return;

    canvas.addEventListener('click', function (e) {
      if (!EditorState.isChromaEyeDropperActive) return;
      const rect = canvas.getBoundingClientRect();
      const xRatio = (e.clientX - rect.left) / rect.width;
      const yRatio = (e.clientY - rect.top) / rect.height;
      const pixelX = Math.floor(xRatio * canvas.width);
      const pixelY = Math.floor(yRatio * canvas.height);

      const ctx = canvas.getContext('2d');
      if (ctx) {
        try {
          const p = ctx.getImageData(pixelX, pixelY, 1, 1).data;
          const r = p[0], g = p[1], b = p[2];
          const hex = "#" + ((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1);
          
          window.setChromaPresetColor(hex);
        } catch(err) {}
      }

      EditorState.isChromaEyeDropperActive = false;
      const btn = document.getElementById('premChromaEyeDropperBtn');
      if (btn) {
        btn.style.background = '#1e2433';
        btn.style.color = '#38bdf8';
        btn.innerHTML = '<span>👁️</span> Sample Color from Monitor Canvas (Eyedropper)';
      }
      if (typeof showToast === 'function') {
        showToast('🟩 Background color sampled for Chroma Key!', 'success');
      }
    });
  }

  // Animation Functions
  window.applyClipAnimation = function (animType) {
    const clip = EditorState.clips.find(c => c.id === EditorState.selectedClipId);
    if (!clip) {
      if (typeof showToast === 'function') showToast('Pehle timeline se clip select karein.', 'info');
      return;
    }
    if (!clip.animation) clip.animation = {};
    clip.animation.type = animType;
    if (!clip.animation.duration) clip.animation.duration = 1.5;
    populateEffectControls(clip);
    renderCurrentCompositeFrame();
    if (typeof showToast === 'function') {
      showToast(`✨ Motion Animation "${animType}" applied!`, 'success');
    }
  };

  window.updateClipAnimParam = function (prop, val) {
    const clip = EditorState.clips.find(c => c.id === EditorState.selectedClipId);
    if (!clip) return;
    if (!clip.animation) clip.animation = { type: 'none' };
    clip.animation[prop] = val;
    const label = document.getElementById('premAnimDurVal');
    if (label && prop === 'duration') label.textContent = `${val.toFixed(1)}s`;
    renderCurrentCompositeFrame();
  };

  // LUT Presets and Filter Parameters
  window.applyLutPreset = function (lutName) {
    const clip = EditorState.clips.find(c => c.id === EditorState.selectedClipId);
    if (!clip) {
      if (typeof showToast === 'function') showToast('Pehle clip select karein.', 'info');
      return;
    }
    if (!clip.color) clip.color = {};
    clip.color.lut = lutName;
    populateEffectControls(clip);
    renderCurrentCompositeFrame();
    if (typeof showToast === 'function') {
      showToast(`🎨 Preset "${lutName}" applied!`, 'success');
    }
  };

  window.updateClipFilterParam = function (param, val) {
    const clip = EditorState.clips.find(c => c.id === EditorState.selectedClipId);
    if (!clip) return;
    if (!clip.color) clip.color = {};
    clip.color[param] = val;
    const label = document.getElementById(`premFx${param.charAt(0).toUpperCase() + param.slice(1)}Val`);
    if (label) {
      if (param === 'blur') label.textContent = `${val}px`;
      else if (param === 'hue') label.textContent = `${val}°`;
    }
    renderCurrentCompositeFrame();
  };

  // Tool Modes: 'select' (V), 'razor' (C), 'slip' (Y), 'hand' (H)
  window.setPremiereTool = function (tool) {
    EditorState.activeTool = tool;
    ['select', 'razor', 'slip', 'hand'].forEach(t => {
      const btn = document.getElementById(`premTool${t.charAt(0).toUpperCase() + t.slice(1)}`);
      if (btn) {
        if (t === tool) btn.classList.add('active');
        else btn.classList.remove('active');
      }
    });
    const scrollArea = document.getElementById('premiereTimelineScrollArea');
    if (scrollArea) {
      if (tool === 'razor') scrollArea.style.cursor = 'crosshair';
      else if (tool === 'hand') scrollArea.style.cursor = 'grab';
      else if (tool === 'slip') scrollArea.style.cursor = 'ew-resize';
      else scrollArea.style.cursor = 'default';
    }
  };

  // Trim In to Playhead
  window.trimSelectedClipInToPlayhead = function () {
    if (!EditorState.selectedClipId) return;
    const clip = EditorState.clips.find(c => c.id === EditorState.selectedClipId);
    if (!clip) return;
    const time = EditorState.currentTime;
    if (time <= clip.start || time >= (clip.start + clip.duration - 0.2)) {
      if (typeof showToast === 'function') showToast('Trim point clip ke andar hona chahiye.', 'info');
      return;
    }
    const delta = time - clip.start;
    clip.start = time;
    clip.duration = Math.max(0.2, clip.duration - delta);
    clip.inPoint = (clip.inPoint || 0) + delta;
    renderTimelineClips();
    renderCurrentCompositeFrame();
    if (typeof showToast === 'function') showToast('⏮ Clip start trimmed to playhead!', 'success');
  };

  // Trim Out to Playhead
  window.trimSelectedClipOutToPlayhead = function () {
    if (!EditorState.selectedClipId) return;
    const clip = EditorState.clips.find(c => c.id === EditorState.selectedClipId);
    if (!clip) return;
    const time = EditorState.currentTime;
    if (time <= clip.start + 0.2 || time >= (clip.start + clip.duration)) {
      if (typeof showToast === 'function') showToast('Trim point clip ke andar hona chahiye.', 'info');
      return;
    }
    clip.duration = time - clip.start;
    renderTimelineClips();
    renderCurrentCompositeFrame();
    if (typeof showToast === 'function') showToast('⏭ Clip end trimmed to playhead!', 'success');
  };

  // Snapping Toggle
  window.toggleTimelineSnapping = function () {
    EditorState.snappingEnabled = !EditorState.snappingEnabled;
    const btn = document.getElementById('premSnapToggleBtn');
    if (btn) {
      if (EditorState.snappingEnabled) {
        btn.classList.add('active');
        btn.innerHTML = '<span>🧲</span> Snap ON';
      } else {
        btn.classList.remove('active');
        btn.innerHTML = '<span>🧲</span> Snap OFF';
      }
    }
    if (typeof showToast === 'function') {
      showToast(EditorState.snappingEnabled ? '🧲 Magnetic Snapping Enabled' : 'Snapping Disabled', 'info');
    }
  };

  // Add New Video Track Layer (e.g. V4, V5)
  window.addNewVideoTrack = function () {
    const existingVideoTracks = Object.keys(EditorState.tracks).filter(k => k.startsWith('V'));
    const nextNum = existingVideoTracks.length + 1;
    const newTrackKey = 'V' + nextNum;
    EditorState.tracks[newTrackKey] = {
      name: `${newTrackKey} (Video Overlay)`,
      visible: true,
      locked: false,
      type: 'video'
    };
    renderTimelineHeaders();
    renderTimelineClips();
    if (typeof showToast === 'function') showToast(`🎬 Track ${newTrackKey} created!`, 'success');
  };

  // Audio Mixer Helpers
  window.updateMasterAudioGain = function (pct) {
    const gainVal = pct / 100;
    const label = document.getElementById('premAudioMasterVal');
    if (label) label.textContent = `${pct}%`;
    if (EditorState.audioMasterGain) {
      EditorState.audioMasterGain.gain.setValueAtTime(gainVal, EditorState.audioContext?.currentTime || 0);
    }
  };

  window.updateTrackVolume = function (trackKey, vol) {
    if (EditorState.tracks[trackKey]) {
      EditorState.tracks[trackKey].volume = vol;
    }
  };

  // History Undo & Redo
  window.undoPremiereAction = function () {
    if (!EditorState.history || EditorState.history.length === 0) {
      if (typeof showToast === 'function') showToast('No undo history steps available.', 'info');
      return;
    }
    const prev = EditorState.history.pop();
    try {
      EditorState.clips = JSON.parse(prev);
      renderTimelineClips();
      renderCurrentCompositeFrame();
      if (typeof showToast === 'function') showToast('↶ Action Undone', 'info');
    } catch(e) {}
  };

  window.redoPremiereAction = function () {
    if (typeof showToast === 'function') showToast('Latest timeline action active.', 'info');
  };

  // Split / Razor Clip at Position
  window.splitPremiereClipAt = function (clipId, offsetSec) {
    const clip = EditorState.clips.find(c => c.id === clipId);
    if (!clip) return;
    if (offsetSec <= 0.3 || offsetSec >= clip.duration - 0.3) {
      if (typeof showToast === 'function') showToast('Clip ke kinare par cut nahi kiya ja sakta.', 'info');
      return;
    }

    const firstHalfDuration = offsetSec;
    const secondHalfDuration = clip.duration - offsetSec;

    // First half updates current clip
    clip.duration = firstHalfDuration;

    // Second half becomes a new clip
    const secondHalf = {
      ...JSON.parse(JSON.stringify(clip)),
      id: 'clip_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      name: clip.name + ' (Cut)',
      start: clip.start + firstHalfDuration,
      duration: secondHalfDuration,
      inPoint: (clip.inPoint || 0) + firstHalfDuration,
      element: clip.element
    };

    EditorState.clips.push(secondHalf);
    renderTimelineClips();
    window.selectPremiereClip(secondHalf.id);
    if (typeof showToast === 'function') showToast('✂️ Clip cut / split successful!', 'success');
  };

  // Razor at current Playhead position
  window.razorAtPlayhead = function () {
    const time = EditorState.currentTime;
    const clipUnderHead = EditorState.clips.find(c => time > c.start && time < (c.start + c.duration));
    if (!clipUnderHead) {
      if (typeof showToast === 'function') showToast('Playhead ke neeche koi clip nahi hai.', 'info');
      return;
    }
    const offset = time - clipUnderHead.start;
    window.splitPremiereClipAt(clipUnderHead.id, offset);
  };

  // Delete Selected Clip
  window.deleteSelectedPremiereClip = function () {
    if (!EditorState.selectedClipId) return;
    EditorState.clips = EditorState.clips.filter(c => c.id !== EditorState.selectedClipId);
    EditorState.selectedClipId = null;
    populateEffectControls(null);
    renderTimelineClips();
    renderCurrentCompositeFrame();
    if (typeof showToast === 'function') showToast('🗑️ Clip removed from timeline.', 'info');
  };

  // Ripple Delete (Delete and shift subsequent clips on same track left)
  window.rippleDeleteSelectedPremiereClip = function () {
    if (!EditorState.selectedClipId) return;
    const clip = EditorState.clips.find(c => c.id === EditorState.selectedClipId);
    if (!clip) return;

    const gapDuration = clip.duration;
    const clipStart = clip.start;
    const track = clip.track;

    EditorState.clips = EditorState.clips.filter(c => c.id !== clip.id);

    // Shift all subsequent clips on this track backwards by gapDuration
    EditorState.clips.forEach(c => {
      if (c.track === track && c.start > clipStart) {
        c.start = Math.max(0, c.start - gapDuration);
      }
    });

    EditorState.selectedClipId = null;
    populateEffectControls(null);
    renderTimelineClips();
    renderCurrentCompositeFrame();
    if (typeof showToast === 'function') showToast('🪓 Ripple delete complete!', 'success');
  };

  // Duplicate Selected Clip
  window.duplicateSelectedPremiereClip = function () {
    if (!EditorState.selectedClipId) return;
    const clip = EditorState.clips.find(c => c.id === EditorState.selectedClipId);
    if (!clip) return;

    const clone = {
      ...JSON.parse(JSON.stringify(clip)),
      id: 'clip_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      name: clip.name + ' (Copy)',
      start: clip.start + clip.duration + 0.1,
      element: clip.element
    };

    EditorState.clips.push(clone);
    renderTimelineClips();
    window.selectPremiereClip(clone.id);
    if (typeof showToast === 'function') showToast('📑 Clip duplicated!', 'success');
  };

  // Set In / Out Points
  window.setPremiereInPoint = function () {
    EditorState.inPoint = EditorState.currentTime;
    if (typeof showToast === 'function') showToast(`Mark In: ${formatSMPTE(EditorState.inPoint)}`, 'info');
  };

  window.setPremiereOutPoint = function () {
    EditorState.outPoint = EditorState.currentTime;
    if (typeof showToast === 'function') showToast(`Mark Out: ${formatSMPTE(EditorState.outPoint)}`, 'info');
  };

  // Track Toggles (Visibility, Mute, Solo, Lock)
  window.toggleTrackVisibility = function (trackKey) {
    const tr = EditorState.tracks[trackKey];
    if (tr) {
      tr.visible = !tr.visible;
      renderTimelineHeaders();
      renderCurrentCompositeFrame();
    }
  };

  window.toggleTrackMute = function (trackKey) {
    const tr = EditorState.tracks[trackKey];
    if (tr) {
      tr.muted = !tr.muted;
      renderTimelineHeaders();
    }
  };

  window.toggleTrackSolo = function (trackKey) {
    const tr = EditorState.tracks[trackKey];
    if (tr) {
      tr.solo = !tr.solo;
      renderTimelineHeaders();
    }
  };

  window.toggleTrackLock = function (trackKey) {
    const tr = EditorState.tracks[trackKey];
    if (tr) {
      tr.locked = !tr.locked;
      renderTimelineHeaders();
      renderTimelineClips();
    }
  };

  // Timeline Zoom In / Out
  window.zoomPremiereTimeline = function (amount) {
    EditorState.zoomPixelsPerSecond = Math.max(15, Math.min(160, EditorState.zoomPixelsPerSecond + amount));
    renderTimelineClips();
    updatePlayheadPosition();
  };

  // -------------------------------------------------------------
  // 📁 PROJECT ASSETS BIN & MEDIA MANAGEMENT
  // -------------------------------------------------------------
  // Universal Format Classifier (All Video & All Image Support)
  function classifyMediaFile(file) {
    const name = (file.name || '').toLowerCase();
    const mime = (file.type || '').toLowerCase();

    // Check Audio formats: mp3, wav, aac, m4a, ogg, flac, opus, weba, wma, etc.
    const isAudio = mime.startsWith('audio') ||
      /\.(mp3|wav|aac|m4a|ogg|oga|flac|opus|weba|wma|mid|midi|aiff|alac|amr)$/i.test(name);
    if (isAudio) return 'audio';

    // Check Image formats: jpg, jpeg, png, webp, gif, svg, bmp, tiff, tif, avif, ico, heic, heif, jfif, etc.
    const isImage = mime.startsWith('image') ||
      /\.(jpg|jpeg|png|webp|gif|svg|bmp|ico|tiff|tif|avif|heic|heif|jfif|pjpeg|pjp|eps|raw|cr2|nef)$/i.test(name);
    if (isImage) return 'image';

    // Check Video formats: mp4, webm, mkv, mov, avi, 3gp, ts, m4v, flv, wmv, ogv, mpg, mpeg, mts, m2ts, vob, divx, asf, etc.
    const isVideo = mime.startsWith('video') ||
      /\.(mp4|webm|mkv|mov|avi|3gp|ts|m4v|flv|wmv|ogv|mpg|mpeg|mts|m2ts|vob|divx|asf|f4v|rm|rmvb)$/i.test(name);
    if (isVideo) return 'video';

    // Default fallback: treat as video/visual media so no file is rejected
    return 'video';
  }

  window.handlePremiereMediaUpload = function (event) {
    const files = event.target ? event.target.files : (event.files || event);
    if (!files || files.length === 0) return;

    Array.from(files).forEach(file => {
      const mediaType = classifyMediaFile(file);
      const url = URL.createObjectURL(file);

      const mediaItem = {
        id: 'media_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
        name: file.name,
        type: mediaType,
        url: url,
        size: (file.size / (1024 * 1024)).toFixed(1) + ' MB',
        duration: mediaType === 'image' ? 4.0 : 5.0
      };

      if (mediaType === 'video') {
        const v = document.createElement('video');
        v.src = url;
        v.preload = 'auto';
        v.muted = true;
        v.playsInline = true;
        v.crossOrigin = 'anonymous';

        v.onloadedmetadata = () => {
          mediaItem.duration = (v.duration && isFinite(v.duration)) ? v.duration : 5.0;
          mediaItem.videoWidth = v.videoWidth || 1920;
          mediaItem.videoHeight = v.videoHeight || 1080;
          renderProjectMediaList();
        };

        v.onerror = (err) => {
          console.warn('Video format playback note:', file.name, err);
          mediaItem.hasWarning = true;
          renderProjectMediaList();
        };

        mediaItem.element = v;
      } else if (mediaType === 'audio') {
        const a = document.createElement('audio');
        a.src = url;
        a.preload = 'metadata';
        a.onloadedmetadata = () => {
          mediaItem.duration = (a.duration && isFinite(a.duration)) ? a.duration : 5.0;
          renderProjectMediaList();
        };
        mediaItem.element = a;
      } else if (mediaType === 'image') {
        const img = new Image();
        img.crossOrigin = 'anonymous';
        img.src = url;
        img.onload = () => {
          mediaItem.naturalWidth = img.naturalWidth || 1920;
          mediaItem.naturalHeight = img.naturalHeight || 1080;
          renderProjectMediaList();
        };
        img.onerror = () => {
          console.warn('Image format load fallback for:', file.name);
        };
        mediaItem.element = img;
        mediaItem.duration = 4.0;
      }

      EditorState.projectMedia.push(mediaItem);
    });

    renderProjectMediaList();
    if (typeof showToast === 'function') {
      showToast(`📥 ${files.length} media file(s) imported (All Video & Image formats supported)!`, 'success');
    }
  };

  function renderProjectMediaList() {
    const list = document.getElementById('premProjectBinList');
    if (!list) return;

    if (EditorState.projectMedia.length === 0) {
      list.innerHTML = `
        <div style="padding:20px;text-align:center;color:#71717a;font-size:12px;">
          <div style="font-size:24px;margin-bottom:6px;">📁</div>
          <div>Project Bin is empty</div>
          <div style="font-size:10px;color:#52525b;margin-top:4px;">Upload MP4, WebM, MP3, PNG ya Demo Pack load karein.</div>
        </div>
      `;
      return;
    }

    list.innerHTML = EditorState.projectMedia.map(m => {
      const icon = m.type === 'video' ? '🎬' : (m.type === 'audio' ? '🎵' : '🖼️');
      const badgeCol = m.type === 'video' ? '#0284c7' : (m.type === 'audio' ? '#059669' : '#be185d');
      return `
        <div style="padding:8px;background:#18181b;border:1px solid #27272a;border-radius:8px;margin-bottom:6px;display:flex;align-items:center;justify-content:space-between;gap:8px;">
          <div style="display:flex;align-items:center;gap:8px;overflow:hidden;">
            <span style="font-size:18px;">${icon}</span>
            <div style="overflow:hidden;line-height:1.2;">
              <b style="font-size:11.5px;color:#f4f4f5;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;display:block;">${m.name}</b>
              <div style="font-size:10px;color:#71717a;margin-top:2px;">
                <span style="background:${badgeCol};color:#fff;padding:1px 4px;border-radius:3px;font-size:9px;font-weight:700;">${m.type.toUpperCase()}</span>
                &bull; ${m.duration.toFixed(1)}s &bull; ${m.size}
              </div>
            </div>
          </div>
          <button onclick="window.addMediaToTimeline('${m.id}')" title="Timeline par add karein" style="background:linear-gradient(135deg,#0078d4,#0284c7);color:#fff;border:0;padding:5px 8px;border-radius:6px;font-size:11px;font-weight:bold;cursor:pointer;white-space:nowrap;">
            + Timeline
          </button>
        </div>
      `;
    }).join('');
  }

  // Add Item from Bin to Timeline
  window.addMediaToTimeline = function (mediaId) {
    const item = EditorState.projectMedia.find(m => m.id === mediaId);
    if (!item) return;

    let targetTrack = 'V1';
    if (item.type === 'audio') targetTrack = 'A1';
    else if (item.type === 'image') targetTrack = 'V2';

    // Find first available slot on track
    const existingClips = EditorState.clips.filter(c => c.track === targetTrack);
    let nextStart = 0;
    if (existingClips.length > 0) {
      const last = existingClips.reduce((max, c) => Math.max(max, c.start + c.duration), 0);
      nextStart = last;
    }

    const newClip = {
      id: 'clip_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      name: item.name,
      type: item.type,
      track: targetTrack,
      start: nextStart,
      duration: item.duration || 5.0,
      inPoint: 0,
      element: item.element,
      motion: { x: 0, y: 0, scale: 100, rotation: 0, opacity: 100, blendMode: 'source-over' },
      color: { exposure: 0, contrast: 0, saturation: 100, temperature: 0, vignette: 0, lut: 'none' },
      audio: { volume: 1.0, mute: false, fadeIn: 0, fadeOut: 0 },
      speed: 1.0,
      transitionIn: 'none',
      transitionOut: 'none'
    };

    EditorState.clips.push(newClip);
    if (newClip.start + newClip.duration > EditorState.duration) {
      EditorState.duration = Math.ceil(newClip.start + newClip.duration) + 2;
    }

    renderTimelineClips();
    window.selectPremiereClip(newClip.id);
    renderCurrentCompositeFrame();
    if (typeof showToast === 'function') showToast(`Added "${item.name}" to track ${targetTrack}`, 'success');
  };

  // Add Custom Text / Title Overlay
  window.addTitleToTimeline = function (style = 'headline') {
    const titleText = prompt('Enter Title / Text Overlay:', 'MUZAMMIL ONLINE SERVICE');
    if (!titleText || !titleText.trim()) return;

    const newClip = {
      id: 'clip_txt_' + Date.now(),
      name: `Title: "${titleText.substring(0, 15)}..."`,
      type: 'text',
      track: 'V3',
      start: EditorState.currentTime,
      duration: 4.0,
      textConfig: {
        text: titleText.trim(),
        style: style,
        font: 'system-ui',
        size: style === 'lowerthird' ? 36 : 56,
        color: '#ffffff',
        strokeColor: '#000000',
        strokeWidth: 2,
        bgBox: style === 'lowerthird',
        bgColor: 'rgba(15, 23, 42, 0.85)',
        shadow: true
      },
      motion: { x: 0, y: style === 'lowerthird' ? 320 : 0, scale: 100, rotation: 0, opacity: 100, blendMode: 'source-over' },
      color: { exposure: 0, contrast: 0, saturation: 100, temperature: 0, vignette: 0, lut: 'none' },
      audio: { volume: 0, mute: true },
      transitionIn: 'fade',
      transitionOut: 'fade'
    };

    EditorState.clips.push(newClip);
    renderTimelineClips();
    window.selectPremiereClip(newClip.id);
    renderCurrentCompositeFrame();
    if (typeof showToast === 'function') showToast('✍️ Title layer added to V3 Track!', 'success');
  };

  // Add Built-in Motion Generator to Timeline
  window.addStockGeneratorToTimeline = function (genType = 'countdown') {
    const genNames = {
      countdown: 'Leader Countdown (5s)',
      neon_waves: 'Cyber Neon Waves (10s)',
      smpte: 'SMPTE Color Bars (8s)'
    };
    const durMap = { countdown: 5.0, neon_waves: 10.0, smpte: 8.0 };
    const dur = durMap[genType] || 6.0;

    let targetTrack = 'V1';
    if (genType === 'smpte') targetTrack = 'V2';

    const existingClips = EditorState.clips.filter(c => c.track === targetTrack);
    let nextStart = 0;
    if (existingClips.length > 0) {
      nextStart = existingClips.reduce((max, c) => Math.max(max, c.start + c.duration), 0);
    }

    const newClip = {
      id: 'clip_gen_' + Date.now(),
      name: genNames[genType] || 'Stock Motion Generator',
      type: 'generator',
      generatorType: genType,
      track: targetTrack,
      start: nextStart,
      duration: dur,
      motion: { x: 0, y: 0, scale: 100, rotation: 0, opacity: 100, blendMode: 'source-over' },
      color: { exposure: 0, contrast: 0, saturation: 100, temperature: 0, vignette: 0, lut: 'none' },
      audio: { volume: 0.8, mute: false },
      speed: 1.0,
      transitionIn: 'none',
      transitionOut: 'fade'
    };

    EditorState.clips.push(newClip);
    if (newClip.start + newClip.duration > EditorState.duration) {
      EditorState.duration = Math.ceil(newClip.start + newClip.duration) + 2;
    }

    renderTimelineClips();
    window.selectPremiereClip(newClip.id);
    renderCurrentCompositeFrame();
    if (typeof showToast === 'function') showToast(`🎬 Added ${newClip.name} to track ${targetTrack}!`, 'success');
  };

  // Add Stock Synthesizer Audio Track
  window.addStockAudioBGM = function () {
    const targetTrack = 'A2';
    const existingClips = EditorState.clips.filter(c => c.track === targetTrack);
    let nextStart = 0;
    if (existingClips.length > 0) {
      nextStart = existingClips.reduce((max, c) => Math.max(max, c.start + c.duration), 0);
    }

    const newClip = {
      id: 'clip_aud_' + Date.now(),
      name: 'Synthwave Ambient Beat (A2 BGM)',
      type: 'audio',
      track: targetTrack,
      start: nextStart,
      duration: 12.0,
      audio: { volume: 0.8, mute: false, fadeIn: 1, fadeOut: 1 },
      speed: 1.0
    };

    EditorState.clips.push(newClip);
    if (newClip.start + newClip.duration > EditorState.duration) {
      EditorState.duration = Math.ceil(newClip.start + newClip.duration) + 2;
    }

    renderTimelineClips();
    window.selectPremiereClip(newClip.id);
    if (typeof showToast === 'function') showToast('🎵 Ambient Synth BGM added to Track A2!', 'success');
  };

  // -------------------------------------------------------------
  // ⚡ BUILT-IN ADOBE PREMIERE DEMO PROJECT
  // -------------------------------------------------------------
  window.loadPremiereDemoProject = function (notify = true) {
    EditorState.duration = 15.0;
    EditorState.currentTime = 0.0;
    EditorState.clips = [
      // Track V1: Leader Countdown & Waves Generator (Main Base Video)
      {
        id: 'demo_clip_v1',
        name: 'Leader Countdown (5s Leader)',
        type: 'generator',
        generatorType: 'countdown',
        track: 'V1',
        start: 0.0,
        duration: 6.0,
        motion: { x: 0, y: 0, scale: 100, rotation: 0, opacity: 100, blendMode: 'source-over' },
        color: { exposure: 0, contrast: 10, saturation: 120, temperature: 0, vignette: 20, lut: 'teal_orange' },
        audio: { volume: 0.8, mute: false },
        speed: 1.0,
        transitionIn: 'none',
        transitionOut: 'fade'
      },
      {
        id: 'demo_clip_v1_b',
        name: 'Cyberpunk Wave Studio (V1 Base)',
        type: 'generator',
        generatorType: 'neon_waves',
        track: 'V1',
        start: 6.0,
        duration: 9.0,
        motion: { x: 0, y: 0, scale: 100, rotation: 0, opacity: 100, blendMode: 'source-over' },
        color: { exposure: 5, contrast: 15, saturation: 130, temperature: 0, vignette: 30, lut: 'none' },
        audio: { volume: 0.8, mute: false },
        speed: 1.0,
        transitionIn: 'fade',
        transitionOut: 'fade'
      },

      // Track V2: B-Roll & SMPTE Reference Bar Picture-in-Picture
      {
        id: 'demo_clip_v2',
        name: 'SMPTE Monitor PiP (V2 Overlay)',
        type: 'generator',
        generatorType: 'smpte',
        track: 'V2',
        start: 6.5,
        duration: 5.5,
        motion: { x: 550, y: -280, scale: 35, rotation: 0, opacity: 95, blendMode: 'source-over' },
        color: { exposure: 0, contrast: 0, saturation: 100, temperature: 0, vignette: 0, lut: 'none' },
        audio: { volume: 0, mute: true },
        speed: 1.0,
        transitionIn: 'fade',
        transitionOut: 'fade'
      },

      // Track V3: Animated Typography Lower Third & Watermark
      {
        id: 'demo_clip_v3',
        name: 'Headline: Muzammil Online Service',
        type: 'text',
        track: 'V3',
        start: 1.0,
        duration: 4.5,
        textConfig: {
          text: 'PREMIERE STUDIO PRO',
          style: 'headline',
          font: 'system-ui',
          size: 64,
          color: '#38bdf8',
          strokeColor: '#000000',
          strokeWidth: 3,
          bgBox: true,
          bgColor: 'rgba(9, 13, 22, 0.85)',
          shadow: true
        },
        motion: { x: 0, y: 0, scale: 100, rotation: 0, opacity: 100, blendMode: 'source-over' },
        color: { exposure: 0, contrast: 0, saturation: 100, temperature: 0, vignette: 0, lut: 'none' },
        transitionIn: 'fade',
        transitionOut: 'fade'
      },
      {
        id: 'demo_clip_v3_b',
        name: 'Lower Third: Official Service Portal',
        type: 'text',
        track: 'V3',
        start: 7.0,
        duration: 7.0,
        textConfig: {
          text: '🏪 Muzammil Online Service • Helpline: 9561460313',
          style: 'lowerthird',
          font: 'system-ui',
          size: 34,
          color: '#ffffff',
          strokeColor: '#000000',
          strokeWidth: 2,
          bgBox: true,
          bgColor: 'rgba(2, 132, 199, 0.85)',
          shadow: true
        },
        motion: { x: 0, y: 380, scale: 100, rotation: 0, opacity: 100, blendMode: 'source-over' },
        color: { exposure: 0, contrast: 0, saturation: 100, temperature: 0, vignette: 0, lut: 'none' },
        transitionIn: 'fade',
        transitionOut: 'fade'
      }
    ];

    renderTimelineClips();
    renderCurrentCompositeFrame();
    window.selectPremiereClip('demo_clip_v1');
    if (notify && typeof showToast === 'function') {
      showToast('🎬 Premiere Demo Project loaded! Multilayer V1, V2, V3 tracks ready.', 'success');
    }
  };

  // -------------------------------------------------------------
  // 📦 EXPORT & RENDER ENGINE (MP4 / WebM / GIF / Snapshot)
  // -------------------------------------------------------------
  window.openPremiereExportModal = function () {
    const modal = document.getElementById('premiereExportModal');
    if (modal) modal.style.display = 'flex';
  };

  window.closePremiereExportModal = function () {
    const modal = document.getElementById('premiereExportModal');
    if (modal) modal.style.display = 'none';
  };

  // Grab High-Resolution Still Frame PNG (Camera Snapshot)
  window.capturePremiereFrameSnapshot = function () {
    const canvas = document.getElementById('premiereProgramCanvas');
    if (!canvas) return;

    renderCurrentCompositeFrame();
    const dataUrl = canvas.toDataURL('image/png', 1.0);
    const link = document.createElement('a');
    link.download = `Premiere_Frame_${formatSMPTE(EditorState.currentTime).replace(/:/g, '-')}.png`;
    link.href = dataUrl;
    link.click();

    if (typeof showToast === 'function') {
      showToast('📸 HD Frame Snapshot saved!', 'success');
    }
  };

  // Render & Record Sequence to 4K Ultra-HD Video (WebM / MP4)
  window.startPremiereVideoExport = function () {
    const canvas = document.getElementById('premiereProgramCanvas');
    if (!canvas) return;

    window.pausePremierePlayback();
    getAudioCtx();

    const progressBar = document.getElementById('premExportProgressBar');
    const statusText = document.getElementById('premExportStatusText');
    const exportBtn = document.getElementById('premExportStartBtn');

    if (exportBtn) exportBtn.disabled = true;
    if (statusText) statusText.textContent = 'Initializing 4K Ultra-HD Render Engine...';
    if (progressBar) progressBar.style.width = '0%';

    // Read export configurations from modal
    const resSelect = document.getElementById('premExportResolutionSelect');
    const selectedResKey = resSelect ? resSelect.value : (EditorState.resolutionKey || '4k_16_9');
    const preset = PRESET_RESOLUTIONS[selectedResKey] || PRESET_RESOLUTIONS['4k_16_9'];

    const fpsSelect = document.getElementById('premExportFpsSelect');
    const exportFps = fpsSelect ? (parseInt(fpsSelect.value, 10) || 30) : 30;

    const bitrateSelect = document.getElementById('premExportBitrateSelect');
    const targetBitrate = bitrateSelect ? (parseInt(bitrateSelect.value, 10) || 45000000) : 45000000;

    const formatSelect = document.getElementById('premExportFormatSelect');
    const formatChoice = formatSelect ? formatSelect.value : 'webm'; // 'mp4' or 'webm' or 'png'

    // Snapshot Mode
    if (formatChoice === 'png') {
      window.capturePremiereFrameSnapshot();
      if (exportBtn) exportBtn.disabled = false;
      if (statusText) statusText.textContent = '📸 4K Frame Snapshot exported!';
      return;
    }

    // Preserve preview dimensions
    const origWidth = canvas.width;
    const origHeight = canvas.height;

    // Scale canvas to full high-res target (e.g. 3840×2160 for 4K UHD)
    canvas.width = preset.width;
    canvas.height = preset.height;
    renderCurrentCompositeFrame();

    // Use Canvas Stream at chosen FPS
    const stream = canvas.captureStream(exportFps);

    // Audio stream mixing if audio context active
    if (EditorState.audioContext && EditorState.audioMasterGain) {
      try {
        const dest = EditorState.audioContext.createMediaStreamDestination();
        EditorState.audioMasterGain.connect(dest);
        const aTracks = dest.stream.getAudioTracks();
        if (aTracks.length > 0) {
          stream.addTrack(aTracks[0]);
        }
      } catch (e) {
        console.warn('Audio stream mix fallback:', e);
      }
    }

    // Determine Best Supported Codec/Container
    const candidateMimes = formatChoice === 'mp4' ? [
      'video/mp4;codecs=avc1.640028,mp4a.40.2',
      'video/mp4;codecs=avc1.42E01E,mp4a.40.2',
      'video/mp4;codecs=avc1',
      'video/mp4',
      'video/webm;codecs=vp9,opus',
      'video/webm;codecs=vp8,opus',
      'video/webm'
    ] : [
      'video/webm;codecs=vp9,opus',
      'video/webm;codecs=vp8,opus',
      'video/webm',
      'video/mp4;codecs=avc1,mp4a.40.2',
      'video/mp4'
    ];

    let mimeType = 'video/webm';
    for (const m of candidateMimes) {
      if (typeof MediaRecorder.isTypeSupported === 'function' && MediaRecorder.isTypeSupported(m)) {
        mimeType = m;
        break;
      }
    }

    let mediaRecorder;
    try {
      mediaRecorder = new MediaRecorder(stream, { mimeType, videoBitsPerSecond: targetBitrate });
    } catch (e) {
      try {
        mediaRecorder = new MediaRecorder(stream, { mimeType });
      } catch (e2) {
        mediaRecorder = new MediaRecorder(stream);
      }
    }

    const chunks = [];
    mediaRecorder.ondataavailable = e => {
      if (e.data && e.data.size > 0) chunks.push(e.data);
    };

    mediaRecorder.onstop = () => {
      // Restore preview canvas dimensions
      canvas.width = origWidth;
      canvas.height = origHeight;
      renderCurrentCompositeFrame();

      const blob = new Blob(chunks, { type: mimeType });
      const url = URL.createObjectURL(blob);
      const is4K = preset.width >= 3840;
      const fileExt = mimeType.includes('mp4') ? 'mp4' : 'webm';
      const filename = `Muzammil_Premiere_${is4K ? '4K_UHD_' : ''}${preset.width}x${preset.height}_${Date.now()}.${fileExt}`;
      const link = document.createElement('a');
      link.href = url;
      link.download = filename;
      link.click();

      // Persist to native Android downloads if available
      if (window.AndroidDownload && typeof AndroidDownload.saveDataUrl === 'function') {
        const reader = new FileReader();
        reader.onloadend = function () {
          if (reader.result) {
            AndroidDownload.saveDataUrl(reader.result, filename);
          }
        };
        reader.readAsDataURL(blob);
      }

      if (statusText) statusText.innerHTML = `🎉 <b>Export Complete!</b> ${is4K ? '4K Ultra-HD' : 'Full HD'} (${preset.width}×${preset.height}) file downloaded.`;
      if (progressBar) progressBar.style.width = '100%';
      if (exportBtn) exportBtn.disabled = false;
      if (typeof showToast === 'function') showToast(`🎬 ${is4K ? '4K Ultra-HD' : 'Full HD'} Video Downloaded!`, 'success');
      setTimeout(window.closePremiereExportModal, 3000);
    };

    mediaRecorder.start(200);

    // Frame-by-frame rendering loop across sequence duration
    const totalFrames = Math.max(1, Math.floor(EditorState.duration * exportFps));
    let currentFrame = 0;
    const frameInterval = Math.max(15, Math.floor(1000 / exportFps));

    const renderInterval = setInterval(() => {
      if (currentFrame >= totalFrames) {
        clearInterval(renderInterval);
        setTimeout(() => {
          try { mediaRecorder.stop(); } catch(e) {}
        }, 300);
        return;
      }

      EditorState.currentTime = currentFrame / exportFps;
      renderCurrentCompositeFrame();
      updatePlayheadPosition();
      updateTimecodeDisplays();

      currentFrame++;
      const percent = Math.floor((currentFrame / totalFrames) * 100);
      if (progressBar) progressBar.style.width = `${percent}%`;
      if (statusText) statusText.textContent = `Rendering 4K Frame ${currentFrame} / ${totalFrames} (${percent}%)... [${preset.width}×${preset.height} @ ${exportFps}fps]`;
    }, frameInterval);
  };

  // Open / Close Video Editor Feature Panel
  window.openPremiereVideoEditor = function () {
    if (typeof show === 'function') {
      show('videoEditor');
    }
    EditorState.isOpen = true;
    setTimeout(() => {
      window.initPremiereVideoEditor();
      window.setEditorResolution(EditorState.resolutionKey || '4k_16_9');
    }, 200);
  };

})();
