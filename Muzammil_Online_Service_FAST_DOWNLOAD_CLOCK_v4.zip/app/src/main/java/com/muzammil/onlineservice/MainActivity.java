package com.muzammil.onlineservice;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class MainActivity extends Activity {
    private WebView w;

    @Override
    public void onCreate(Bundle b) {
        super.onCreate(b);

        w = new WebView(this);
        WebSettings s = w.getSettings();

        // Fast, normal WebView configuration.
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setLoadsImagesAutomatically(true);
        s.setBlockNetworkImage(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(false);
        s.setMediaPlaybackRequiresUserGesture(true);

        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(w, true);

        w.setWebViewClient(new WebViewClient());
        w.setWebChromeClient(new WebChromeClient());

        // Government sites and other HTTPS sites can send documents/PDFs for download.
        w.setDownloadListener(new DownloadListener() {
            @Override
            public void onDownloadStart(String url, String userAgent,
                                        String contentDisposition, String mimetype,
                                        long contentLength) {
                try {
                    DownloadManager.Request req =
                            new DownloadManager.Request(Uri.parse(url));

                    req.setMimeType(mimetype);
                    req.addRequestHeader("User-Agent",
                            userAgent != null ? userAgent : s.getUserAgentString());

                    String cookie = CookieManager.getInstance().getCookie(url);
                    if (cookie != null && !cookie.isEmpty()) {
                        req.addRequestHeader("Cookie", cookie);
                    }

                    String filename = URLUtil.guessFileName(
                            url, contentDisposition, mimetype);

                    req.setTitle(filename);
                    req.setDescription("Muzammil Online Service");
                    req.setNotificationVisibility(
                            DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    req.setAllowedOverMetered(true);
                    req.setAllowedOverRoaming(true);
                    req.setDestinationInExternalPublicDir(
                            Environment.DIRECTORY_DOWNLOADS, filename);

                    DownloadManager dm =
                            (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
                    dm.enqueue(req);

                    Toast.makeText(MainActivity.this,
                            "Download started: " + filename,
                            Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this,
                            "Download start nahi hua",
                            Toast.LENGTH_LONG).show();
                }
            }
        });

        setContentView(w);
        w.loadUrl("file:///android_asset/index.html");
    }

    @Override
    public void onBackPressed() {
        if (w != null && w.canGoBack()) {
            w.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (w != null) {
            w.stopLoading();
            w.loadUrl("about:blank");
            w.removeAllViews();
            w.destroy();
            w = null;
        }
        super.onDestroy();
    }
}
