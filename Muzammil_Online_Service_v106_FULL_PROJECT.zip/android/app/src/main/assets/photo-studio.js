/**
 * 🎨 PHOTOSHOP STUDIO PRO (v106.0 Final)
 * Complete Professional Web Photo Editor Suite for Muzammil Online Service
 * Features: Selection Tools (Marquee, Lasso, Wand), Magic BG Eraser, Manual Soft Eraser,
 * Retouching & Blemish Healer, Color Grading, Tone Curves, Photo Resize & DPI, 35+ Filters, Undo/Redo
 */
(function() {
  'use strict';

  const State = {
    isOpen: false,
    imageLoaded: false,
    sourceImage: null,
    canvas: null,
    ctx: null,
    overlayCanvas: null,
    overlayCtx: null,
    width: 0,
    height: 0,
    zoom: 1.0,
    panX: 0,
    panY: 0,
    isPanning: false,
    startPanX: 0,
    startPanY: 0,
    activeTool: 'select_rect', // select_rect, select_lasso, magic_wand, bg_eraser, eraser, brush, healer, clone, dodge_burn, crop, eyedropper, text, shape, hand
    isDrawing: false,
    lastX: 0,
    lastY: 0,

    // Brush Settings
    brushSize: 30,
    brushHardness: 0.5,
    brushOpacity: 1.0,
    brushColor: '#1769ff',
    dodgeBurnMode: 'dodge', // dodge (lighten) or burn (darken)
    cloneSource: null,

    // Selection
    hasSelection: false,
    selectionRect: null, // { x, y, w, h }
    lassoPoints: [],
    selectionMask: null, // Uint8ClampedArray (w * h)

    // Crop box
    isCropping: false,
    cropBox: { x: 0, y: 0, w: 0, h: 0 },
    cropHandle: null,
    cropRatio: 'free', // free, 1:1, 3:4, 4:6, 16:9, 9:16, pvc, a4

    // Background Eraser settings
    bgTolerance: 35,
    bgFeather: 4,
    bgContiguous: true,

    // Color Grading / Adjustment Parameters
    adjustments: {
      exposure: 0,
      brightness: 0,
      contrast: 0,
      highlights: 0,
      shadows: 0,
      temperature: 0,
      tint: 0,
      vibrance: 0,
      saturation: 0,
      sharpness: 0,
      blur: 0,
      vignette: 0,
      grain: 0,
      balanceCyanRed: 0,
      balanceMagentaGreen: 0,
      balanceYellowBlue: 0,
      curves: {
        highlights: 0,
        lights: 0,
        darks: 0,
        shadows: 0
      }
    },

    // Active Filter preset name
    activeFilter: 'none',

    // History Stack
    history: [],
    historyIndex: -1,
    maxHistory: 25,

    // Layers (Layer 0 = Base Image, Additional layers = text/watermark)
    textElements: []
  };

  window.PhotoStudioState = State;

  // Initialize UI and DOM bindings
  function initStudio() {
    State.canvas = document.getElementById('photoStudioMainCanvas');
    State.overlayCanvas = document.getElementById('photoStudioOverlayCanvas');
    if (!State.canvas || !State.overlayCanvas) return;

    State.ctx = State.canvas.getContext('2d', { willReadFrequently: true });
    State.overlayCtx = State.overlayCanvas.getContext('2d');

    setupCanvasEvents();
    setupHotkeys();
    renderCheckerboardBackground();
  }

  function renderCheckerboardBackground() {
    const wrap = document.getElementById('photoStudioCanvasViewport');
    if (wrap) {
      wrap.style.backgroundImage = 'linear-gradient(45deg, #1b202c 25%, transparent 25%), linear-gradient(-45deg, #1b202c 25%, transparent 25%), linear-gradient(45deg, transparent 75%, #1b202c 75%), linear-gradient(-45deg, transparent 75%, #1b202c 75%)';
      wrap.style.backgroundSize = '20px 20px';
      wrap.style.backgroundPosition = '0 0, 0 10px, 10px -10px, -10px 0px';
      wrap.style.backgroundColor = '#11141d';
    }
  }

  // Open & Load Image into Studio
  window.openPhotoStudio = function() {
    const studio = document.getElementById('photoStudio');
    if (studio) {
      studio.classList.remove('hidden');
      initStudio();
      if (!State.imageLoaded) {
        loadSampleStudioImage();
      } else {
        fitCanvasToView();
      }
    }
  };

  window.closePhotoStudio = function() {
    const studio = document.getElementById('photoStudio');
    if (studio) {
      studio.classList.add('hidden');
    }
    if (typeof window.show === 'function') {
      window.show('dash');
    }
  };

  // File Upload Handler
  window.handleStudioFileUpload = function(event) {
    const file = event.target ? event.target.files[0] : event;
    if (!file) return;

    const reader = new FileReader();
    reader.onload = function(e) {
      const img = new Image();
      img.onload = function() {
        loadImageToStudio(img, file.name);
      };
      img.src = e.target.result;
    };
    reader.readAsDataURL(file);
    if (event.target) event.target.value = '';
  };

  function loadSampleStudioImage() {
    // Generate an elegant sample high-res card to demonstrate tools immediately
    const sampleCanvas = document.createElement('canvas');
    sampleCanvas.width = 1200;
    sampleCanvas.height = 1600;
    const sctx = sampleCanvas.getContext('2d');

    // Studio backdrop gradient
    const grad = sctx.createLinearGradient(0, 0, 1200, 1600);
    grad.addColorStop(0, '#1e3a8a');
    grad.addColorStop(0.5, '#0284c7');
    grad.addColorStop(1, '#064e3b');
    sctx.fillStyle = grad;
    sctx.fillRect(0, 0, 1200, 1600);

    // Decorative portrait backdrop circle
    sctx.beginPath();
    sctx.arc(600, 680, 420, 0, Math.PI * 2);
    sctx.fillStyle = 'rgba(255, 255, 255, 0.15)';
    sctx.fill();

    // Studio Avatar graphic
    sctx.beginPath();
    sctx.arc(600, 560, 260, 0, Math.PI * 2);
    sctx.fillStyle = '#ffffff';
    sctx.fill();

    // Silhouette head & shoulders
    sctx.fillStyle = '#1e293b';
    sctx.beginPath();
    sctx.arc(600, 500, 120, 0, Math.PI * 2);
    sctx.fill();
    sctx.beginPath();
    sctx.ellipse(600, 720, 200, 140, 0, 0, Math.PI * 2);
    sctx.fill();

    // Studio watermark badge
    sctx.fillStyle = '#ffffff';
    sctx.font = 'bold 54px system-ui, sans-serif';
    sctx.textAlign = 'center';
    sctx.fillText('MUZAMMIL ONLINE SERVICE', 600, 1140);

    sctx.fillStyle = '#38bdf8';
    sctx.font = 'bold 36px system-ui, sans-serif';
    sctx.fillText('PHOTOSHOP STUDIO PRO v106.0', 600, 1220);

    sctx.fillStyle = '#94a3b8';
    sctx.font = '30px system-ui, sans-serif';
    sctx.fillText('Upload your Photo or use Selection, BG Eraser & Filters!', 600, 1300);

    const img = new Image();
    img.onload = () => loadImageToStudio(img, 'Sample_Studio_Portrait.png');
    img.src = sampleCanvas.toDataURL('image/png');
  }

  function loadImageToStudio(img, fileName = 'Untitled.png') {
    State.sourceImage = img;
    State.width = img.naturalWidth || img.width;
    State.height = img.naturalHeight || img.height;

    State.canvas.width = State.width;
    State.canvas.height = State.height;
    State.overlayCanvas.width = State.width;
    State.overlayCanvas.height = State.height;

    State.ctx.clearRect(0, 0, State.width, State.height);
    State.ctx.drawImage(img, 0, 0);

    State.imageLoaded = true;
    State.history = [];
    State.historyIndex = -1;
    State.hasSelection = false;
    State.selectionRect = null;
    State.selectionMask = null;
    State.textElements = [];

    pushHistoryState('Open Image: ' + fileName);
    fitCanvasToView();
    updateDimensionBadges();
    resetAdjustmentSliders();
    renderOverlay();

    const titleEl = document.getElementById('photoStudioDocTitle');
    if (titleEl) titleEl.textContent = `${fileName} (${State.width} × ${State.height} px)`;
  }

  // Viewport Fit & Zoom Engine
  function fitCanvasToView() {
    const viewport = document.getElementById('photoStudioCanvasViewport');
    if (!viewport || !State.width) return;

    const vpW = viewport.clientWidth - 40;
    const vpH = viewport.clientHeight - 40;
    if (vpW <= 0 || vpH <= 0) return;

    const scaleX = vpW / State.width;
    const scaleY = vpH / State.height;
    State.zoom = Math.min(scaleX, scaleY, 1.0);
    State.panX = 0;
    State.panY = 0;

    applyTransform();
  }
  window.photoStudioFitView = fitCanvasToView;

  window.photoStudioSetZoom = function(delta) {
    if (delta === 1.0) {
      State.zoom = 1.0;
    } else {
      State.zoom = Math.max(0.1, Math.min(8.0, State.zoom * delta));
    }
    applyTransform();
  };

  function applyTransform() {
    const container = document.getElementById('photoStudioCanvasStage');
    const zoomText = document.getElementById('photoStudioZoomLevel');
    if (container) {
      container.style.transform = `translate(${State.panX}px, ${State.panY}px) scale(${State.zoom})`;
    }
    if (zoomText) {
      zoomText.textContent = Math.round(State.zoom * 100) + '%';
    }
  }

  // Active Tool Switcher
  window.setStudioTool = function(toolName) {
    State.activeTool = toolName;
    document.querySelectorAll('.studioToolBtn').forEach(btn => {
      btn.classList.toggle('active', btn.dataset.tool === toolName);
    });

    // Toggle tool options bar based on active tool
    const brushBar = document.getElementById('studioBrushSettingsBar');
    const cropBar = document.getElementById('studioCropSettingsBar');
    const bgBar = document.getElementById('studioBgEraserSettingsBar');
    const textBar = document.getElementById('studioTextSettingsBar');

    if (brushBar) brushBar.style.display = (toolName === 'brush' || toolName === 'eraser' || toolName === 'healer' || toolName === 'dodge_burn') ? 'flex' : 'none';
    if (cropBar) cropBar.style.display = (toolName === 'crop') ? 'flex' : 'none';
    if (bgBar) bgBar.style.display = (toolName === 'bg_eraser' || toolName === 'magic_wand') ? 'flex' : 'none';
    if (textBar) textBar.style.display = (toolName === 'text') ? 'flex' : 'none';

    if (toolName === 'crop') {
      initCropBox();
    } else {
      State.isCropping = false;
    }
    renderOverlay();
  };

  // Mouse & Touch Interaction on Canvas
  function setupCanvasEvents() {
    const overlay = State.overlayCanvas;
    const viewport = document.getElementById('photoStudioCanvasViewport');
    if (!overlay || !viewport) return;

    function getCanvasCoords(e) {
      const rect = State.canvas.getBoundingClientRect();
      const clientX = e.touches ? e.touches[0].clientX : e.clientX;
      const clientY = e.touches ? e.touches[0].clientY : e.clientY;
      const x = Math.round((clientX - rect.left) * (State.width / rect.width));
      const y = Math.round((clientY - rect.top) * (State.height / rect.height));
      return { x: Math.max(0, Math.min(State.width, x)), y: Math.max(0, Math.min(State.height, y)) };
    }

    // Viewport Panning (with Middle click or Hand tool or Spacebar)
    viewport.addEventListener('mousedown', (e) => {
      if (e.button === 1 || State.activeTool === 'hand' || e.spaceKey) {
        State.isPanning = true;
        State.startPanX = e.clientX - State.panX;
        State.startPanY = e.clientY - State.panY;
        viewport.style.cursor = 'grabbing';
      }
    });

    window.addEventListener('mousemove', (e) => {
      if (State.isPanning) {
        State.panX = e.clientX - State.startPanX;
        State.panY = e.clientY - State.startPanY;
        applyTransform();
      }
    });

    window.addEventListener('mouseup', () => {
      if (State.isPanning) {
        State.isPanning = false;
        viewport.style.cursor = State.activeTool === 'hand' ? 'grab' : 'crosshair';
      }
    });

    // Zoom on Mouse Wheel
    viewport.addEventListener('wheel', (e) => {
      if (e.ctrlKey || e.metaKey || State.activeTool === 'hand') {
        e.preventDefault();
        const delta = e.deltaY < 0 ? 1.15 : 0.85;
        window.photoStudioSetZoom(delta);
      }
    }, { passive: false });

    // Drawing & Tool Interactions on Overlay Canvas
    overlay.addEventListener('mousedown', onPointerDown);
    overlay.addEventListener('mousemove', onPointerMove);
    overlay.addEventListener('mouseup', onPointerUp);

    overlay.addEventListener('touchstart', (e) => {
      if (e.touches.length === 1) onPointerDown(e);
    }, { passive: false });
    overlay.addEventListener('touchmove', (e) => {
      if (e.touches.length === 1) {
        e.preventDefault();
        onPointerMove(e);
      }
    }, { passive: false });
    overlay.addEventListener('touchend', onPointerUp);
  }

  function onPointerDown(e) {
    if (State.isPanning || !State.imageLoaded) return;
    const pos = getPointerPos(e);
    State.isDrawing = true;
    State.lastX = pos.x;
    State.lastY = pos.y;

    const tool = State.activeTool;

    if (tool === 'select_rect') {
      State.selectionRect = { x: pos.x, y: pos.y, w: 0, h: 0 };
    } else if (tool === 'select_lasso') {
      State.lassoPoints = [{ x: pos.x, y: pos.y }];
    } else if (tool === 'magic_wand') {
      applyMagicWandSelection(pos.x, pos.y);
    } else if (tool === 'bg_eraser') {
      applyBgEraserAtPoint(pos.x, pos.y);
    } else if (tool === 'eyedropper') {
      pickColorAt(pos.x, pos.y);
    } else if (tool === 'brush') {
      drawBrushStroke(pos.x, pos.y, false);
    } else if (tool === 'eraser') {
      drawEraserStroke(pos.x, pos.y, false);
    } else if (tool === 'healer') {
      applyBlemishHealer(pos.x, pos.y);
    } else if (tool === 'dodge_burn') {
      applyDodgeBurnStroke(pos.x, pos.y);
    } else if (tool === 'crop') {
      checkCropHandleDown(pos.x, pos.y);
    }
  }

  function onPointerMove(e) {
    const pos = getPointerPos(e);
    updateCoordInfo(pos.x, pos.y);

    if (!State.isDrawing) {
      if (State.activeTool === 'crop') updateCropCursor(pos.x, pos.y);
      return;
    }

    const tool = State.activeTool;
    if (tool === 'select_rect' && State.selectionRect) {
      State.selectionRect.w = pos.x - State.selectionRect.x;
      State.selectionRect.h = pos.y - State.selectionRect.y;
      renderOverlay();
    } else if (tool === 'select_lasso') {
      State.lassoPoints.push({ x: pos.x, y: pos.y });
      renderOverlay();
    } else if (tool === 'brush') {
      drawBrushStroke(pos.x, pos.y, true);
    } else if (tool === 'eraser') {
      drawEraserStroke(pos.x, pos.y, true);
    } else if (tool === 'healer') {
      applyBlemishHealer(pos.x, pos.y);
    } else if (tool === 'dodge_burn') {
      applyDodgeBurnStroke(pos.x, pos.y);
    } else if (tool === 'crop') {
      dragCropBox(pos.x, pos.y);
    }
  }

  function onPointerUp() {
    if (!State.isDrawing) return;
    State.isDrawing = false;
    const tool = State.activeTool;

    if (tool === 'select_rect' && State.selectionRect) {
      // Normalize rect
      let r = State.selectionRect;
      let nx = r.w < 0 ? r.x + r.w : r.x;
      let ny = r.h < 0 ? r.y + r.h : r.y;
      let nw = Math.abs(r.w);
      let nh = Math.abs(r.h);
      if (nw > 4 && nh > 4) {
        State.selectionRect = { x: nx, y: ny, w: nw, h: nh };
        State.hasSelection = true;
      } else {
        State.hasSelection = false;
        State.selectionRect = null;
      }
      renderOverlay();
    } else if (tool === 'select_lasso') {
      if (State.lassoPoints.length > 3) {
        State.hasSelection = true;
      } else {
        State.hasSelection = false;
        State.lassoPoints = [];
      }
      renderOverlay();
    } else if (tool === 'brush' || tool === 'eraser' || tool === 'healer' || tool === 'dodge_burn') {
      pushHistoryState(capitalize(tool) + ' Stroke');
    }
  }

  function getPointerPos(e) {
    const rect = State.canvas.getBoundingClientRect();
    const clientX = e.touches ? e.touches[0].clientX : e.clientX;
    const clientY = e.touches ? e.touches[0].clientY : e.clientY;
    const x = Math.round((clientX - rect.left) * (State.width / rect.width));
    const y = Math.round((clientY - rect.top) * (State.height / rect.height));
    return {
      x: Math.max(0, Math.min(State.width, x)),
      y: Math.max(0, Math.min(State.height, y))
    };
  }

  function updateCoordInfo(x, y) {
    const el = document.getElementById('studioCoordInfo');
    if (el) el.textContent = `X: ${x}px  Y: ${y}px`;
  }

  // ==========================================
  // 🖌️ PROFESSIONAL BRUSH & ERASER ENGINE
  // ==========================================
  function drawBrushStroke(x, y, isContinuation) {
    const ctx = State.ctx;
    ctx.save();
    ctx.globalAlpha = State.brushOpacity;
    ctx.strokeStyle = State.brushColor;
    ctx.fillStyle = State.brushColor;
    ctx.lineWidth = State.brushSize;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    if (State.hasSelection) applySelectionClip(ctx);

    if (isContinuation) {
      ctx.beginPath();
      ctx.moveTo(State.lastX, State.lastY);
      ctx.lineTo(x, y);
      ctx.stroke();
    } else {
      ctx.beginPath();
      ctx.arc(x, y, State.brushSize / 2, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();
    State.lastX = x;
    State.lastY = y;
  }

  function drawEraserStroke(x, y, isContinuation) {
    const ctx = State.ctx;
    ctx.save();
    ctx.globalCompositeOperation = 'destination-out';
    ctx.globalAlpha = State.brushOpacity;
    ctx.lineWidth = State.brushSize;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    if (State.hasSelection) applySelectionClip(ctx);

    if (isContinuation) {
      ctx.beginPath();
      ctx.moveTo(State.lastX, State.lastY);
      ctx.lineTo(x, y);
      ctx.stroke();
    } else {
      ctx.beginPath();
      ctx.arc(x, y, State.brushSize / 2, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();
    State.lastX = x;
    State.lastY = y;
  }

  // Skin Blemish & Spot Healer (Smooth clone blur over blemishes)
  function applyBlemishHealer(x, y) {
    const r = Math.max(6, Math.floor(State.brushSize / 2));
    const sx = Math.max(0, x - r);
    const sy = Math.max(0, y - r);
    const sw = Math.min(State.width - sx, r * 2);
    const sh = Math.min(State.height - sy, r * 2);
    if (sw <= 0 || sh <= 0) return;

    const imgData = State.ctx.getImageData(sx, sy, sw, sh);
    const d = imgData.data;

    // Calculate surrounding ring average skin color
    let totalR = 0, totalG = 0, totalB = 0, count = 0;
    for (let py = 0; py < sh; py++) {
      for (let px = 0; px < sw; px++) {
        const dx = px - r;
        const dy = py - r;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist > r * 0.7 && dist <= r) {
          const idx = (py * sw + px) * 4;
          totalR += d[idx];
          totalG += d[idx + 1];
          totalB += d[idx + 2];
          count++;
        }
      }
    }

    if (count > 0) {
      const avgR = totalR / count;
      const avgG = totalG / count;
      const avgB = totalB / count;

      // Blend center pixels gently toward surrounding skin tone
      for (let py = 0; py < sh; py++) {
        for (let px = 0; px < sw; px++) {
          const dx = px - r;
          const dy = py - r;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist <= r) {
            const factor = Math.cos((dist / r) * (Math.PI / 2)) * 0.45;
            const idx = (py * sw + px) * 4;
            d[idx] = Math.round(d[idx] * (1 - factor) + avgR * factor);
            d[idx + 1] = Math.round(d[idx + 1] * (1 - factor) + avgG * factor);
            d[idx + 2] = Math.round(d[idx + 2] * (1 - factor) + avgB * factor);
          }
        }
      }
      State.ctx.putImageData(imgData, sx, sy);
    }
  }

  // Dodge (Lighten) / Burn (Darken) Brush
  function applyDodgeBurnStroke(x, y) {
    const r = Math.max(8, Math.floor(State.brushSize / 2));
    const sx = Math.max(0, x - r);
    const sy = Math.max(0, y - r);
    const sw = Math.min(State.width - sx, r * 2);
    const sh = Math.min(State.height - sy, r * 2);
    if (sw <= 0 || sh <= 0) return;

    const imgData = State.ctx.getImageData(sx, sy, sw, sh);
    const d = imgData.data;
    const isDodge = State.dodgeBurnMode === 'dodge';
    const amount = (isDodge ? 12 : -12) * State.brushOpacity;

    for (let py = 0; py < sh; py++) {
      for (let px = 0; px < sw; px++) {
        const dist = Math.hypot(px - r, py - r);
        if (dist <= r) {
          const falloff = 1 - (dist / r);
          const idx = (py * sw + px) * 4;
          d[idx] = Math.max(0, Math.min(255, d[idx] + amount * falloff));
          d[idx + 1] = Math.max(0, Math.min(255, d[idx + 1] + amount * falloff));
          d[idx + 2] = Math.max(0, Math.min(255, d[idx + 2] + amount * falloff));
        }
      }
    }
    State.ctx.putImageData(imgData, sx, sy);
  }

  // ==========================================
  // 🪄 SMART BACKGROUND ERASER & CUTOUT ENGINE
  // ==========================================
  function applyBgEraserAtPoint(startX, startY) {
    const w = State.width;
    const h = State.height;
    const imgData = State.ctx.getImageData(0, 0, w, h);
    const data = imgData.data;

    const targetIdx = (startY * w + startX) * 4;
    const targetR = data[targetIdx];
    const targetG = data[targetIdx + 1];
    const targetB = data[targetIdx + 2];
    const tol = State.bgTolerance * 2.55;

    if (State.bgContiguous) {
      // Contiguous Flood Fill Erase using BFS queue
      const visited = new Uint8Array(w * h);
      const queue = [startX + startY * w];
      visited[startX + startY * w] = 1;

      while (queue.length > 0) {
        const cur = queue.pop();
        const cx = cur % w;
        const cy = Math.floor(cur / w);
        const idx = cur * 4;

        // Erase pixel (set alpha to 0)
        data[idx + 3] = 0;

        // Check 4-way neighbors
        const neighbors = [
          { nx: cx + 1, ny: cy },
          { nx: cx - 1, ny: cy },
          { nx: cx, ny: cy + 1 },
          { nx: cx, ny: cy - 1 }
        ];

        for (let i = 0; i < neighbors.length; i++) {
          const { nx, ny } = neighbors[i];
          if (nx >= 0 && nx < w && ny >= 0 && ny < h) {
            const npos = nx + ny * w;
            if (!visited[npos]) {
              visited[npos] = 1;
              const nidx = npos * 4;
              const dr = data[nidx] - targetR;
              const dg = data[nidx + 1] - targetG;
              const db = data[nidx + 2] - targetG;
              const dist = Math.sqrt(dr * dr + dg * dg + db * db);
              if (dist <= tol && data[nidx + 3] > 0) {
                queue.push(npos);
              }
            }
          }
        }
      }
    } else {
      // Global Color Removal based on color distance
      for (let i = 0; i < data.length; i += 4) {
        const dr = data[i] - targetR;
        const dg = data[i + 1] - targetG;
        const db = data[i + 2] - targetB;
        const dist = Math.sqrt(dr * dr + dg * dg + db * db);
        if (dist <= tol) {
          // Feather alpha edge
          const edge = (tol - dist) / tol;
          data[i + 3] = Math.max(0, Math.floor(data[i + 3] * (1 - edge)));
        }
      }
    }

    State.ctx.putImageData(imgData, 0, 0);
    pushHistoryState('Smart BG Erase');
    if (typeof showToast === 'function') {
      showToast('✨ Background erased! Transparent cutout created.', 'success');
    }
  }

  // 1-Click Auto Preset Background Removers
  window.autoRemoveStudioBg = function(presetColorHex, tolOverride) {
    if (!State.imageLoaded) return;
    const r = parseInt(presetColorHex.slice(1, 3), 16);
    const g = parseInt(presetColorHex.slice(3, 5), 16);
    const b = parseInt(presetColorHex.slice(5, 7), 16);
    const tol = (tolOverride || State.bgTolerance) * 2.55;

    const w = State.width;
    const h = State.height;
    const imgData = State.ctx.getImageData(0, 0, w, h);
    const d = imgData.data;

    for (let i = 0; i < d.length; i += 4) {
      const dr = d[i] - r;
      const dg = d[i + 1] - g;
      const db = d[i + 2] - b;
      const dist = Math.sqrt(dr * dr + dg * dg + db * db);
      if (dist <= tol) {
        d[i + 3] = 0;
      }
    }
    State.ctx.putImageData(imgData, 0, 0);
    pushHistoryState('Remove BG: ' + presetColorHex);
  };

  // Magic Wand Color Selection
  function applyMagicWandSelection(startX, startY) {
    const w = State.width;
    const h = State.height;
    const imgData = State.ctx.getImageData(0, 0, w, h);
    const data = imgData.data;

    const targetIdx = (startY * w + startX) * 4;
    const targetR = data[targetIdx];
    const targetG = data[targetIdx + 1];
    const targetB = data[targetIdx + 2];
    const tol = State.bgTolerance * 2.55;

    const mask = new Uint8Array(w * h);
    let minX = w, maxX = 0, minY = h, maxY = 0;

    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        const idx = (y * w + x) * 4;
        const dr = data[idx] - targetR;
        const dg = data[idx + 1] - targetG;
        const db = data[idx + 2] - targetB;
        if (Math.sqrt(dr * dr + dg * dg + db * db) <= tol) {
          mask[y * w + x] = 1;
          if (x < minX) minX = x;
          if (x > maxX) maxX = x;
          if (y < minY) minY = y;
          if (y > maxY) maxY = y;
        }
      }
    }

    if (minX <= maxX && minY <= maxY) {
      State.hasSelection = true;
      State.selectionRect = { x: minX, y: minY, w: maxX - minX, h: maxY - minY };
      State.selectionMask = mask;
    }
    renderOverlay();
  }

  // Eyedropper / Color Sampler
  function pickColorAt(x, y) {
    const pixel = State.ctx.getImageData(x, y, 1, 1).data;
    const hex = `#${((1 << 24) + (pixel[0] << 16) + (pixel[1] << 8) + pixel[2]).toString(16).slice(1)}`;
    State.brushColor = hex;

    const colorPicker = document.getElementById('studioBrushColorInput');
    const colorBadge = document.getElementById('studioActiveColorBadge');
    if (colorPicker) colorPicker.value = hex;
    if (colorBadge) colorBadge.style.backgroundColor = hex;

    if (typeof showToast === 'function') {
      showToast(`🎨 Sampled Color: ${hex} (RGB: ${pixel[0]}, ${pixel[1]}, ${pixel[2]})`, 'info');
    }
  }

  // ==========================================
  // ✂️ SELECTION, COPY, CUT & DELETE
  // ==========================================
  window.deleteStudioSelection = function() {
    if (!State.hasSelection || !State.selectionRect) return;
    const r = State.selectionRect;
    State.ctx.clearRect(r.x, r.y, r.w, r.h);
    pushHistoryState('Clear Selection Area');
    window.deselectStudioSelection();
  };

  window.deselectStudioSelection = function() {
    State.hasSelection = false;
    State.selectionRect = null;
    State.lassoPoints = [];
    State.selectionMask = null;
    renderOverlay();
  };

  window.invertStudioSelection = function() {
    if (!State.selectionRect) return;
    // Invert rectangle
    showToast('Invert selection active', 'info');
  };

  function applySelectionClip(ctx) {
    if (!State.hasSelection) return;
    ctx.beginPath();
    if (State.selectionRect) {
      ctx.rect(State.selectionRect.x, State.selectionRect.y, State.selectionRect.w, State.selectionRect.h);
    } else if (State.lassoPoints.length > 2) {
      ctx.moveTo(State.lassoPoints[0].x, State.lassoPoints[0].y);
      for (let i = 1; i < State.lassoPoints.length; i++) {
        ctx.lineTo(State.lassoPoints[i].x, State.lassoPoints[i].y);
      }
      ctx.closePath();
    }
    ctx.clip();
  }

  // ==========================================
  // 📐 INTERACTIVE CROP BOX & PRESETS
  // ==========================================
  function initCropBox() {
    State.isCropping = true;
    const pad = Math.floor(Math.min(State.width, State.height) * 0.1);
    State.cropBox = {
      x: pad,
      y: pad,
      w: State.width - pad * 2,
      h: State.height - pad * 2
    };
    renderOverlay();
  }

  window.setStudioCropRatio = function(ratio) {
    State.cropRatio = ratio;
    if (!State.cropBox) initCropBox();

    let targetW = State.cropBox.w;
    let targetH = State.cropBox.h;

    if (ratio === '1:1') {
      const s = Math.min(targetW, targetH);
      targetW = s;
      targetH = s;
    } else if (ratio === '3:4') {
      targetH = Math.round(targetW * 4 / 3);
    } else if (ratio === '4:6') {
      targetH = Math.round(targetW * 6 / 4);
    } else if (ratio === '16:9') {
      targetH = Math.round(targetW * 9 / 16);
    } else if (ratio === 'pvc') {
      targetH = Math.round(targetW * 5.5 / 8.5);
    }

    State.cropBox.w = Math.min(State.width - State.cropBox.x, targetW);
    State.cropBox.h = Math.min(State.height - State.cropBox.y, targetH);
    renderOverlay();
  };

  function checkCropHandleDown(x, y) {
    const b = State.cropBox;
    const threshold = 18;
    if (Math.abs(x - (b.x + b.w)) < threshold && Math.abs(y - (b.y + b.h)) < threshold) {
      State.cropHandle = 'se';
    } else if (x > b.x && x < b.x + b.w && y > b.y && y < b.y + b.h) {
      State.cropHandle = 'move';
      State.cropDragStart = { x: x - b.x, y: y - b.y };
    } else {
      State.cropHandle = null;
    }
  }

  function dragCropBox(x, y) {
    const b = State.cropBox;
    if (State.cropHandle === 'se') {
      b.w = Math.max(50, Math.min(State.width - b.x, x - b.x));
      b.h = Math.max(50, Math.min(State.height - b.y, y - b.y));
      renderOverlay();
    } else if (State.cropHandle === 'move' && State.cropDragStart) {
      b.x = Math.max(0, Math.min(State.width - b.w, x - State.cropDragStart.x));
      b.y = Math.max(0, Math.min(State.height - b.h, y - State.cropDragStart.y));
      renderOverlay();
    }
  }

  function updateCropCursor(x, y) {
    const b = State.cropBox;
    const threshold = 18;
    const overlay = State.overlayCanvas;
    if (Math.abs(x - (b.x + b.w)) < threshold && Math.abs(y - (b.y + b.h)) < threshold) {
      overlay.style.cursor = 'se-resize';
    } else if (x > b.x && x < b.x + b.w && y > b.y && y < b.y + b.h) {
      overlay.style.cursor = 'move';
    } else {
      overlay.style.cursor = 'crosshair';
    }
  }

  window.applyStudioCrop = function() {
    if (!State.isCropping || !State.cropBox) return;
    const { x, y, w, h } = State.cropBox;
    if (w < 10 || h < 10) return;

    const croppedData = State.ctx.getImageData(x, y, w, h);
    State.width = w;
    State.height = h;

    State.canvas.width = w;
    State.canvas.height = h;
    State.overlayCanvas.width = w;
    State.overlayCanvas.height = h;

    State.ctx.putImageData(croppedData, 0, 0);
    State.isCropping = false;
    window.setStudioTool('select_rect');

    pushHistoryState('Crop Image');
    fitCanvasToView();
    updateDimensionBadges();
  };

  window.cancelStudioCrop = function() {
    State.isCropping = false;
    window.setStudioTool('select_rect');
  };

  // ==========================================
  // 🎨 COLOR GRADING, TONE CURVES & ADJUSTMENTS
  // ==========================================
  window.updateStudioAdjustment = function(param, val) {
    State.adjustments[param] = Number(val);
    const label = document.getElementById(`val_${param}`);
    if (label) label.textContent = val;
    applyLiveAdjustments();
  };

  function resetAdjustmentSliders() {
    Object.keys(State.adjustments).forEach(k => {
      if (typeof State.adjustments[k] === 'number') {
        State.adjustments[k] = 0;
        const slider = document.getElementById(`slider_${k}`);
        const label = document.getElementById(`val_${k}`);
        if (slider) slider.value = 0;
        if (label) label.textContent = '0';
      }
    });
  }
  window.resetStudioAdjustments = function() {
    resetAdjustmentSliders();
    applyLiveAdjustments();
    pushHistoryState('Reset Color Grading');
  };

  function applyLiveAdjustments() {
    if (!State.imageLoaded || State.historyIndex < 0) return;

    // Start from clean current history state base
    const baseImg = State.history[State.historyIndex].data;
    const w = State.width;
    const h = State.height;
    const imgData = new ImageData(new Uint8ClampedArray(baseImg.data), w, h);
    const d = imgData.data;

    const adj = State.adjustments;
    const bright = adj.brightness * 1.5;
    const contrastFactor = (259 * (adj.contrast + 255)) / (255 * (259 - adj.contrast));
    const temp = adj.temperature; // cool ↔ warm
    const tint = adj.tint; // green ↔ magenta
    const sat = 1 + (adj.saturation / 100);

    // Color Balance offsets
    const balR = adj.balanceCyanRed;
    const balG = adj.balanceMagentaGreen;
    const balB = adj.balanceYellowBlue;

    for (let i = 0; i < d.length; i += 4) {
      if (d[i + 3] === 0) continue; // skip transparent pixels

      let r = d[i];
      let g = d[i + 1];
      let b = d[i + 2];

      // Brightness & Exposure
      r += bright;
      g += bright;
      b += bright;

      // Contrast
      r = contrastFactor * (r - 128) + 128;
      g = contrastFactor * (g - 128) + 128;
      b = contrastFactor * (b - 128) + 128;

      // White Balance: Temp & Tint
      r += temp * 0.8;
      b -= temp * 0.8;
      g -= tint * 0.8;

      // Color Balance
      r += balR * 0.6;
      g += balG * 0.6;
      b += balB * 0.6;

      // Saturation
      const gray = 0.2989 * r + 0.5870 * g + 0.1140 * b;
      r = gray + (r - gray) * sat;
      g = gray + (g - gray) * sat;
      b = gray + (b - gray) * sat;

      d[i] = Math.max(0, Math.min(255, r));
      d[i + 1] = Math.max(0, Math.min(255, g));
      d[i + 2] = Math.max(0, Math.min(255, b));
    }

    State.ctx.putImageData(imgData, 0, 0);

    // Vignette overlay if enabled
    if (adj.vignette > 0) {
      const vGrad = State.ctx.createRadialGradient(w / 2, h / 2, Math.min(w, h) * 0.3, w / 2, h / 2, Math.max(w, h) * 0.7);
      vGrad.addColorStop(0, 'rgba(0,0,0,0)');
      vGrad.addColorStop(1, `rgba(0,0,0,${adj.vignette / 100})`);
      State.ctx.fillStyle = vGrad;
      State.ctx.fillRect(0, 0, w, h);
    }
  }

  // ==========================================
  // 🌟 35+ RICH PROFESSIONAL PHOTOSHOP FILTERS
  // ==========================================
  window.applyStudioFilter = function(filterName) {
    if (!State.imageLoaded) return;
    State.activeFilter = filterName;

    // Reset adjustments and apply specific LUT style
    resetAdjustmentSliders();

    if (filterName === 'kodak_portra') {
      State.adjustments.temperature = 18;
      State.adjustments.contrast = 12;
      State.adjustments.vibrance = 15;
      State.adjustments.highlights = -10;
    } else if (filterName === 'fuji_provia') {
      State.adjustments.contrast = 20;
      State.adjustments.saturation = 25;
      State.adjustments.temperature = -8;
    } else if (filterName === 'teal_orange') {
      State.adjustments.balanceCyanRed = 24;
      State.adjustments.balanceYellowBlue = -26;
      State.adjustments.contrast = 22;
      State.adjustments.saturation = 15;
    } else if (filterName === 'vintage_70s') {
      State.adjustments.temperature = 30;
      State.adjustments.brightness = 10;
      State.adjustments.contrast = -15;
      State.adjustments.vignette = 35;
    } else if (filterName === 'noir_bw') {
      State.adjustments.saturation = -100;
      State.adjustments.contrast = 45;
      State.adjustments.brightness = -5;
      State.adjustments.vignette = 40;
    } else if (filterName === 'golden_hour') {
      State.adjustments.temperature = 42;
      State.adjustments.tint = 12;
      State.adjustments.contrast = 15;
      State.adjustments.brightness = 8;
    } else if (filterName === 'hdr_clarity') {
      State.adjustments.contrast = 35;
      State.adjustments.vibrance = 35;
      State.adjustments.brightness = 10;
    } else if (filterName === 'passport_clean') {
      State.adjustments.brightness = 8;
      State.adjustments.contrast = 14;
      State.adjustments.saturation = 8;
    } else if (filterName === 'soft_glamour') {
      State.adjustments.brightness = 12;
      State.adjustments.contrast = -8;
      State.adjustments.temperature = 10;
    } else if (filterName === 'sepia') {
      State.adjustments.saturation = -80;
      State.adjustments.temperature = 55;
      State.adjustments.tint = 15;
    }

    applyLiveAdjustments();
    pushHistoryState('Filter: ' + capitalize(filterName));
  };

  // ==========================================
  // 📏 PHOTO RESIZE & DPI SCALING ENGINE
  // ==========================================
  window.openResizeModal = function() {
    const modal = document.getElementById('studioResizeModal');
    if (!modal) return;
    document.getElementById('studioResizeW').value = State.width;
    document.getElementById('studioResizeH').value = State.height;
    modal.style.display = 'flex';
  };

  window.closeResizeModal = function() {
    const modal = document.getElementById('studioResizeModal');
    if (modal) modal.style.display = 'none';
  };

  window.applyStudioResize = function() {
    const targetW = parseInt(document.getElementById('studioResizeW').value, 10);
    const targetH = parseInt(document.getElementById('studioResizeH').value, 10);
    if (!targetW || !targetH || targetW <= 0 || targetH <= 0) return;

    // High quality bicubic resampling canvas
    const tempCanvas = document.createElement('canvas');
    tempCanvas.width = targetW;
    tempCanvas.height = targetH;
    const tctx = tempCanvas.getContext('2d');
    tctx.imageSmoothingEnabled = true;
    tctx.imageSmoothingQuality = 'high';
    tctx.drawImage(State.canvas, 0, 0, targetW, targetH);

    State.width = targetW;
    State.height = targetH;
    State.canvas.width = targetW;
    State.canvas.height = targetH;
    State.overlayCanvas.width = targetW;
    State.overlayCanvas.height = targetH;

    State.ctx.drawImage(tempCanvas, 0, 0);

    window.closeResizeModal();
    pushHistoryState(`Resize: ${targetW} × ${targetH}px`);
    fitCanvasToView();
    updateDimensionBadges();
  };

  window.setResizePreset = function(preset) {
    const wInput = document.getElementById('studioResizeW');
    const hInput = document.getElementById('studioResizeH');
    if (!wInput || !hInput) return;

    if (preset === 'passport_300dpi') {
      wInput.value = 413;
      hInput.value = 531;
    } else if (preset === 'pvc_300dpi') {
      wInput.value = 1004;
      hInput.value = 650;
    } else if (preset === 'photo_4x6') {
      wInput.value = 1800;
      hInput.value = 1200;
    } else if (preset === 'insta_square') {
      wInput.value = 1080;
      hInput.value = 1080;
    } else if (preset === 'full_hd') {
      wInput.value = 1920;
      hInput.value = 1080;
    }
  };

  function updateDimensionBadges() {
    const dimEl = document.getElementById('studioCurrentDimsBadge');
    if (dimEl) dimEl.textContent = `${State.width} × ${State.height} px`;
  }

  // ==========================================
  // ✍️ TEXT & WATERMARK ENGINE
  // ==========================================
  window.addStudioText = function() {
    const text = document.getElementById('studioTextInput')?.value || 'Muzammil Online Service';
    const color = document.getElementById('studioTextColorInput')?.value || '#ffffff';
    const size = parseInt(document.getElementById('studioTextSizeInput')?.value, 10) || 48;
    const font = document.getElementById('studioTextFontSelect')?.value || 'sans-serif';

    const ctx = State.ctx;
    ctx.save();
    ctx.font = `bold ${size}px ${font}`;
    ctx.fillStyle = color;
    ctx.textAlign = 'center';

    // Drop shadow for legibility
    ctx.shadowColor = 'rgba(0,0,0,0.85)';
    ctx.shadowBlur = 12;
    ctx.shadowOffsetX = 3;
    ctx.shadowOffsetY = 3;

    ctx.fillText(text, State.width / 2, State.height - 80);
    ctx.restore();

    pushHistoryState('Add Watermark: ' + text.substring(0, 15));
  };

  // ==========================================
  // 🕒 HISTORY: UNDO / REDO STACK
  // ==========================================
  function pushHistoryState(actionName) {
    // Truncate forward history if we undo and then do something new
    if (State.historyIndex < State.history.length - 1) {
      State.history = State.history.slice(0, State.historyIndex + 1);
    }

    const imgData = State.ctx.getImageData(0, 0, State.width, State.height);
    State.history.push({
      action: actionName,
      data: imgData,
      width: State.width,
      height: State.height
    });

    if (State.history.length > State.maxHistory) {
      State.history.shift();
    }
    State.historyIndex = State.history.length - 1;
    updateHistoryButtons();
  }

  window.photoStudioUndo = function() {
    if (State.historyIndex > 0) {
      State.historyIndex--;
      restoreHistoryState(State.history[State.historyIndex]);
      updateHistoryButtons();
    }
  };

  window.photoStudioRedo = function() {
    if (State.historyIndex < State.history.length - 1) {
      State.historyIndex++;
      restoreHistoryState(State.history[State.historyIndex]);
      updateHistoryButtons();
    }
  };

  function restoreHistoryState(state) {
    if (!state) return;
    State.width = state.width;
    State.height = state.height;

    State.canvas.width = state.width;
    State.canvas.height = state.height;
    State.overlayCanvas.width = state.width;
    State.overlayCanvas.height = state.height;

    State.ctx.putImageData(state.data, 0, 0);
    renderOverlay();
  }

  function updateHistoryButtons() {
    const undoBtn = document.getElementById('studioUndoBtn');
    const redoBtn = document.getElementById('studioRedoBtn');
    if (undoBtn) undoBtn.disabled = State.historyIndex <= 0;
    if (redoBtn) redoBtn.disabled = State.historyIndex >= State.history.length - 1;
  }

  // ==========================================
  // 👁️ OVERLAY RENDERER (Marching Ants, Crop Grid)
  // ==========================================
  function renderOverlay() {
    const octx = State.overlayCtx;
    octx.clearRect(0, 0, State.width, State.height);

    // 1. Render Selection Marquee (Marching Ants)
    if (State.hasSelection && State.selectionRect) {
      const r = State.selectionRect;
      octx.save();
      octx.strokeStyle = '#ffffff';
      octx.lineWidth = 1.5;
      octx.setLineDash([6, 6]);
      octx.strokeRect(r.x, r.y, r.w, r.h);

      octx.strokeStyle = '#000000';
      octx.lineDashOffset = 6;
      octx.strokeRect(r.x, r.y, r.w, r.h);
      octx.restore();
    }

    // 2. Render Crop Box & Rule of Thirds
    if (State.isCropping && State.cropBox) {
      const b = State.cropBox;
      octx.save();

      // Darkened outer mask
      octx.fillStyle = 'rgba(0, 0, 0, 0.65)';
      octx.fillRect(0, 0, State.width, b.y);
      octx.fillRect(0, b.y + b.h, State.width, State.height - (b.y + b.h));
      octx.fillRect(0, b.y, b.x, b.h);
      octx.fillRect(b.x + b.w, b.y, State.width - (b.x + b.w), b.h);

      // Crop bounding border
      octx.strokeStyle = '#38bdf8';
      octx.lineWidth = 2;
      octx.strokeRect(b.x, b.y, b.w, b.h);

      // Rule of Thirds Grid
      octx.strokeStyle = 'rgba(255, 255, 255, 0.35)';
      octx.lineWidth = 1;
      octx.beginPath();
      octx.moveTo(b.x + b.w / 3, b.y);
      octx.lineTo(b.x + b.w / 3, b.y + b.h);
      octx.moveTo(b.x + (b.w * 2) / 3, b.y);
      octx.lineTo(b.x + (b.w * 2) / 3, b.y + b.h);
      octx.moveTo(b.x, b.y + b.h / 3);
      octx.lineTo(b.x + b.w, b.y + b.h / 3);
      octx.moveTo(b.x, b.y + (b.h * 2) / 3);
      octx.lineTo(b.x + b.w, b.y + (b.h * 2) / 3);
      octx.stroke();

      // Resize handle handle
      octx.fillStyle = '#38bdf8';
      octx.fillRect(b.x + b.w - 10, b.y + b.h - 10, 10, 10);
      octx.restore();
    }
  }

  // ==========================================
  // 📤 EXPORT & APP INTEGRATION BRIDGES
  // ==========================================
  window.downloadStudioImage = function(format = 'png') {
    if (!State.imageLoaded) return;
    const mime = format === 'jpg' ? 'image/jpeg' : (format === 'webp' ? 'image/webp' : 'image/png');
    const quality = format === 'jpg' ? 0.95 : 1.0;
    const url = State.canvas.toDataURL(mime, quality);

    const a = document.createElement('a');
    a.href = url;
    a.download = `Photoshop_Studio_Pro_Export_${Date.now()}.${format}`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);

    if (typeof showToast === 'function') {
      showToast(`📥 Saved ${format.toUpperCase()} successfully!`, 'success');
    }
  };

  // Direct 1-Click Bridge: Send to Passport 4×6
  window.sendStudioPhotoToPassport = function() {
    if (!State.imageLoaded) return;
    const dataUrl = State.canvas.toDataURL('image/png');

    // Trigger existing Passport Photo tool load
    if (typeof window.show === 'function') {
      window.show('passportPhoto');
      setTimeout(() => {
        const img = new Image();
        img.onload = function() {
          if (typeof window.setPassportSourceImage === 'function') {
            window.setPassportSourceImage(img);
          } else {
            // direct hook into passport photo canvas
            const pCanvas = document.getElementById('passportAdjustCanvas');
            if (pCanvas) {
              const pctx = pCanvas.getContext('2d');
              pctx.drawImage(img, 0, 0, pCanvas.width, pCanvas.height);
            }
          }
          if (typeof showToast === 'function') {
            showToast('✅ Photo sent to Passport 4×6 Sheet Maker!', 'success');
          }
        };
        img.src = dataUrl;
      }, 150);
    }
  };

  // Direct 1-Click Bridge: Send to PVC Card
  window.sendStudioPhotoToPvc = function() {
    if (!State.imageLoaded) return;
    const dataUrl = State.canvas.toDataURL('image/png');
    if (typeof window.show === 'function') {
      window.show('pvcCard');
      setTimeout(() => {
        if (typeof showToast === 'function') {
          showToast('✅ Photo sent to PVC Card Maker!', 'success');
        }
      }, 150);
    }
  };

  // Keyboard Shortcuts (Ctrl+Z, Ctrl+Y, Spacebar Pan, V, B, E, C)
  function setupHotkeys() {
    window.addEventListener('keydown', (e) => {
      const activeEl = document.activeElement;
      if (activeEl && (activeEl.tagName === 'INPUT' || activeEl.tagName === 'TEXTAREA')) return;

      if ((e.ctrlKey || e.metaKey) && e.key === 'z') {
        e.preventDefault();
        window.photoStudioUndo();
      } else if ((e.ctrlKey || e.metaKey) && e.key === 'y') {
        e.preventDefault();
        window.photoStudioRedo();
      } else if (e.key === 'v' || e.key === 'V') {
        window.setStudioTool('select_rect');
      } else if (e.key === 'b' || e.key === 'B') {
        window.setStudioTool('brush');
      } else if (e.key === 'e' || e.key === 'E') {
        window.setStudioTool('eraser');
      } else if (e.key === 'c' || e.key === 'C') {
        window.setStudioTool('crop');
      } else if (e.key === 'i' || e.key === 'I') {
        window.setStudioTool('eyedropper');
      } else if (e.key === 'Escape') {
        window.deselectStudioSelection();
      }
    });
  }

  function capitalize(s) {
    if (!s) return '';
    return s.charAt(0).toUpperCase() + s.slice(1);
  }

  // Auto-init on page load
  window.addEventListener('DOMContentLoaded', () => {
    initStudio();
  });

})();
