import { initializeApp } from 'firebase/app';
import {
  initializeFirestore,
  setLogLevel,
  doc,
  setDoc,
  getDoc,
  deleteDoc,
  collection,
  getDocs,
  query,
  where,
  onSnapshot,
  Firestore,
  Unsubscribe
} from 'firebase/firestore';

const firebaseConfig = {
  projectId: "isentropic-guard-7smzh",
  appId: "1:921992138219:web:ab821123fe534cbc0b9dae",
  apiKey: "AIzaSyCt3NGwK1PnEYEQGmTErg-s_bEUpSNZXyo",
  authDomain: "isentropic-guard-7smzh.firebaseapp.com",
  firestoreDatabaseId: "ai-studio-muzammilonlinese-ab4b6a22-51fb-4956-9a68-432f8cad9d34",
  storageBucket: "isentropic-guard-7smzh.firebasestorage.app",
  messagingSenderId: "921992138219"
};

export const APP_CURRENT_VERSION = '101.0';
export const APP_BUILD_NUMBER = 101;

try {
  setLogLevel('silent');
} catch (e) {}

let db: Firestore | null = null;
let currentWatcherUnsub: Unsubscribe | null = null;
let globalUsersWatcherUnsub: Unsubscribe | null = null;
let deletedUsersWatcherUnsub: Unsubscribe | null = null;
const cloudDeletedUsersSet = new Set<string>();

export function initFirebase() {
  if (db) return db;
  try {
    try {
      setLogLevel('silent');
    } catch (e) {}
    const app = initializeApp({
      apiKey: firebaseConfig.apiKey,
      authDomain: firebaseConfig.authDomain,
      projectId: firebaseConfig.projectId,
      storageBucket: firebaseConfig.storageBucket,
      messagingSenderId: firebaseConfig.messagingSenderId,
      appId: firebaseConfig.appId
    });
    db = initializeFirestore(app, {
      experimentalAutoDetectLongPolling: true
    }, firebaseConfig.firestoreDatabaseId);
    console.log('⚡ Firebase Realtime Sync Initialized with database:', firebaseConfig.firestoreDatabaseId);
    return db;
  } catch (err) {
    console.warn('Firebase init error:', err);
    return null;
  }
}

export async function saveUserToCloud(user: any): Promise<boolean> {
  const firestore = initFirebase();
  if (!firestore || !user || !user.username) return false;
  const username = String(user.username).trim().toLowerCase();
  try {
    const payload = {
      username: username,
      displayName: user.displayName || user.display_name || user.username,
      phone: user.phone ? String(user.phone).trim() : '',
      shopName: user.shopName || user.shop_name || '',
      role: user.role || 'operator',
      status: user.status || 'active',
      passwordPlain: user.password || user.passwordPlain || '',
      passwordHash: user.password_hash || user.passwordHash || '',
      expiresAt: user.expires_at || user.expiresAt || null,
      deviceAllowance: user.deviceAllowance || user.device_allowance || (user.role === 'admin' ? 'multi' : 'single'),
      activeDeviceId: user.activeDeviceId || user.deviceId || null,
      activeSessionToken: user.activeSessionToken || user.sessionToken || null,
      updatedAt: new Date().toISOString()
    };
    await setDoc(doc(firestore, 'users', username), payload, { merge: true });
    // If it was in deleted_users, remove it
    cloudDeletedUsersSet.delete(username);
    deleteDoc(doc(firestore, 'deleted_users', username)).catch(() => {});
    console.log(`✅ [Firebase Cloud] User @${username} saved successfully.`);
    return true;
  } catch (e) {
    console.warn('Firebase save user error:', e);
    return false;
  }
}

export async function deleteUserFromCloud(username: string): Promise<boolean> {
  const firestore = initFirebase();
  if (!firestore || !username) return false;
  const clean = String(username).trim().toLowerCase();
  cloudDeletedUsersSet.add(clean);
  try {
    await deleteDoc(doc(firestore, 'users', clean));
    await setDoc(doc(firestore, 'deleted_users', clean), {
      username: clean,
      deletedAt: new Date().toISOString()
    });
    console.log(`🗑️ [Firebase Cloud] User @${clean} deleted and saved to deleted_users.`);
    return true;
  } catch (e) {
    console.warn('Firebase delete user error:', e);
    return false;
  }
}

export async function getUserFromCloud(queryKey: string): Promise<any | null> {
  const firestore = initFirebase();
  if (!firestore || !queryKey) return null;
  const raw = String(queryKey).trim();
  const clean = raw.toLowerCase();
  const digitsOnly = raw.replace(/\D/g, '');

  try {
    // 1. Direct document ID lookup (username)
    const snap = await getDoc(doc(firestore, 'users', clean));
    if (snap.exists()) {
      return snap.data();
    }

    // 2. Query by phone if numeric or provided
    if (raw) {
      const qPhone = query(collection(firestore, 'users'), where('phone', '==', raw));
      const phoneSnap = await getDocs(qPhone);
      if (!phoneSnap.empty) {
        return phoneSnap.docs[0].data();
      }
    }

    // 3. Query with digitsOnly if 10-digit phone
    if (digitsOnly && digitsOnly.length >= 10) {
      const tenDigits = digitsOnly.slice(-10);
      const allUsers = await getAllUsersFromCloud();
      const found = allUsers.find(u => {
        const uPhoneDigits = String(u.phone || '').replace(/\D/g, '');
        return uPhoneDigits === digitsOnly || uPhoneDigits.endsWith(tenDigits);
      });
      if (found) return found;
    }

    // 4. Query by exact username field
    const qUser = query(collection(firestore, 'users'), where('username', '==', clean));
    const userSnap = await getDocs(qUser);
    if (!userSnap.empty) {
      return userSnap.docs[0].data();
    }

    return null;
  } catch (e) {
    console.warn('Firebase get user error:', e);
    return null;
  }
}

export async function getAllUsersFromCloud(): Promise<any[]> {
  const firestore = initFirebase();
  if (!firestore) return [];
  try {
    const snap = await getDocs(collection(firestore, 'users'));
    const list: any[] = [];
    snap.forEach(d => {
      const u = d.data();
      if (u && u.username && !cloudDeletedUsersSet.has(String(u.username).toLowerCase())) {
        list.push(u);
      }
    });
    return list;
  } catch (e) {
    console.warn('Firebase get all users error:', e);
    return [];
  }
}

// Multi-phone Realtime Universal Sync:
// Keeps all operators synced to localStorage on ANY device in real time!
export function startGlobalUsersRealtimeSync(onUsersUpdate?: (users: any[]) => void): () => void {
  const firestore = initFirebase();
  if (!firestore) return () => {};

  if (globalUsersWatcherUnsub) {
    globalUsersWatcherUnsub();
    globalUsersWatcherUnsub = null;
  }
  if (deletedUsersWatcherUnsub) {
    deletedUsersWatcherUnsub();
    deletedUsersWatcherUnsub = null;
  }

  try {
    // 1. Watch deleted_users collection so any deletion across any phone is instantly applied
    deletedUsersWatcherUnsub = onSnapshot(
      collection(firestore, 'deleted_users'),
      (snap) => {
        snap.forEach(d => {
          cloudDeletedUsersSet.add(String(d.id).toLowerCase());
        });
        // Remove deleted users from localStorage immediately
        try {
          if (typeof localStorage !== 'undefined') {
            const raw = localStorage.getItem('mos_users');
            if (raw) {
              const parsed = JSON.parse(raw);
              if (Array.isArray(parsed)) {
                const cleaned = parsed.filter(u => !cloudDeletedUsersSet.has(String(u.username).toLowerCase()));
                localStorage.setItem('mos_users', JSON.stringify(cleaned));
              }
            }
            let deletedArr: string[] = [];
            try {
              const dRaw = localStorage.getItem('mos_deleted_users');
              if (dRaw) deletedArr = JSON.parse(dRaw);
            } catch (e) {}
            cloudDeletedUsersSet.forEach(u => {
              if (!deletedArr.includes(u)) deletedArr.push(u);
            });
            localStorage.setItem('mos_deleted_users', JSON.stringify(deletedArr));
          }
        } catch (e) {}
      }
    );

    // 2. Watch users collection
    console.log('📡 [Firebase Cloud] Subscribing to live operators collection across devices...');
    globalUsersWatcherUnsub = onSnapshot(
      collection(firestore, 'users'),
      (snap) => {
        const cloudUsers: any[] = [];
        snap.forEach(d => {
          const u = d.data();
          if (u && u.username && !cloudDeletedUsersSet.has(String(u.username).toLowerCase())) {
            cloudUsers.push({
              id: u.id || ('u_' + u.username),
              uid: 'usr_' + u.username,
              username: u.username,
              displayName: u.displayName || u.username,
              phone: u.phone || '',
              shopName: u.shopName || '',
              role: u.role || 'operator',
              status: u.status || 'active',
              password: u.passwordPlain || u.password || '',
              passwordPlain: u.passwordPlain || u.password || '',
              password_hash: u.passwordHash || u.password_hash || '',
              expires_at: u.expiresAt || u.expires_at || null,
              device_allowance: u.deviceAllowance || u.device_allowance || (u.role === 'admin' ? 'multi' : 'single'),
              deviceAllowance: u.deviceAllowance || u.device_allowance || (u.role === 'admin' ? 'multi' : 'single'),
              created_at: u.updatedAt || new Date().toISOString()
            });
          }
        });

        // Store active users into local storage - STRICTLY FILTER OUT ANY DELETED USERS
        try {
          if (typeof localStorage !== 'undefined') {
            let deletedLocal: string[] = [];
            try {
              const dRaw = localStorage.getItem('mos_deleted_users');
              if (dRaw) deletedLocal = JSON.parse(dRaw);
            } catch (e) {}

            const finalUsers = cloudUsers.filter(u => {
              const k = String(u.username).toLowerCase();
              return !cloudDeletedUsersSet.has(k) && !deletedLocal.includes(k);
            });

            localStorage.setItem('mos_users', JSON.stringify(finalUsers));
            console.log(`⚡ [Firebase Realtime] Live synced ${finalUsers.length} active operators to this device!`);

            // Detect newly created users across devices
            const currentKnown = new Set<string>();
            finalUsers.forEach(u => currentKnown.add(String(u.username).toLowerCase()));

            if (typeof window !== 'undefined') {
              if ((window as any)._previousKnownUsernamesSet) {
                const prev = (window as any)._previousKnownUsernamesSet as Set<string>;
                finalUsers.forEach(u => {
                  const uKey = String(u.username).toLowerCase();
                  if (!prev.has(uKey)) {
                    console.log(`🎉 [Realtime Event] Newly created user detected: @${u.username}`);
                    window.dispatchEvent(new CustomEvent('mos:user-created', { detail: { user: u } }));
                  }
                });
              }
              (window as any)._previousKnownUsernamesSet = currentKnown;
              // Broadcast users changed event so any active admin table re-renders in real-time
              window.dispatchEvent(new CustomEvent('mos:users-changed', { detail: { users: finalUsers } }));
            }
          }
        } catch (e) {
          console.warn('Sync to localStorage error:', e);
        }

        if (onUsersUpdate) {
          onUsersUpdate(cloudUsers);
        }
      },
      (err) => {
        console.warn('Realtime collection watcher error:', err);
      }
    );
  } catch (err) {
    console.warn('Failed to start global users realtime sync:', err);
  }

  return () => {
    if (globalUsersWatcherUnsub) {
      globalUsersWatcherUnsub();
      globalUsersWatcherUnsub = null;
    }
    if (deletedUsersWatcherUnsub) {
      deletedUsersWatcherUnsub();
      deletedUsersWatcherUnsub = null;
    }
  };
}

export function startUserRealtimeWatch(
  username: string,
  onKickOut: (reason: string) => void,
  onUpdate?: (data: any) => void
): () => void {
  const firestore = initFirebase();
  if (!firestore || !username) return () => {};
  const clean = String(username).trim().toLowerCase();
  if (clean === 'admin' || clean === 'imran') return () => {};

  if (currentWatcherUnsub) {
    currentWatcherUnsub();
    currentWatcherUnsub = null;
  }

  try {
    console.log(`📡 [Firebase Realtime] Listening to @${clean} changes & single-device session...`);
    currentWatcherUnsub = onSnapshot(
      doc(firestore, 'users', clean),
      (snap) => {
        if (!snap.exists()) {
          console.warn(`🚨 [Firebase Realtime] User @${clean} was DELETED by admin!`);
          onKickOut('User account has been deleted by Master Admin Imran Khan.');
          return;
        }
        const data = snap.data();
        if (data.status === 'blocked') {
          console.warn(`🚨 [Firebase Realtime] User @${clean} was BLOCKED!`);
          onKickOut('Aapka account Master Admin dwara block kar diya gaya hai.');
          return;
        }
        if (data.expiresAt) {
          const expTime = new Date(data.expiresAt).getTime();
          if (expTime < Date.now()) {
            console.warn(`🚨 [Firebase Realtime] User @${clean} validity EXPIRED!`);
            onKickOut('Aapka account plan expire ho chuka hai. Validity extend karayein.');
            return;
          }
        }

        // 🔒 STRICT SINGLE-DEVICE & DUAL PC+PHONE ENFORCEMENT VIA FIREBASE
        if (typeof localStorage !== 'undefined') {
          const localToken = localStorage.getItem('mos_session_token');
          const localDevId = localStorage.getItem('mos_device_id');
          const isPhone = typeof navigator !== 'undefined' && /mobile|android|iphone|ipad/i.test(navigator.userAgent || '');
          const myCategory = isPhone ? 'phone' : 'pc';

          // 1. If multi-session array is present in doc (supports PC + Phone dual login):
          if (Array.isArray(data.activeSessions) && data.activeSessions.length > 0) {
            const isAuthorized = data.activeSessions.some((s: any) => 
              (s.deviceId && localDevId && s.deviceId === localDevId) ||
              (s.sessionToken && localToken && s.sessionToken === localToken)
            );
            if (!isAuthorized && localToken) {
              console.warn(`🚨 [Firebase Realtime] Device ${localDevId} no longer in activeSessions for @${clean}!`);
              const kickMsg = data.deviceAllowance === 'dual_pc_phone'
                ? (myCategory === 'phone'
                    ? '⚠️ Suraksha Niyam: Yeh account kisi doosre phone me login ho chuka hai. (Aapka PC session chalu rahega).'
                    : '⚠️ Suraksha Niyam: Yeh account kisi doosre PC / computer me login ho chuka hai. (Aapka Phone session chalu rahega).')
                : '⚠️ Suraksha Niyam: Yeh account kisi doosre device me login ho chuka hai. Ek ID se ek hi device connect ho sakta hai.';
              onKickOut(data.lastKickReason || kickMsg);
              return;
            }
          } else {
            // Fallback for single session
            if (data.activeSessionToken && localToken && data.activeSessionToken !== localToken) {
              console.warn(`🚨 [Firebase Realtime] Multiple login detected for @${clean}: Active token mismatch!`);
              onKickOut('⚠️ Suraksha Niyam: Yeh account kisi doosre phone / device me login ho chuka hai. Ek ID se ek hi device connect ho sakta hai.');
              return;
            }
            if (data.activeDeviceId && localDevId && data.activeDeviceId !== localDevId) {
              console.warn(`🚨 [Firebase Realtime] Multiple device detected for @${clean}: Device ID mismatch!`);
              onKickOut('⚠️ Suraksha Niyam: Yeh account kisi doosre phone me login ho chuka hai. Ek ID se ek device allow hai.');
              return;
            }
          }
        }

        if (onUpdate) {
          onUpdate(data);
        }
      },
      (err) => {
        console.warn('Realtime watcher listener error:', err);
      }
    );
  } catch (err) {
    console.warn('Failed to start realtime watcher:', err);
  }

  return () => {
    if (currentWatcherUnsub) {
      currentWatcherUnsub();
      currentWatcherUnsub = null;
    }
  };
}

export function isUserDeletedFromCloud(username: string): boolean {
  if (!username) return false;
  return cloudDeletedUsersSet.has(String(username).trim().toLowerCase());
}

// Expose on global window object for web-bridge.js and all scripts
const MosFirebase = {
  version: APP_CURRENT_VERSION,
  build: APP_BUILD_NUMBER,
  init: initFirebase,
  saveUser: saveUserToCloud,
  deleteUser: deleteUserFromCloud,
  getUser: getUserFromCloud,
  getAllUsers: getAllUsersFromCloud,
  isUserDeleted: isUserDeletedFromCloud,
  watchUser: startUserRealtimeWatch,
  watchAllUsers: startGlobalUsersRealtimeSync
};

(window as any).MosFirebase = MosFirebase;
export default MosFirebase;
