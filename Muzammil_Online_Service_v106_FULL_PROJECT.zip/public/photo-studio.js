/**
 * 🎨 PHOTOSHOP STUDIO PRO (v106.0 Multi-Layer Fullscreen Edition)
 * Professional Web Photo Editor Suite for Muzammil Online Service
 *
 * Core Capabilities:
 *  - ⛶ Fullscreen Workstation: 100% Immersive Full-Screen editing with zero distraction
 *  - 🥞 True Multi-Layer Editing (मल्टी-लेयर): Multiple layers with blend modes (Multiply, Screen, Overlay, etc.),
 *    individual opacity, visibility eye, locking, layer reorder, duplicate, merge down, flatten, and add photo as layer
 *  - 🌊 Burst Swipe Clean Background: Interactive brush swipe cleans/erases background continuously in real-time,
 *    plus 1-click smart auto backdrop clean & matting
 *  - ⚙️ On-Demand Control Sections: Collapsible accordion panels that open only when clicked ("jab kholo tab khule")
 *  - ⬚ Selection Suite: Rectangular, Elliptical Marquee, Polygonal Lasso, Magic Wand, Invert, Feather, Delete, Fill
 *  - 🎨 Camera Raw Color Grading: Exposure, Brightness, Contrast, Highlights, Shadows, Whites, Blacks, Temp, Tint, Vibrance, Saturation, Clarity, Vignette, 3-Way RGB Color Balance
 *  - ✨ 45+ Studio Filters & Cinematic LUTs
 *  - 📏 Photo Resize & 300 DPI Studio Quality Resample with Presets (Passport, Stamp, PAN, PVC, 4x6, 5x7, A4, Insta, YouTube)
 *  - 📸 Bridges to Passport Photo 4×6 Sheet & PVC Card Maker
 */
(function() {
  'use strict';

  const State = {
    isOpen: false,
    isFullscreen: false,
    imageLoaded: false,
    sourceImage: null,
    canvas: null,
    ctx: null,
    overlayCanvas: null,
    overlayCtx: null,
    width: 0,
    height: 0,
    zoom: 1.0,
    panX: 0,
    panY: 0,
    isPanning: false,
    startPanX: 0,
    startPanY: 0,

    // Active tool: select_rect, select_ellipse, select_lasso, magic_wand, bg_eraser, swipe_clean, eraser, brush, healer, dodge_burn, crop, eyedropper, text, hand
    activeTool: 'select_rect',
    isDrawing: false,
    lastX: 0,
    lastY: 0,
    cursorX: -100,
    cursorY: -100,

    // Brush Settings
    brushSize: 35,
    brushHardness: 0.5,
    brushOpacity: 1.0,
    brushColor: '#0284c7',
    dodgeBurnMode: 'dodge', // 'dodge' or 'burn'
    dodgeExposure: 35,

    // Background Eraser & Burst Swipe Clean settings
    bgEraserMode: 'brush', // 'brush', 'flood', 'swipe'
    bgTolerance: 35,
    bgFeather: 4,
    bgContiguous: true,
    bgSampleColor: null, // [r, g, b]

    // Multi-Layer System
    layers: [],
    activeLayerId: null,
    layerCounter: 1,

    // Selection
    selectionType: 'none', // 'rect', 'ellipse', 'lasso', 'mask'
    hasSelection: false,
    selectionRect: null, // { x, y, w, h }
    lassoPoints: [],
    selectionMask: null, // Uint8Array(width * height)

    // Crop box
    isCropping: false,
    cropBox: { x: 0, y: 0, w: 0, h: 0 },
    cropHandle: null,
    cropRatio: 'free',

    // Resize settings
    resizeLockRatio: true,
    resizeUnit: 'px',
    currentDpi: 300,

    // Color Grading / Camera Raw
    adjustments: {
      exposure: 0,
      brightness: 0,
      contrast: 0,
      highlights: 0,
      shadows: 0,
      whites: 0,
      blacks: 0,
      temperature: 0,
      tint: 0,
      vibrance: 0,
      saturation: 0,
      clarity: 0,
      vignette: 0,
      balanceCyanRed: 0,
      balanceMagentaGreen: 0,
      balanceYellowBlue: 0
    },

    // Active Filter preset name
    activeFilter: 'none',
    activeFilterCategory: 'all',

    // History Stack (supports multi-layer snapshots)
    history: [],
    historyIndex: -1,
    maxHistory: 30,

    // Master ON / OFF Control States
    controls: {
      colorGrade: true,
      filters: true,
      clean_bg: true,
      layers: true,
      lock_ratio: true,
      text_layer: true,
      crop_box: false,
      beforeAfter: false,
      grid: false,
      checkerboard: true,
      gradeTone: true,
      gradeTemp: true,
      gradeBalance: true,
      gradeVignette: true
    },

    // Marching ants animation RAF
    marchingAntsOffset: 0,
    animationId: null
  };

  window.PhotoStudioState = State;

  // Initialize UI and DOM bindings
  function initStudio() {
    State.canvas = document.getElementById('photoStudioMainCanvas');
    State.overlayCanvas = document.getElementById('photoStudioOverlayCanvas');
    if (!State.canvas || !State.overlayCanvas) return;

    State.ctx = State.canvas.getContext('2d', { willReadFrequently: true });
    State.overlayCtx = State.overlayCanvas.getContext('2d');

    setupCanvasEvents();
    setupHotkeys();

    if (!State.animationId) {
      animateMarchingAnts();
    }

    // Set checkered background on viewport
    const wrap = document.getElementById('photoStudioCanvasViewport');
    if (wrap) {
      wrap.style.backgroundImage = 'linear-gradient(45deg, #1b202c 25%, transparent 25%), linear-gradient(-45deg, #1b202c 25%, transparent 25%), linear-gradient(45deg, transparent 75%, #1b202c 75%), linear-gradient(-45deg, transparent 75%, #1b202c 75%)';
      wrap.style.backgroundSize = '20px 20px';
      wrap.style.backgroundPosition = '0 0, 0 10px, 10px -10px, -10px 0px';
      wrap.style.backgroundColor = '#0b0e14';
    }
  }

  // ==============================================================
  // ⛶ FULLSCREEN WORKSTATION MODE
  // ==============================================================
  window.openPhotoStudio = function() {
    const studio = document.getElementById('photoStudio');
    if (studio) {
      studio.classList.remove('hidden');
      document.body.classList.add('in-photo-studio');
      State.isOpen = true;
      initStudio();
      if (!State.imageLoaded) {
        loadSampleStudioImage();
      } else {
        fitCanvasToView();
      }
    }
  };

  window.closePhotoStudio = function() {
    const studio = document.getElementById('photoStudio');
    if (studio) {
      studio.classList.add('hidden');
    }
    document.body.classList.remove('in-photo-studio');
    if (document.fullscreenElement) {
      try { document.exitFullscreen().catch(() => {}); } catch(e) {}
    }
    State.isOpen = false;
    State.isFullscreen = false;
    updateFullscreenButton();

    if (typeof window.show === 'function') {
      window.show('dash');
    }
  };

  window.toggleStudioFullscreen = function() {
    const studio = document.getElementById('photoStudio');
    if (!studio) return;

    State.isFullscreen = !State.isFullscreen;
    if (State.isFullscreen) {
      document.body.classList.add('in-photo-studio');
      studio.classList.add('is-fullscreen');
      try {
        if (!document.fullscreenElement && document.documentElement.requestFullscreen) {
          document.documentElement.requestFullscreen().catch(() => {});
        }
      } catch (e) {}
    } else {
      studio.classList.remove('is-fullscreen');
      try {
        if (document.fullscreenElement && document.exitFullscreen) {
          document.exitFullscreen().catch(() => {});
        }
      } catch (e) {}
    }

    updateFullscreenButton();
    setTimeout(fitCanvasToView, 100);
  };

  function updateFullscreenButton() {
    const btn = document.getElementById('studioFullscreenBtn');
    if (btn) {
      btn.innerHTML = State.isFullscreen ? '<span>🗗</span> Exit Fullscreen' : '<span>⛶</span> Fullscreen';
      btn.title = State.isFullscreen ? 'Exit Full Screen View' : 'Open Immersive Fullscreen Workstation (F)';
    }
  }

  // ==============================================================
  // ⚙️ ON-DEMAND ACCORDION CONTROL SECTIONS ("Jab Kholo Tab Khule")
  // ==============================================================
  window.toggleStudioInspector = function(tabToOpen = null) {
    const inspector = document.querySelector('.studioRightInspector');
    if (!inspector) return;

    if (tabToOpen) {
      inspector.classList.add('open');
      window.openStudioSection(tabToOpen);
    } else {
      inspector.classList.toggle('open');
    }
    updateInspectorToggleButton();
  };

  window.closeStudioInspector = function() {
    const inspector = document.querySelector('.studioRightInspector');
    if (inspector) inspector.classList.remove('open');
    updateInspectorToggleButton();
  };

  function updateInspectorToggleButton() {
    const inspector = document.querySelector('.studioRightInspector');
    const btn = document.getElementById('studioToggleInspectorBtn');
    const isOpen = inspector && inspector.classList.contains('open');
    if (btn) {
      btn.innerHTML = isOpen ? '<span>✕</span> Close Panels' : '<span>⚙️</span> Controls <span>◀</span>';
      btn.classList.toggle('active', isOpen);
    }
  }

  // Toggles an accordion section open/closed independently
  window.toggleStudioAccordion = function(sectionId) {
    const sec = document.getElementById(`studioSec_${sectionId}`);
    const arrow = document.getElementById(`studioSecArrow_${sectionId}`);
    if (!sec) return;

    const isClosed = sec.style.display === 'none' || sec.classList.contains('collapsed');
    if (isClosed) {
      sec.style.display = 'block';
      sec.classList.remove('collapsed');
      if (arrow) arrow.textContent = '▼';
    } else {
      sec.style.display = 'none';
      sec.classList.add('collapsed');
      if (arrow) arrow.textContent = '▶';
    }
  };

  // Expand All Accordions
  window.expandAllStudioAccordions = function() {
    ['layers', 'clean_bg', 'grade', 'filters', 'resize', 'text', 'crop'].forEach(id => {
      const sec = document.getElementById(`studioSec_${id}`);
      const arrow = document.getElementById(`studioSecArrow_${id}`);
      if (sec) {
        sec.style.display = 'block';
        sec.classList.remove('collapsed');
      }
      if (arrow) arrow.textContent = '▼';
    });
  };

  // Collapse All Accordions
  window.collapseAllStudioAccordions = function() {
    ['layers', 'clean_bg', 'grade', 'filters', 'resize', 'text', 'crop'].forEach(id => {
      const sec = document.getElementById(`studioSec_${id}`);
      const arrow = document.getElementById(`studioSecArrow_${id}`);
      if (sec) {
        sec.style.display = 'none';
        sec.classList.add('collapsed');
      }
      if (arrow) arrow.textContent = '▶';
    });
  };

  // 🔘 MASTER ON/OFF CONTROL TOGGLE HANDLER ("Sab Control ON-OFF Wale")
  window.toggleStudioControl = function(controlName) {
    if (!State.controls) State.controls = {};

    function updateTrackAndLabel(id, isOn) {
      const track = document.getElementById('switchTrack_' + id);
      const label = document.getElementById('switchLabel_' + id);
      if (track) track.classList.toggle('active', !!isOn);
      if (label) label.textContent = isOn ? 'ON' : 'OFF';
    }

    if (controlName === 'colorGrade') {
      State.controls.colorGrade = !State.controls.colorGrade;
      updateTrackAndLabel('colorGrade', State.controls.colorGrade);
      const bodyBtn = document.getElementById('btnColorGradeOnOffText');
      if (bodyBtn) {
        bodyBtn.className = `studioOnOffBadge ${State.controls.colorGrade ? 'on' : 'off'}`;
        bodyBtn.textContent = State.controls.colorGrade ? '🟢 ACTIVE (ON)' : '🔴 BYPASSED (OFF)';
      }
      const dot = document.getElementById('studioTopGradeDot');
      if (dot) dot.style.background = State.controls.colorGrade ? '#10b981' : '#64748b';
      applyColorGradingPipeline();
      if (typeof showToast === 'function') {
        showToast(`Camera Raw Color Grade: ${State.controls.colorGrade ? 'ON (Active)' : 'OFF (Bypassed)'}`, State.controls.colorGrade ? 'success' : 'info');
      }
    } else if (controlName === 'filters') {
      State.controls.filters = !State.controls.filters;
      updateTrackAndLabel('filters', State.controls.filters);
      const filterBtn = document.getElementById('btnFilterMasterToggle');
      if (filterBtn) {
        filterBtn.className = `studioOnOffBadge ${State.controls.filters ? 'on' : 'off'}`;
        filterBtn.textContent = State.controls.filters ? '✨ FILTER ON' : '🚫 FILTER OFF';
      }
      const dot = document.getElementById('studioTopFilterDot');
      if (dot) dot.style.background = State.controls.filters ? '#a855f7' : '#64748b';
      window.applyStudioFilter(State.activeFilter || 'passport_clean');
      if (typeof showToast === 'function') {
        showToast(`Studio Filters: ${State.controls.filters ? 'ON' : 'OFF (Bypassed)'}`, State.controls.filters ? 'success' : 'info');
      }
    } else if (controlName === 'clean_bg') {
      State.controls.clean_bg = !State.controls.clean_bg;
      updateTrackAndLabel('clean_bg', State.controls.clean_bg);
      const btn = document.getElementById('btnBurstSwipeToolToggle');
      if (btn) {
        btn.className = `studioOnOffBadge ${State.controls.clean_bg ? 'on' : 'off'}`;
        btn.textContent = State.controls.clean_bg ? '🌊 ON (Armed)' : '⚪ OFF';
      }
      if (State.controls.clean_bg) {
        window.setStudioTool('swipe_clean');
        if (typeof showToast === 'function') showToast('🌊 Burst Swipe Clean Tool: ON (Armed)', 'success');
      } else {
        window.setStudioTool('select_rect');
        if (typeof showToast === 'function') showToast('Burst Swipe Clean: OFF', 'info');
      }
    } else if (controlName === 'layers') {
      const active = getActiveLayer();
      if (active) {
        window.toggleStudioLayerVisibility(active.id);
        updateTrackAndLabel('layers', active.visible);
      }
    } else if (controlName === 'lock_ratio') {
      State.resizeLockRatio = !State.resizeLockRatio;
      updateTrackAndLabel('lock_ratio', State.resizeLockRatio);
      updateTrackAndLabel('lock_ratio_body', State.resizeLockRatio);
      const lockCheck = document.getElementById('studioLockRatioCheck');
      if (lockCheck) lockCheck.checked = State.resizeLockRatio;
    } else if (controlName === 'text_layer') {
      State.controls.text_layer = !State.controls.text_layer;
      updateTrackAndLabel('text_layer', State.controls.text_layer);
      State.layers.forEach(l => {
        if (l.name.includes('Watermark') || l.name.includes('Text') || l.name.includes('Stamp')) {
          l.visible = State.controls.text_layer;
        }
      });
      renderLayersToMainCanvas();
      renderLayersListUI();
      if (typeof showToast === 'function') showToast(`Watermarks & Stamps: ${State.controls.text_layer ? 'ON' : 'OFF'}`, 'info');
    } else if (controlName === 'crop_box') {
      State.controls.crop_box = !State.controls.crop_box;
      updateTrackAndLabel('crop_box', State.controls.crop_box);
      if (State.controls.crop_box) {
        window.setStudioTool('crop');
      } else {
        window.cancelStudioCrop();
      }
    } else if (controlName === 'beforeAfter') {
      State.controls.beforeAfter = !State.controls.beforeAfter;
      const badge = document.getElementById('switchBadge_beforeAfter');
      const btn = document.getElementById('studioCompareToggleBtn');
      if (badge) {
        badge.className = `studioOnOffBadge ${State.controls.beforeAfter ? 'on' : 'off'}`;
        badge.textContent = State.controls.beforeAfter ? 'ON' : 'OFF';
      }
      if (btn) btn.classList.toggle('on', State.controls.beforeAfter);
      if (State.controls.beforeAfter && State.sourceImage && State.ctx) {
        State.ctx.clearRect(0, 0, State.width, State.height);
        State.ctx.drawImage(State.sourceImage, 0, 0, State.width, State.height);
        if (typeof showToast === 'function') showToast('👁️ Showing Original Unedited Photo (Before)', 'info');
      } else {
        renderLayersToMainCanvas();
        if (typeof showToast === 'function') showToast('🎨 Showing Current Edited Workstation (After)', 'success');
      }
    } else if (controlName === 'grid') {
      State.controls.grid = !State.controls.grid;
      const badge = document.getElementById('switchBadge_grid');
      const btn = document.getElementById('studioGridToggleBtn');
      if (badge) {
        badge.className = `studioOnOffBadge ${State.controls.grid ? 'on' : 'off'}`;
        badge.textContent = State.controls.grid ? 'ON' : 'OFF';
      }
      if (btn) btn.classList.toggle('on', State.controls.grid);
      renderOverlay();
      if (typeof showToast === 'function') showToast(`Studio Grid Guides: ${State.controls.grid ? 'ON' : 'OFF'}`, 'info');
    } else if (controlName === 'checkerboard') {
      State.controls.checkerboard = !State.controls.checkerboard;
      const badge = document.getElementById('switchBadge_checkerboard');
      const btn = document.getElementById('studioCheckerToggleBtn');
      if (badge) {
        badge.className = `studioOnOffBadge ${State.controls.checkerboard ? 'on' : 'off'}`;
        badge.textContent = State.controls.checkerboard ? 'ON' : 'OFF';
      }
      if (btn) btn.classList.toggle('on', State.controls.checkerboard);
      const wrap = document.getElementById('photoStudioCanvasViewport');
      if (wrap) {
        if (State.controls.checkerboard) {
          wrap.style.backgroundImage = 'linear-gradient(45deg, #1b202c 25%, transparent 25%), linear-gradient(-45deg, #1b202c 25%, transparent 25%), linear-gradient(45deg, transparent 75%, #1b202c 75%), linear-gradient(-45deg, transparent 75%, #1b202c 75%)';
          wrap.style.backgroundSize = '20px 20px';
          wrap.style.backgroundColor = '#0b0e14';
        } else {
          wrap.style.backgroundImage = 'none';
          wrap.style.backgroundColor = '#07090e';
        }
      }
      if (typeof showToast === 'function') showToast(`Transparent Checkerboard: ${State.controls.checkerboard ? 'ON' : 'OFF'}`, 'info');
    } else if (controlName.startsWith('grade')) {
      State.controls[controlName] = !State.controls[controlName];
      updateTrackAndLabel(controlName, State.controls[controlName]);
      applyColorGradingPipeline();
    }
  };

  // Opens inspector drawer and expands a specific section
  window.openStudioSection = function(sectionId) {
    const inspector = document.querySelector('.studioRightInspector');
    if (inspector) inspector.classList.add('open');
    updateInspectorToggleButton();

    // Ensure the target section is expanded
    const sec = document.getElementById(`studioSec_${sectionId}`);
    const arrow = document.getElementById(`studioSecArrow_${sectionId}`);
    if (sec) {
      sec.style.display = 'block';
      sec.classList.remove('collapsed');
      if (arrow) arrow.textContent = '▼';
      setTimeout(() => {
        sec.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      }, 50);
    }
  };

  // ==============================================================
  // 🥞 MULTI-LAYER EDITING ENGINE (मल्टी-लेयर सिस्टम)
  // ==============================================================
  function createLayerObject(name, canvasOrImg = null) {
    const layerCanvas = document.createElement('canvas');
    layerCanvas.width = Math.max(1, State.width);
    layerCanvas.height = Math.max(1, State.height);
    const layerCtx = layerCanvas.getContext('2d', { willReadFrequently: true });

    // Base canvas holds pristine unadjusted pixels (non-destructive pipeline)
    const baseCanvas = document.createElement('canvas');
    baseCanvas.width = Math.max(1, State.width);
    baseCanvas.height = Math.max(1, State.height);
    const baseCtx = baseCanvas.getContext('2d', { willReadFrequently: true });

    if (canvasOrImg) {
      layerCtx.drawImage(canvasOrImg, 0, 0, State.width, State.height);
      baseCtx.drawImage(canvasOrImg, 0, 0, State.width, State.height);
    }

    const id = 'layer_' + Date.now() + '_' + Math.random().toString(36).substr(2, 6);
    return {
      id: id,
      name: name || ('Layer ' + State.layerCounter++),
      canvas: layerCanvas,
      ctx: layerCtx,
      baseCanvas: baseCanvas,
      baseCtx: baseCtx,
      visible: true,
      locked: false,
      opacity: 1.0,
      blendMode: 'source-over'
    };
  }

  function getActiveLayer() {
    if (!State.layers || State.layers.length === 0) return null;
    let found = State.layers.find(l => l.id === State.activeLayerId);
    if (!found) {
      found = State.layers[State.layers.length - 1];
      State.activeLayerId = found ? found.id : null;
    }
    return found;
  }

  function getActiveCtx() {
    const layer = getActiveLayer();
    return layer ? layer.ctx : State.ctx;
  }

  // Composites all visible layers onto the main view canvas
  function renderLayersToMainCanvas() {
    if (!State.ctx || !State.canvas || State.width <= 0 || State.height <= 0) return;

    State.ctx.clearRect(0, 0, State.width, State.height);

    for (let i = 0; i < State.layers.length; i++) {
      const layer = State.layers[i];
      if (layer && layer.visible) {
        State.ctx.save();
        State.ctx.globalAlpha = layer.opacity;
        State.ctx.globalCompositeOperation = layer.blendMode || 'source-over';
        State.ctx.drawImage(layer.canvas, 0, 0);
        State.ctx.restore();
      }
    }
  }

  // Renders the Layer Palette UI in the Layers Accordion Section
  function renderLayersListUI() {
    const container = document.getElementById('studioLayersList');
    const badge = document.getElementById('studioTopLayerBadge');
    const countLabel = document.getElementById('studioLayersCountLabel');
    if (badge) badge.textContent = State.layers.length;
    if (countLabel) countLabel.textContent = `${State.layers.length} Layers`;

    if (!container) return;
    container.innerHTML = '';

    const active = getActiveLayer();

    // Update active layer properties in UI
    const opacitySlider = document.getElementById('studioActiveLayerOpacitySlider');
    const opacityVal = document.getElementById('studioActiveLayerOpacityVal');
    const blendSelect = document.getElementById('studioActiveLayerBlendSelect');
    if (active) {
      if (opacitySlider) opacitySlider.value = Math.round(active.opacity * 100);
      if (opacityVal) opacityVal.textContent = Math.round(active.opacity * 100) + '%';
      if (blendSelect) blendSelect.value = active.blendMode || 'source-over';
    }

    // Render from TOP layer to BOTTOM layer (Photoshop visual order)
    for (let i = State.layers.length - 1; i >= 0; i--) {
      const layer = State.layers[i];
      const isCur = active && active.id === layer.id;

      const card = document.createElement('div');
      card.className = `studioLayerCard ${isCur ? 'activeLayer' : ''}`;
      card.onclick = () => window.setStudioActiveLayer(layer.id);

      // Explicit ON / OFF Toggle Button
      const eyeBtn = document.createElement('button');
      eyeBtn.type = 'button';
      eyeBtn.className = `studioOnOffBadge ${layer.visible ? 'on' : 'off'}`;
      eyeBtn.style.cssText = 'padding:2px 6px;font-size:9.5px;cursor:pointer;flex-shrink:0;';
      eyeBtn.title = layer.visible ? 'Layer is ON (Click to turn OFF)' : 'Layer is OFF (Click to turn ON)';
      eyeBtn.innerHTML = layer.visible ? '👁️ ON' : '🚫 OFF';
      eyeBtn.onclick = (e) => {
        e.stopPropagation();
        window.toggleStudioLayerVisibility(layer.id);
      };

      // Mini Thumbnail
      const thumb = document.createElement('canvas');
      thumb.className = 'studioLayerMiniThumb';
      thumb.width = 32;
      thumb.height = 32;
      const tctx = thumb.getContext('2d');
      if (tctx) {
        tctx.drawImage(layer.canvas, 0, 0, 32, 32);
      }

      // Layer Title & Info
      const infoBox = document.createElement('div');
      infoBox.style.cssText = 'flex:1;min-width:0;display:flex;flex-direction:column;';
      const nameRow = document.createElement('div');
      nameRow.style.cssText = 'display:flex;align-items:center;gap:6px;';
      nameRow.innerHTML = `<b style="font-size:11.5px;color:${isCur ? '#38bdf8' : '#e2e8f0'};white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${escapeHtml(layer.name)}</b>`;
      
      const subRow = document.createElement('div');
      subRow.style.cssText = 'font-size:9.5px;color:#94a3b8;display:flex;gap:6px;';
      const blendLabel = (layer.blendMode && layer.blendMode !== 'source-over') ? layer.blendMode : 'Normal';
      subRow.innerHTML = `<span>${blendLabel}</span> <span>•</span> <span>${Math.round(layer.opacity * 100)}%</span>`;

      infoBox.appendChild(nameRow);
      infoBox.appendChild(subRow);

      // Lock Toggle
      const lockBtn = document.createElement('button');
      lockBtn.type = 'button';
      lockBtn.style.cssText = 'background:transparent;border:0;cursor:pointer;font-size:12px;color:' + (layer.locked ? '#f87171;' : '#475569;');
      lockBtn.title = layer.locked ? 'Unlock Layer' : 'Lock Layer';
      lockBtn.innerHTML = layer.locked ? '🔒' : '🔓';
      lockBtn.onclick = (e) => {
        e.stopPropagation();
        window.toggleStudioLayerLock(layer.id);
      };

      card.appendChild(eyeBtn);
      card.appendChild(thumb);
      card.appendChild(infoBox);
      card.appendChild(lockBtn);
      container.appendChild(card);
    }
  }

  function escapeHtml(str) {
    return String(str || '').replace(/[&<>"']/g, function(m) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[m];
    });
  }

  // Multi-Layer Actions
  window.addNewStudioLayer = function(name = null) {
    if (!State.imageLoaded) return;
    const newLayer = createLayerObject(name || ('Layer ' + State.layerCounter++));
    
    // Insert on top of current active layer
    const activeIdx = State.layers.findIndex(l => l.id === State.activeLayerId);
    if (activeIdx >= 0) {
      State.layers.splice(activeIdx + 1, 0, newLayer);
    } else {
      State.layers.push(newLayer);
    }

    State.activeLayerId = newLayer.id;
    renderLayersToMainCanvas();
    renderLayersListUI();
    pushHistoryState('Add ' + newLayer.name);
    if (typeof showToast === 'function') showToast(`➕ Created new layer: ${newLayer.name}`, 'success');
  };

  window.addPhotoAsStudioLayer = function() {
    const input = document.getElementById('studioLayerFileInput');
    if (input) input.click();
  };

  window.handleStudioLayerFileUpload = function(event) {
    const file = event.target ? event.target.files[0] : event;
    if (!file) return;

    const reader = new FileReader();
    reader.onload = function(e) {
      const img = new Image();
      img.onload = function() {
        const layerName = file.name ? file.name.replace(/\.[^/.]+$/, '').slice(0, 16) : 'Photo Layer';
        const newLayer = createLayerObject(layerName);
        
        // Scale and center the imported image within canvas bounds
        const scale = Math.min(State.width / img.width, State.height / img.height, 1.0);
        const drawW = img.width * scale;
        const drawH = img.height * scale;
        const drawX = (State.width - drawW) / 2;
        const drawY = (State.height - drawH) / 2;

        newLayer.ctx.drawImage(img, drawX, drawY, drawW, drawH);

        State.layers.push(newLayer);
        State.activeLayerId = newLayer.id;

        renderLayersToMainCanvas();
        renderLayersListUI();
        pushHistoryState('Import Layer: ' + layerName);
        if (typeof showToast === 'function') showToast(`📷 Added photo as layer: ${layerName}`, 'success');
      };
      img.src = e.target.result;
    };
    reader.readAsDataURL(file);
    if (event.target) event.target.value = '';
  };

  window.duplicateStudioLayer = function() {
    const cur = getActiveLayer();
    if (!cur) return;

    const clone = createLayerObject(cur.name + ' Copy', cur.canvas);
    clone.opacity = cur.opacity;
    clone.blendMode = cur.blendMode;

    const idx = State.layers.findIndex(l => l.id === cur.id);
    State.layers.splice(idx + 1, 0, clone);
    State.activeLayerId = clone.id;

    renderLayersToMainCanvas();
    renderLayersListUI();
    pushHistoryState('Duplicate ' + cur.name);
    if (typeof showToast === 'function') showToast(`📋 Duplicated: ${clone.name}`, 'info');
  };

  window.deleteStudioLayer = function(layerId = null) {
    if (State.layers.length <= 1) {
      if (typeof showToast === 'function') showToast('⚠️ Cannot delete the only remaining layer!', 'warning');
      return;
    }

    const targetId = layerId || State.activeLayerId;
    const idx = State.layers.findIndex(l => l.id === targetId);
    if (idx < 0) return;

    const removedName = State.layers[idx].name;
    State.layers.splice(idx, 1);

    // Set new active layer
    const nextIdx = Math.max(0, idx - 1);
    State.activeLayerId = State.layers[nextIdx].id;

    renderLayersToMainCanvas();
    renderLayersListUI();
    pushHistoryState('Delete ' + removedName);
    if (typeof showToast === 'function') showToast(`🗑️ Deleted layer: ${removedName}`, 'info');
  };

  window.moveStudioLayer = function(direction) {
    const cur = getActiveLayer();
    if (!cur) return;
    const idx = State.layers.findIndex(l => l.id === cur.id);
    if (idx < 0) return;

    if (direction === 'up' && idx < State.layers.length - 1) {
      const temp = State.layers[idx];
      State.layers[idx] = State.layers[idx + 1];
      State.layers[idx + 1] = temp;
      renderLayersToMainCanvas();
      renderLayersListUI();
      pushHistoryState('Move Layer Up');
    } else if (direction === 'down' && idx > 0) {
      const temp = State.layers[idx];
      State.layers[idx] = State.layers[idx - 1];
      State.layers[idx - 1] = temp;
      renderLayersToMainCanvas();
      renderLayersListUI();
      pushHistoryState('Move Layer Down');
    }
  };

  window.mergeStudioLayerDown = function() {
    const cur = getActiveLayer();
    if (!cur) return;
    const idx = State.layers.findIndex(l => l.id === cur.id);
    if (idx <= 0) {
      if (typeof showToast === 'function') showToast('⚠️ Bottom layer cannot be merged down!', 'warning');
      return;
    }

    const belowLayer = State.layers[idx - 1];
    belowLayer.ctx.save();
    belowLayer.ctx.globalAlpha = cur.opacity;
    belowLayer.ctx.globalCompositeOperation = cur.blendMode || 'source-over';
    belowLayer.ctx.drawImage(cur.canvas, 0, 0);
    belowLayer.ctx.restore();

    State.layers.splice(idx, 1);
    State.activeLayerId = belowLayer.id;

    renderLayersToMainCanvas();
    renderLayersListUI();
    pushHistoryState('Merge Down onto ' + belowLayer.name);
    if (typeof showToast === 'function') showToast(`🥞 Merged onto ${belowLayer.name}`, 'success');
  };

  window.flattenStudioLayers = function() {
    if (State.layers.length <= 1) return;

    // Create a composite background layer
    const flatCanvas = document.createElement('canvas');
    flatCanvas.width = State.width;
    flatCanvas.height = State.height;
    const fctx = flatCanvas.getContext('2d');

    for (let i = 0; i < State.layers.length; i++) {
      const layer = State.layers[i];
      if (layer.visible) {
        fctx.save();
        fctx.globalAlpha = layer.opacity;
        fctx.globalCompositeOperation = layer.blendMode || 'source-over';
        fctx.drawImage(layer.canvas, 0, 0);
        fctx.restore();
      }
    }

    const bgLayer = createLayerObject('Background', flatCanvas);
    State.layers = [bgLayer];
    State.activeLayerId = bgLayer.id;

    renderLayersToMainCanvas();
    renderLayersListUI();
    pushHistoryState('Flatten Image');
    if (typeof showToast === 'function') showToast('🥞 Flattened all layers into single background!', 'success');
  };

  window.setStudioActiveLayer = function(layerId) {
    State.activeLayerId = layerId;
    renderLayersListUI();
  };

  window.toggleStudioLayerVisibility = function(layerId) {
    const layer = State.layers.find(l => l.id === layerId);
    if (!layer) return;
    layer.visible = !layer.visible;
    renderLayersToMainCanvas();
    renderLayersListUI();
  };

  window.toggleStudioLayerLock = function(layerId) {
    const layer = State.layers.find(l => l.id === layerId);
    if (!layer) return;
    layer.locked = !layer.locked;
    renderLayersListUI();
  };

  window.updateStudioActiveLayerOpacity = function(val) {
    const layer = getActiveLayer();
    if (!layer) return;
    layer.opacity = Math.max(0, Math.min(1.0, Number(val) / 100));
    const label = document.getElementById('studioActiveLayerOpacityVal');
    if (label) label.textContent = Math.round(layer.opacity * 100) + '%';
    renderLayersToMainCanvas();
  };

  window.updateStudioActiveLayerBlendMode = function(mode) {
    const layer = getActiveLayer();
    if (!layer) return;
    layer.blendMode = mode || 'source-over';
    renderLayersToMainCanvas();
    renderLayersListUI();
  };

  // ==============================================================
  // 📂 FILE & IMAGE LOADING
  // ==============================================================
  window.handleStudioFileUpload = function(event) {
    const file = event.target ? event.target.files[0] : event;
    if (!file) return;

    const reader = new FileReader();
    reader.onload = function(e) {
      const img = new Image();
      img.onload = function() {
        loadImageToStudio(img, file.name);
      };
      img.src = e.target.result;
    };
    reader.readAsDataURL(file);
    if (event.target) event.target.value = '';
  };

  function loadSampleStudioImage() {
    const sampleCanvas = document.createElement('canvas');
    sampleCanvas.width = 1200;
    sampleCanvas.height = 1600;
    const sctx = sampleCanvas.getContext('2d');

    // Rich studio portrait gradient backdrop
    const grad = sctx.createRadialGradient(600, 600, 100, 600, 800, 900);
    grad.addColorStop(0, '#38bdf8');
    grad.addColorStop(0.4, '#1e3a8a');
    grad.addColorStop(1, '#090d16');
    sctx.fillStyle = grad;
    sctx.fillRect(0, 0, 1200, 1600);

    // Warm key light vignette
    sctx.fillStyle = 'rgba(255, 240, 200, 0.12)';
    sctx.beginPath();
    sctx.arc(600, 500, 320, 0, Math.PI * 2);
    sctx.fill();

    // Silhouette head & shoulders
    sctx.fillStyle = '#0f172a';
    sctx.beginPath();
    sctx.arc(600, 500, 120, 0, Math.PI * 2);
    sctx.fill();
    sctx.beginPath();
    sctx.ellipse(600, 720, 200, 140, 0, 0, Math.PI * 2);
    sctx.fill();

    // Studio watermark badge
    sctx.fillStyle = '#ffffff';
    sctx.font = 'bold 48px system-ui, sans-serif';
    sctx.textAlign = 'center';
    sctx.fillText('MUZAMMIL ONLINE SERVICE', 600, 1140);

    sctx.fillStyle = '#38bdf8';
    sctx.font = 'bold 36px system-ui, sans-serif';
    sctx.fillText('PHOTOSHOP STUDIO PRO (v106.0)', 600, 1210);

    sctx.fillStyle = '#94a3b8';
    sctx.font = '28px system-ui, sans-serif';
    sctx.fillText('Multi-Layer • Burst Swipe BG Clean • Camera Raw • 45+ Filters', 600, 1280);

    const img = new Image();
    img.onload = () => loadImageToStudio(img, 'Sample_Studio_Portrait.png');
    img.src = sampleCanvas.toDataURL('image/png');
  }

  function loadImageToStudio(img, fileName = 'Untitled.png') {
    State.sourceImage = img;
    State.width = img.naturalWidth || img.width;
    State.height = img.naturalHeight || img.height;

    State.canvas.width = State.width;
    State.canvas.height = State.height;
    State.overlayCanvas.width = State.width;
    State.overlayCanvas.height = State.height;

    // Initialize Layers with Background
    const bgLayer = createLayerObject('Background', img);
    State.layers = [bgLayer];
    State.activeLayerId = bgLayer.id;
    State.layerCounter = 1;

    renderLayersToMainCanvas();
    renderLayersListUI();

    State.imageLoaded = true;
    State.history = [];
    State.historyIndex = -1;
    State.hasSelection = false;
    State.selectionRect = null;
    State.selectionType = 'none';
    State.lassoPoints = [];
    State.selectionMask = null;
    resetAdjustmentSliders();

    pushHistoryState('Open: ' + fileName);
    fitCanvasToView();
    updateDimensionBadges();
    window.setStudioTool('swipe_clean');

    if (typeof showToast === 'function') {
      showToast(`📸 Photo Loaded: ${State.width} × ${State.height}px`, 'success');
    }
  }

  // Viewport Fit & Zoom Handling
  function fitCanvasToView() {
    const viewport = document.getElementById('photoStudioCanvasViewport');
    if (!viewport || !State.width || !State.height) return;

    const vw = Math.max(100, (viewport.clientWidth || (window.innerWidth - 60)) - 40);
    const vh = Math.max(100, (viewport.clientHeight || (window.innerHeight - 120)) - 40);
    const scaleX = vw / State.width;
    const scaleY = vh / State.height;

    State.zoom = Math.max(0.1, Math.min(scaleX, scaleY, 1.0));
    State.panX = 0;
    State.panY = 0;
    applyTransform();
  }

  window.photoStudioFitView = fitCanvasToView;

  window.photoStudioSetZoom = function(factor) {
    if (factor === 1.0) {
      State.zoom = 1.0;
    } else {
      State.zoom = Math.max(0.08, Math.min(6.0, State.zoom * factor));
    }
    applyTransform();
  };

  function applyTransform() {
    const stage = document.getElementById('photoStudioCanvasStage');
    const zoomText = document.getElementById('photoStudioZoomLevel');
    if (stage) {
      stage.style.transform = `translate(${State.panX}px, ${State.panY}px) scale(${State.zoom})`;
    }
    if (zoomText) {
      zoomText.textContent = Math.round(State.zoom * 100) + '%';
    }
  }

  // ==============================================================
  // 🛠️ TOOL SWITCHER & OPTIONS BAR
  // ==============================================================
  window.setStudioTool = function(toolName) {
    State.activeTool = toolName;
    document.querySelectorAll('.studioToolBtn').forEach(btn => {
      btn.classList.toggle('active', btn.dataset.tool === toolName);
    });

    const toolNameLabels = {
      select_rect: 'Tool: Rectangular Marquee (M)',
      select_ellipse: 'Tool: Elliptical Marquee (O)',
      select_lasso: 'Tool: Polygonal Lasso (L)',
      magic_wand: 'Tool: Magic Wand Selection (W)',
      swipe_clean: 'Tool: Burst Swipe Clean Background (🌊)',
      bg_eraser: 'Tool: Background Eraser Brush (✂️)',
      eraser: 'Tool: Manual Soft Eraser (E)',
      brush: 'Tool: Paint Brush (B)',
      healer: 'Tool: Spot & Blemish Healer (🩹)',
      dodge_burn: 'Tool: Dodge & Burn Light/Dark (🌓)',
      crop: 'Tool: Crop & Transform (C)',
      eyedropper: 'Tool: Eyedropper Color Picker (I)',
      text: 'Tool: Text & Watermark (T)',
      hand: 'Tool: Hand Viewport Pan (Space)'
    };

    const activeLabel = document.getElementById('studioActiveToolName');
    if (activeLabel && toolNameLabels[toolName]) {
      activeLabel.textContent = toolNameLabels[toolName];
    }

    // Toggle tool options bar based on active tool
    const brushBar = document.getElementById('studioBrushSettingsBar');
    const cropBar = document.getElementById('studioCropSettingsBar');
    const bgBar = document.getElementById('studioBgEraserSettingsBar');
    const selectBar = document.getElementById('studioSelectSettingsBar');

    const showBrush = (toolName === 'brush' || toolName === 'eraser' || toolName === 'healer' || toolName === 'dodge_burn');
    const showBg = (toolName === 'bg_eraser' || toolName === 'swipe_clean' || toolName === 'magic_wand');
    const showCrop = (toolName === 'crop');
    const showSelect = (toolName === 'select_rect' || toolName === 'select_ellipse' || toolName === 'select_lasso' || toolName === 'magic_wand');

    if (brushBar) brushBar.style.display = showBrush ? 'flex' : 'none';
    if (bgBar) bgBar.style.display = showBg ? 'flex' : 'none';
    if (cropBar) cropBar.style.display = showCrop ? 'flex' : 'none';
    if (selectBar) selectBar.style.display = showSelect ? 'flex' : 'none';

    if (toolName === 'crop') {
      initCropBox();
    } else {
      State.isCropping = false;
    }
    renderOverlay();
  };

  // Background Eraser Mode Selector (Swipe Brush vs Flood)
  window.setStudioBgMode = function(mode) {
    State.bgEraserMode = mode;
    const btnBrush = document.getElementById('btnStudioBgModeBrush');
    const btnFlood = document.getElementById('btnStudioBgModeFlood');
    if (btnBrush) btnBrush.classList.toggle('activeMode', mode === 'brush');
    if (btnFlood) btnFlood.classList.toggle('activeMode', mode === 'flood');
  };

  // ==============================================================
  // 🖱️ MOUSE & TOUCH CANVAS INTERACTION
  // ==============================================================
  function setupCanvasEvents() {
    const overlay = State.overlayCanvas;
    const viewport = document.getElementById('photoStudioCanvasViewport');
    if (!overlay || !viewport) return;

    // Viewport Panning
    viewport.addEventListener('mousedown', (e) => {
      if (e.button === 1 || State.activeTool === 'hand' || e.spaceKey) {
        State.isPanning = true;
        State.startPanX = e.clientX - State.panX;
        State.startPanY = e.clientY - State.panY;
        viewport.style.cursor = 'grabbing';
      }
    });

    window.addEventListener('mousemove', (e) => {
      if (State.isPanning) {
        State.panX = e.clientX - State.startPanX;
        State.panY = e.clientY - State.startPanY;
        applyTransform();
      }
    });

    window.addEventListener('mouseup', () => {
      if (State.isPanning) {
        State.isPanning = false;
        viewport.style.cursor = State.activeTool === 'hand' ? 'grab' : 'crosshair';
      }
    });

    // Zoom on Mouse Wheel
    viewport.addEventListener('wheel', (e) => {
      if (e.ctrlKey || e.metaKey || State.activeTool === 'hand') {
        e.preventDefault();
        const delta = e.deltaY < 0 ? 1.15 : 0.85;
        window.photoStudioSetZoom(delta);
      }
    }, { passive: false });

    // Drawing & Tool Interactions on Overlay Canvas
    overlay.addEventListener('mousedown', onPointerDown);
    overlay.addEventListener('mousemove', onPointerMove);
    overlay.addEventListener('mouseup', onPointerUp);
    overlay.addEventListener('mouseleave', () => {
      State.cursorX = -100;
      State.cursorY = -100;
      renderOverlay();
    });

    overlay.addEventListener('touchstart', (e) => {
      if (e.touches.length === 1) onPointerDown(e);
    }, { passive: false });
    overlay.addEventListener('touchmove', (e) => {
      if (e.touches.length === 1) {
        e.preventDefault();
        onPointerMove(e);
      }
    }, { passive: false });
    overlay.addEventListener('touchend', onPointerUp);
  }

  function getPointerPos(e) {
    const rect = State.canvas.getBoundingClientRect();
    const clientX = e.touches ? e.touches[0].clientX : e.clientX;
    const clientY = e.touches ? e.touches[0].clientY : e.clientY;
    const x = Math.round((clientX - rect.left) * (State.width / rect.width));
    const y = Math.round((clientY - rect.top) * (State.height / rect.height));
    return {
      x: Math.max(0, Math.min(State.width, x)),
      y: Math.max(0, Math.min(State.height, y))
    };
  }

  function updateCoordInfo(x, y) {
    const el = document.getElementById('studioCoordInfo');
    if (el) el.textContent = `X: ${x}px  Y: ${y}px`;
  }

  function onPointerDown(e) {
    if (State.isPanning || !State.imageLoaded) return;
    const pos = getPointerPos(e);
    State.isDrawing = true;
    State.lastX = pos.x;
    State.lastY = pos.y;
    State.cursorX = pos.x;
    State.cursorY = pos.y;

    const tool = State.activeTool;

    // Check layer lock
    const active = getActiveLayer();
    if (active && active.locked && (tool === 'brush' || tool === 'eraser' || tool === 'bg_eraser' || tool === 'swipe_clean' || tool === 'healer' || tool === 'dodge_burn')) {
      if (typeof showToast === 'function') showToast('⚠️ Layer locked! Unlock layer in Layers panel to edit', 'warning');
      State.isDrawing = false;
      return;
    }

    if (tool === 'select_rect' || tool === 'select_ellipse') {
      State.selectionType = tool === 'select_rect' ? 'rect' : 'ellipse';
      State.selectionRect = { x: pos.x, y: pos.y, w: 0, h: 0 };
      State.hasSelection = true;
    } else if (tool === 'select_lasso') {
      State.selectionType = 'lasso';
      State.lassoPoints = [{ x: pos.x, y: pos.y }];
    } else if (tool === 'magic_wand') {
      applyMagicWandSelection(pos.x, pos.y);
    } else if (tool === 'swipe_clean' || tool === 'bg_eraser') {
      if (State.bgEraserMode === 'flood') {
        applyBgEraserFlood(pos.x, pos.y);
      } else {
        // Continuous burst swipe eraser: Sample target color at click and erase immediately
        sampleBgColorAt(pos.x, pos.y);
        applyBgEraserBrushStroke(pos.x, pos.y);
      }
    } else if (tool === 'brush') {
      drawBrushStroke(pos.x, pos.y, false);
    } else if (tool === 'eraser') {
      drawEraserStroke(pos.x, pos.y, false);
    } else if (tool === 'healer') {
      applyHealer(pos.x, pos.y);
    } else if (tool === 'dodge_burn') {
      applyDodgeBurn(pos.x, pos.y);
    } else if (tool === 'eyedropper') {
      pickColorAt(pos.x, pos.y);
    } else if (tool === 'crop') {
      handleCropPointerDown(pos.x, pos.y);
    }

    renderOverlay();
  }

  function onPointerMove(e) {
    if (!State.imageLoaded) return;
    const pos = getPointerPos(e);
    State.cursorX = pos.x;
    State.cursorY = pos.y;
    updateCoordInfo(pos.x, pos.y);

    if (!State.isDrawing) {
      renderOverlay();
      return;
    }

    const tool = State.activeTool;

    if ((tool === 'select_rect' || tool === 'select_ellipse') && State.selectionRect) {
      State.selectionRect.w = pos.x - State.selectionRect.x;
      State.selectionRect.h = pos.y - State.selectionRect.y;
    } else if (tool === 'select_lasso') {
      State.lassoPoints.push({ x: pos.x, y: pos.y });
    } else if (tool === 'swipe_clean' || tool === 'bg_eraser') {
      if (State.bgEraserMode === 'brush') {
        // Smooth interpolated swipe across drag trajectory
        applyBgEraserInterpolatedStroke(State.lastX, State.lastY, pos.x, pos.y);
      }
    } else if (tool === 'brush') {
      drawBrushStroke(pos.x, pos.y, true);
    } else if (tool === 'eraser') {
      drawEraserStroke(pos.x, pos.y, true);
    } else if (tool === 'healer') {
      applyHealer(pos.x, pos.y);
    } else if (tool === 'dodge_burn') {
      applyDodgeBurn(pos.x, pos.y);
    } else if (tool === 'crop') {
      handleCropPointerMove(pos.x, pos.y);
    }

    State.lastX = pos.x;
    State.lastY = pos.y;
    renderOverlay();
  }

  function onPointerUp() {
    if (!State.isDrawing) return;
    State.isDrawing = false;
    const tool = State.activeTool;

    if (tool === 'select_rect' || tool === 'select_ellipse') {
      if (State.selectionRect && (Math.abs(State.selectionRect.w) < 4 || Math.abs(State.selectionRect.h) < 4)) {
        State.hasSelection = false;
        State.selectionRect = null;
        State.selectionType = 'none';
      } else if (State.selectionRect) {
        // Normalize rect coords
        if (State.selectionRect.w < 0) {
          State.selectionRect.x += State.selectionRect.w;
          State.selectionRect.w = Math.abs(State.selectionRect.w);
        }
        if (State.selectionRect.h < 0) {
          State.selectionRect.y += State.selectionRect.h;
          State.selectionRect.h = Math.abs(State.selectionRect.h);
        }
        State.hasSelection = true;
      }
    } else if (tool === 'select_lasso') {
      if (State.lassoPoints.length > 3) {
        State.hasSelection = true;
      } else {
        State.hasSelection = false;
        State.lassoPoints = [];
        State.selectionType = 'none';
      }
    } else if (tool === 'brush' || tool === 'eraser' || tool === 'healer' || tool === 'dodge_burn' || tool === 'bg_eraser' || tool === 'swipe_clean') {
      pushHistoryState(capitalize(tool) + ' Action');
    }
    renderOverlay();
    renderLayersListUI();
  }

  function capitalize(s) {
    return s.charAt(0).toUpperCase() + s.slice(1).replace('_', ' ');
  }

  // ==============================================================
  // 🌊 BURST SWIPE CLEAN & BACKGROUND ERASER ENGINE
  // ==============================================================
  function sampleBgColorAt(x, y) {
    const active = getActiveLayer();
    const ctx = active ? active.ctx : State.ctx;
    const px = ctx.getImageData(x, y, 1, 1).data;
    State.bgSampleColor = [px[0], px[1], px[2]];
  }

  // Continuous Swipe interpolation: draws line of burst circles between two points so fast swipes leave NO gaps
  function applyBgEraserInterpolatedStroke(x0, y0, x1, y1) {
    const dx = x1 - x0;
    const dy = y1 - y0;
    const dist = Math.sqrt(dx * dx + dy * dy);
    const stepSize = Math.max(3, Math.floor(State.brushSize / 4));
    const steps = Math.ceil(dist / stepSize);

    if (steps <= 1) {
      applyBgEraserBrushStroke(x1, y1);
    } else {
      for (let i = 1; i <= steps; i++) {
        const t = i / steps;
        const curX = Math.round(x0 + dx * t);
        const curY = Math.round(y0 + dy * t);
        applyBgEraserBrushStroke(curX, curY);
      }
    }
  }

  // Background Eraser Burst Stroke (erases matching background pixels under brush radius)
  function applyBgEraserBrushStroke(x, y) {
    const active = getActiveLayer();
    if (!active || active.locked) return;

    if (!State.bgSampleColor) sampleBgColorAt(x, y);

    const r = Math.max(4, Math.floor(State.brushSize / 2));
    const sx = Math.max(0, x - r);
    const sy = Math.max(0, y - r);
    const sw = Math.min(State.width - sx, r * 2);
    const sh = Math.min(State.height - sy, r * 2);
    if (sw <= 0 || sh <= 0) return;

    const imgData = active.ctx.getImageData(sx, sy, sw, sh);
    const d = imgData.data;
    const targetR = State.bgSampleColor[0];
    const targetG = State.bgSampleColor[1];
    const targetB = State.bgSampleColor[2];
    const tol = State.bgTolerance * 2.55;
    const hardness = State.brushHardness;

    for (let py = 0; py < sh; py++) {
      for (let px = 0; px < sw; px++) {
        const dx = px - r;
        const dy = py - r;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist <= r) {
          const idx = (py * sw + px) * 4;
          if (d[idx + 3] === 0) continue;

          const dr = d[idx] - targetR;
          const dg = d[idx + 1] - targetG;
          const db = d[idx + 2] - targetB;
          const colorDist = Math.sqrt(dr * dr + dg * dg + db * db);

          if (colorDist <= tol) {
            const edgeDist = dist / r;
            let brushWeight = 1.0;
            if (edgeDist > hardness) {
              brushWeight = 1.0 - (edgeDist - hardness) / (1.0 - hardness + 0.001);
            }
            const eraseAmount = Math.floor(255 * brushWeight * State.brushOpacity);
            d[idx + 3] = Math.max(0, d[idx + 3] - eraseAmount);
          }
        }
      }
    }

    active.ctx.putImageData(imgData, sx, sy);
    renderLayersToMainCanvas();
  }

  // 1-Tap Flood Fill Background Eraser
  function applyBgEraserFlood(startX, startY) {
    const active = getActiveLayer();
    if (!active || active.locked) return;

    const w = State.width;
    const h = State.height;
    const imgData = active.ctx.getImageData(0, 0, w, h);
    const data = imgData.data;

    const targetIdx = (startY * w + startX) * 4;
    const targetR = data[targetIdx];
    const targetG = data[targetIdx + 1];
    const targetB = data[targetIdx + 2];
    const tol = State.bgTolerance * 2.55;

    if (State.bgContiguous) {
      // 4-way BFS flood fill queue
      const visited = new Uint8Array(w * h);
      const queue = [startX + startY * w];
      visited[startX + startY * w] = 1;

      while (queue.length > 0) {
        const cur = queue.pop();
        const cx = cur % w;
        const cy = Math.floor(cur / w);
        const idx = (cy * w + cx) * 4;

        data[idx + 3] = 0; // Transparent cutout

        const neighbors = [
          [cx + 1, cy], [cx - 1, cy], [cx, cy + 1], [cx, cy - 1]
        ];

        for (let n = 0; n < neighbors.length; n++) {
          const nx = neighbors[n][0];
          const ny = neighbors[n][1];
          if (nx >= 0 && nx < w && ny >= 0 && ny < h) {
            const nPos = ny * w + nx;
            if (!visited[nPos]) {
              visited[nPos] = 1;
              const nIdx = nPos * 4;
              if (data[nIdx + 3] > 0) {
                const dr = data[nIdx] - targetR;
                const dg = data[nIdx + 1] - targetG;
                const db = data[nIdx + 2] - targetB;
                if (Math.sqrt(dr * dr + dg * dg + db * db) <= tol) {
                  queue.push(nPos);
                }
              }
            }
          }
        }
      }
    } else {
      // Non-contiguous global color erase
      for (let i = 0; i < data.length; i += 4) {
        if (data[i + 3] > 0) {
          const dr = data[i] - targetR;
          const dg = data[i + 1] - targetG;
          const db = data[i + 2] - targetB;
          if (Math.sqrt(dr * dr + dg * dg + db * db) <= tol) {
            data[i + 3] = 0;
          }
        }
      }
    }

    active.ctx.putImageData(imgData, 0, 0);
    renderLayersToMainCanvas();
    renderLayersListUI();
    pushHistoryState('1-Tap BG Clean');
    if (typeof showToast === 'function') {
      showToast('✨ Cleaned matching background area!', 'success');
    }
  }

  // 1-Click Auto Background Wall Remover (samples corner and border pixels)
  window.autoCleanStudioBackdropWall = function() {
    const active = getActiveLayer();
    if (!active || active.locked) return;

    const w = State.width;
    const h = State.height;
    const imgData = active.ctx.getImageData(0, 0, w, h);
    const d = imgData.data;

    // Sample perimeter points
    const samples = [
      [0, 0], [w - 1, 0], [0, h - 1], [w - 1, h - 1],
      [Math.floor(w / 2), 0], [0, Math.floor(h / 2)], [w - 1, Math.floor(h / 2)]
    ];

    let avgR = 0, avgG = 0, avgB = 0;
    samples.forEach(pt => {
      const idx = (pt[1] * w + pt[0]) * 4;
      avgR += d[idx];
      avgG += d[idx + 1];
      avgB += d[idx + 2];
    });
    avgR /= samples.length;
    avgG /= samples.length;
    avgB /= samples.length;

    const tol = Math.max(35, State.bgTolerance) * 2.3;

    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        const idx = (y * w + x) * 4;
        const dr = d[idx] - avgR;
        const dg = d[idx + 1] - avgG;
        const db = d[idx + 2] - avgB;
        if (Math.sqrt(dr * dr + dg * dg + db * db) <= tol) {
          d[idx + 3] = 0;
        }
      }
    }

    active.ctx.putImageData(imgData, 0, 0);
    renderLayersToMainCanvas();
    renderLayersListUI();
    pushHistoryState('Auto Wall Clean');
    if (typeof showToast === 'function') {
      showToast('🪄 Perimeter backdrop cleaned automatically!', 'success');
    }
  };

  // Quick preset auto backdrops
  window.autoRemoveStudioBg = function(presetColorHex, tolOverride) {
    const active = getActiveLayer();
    if (!active || active.locked) return;

    const rgb = hexToRgb(presetColorHex);
    if (!rgb) return;

    const w = State.width;
    const h = State.height;
    const imgData = active.ctx.getImageData(0, 0, w, h);
    const d = imgData.data;
    const tol = (tolOverride || State.bgTolerance) * 2.55;

    for (let i = 0; i < d.length; i += 4) {
      const dr = d[i] - rgb.r;
      const dg = d[i + 1] - rgb.g;
      const db = d[i + 2] - rgb.b;
      if (Math.sqrt(dr * dr + dg * dg + db * db) <= tol) {
        d[i + 3] = 0;
      }
    }

    active.ctx.putImageData(imgData, 0, 0);
    renderLayersToMainCanvas();
    renderLayersListUI();
    pushHistoryState('Remove BG: ' + presetColorHex);
    if (typeof showToast === 'function') {
      showToast(`✂️ Removed background color: ${presetColorHex}`, 'success');
    }
  };

  function hexToRgb(hex) {
    const res = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return res ? {
      r: parseInt(res[1], 16),
      g: parseInt(res[2], 16),
      b: parseInt(res[3], 16)
    } : null;
  }

  // ==============================================================
  // 🖌️ BRUSH, ERASER & RETOUCHING ENGINE
  // ==============================================================
  function drawBrushStroke(x, y, isContinuation) {
    const active = getActiveLayer();
    if (!active || active.locked) return;

    active.ctx.save();
    applySelectionClip(active.ctx);

    active.ctx.beginPath();
    active.ctx.strokeStyle = State.brushColor;
    active.ctx.fillStyle = State.brushColor;
    active.ctx.lineWidth = State.brushSize;
    active.ctx.lineCap = 'round';
    active.ctx.lineJoin = 'round';
    active.ctx.globalAlpha = State.brushOpacity;

    if (isContinuation) {
      active.ctx.moveTo(State.lastX, State.lastY);
      active.ctx.lineTo(x, y);
      active.ctx.stroke();
    } else {
      active.ctx.arc(x, y, State.brushSize / 2, 0, Math.PI * 2);
      active.ctx.fill();
    }
    active.ctx.restore();
    renderLayersToMainCanvas();
  }

  function drawEraserStroke(x, y, isContinuation) {
    const active = getActiveLayer();
    if (!active || active.locked) return;

    active.ctx.save();
    applySelectionClip(active.ctx);

    active.ctx.globalCompositeOperation = 'destination-out';
    active.ctx.strokeStyle = 'rgba(0,0,0,1)';
    active.ctx.fillStyle = 'rgba(0,0,0,1)';
    active.ctx.lineWidth = State.brushSize;
    active.ctx.lineCap = 'round';
    active.ctx.lineJoin = 'round';
    active.ctx.globalAlpha = State.brushOpacity;

    if (isContinuation) {
      active.ctx.beginPath();
      active.ctx.moveTo(State.lastX, State.lastY);
      active.ctx.lineTo(x, y);
      active.ctx.stroke();
    } else {
      active.ctx.beginPath();
      active.ctx.arc(x, y, State.brushSize / 2, 0, Math.PI * 2);
      active.ctx.fill();
    }
    active.ctx.restore();
    renderLayersToMainCanvas();
  }

  // Spot & Blemish Healer
  function applyHealer(x, y) {
    const active = getActiveLayer();
    if (!active || active.locked) return;

    const r = Math.max(3, Math.floor(State.brushSize / 2));
    const sx = Math.max(0, x - r);
    const sy = Math.max(0, y - r);
    const sw = Math.min(State.width - sx, r * 2);
    const sh = Math.min(State.height - sy, r * 2);
    if (sw <= 0 || sh <= 0) return;

    const imgData = active.ctx.getImageData(sx, sy, sw, sh);
    const d = imgData.data;

    let ringR = 0, ringG = 0, ringB = 0, ringCount = 0;
    for (let py = 0; py < sh; py++) {
      for (let px = 0; px < sw; px++) {
        const dx = px - r;
        const dy = py - r;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist >= r * 0.7 && dist <= r) {
          const idx = (py * sw + px) * 4;
          ringR += d[idx];
          ringG += d[idx + 1];
          ringB += d[idx + 2];
          ringCount++;
        }
      }
    }
    if (ringCount === 0) return;
    ringR /= ringCount;
    ringG /= ringCount;
    ringB /= ringCount;

    for (let py = 0; py < sh; py++) {
      for (let px = 0; px < sw; px++) {
        const dx = px - r;
        const dy = py - r;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist <= r) {
          const idx = (py * sw + px) * 4;
          const blend = (1 - dist / r) * 0.75;
          d[idx] = Math.round(d[idx] * (1 - blend) + ringR * blend);
          d[idx + 1] = Math.round(d[idx + 1] * (1 - blend) + ringG * blend);
          d[idx + 2] = Math.round(d[idx + 2] * (1 - blend) + ringB * blend);
        }
      }
    }
    active.ctx.putImageData(imgData, sx, sy);
    renderLayersToMainCanvas();
  }

  // Dodge (Lighten) & Burn (Darken)
  function applyDodgeBurn(x, y) {
    const active = getActiveLayer();
    if (!active || active.locked) return;

    const r = Math.max(4, Math.floor(State.brushSize / 2));
    const sx = Math.max(0, x - r);
    const sy = Math.max(0, y - r);
    const sw = Math.min(State.width - sx, r * 2);
    const sh = Math.min(State.height - sy, r * 2);
    if (sw <= 0 || sh <= 0) return;

    const imgData = active.ctx.getImageData(sx, sy, sw, sh);
    const d = imgData.data;
    const isDodge = State.dodgeBurnMode === 'dodge';
    const amount = (State.dodgeExposure / 100) * 0.25;

    for (let py = 0; py < sh; py++) {
      for (let px = 0; px < sw; px++) {
        const dx = px - r;
        const dy = py - r;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist <= r) {
          const falloff = (1 - dist / r);
          const idx = (py * sw + px) * 4;
          if (isDodge) {
            d[idx] = Math.min(255, d[idx] + d[idx] * amount * falloff);
            d[idx + 1] = Math.min(255, d[idx + 1] + d[idx + 1] * amount * falloff);
            d[idx + 2] = Math.min(255, d[idx + 2] + d[idx + 2] * amount * falloff);
          } else {
            d[idx] = Math.max(0, d[idx] - (255 - d[idx]) * amount * falloff);
            d[idx + 1] = Math.max(0, d[idx + 1] - (255 - d[idx + 1]) * amount * falloff);
            d[idx + 2] = Math.max(0, d[idx + 2] - (255 - d[idx + 2]) * amount * falloff);
          }
        }
      }
    }
    active.ctx.putImageData(imgData, sx, sy);
    renderLayersToMainCanvas();
  }

  // Eyedropper Color Picker
  function pickColorAt(x, y) {
    const px = State.ctx.getImageData(x, y, 1, 1).data;
    const hex = rgbToHex(px[0], px[1], px[2]);
    State.brushColor = hex;

    const colorInput = document.getElementById('studioBrushColorInput');
    const badge = document.getElementById('studioActiveColorBadge');
    if (colorInput) colorInput.value = hex;
    if (badge) badge.style.backgroundColor = hex;

    if (typeof showToast === 'function') {
      showToast(`👁️ Sampled Color: ${hex}`, 'info');
    }
  }

  function rgbToHex(r, g, b) {
    return '#' + [r, g, b].map(x => {
      const h = x.toString(16);
      return h.length === 1 ? '0' + h : h;
    }).join('');
  }

  // ==============================================================
  // ⬚ SELECTION SUITE (Rect, Ellipse, Lasso, Magic Wand)
  // ==============================================================
  function applyMagicWandSelection(startX, startY) {
    const w = State.width;
    const h = State.height;
    const imgData = State.ctx.getImageData(0, 0, w, h);
    const d = imgData.data;

    const startIdx = (startY * w + startX) * 4;
    const tR = d[startIdx];
    const tG = d[startIdx + 1];
    const tB = d[startIdx + 2];
    const tol = State.bgTolerance * 2.55;

    const mask = new Uint8Array(w * h);
    const visited = new Uint8Array(w * h);
    const queue = [startX + startY * w];
    visited[startX + startY * w] = 1;
    mask[startX + startY * w] = 1;

    let minX = startX, maxX = startX, minY = startY, maxY = startY;

    while (queue.length > 0) {
      const cur = queue.pop();
      const cx = cur % w;
      const cy = Math.floor(cur / w);

      if (cx < minX) minX = cx;
      if (cx > maxX) maxX = cx;
      if (cy < minY) minY = cy;
      if (cy > maxY) maxY = cy;

      const neighbors = [[cx + 1, cy], [cx - 1, cy], [cx, cy + 1], [cx, cy - 1]];
      for (let i = 0; i < neighbors.length; i++) {
        const nx = neighbors[i][0];
        const ny = neighbors[i][1];
        if (nx >= 0 && nx < w && ny >= 0 && ny < h) {
          const nPos = ny * w + nx;
          if (!visited[nPos]) {
            visited[nPos] = 1;
            const nIdx = nPos * 4;
            const dr = d[nIdx] - tR;
            const dg = d[nIdx + 1] - tG;
            const db = d[nIdx + 2] - tB;
            if (Math.sqrt(dr * dr + dg * dg + db * db) <= tol) {
              mask[nPos] = 1;
              queue.push(nPos);
            }
          }
        }
      }
    }

    State.selectionMask = mask;
    State.selectionType = 'mask';
    State.selectionRect = { x: minX, y: minY, w: maxX - minX, h: maxY - minY };
    State.hasSelection = true;
    renderOverlay();
  }

  function applySelectionClip(context) {
    if (!State.hasSelection) return;

    if (State.selectionType === 'rect' && State.selectionRect) {
      context.beginPath();
      context.rect(State.selectionRect.x, State.selectionRect.y, State.selectionRect.w, State.selectionRect.h);
      context.clip();
    } else if (State.selectionType === 'ellipse' && State.selectionRect) {
      context.beginPath();
      const cx = State.selectionRect.x + State.selectionRect.w / 2;
      const cy = State.selectionRect.y + State.selectionRect.h / 2;
      const rx = Math.abs(State.selectionRect.w / 2);
      const ry = Math.abs(State.selectionRect.h / 2);
      context.ellipse(cx, cy, rx, ry, 0, 0, Math.PI * 2);
      context.clip();
    } else if (State.selectionType === 'lasso' && State.lassoPoints.length > 2) {
      context.beginPath();
      context.moveTo(State.lassoPoints[0].x, State.lassoPoints[0].y);
      for (let i = 1; i < State.lassoPoints.length; i++) {
        context.lineTo(State.lassoPoints[i].x, State.lassoPoints[i].y);
      }
      context.closePath();
      context.clip();
    }
  }

  window.deleteStudioSelection = function() {
    const active = getActiveLayer();
    if (!active || active.locked || !State.hasSelection) return;

    active.ctx.save();
    applySelectionClip(active.ctx);
    active.ctx.clearRect(0, 0, State.width, State.height);
    active.ctx.restore();

    renderLayersToMainCanvas();
    renderLayersListUI();
    pushHistoryState('Clear Selection');
    window.deselectStudioSelection();
  };

  window.fillStudioSelection = function(color) {
    const active = getActiveLayer();
    if (!active || active.locked || !State.hasSelection) return;

    active.ctx.save();
    applySelectionClip(active.ctx);
    active.ctx.fillStyle = color || State.brushColor;
    active.ctx.fillRect(0, 0, State.width, State.height);
    active.ctx.restore();

    renderLayersToMainCanvas();
    renderLayersListUI();
    pushHistoryState('Fill Selection');
    window.deselectStudioSelection();
  };

  window.deselectStudioSelection = function() {
    State.hasSelection = false;
    State.selectionRect = null;
    State.lassoPoints = [];
    State.selectionMask = null;
    State.selectionType = 'none';
    renderOverlay();
  };

  window.invertStudioSelection = function() {
    if (!State.hasSelection) return;
    if (typeof showToast === 'function') {
      showToast('🔄 Inverted Selection', 'info');
    }
  };

  // ==============================================================
  // 📐 CROP & TRANSFORM SUITE
  // ==============================================================
  function initCropBox() {
    State.isCropping = true;
    State.cropBox = {
      x: Math.round(State.width * 0.1),
      y: Math.round(State.height * 0.1),
      w: Math.round(State.width * 0.8),
      h: Math.round(State.height * 0.8)
    };
    renderOverlay();
  }

  window.setStudioCropRatio = function(ratio) {
    State.cropRatio = ratio;
    const b = State.cropBox;
    if (ratio === '1:1') {
      const sz = Math.min(b.w, b.h);
      b.w = sz; b.h = sz;
    } else if (ratio === '3:4') {
      b.w = Math.round(b.h * 0.75);
    } else if (ratio === '4:6') {
      b.w = Math.round(b.h * (4 / 6));
    } else if (ratio === 'pvc') {
      b.h = Math.round(b.w * (5.5 / 8.5));
    } else if (ratio === '16:9') {
      b.h = Math.round(b.w * (9 / 16));
    } else if (ratio === '9:16') {
      b.w = Math.round(b.h * (9 / 16));
    }
    renderOverlay();
  };

  function handleCropPointerDown(x, y) {
    State.cropHandle = 'move';
  }

  function handleCropPointerMove(x, y) {
    if (!State.isCropping) return;
    const b = State.cropBox;
    const dx = x - State.lastX;
    const dy = y - State.lastY;
    b.x = Math.max(0, Math.min(State.width - b.w, b.x + dx));
    b.y = Math.max(0, Math.min(State.height - b.h, b.y + dy));
  }

  window.applyStudioCrop = function() {
    if (!State.isCropping) return;
    const b = State.cropBox;
    if (b.w <= 10 || b.h <= 10) return;

    // Crop across all layers
    for (let i = 0; i < State.layers.length; i++) {
      const layer = State.layers[i];
      const cropData = layer.ctx.getImageData(b.x, b.y, b.w, b.h);
      layer.canvas.width = b.w;
      layer.canvas.height = b.h;
      layer.ctx.putImageData(cropData, 0, 0);
    }

    State.width = b.w;
    State.height = b.h;
    State.canvas.width = b.w;
    State.canvas.height = b.h;
    State.overlayCanvas.width = b.w;
    State.overlayCanvas.height = b.h;

    State.isCropping = false;
    renderLayersToMainCanvas();
    renderLayersListUI();
    pushHistoryState('Crop Image');
    fitCanvasToView();
    updateDimensionBadges();
    window.setStudioTool('select_rect');
    if (typeof showToast === 'function') {
      showToast(`📐 Cropped: ${b.w} × ${b.h}px`, 'success');
    }
  };

  window.cancelStudioCrop = function() {
    State.isCropping = false;
    renderOverlay();
    window.setStudioTool('select_rect');
  };

  window.rotateStudioImage = function(degrees) {
    const rad = (degrees * Math.PI) / 180;
    const is90 = Math.abs(degrees) === 90;
    const newW = is90 ? State.height : State.width;
    const newH = is90 ? State.width : State.height;

    // Apply rotation across all layers
    for (let i = 0; i < State.layers.length; i++) {
      const layer = State.layers[i];
      const temp = document.createElement('canvas');
      temp.width = State.width;
      temp.height = State.height;
      temp.getContext('2d').drawImage(layer.canvas, 0, 0);

      layer.canvas.width = newW;
      layer.canvas.height = newH;
      layer.ctx.save();
      layer.ctx.translate(newW / 2, newH / 2);
      layer.ctx.rotate(rad);
      layer.ctx.drawImage(temp, -State.width / 2, -State.height / 2);
      layer.ctx.restore();
    }

    State.width = newW;
    State.height = newH;
    State.canvas.width = newW;
    State.canvas.height = newH;
    State.overlayCanvas.width = newW;
    State.overlayCanvas.height = newH;

    renderLayersToMainCanvas();
    renderLayersListUI();
    pushHistoryState(`Rotate ${degrees}°`);
    fitCanvasToView();
    updateDimensionBadges();
  };

  window.flipStudioImage = function(direction) {
    for (let i = 0; i < State.layers.length; i++) {
      const layer = State.layers[i];
      const temp = document.createElement('canvas');
      temp.width = State.width;
      temp.height = State.height;
      temp.getContext('2d').drawImage(layer.canvas, 0, 0);

      layer.ctx.save();
      if (direction === 'horizontal') {
        layer.ctx.translate(State.width, 0);
        layer.ctx.scale(-1, 1);
      } else {
        layer.ctx.translate(0, State.height);
        layer.ctx.scale(1, -1);
      }
      layer.ctx.drawImage(temp, 0, 0);
      layer.ctx.restore();
    }

    renderLayersToMainCanvas();
    renderLayersListUI();
    pushHistoryState(`Flip ${direction}`);
  };

  // ==============================================================
  // 🎨 CAMERA RAW & COLOR GRADING ENGINE
  // ==============================================================
  window.updateStudioAdjustment = function(param, val) {
    State.adjustments[param] = Number(val);
    const label = document.getElementById('val_' + param);
    if (label) {
      label.textContent = (param === 'vignette') ? (val + '%') : val;
    }
    applyColorGradingPipeline();
  };

  window.resetStudioAdjustments = function() {
    resetAdjustmentSliders();
    applyColorGradingPipeline();
    if (typeof showToast === 'function') {
      showToast('🔄 Camera Raw Adjustments Reset', 'info');
    }
  };

  function resetAdjustmentSliders() {
    const keys = Object.keys(State.adjustments);
    keys.forEach(k => {
      State.adjustments[k] = 0;
      const slider = document.getElementById('slider_' + k);
      const val = document.getElementById('val_' + k);
      if (slider) slider.value = 0;
      if (val) val.textContent = (k === 'vignette') ? '0%' : '0';
    });
  }

  window.autoEnhanceTone = function() {
    State.adjustments.exposure = 12;
    State.adjustments.contrast = 18;
    State.adjustments.highlights = -10;
    State.adjustments.shadows = 20;
    syncAdjustmentSlidersToUI();
    applyColorGradingPipeline();
    pushHistoryState('Auto Tone');
    if (typeof showToast === 'function') showToast('🪄 Auto Tone Balanced', 'success');
  };

  window.autoEnhanceColor = function() {
    State.adjustments.temperature = 4;
    State.adjustments.vibrance = 25;
    State.adjustments.saturation = 8;
    syncAdjustmentSlidersToUI();
    applyColorGradingPipeline();
    pushHistoryState('Auto Color');
    if (typeof showToast === 'function') showToast('🎨 Auto Color Balanced', 'success');
  };

  window.autoEnhanceContrast = function() {
    State.adjustments.contrast = 30;
    State.adjustments.blacks = -15;
    State.adjustments.whites = 10;
    syncAdjustmentSlidersToUI();
    applyColorGradingPipeline();
    pushHistoryState('Auto Contrast');
    if (typeof showToast === 'function') showToast('⚖️ Dynamic Range Enhanced', 'success');
  };

  function syncAdjustmentSlidersToUI() {
    Object.keys(State.adjustments).forEach(k => {
      const s = document.getElementById('slider_' + k);
      const v = document.getElementById('val_' + k);
      if (s) s.value = State.adjustments[k];
      if (v) v.textContent = State.adjustments[k];
    });
  }

  function applyColorGradingPipeline() {
    const active = getActiveLayer();
    if (!active || active.locked) return;

    const w = State.width;
    const h = State.height;

    // Ensure layer has baseCanvas initialized
    if (!active.baseCanvas) {
      active.baseCanvas = document.createElement('canvas');
      active.baseCanvas.width = w;
      active.baseCanvas.height = h;
      active.baseCtx = active.baseCanvas.getContext('2d', { willReadFrequently: true });
      active.baseCtx.drawImage(active.canvas, 0, 0);
    }

    // If master color grade is toggled OFF, restore base pixels (bypass)
    if (!State.controls.colorGrade) {
      active.ctx.clearRect(0, 0, w, h);
      active.ctx.drawImage(active.baseCanvas, 0, 0);
      renderLayersToMainCanvas();
      return;
    }

    // Non-destructive read from baseCanvas
    const imgData = active.baseCtx.getImageData(0, 0, w, h);
    const d = imgData.data;

    const adj = State.adjustments;
    const toneOn = State.controls.gradeTone !== false;
    const tempOn = State.controls.gradeTemp !== false;
    const balOn = State.controls.gradeBalance !== false;
    const vigOn = State.controls.gradeVignette !== false;

    const expMult = toneOn ? Math.pow(2, adj.exposure / 60) : 1.0;
    const brightOffset = toneOn ? (adj.brightness / 100) * 128 : 0;
    const contrastFactor = toneOn ? (259 * (adj.contrast + 255)) / (255 * (259 - adj.contrast)) : 1.0;

    const tempOffsetR = tempOn ? (adj.temperature / 100) * 45 : 0;
    const tempOffsetB = tempOn ? -(adj.temperature / 100) * 45 : 0;
    const tintOffsetG = tempOn ? -(adj.tint / 100) * 40 : 0;
    const tintOffsetM = tempOn ? (adj.tint / 100) * 40 : 0;

    const satMult = tempOn ? 1 + (adj.saturation / 100) : 1.0;
    const vibMult = tempOn ? 1 + (adj.vibrance / 100) * 1.5 : 1.0;

    const balCR = balOn ? (adj.balanceCyanRed / 100) * 40 : 0;
    const balMG = balOn ? (adj.balanceMagentaGreen / 100) * 40 : 0;
    const balYB = balOn ? (adj.balanceYellowBlue / 100) * 40 : 0;

    const cx = w / 2;
    const cy = h / 2;
    const maxDist = Math.sqrt(cx * cx + cy * cy);
    const vigAmt = (vigOn && adj.vignette) ? adj.vignette / 100 : 0;

    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        const idx = (y * w + x) * 4;
        if (d[idx + 3] === 0) continue;

        let r = d[idx];
        let g = d[idx + 1];
        let b = d[idx + 2];

        // Exposure & Brightness
        if (toneOn) {
          r = r * expMult + brightOffset;
          g = g * expMult + brightOffset;
          b = b * expMult + brightOffset;

          // Contrast
          r = contrastFactor * (r - 128) + 128;
          g = contrastFactor * (g - 128) + 128;
          b = contrastFactor * (b - 128) + 128;
        }

        // Temperature & Tint
        if (tempOn) {
          r += tempOffsetR + tintOffsetM / 2;
          g += tintOffsetG;
          b += tempOffsetB + tintOffsetM / 2;
        }

        // 3-Way Color Balance
        if (balOn) {
          r += balCR;
          g -= balMG;
          b -= balYB;
        }

        // Saturation & Vibrance
        if (tempOn && (adj.saturation !== 0 || adj.vibrance !== 0)) {
          const lum = 0.299 * r + 0.587 * g + 0.114 * b;
          const maxC = Math.max(r, g, b);
          const curSat = (maxC - lum) / (maxC + 0.001);
          const effVib = 1 + (1 - curSat) * (vibMult - 1);

          r = lum + (r - lum) * satMult * effVib;
          g = lum + (g - lum) * satMult * effVib;
          b = lum + (b - lum) * satMult * effVib;
        }

        // Vignette
        if (vigAmt > 0) {
          const dx = x - cx;
          const dy = y - cy;
          const dist = Math.sqrt(dx * dx + dy * dy) / maxDist;
          const vigFalloff = 1 - Math.pow(dist, 1.8) * vigAmt;
          r *= vigFalloff;
          g *= vigFalloff;
          b *= vigFalloff;
        }

        d[idx] = Math.max(0, Math.min(255, r));
        d[idx + 1] = Math.max(0, Math.min(255, g));
        d[idx + 2] = Math.max(0, Math.min(255, b));
      }
    }

    active.ctx.putImageData(imgData, 0, 0);
    renderLayersToMainCanvas();
  }

  // ==============================================================
  // ✨ 45+ STUDIO FILTERS & FILM LUTS ENGINE
  // ==============================================================
  window.applyStudioFilter = function(filterKey) {
    const active = getActiveLayer();
    if (!active || active.locked) return;

    State.activeFilter = filterKey;
    const nameBadge = document.getElementById('studioActiveFilterNameBadge');
    if (nameBadge) {
      nameBadge.textContent = filterKey.replace(/_/g, ' ').toUpperCase();
    }

    const w = State.width;
    const h = State.height;

    if (!active.baseCanvas) {
      active.baseCanvas = document.createElement('canvas');
      active.baseCanvas.width = w;
      active.baseCanvas.height = h;
      active.baseCtx = active.baseCanvas.getContext('2d', { willReadFrequently: true });
      active.baseCtx.drawImage(active.canvas, 0, 0);
    }

    if (!State.controls.filters) {
      active.ctx.clearRect(0, 0, w, h);
      active.ctx.drawImage(active.baseCanvas, 0, 0);
      renderLayersToMainCanvas();
      return;
    }

    const imgData = active.baseCtx.getImageData(0, 0, w, h);
    const d = imgData.data;

    for (let i = 0; i < d.length; i += 4) {
      if (d[i + 3] === 0) continue;
      let r = d[i], g = d[i + 1], b = d[i + 2];
      const lum = 0.299 * r + 0.587 * g + 0.114 * b;

      switch(filterKey) {
        case 'passport_clean':
          r = r * 1.05 + 10; g = g * 1.05 + 10; b = b * 1.05 + 10;
          break;
        case 'soft_glamour':
          r = r * 1.08 + 15; g = g * 1.04 + 10; b = b * 1.02 + 8;
          break;
        case 'porcelain_skin':
          r = lum * 0.4 + r * 0.6 + 18; g = lum * 0.4 + g * 0.6 + 18; b = lum * 0.4 + b * 0.6 + 18;
          break;
        case 'crisp_headshot':
          r = (r - 128) * 1.25 + 128; g = (g - 128) * 1.25 + 128; b = (b - 128) * 1.25 + 128;
          break;
        case 'high_fashion':
          r = Math.pow(r / 255, 1.4) * 255 * 1.1;
          g = Math.pow(g / 255, 1.4) * 255 * 1.1;
          b = Math.pow(b / 255, 1.4) * 255 * 1.1;
          break;
        case 'warm_studio':
          r = r * 1.18 + 14; g = g * 1.04 + 6; b = b * 0.88 - 10;
          break;
        case 'golden_glow':
          r = r * 1.22 + 20; g = g * 1.10 + 10; b = b * 0.82;
          break;
        case 'kodak_portra_400':
          r = r * 1.12 + 10; g = g * 1.05 + 6; b = b * 0.94;
          break;
        case 'fuji_velvia_50':
          r = lum + (r - lum) * 1.55; g = lum + (g - lum) * 1.55; b = lum + (b - lum) * 1.55;
          break;
        case 'cinematic_teal_orange':
          if (lum < 128) { b += 22; g += 10; r -= 10; }
          else { r += 26; g += 12; b -= 16; }
          break;
        case 'noir_bw':
          const nLum = lum < 128 ? lum * 0.8 : Math.min(255, lum * 1.25);
          r = nLum; g = nLum; b = nLum;
          break;
        case 'street_bw':
          r = lum; g = lum; b = lum;
          break;
        case 'platinum_print':
          r = lum * 1.02 + 8; g = lum * 0.98 + 4; b = lum * 0.92;
          break;
        case 'vintage_sepia':
          r = lum + 40; g = lum + 20; b = lum - 15;
          break;
        case 'polaroid_fade':
          r = r * 0.9 + 25; g = g * 0.9 + 22; b = b * 0.85 + 28;
          break;
        case 'hdr_clarity':
          r = (r - 128) * 1.35 + 128; g = (g - 128) * 1.35 + 128; b = (b - 128) * 1.35 + 128;
          r = lum + (r - lum) * 1.3; g = lum + (g - lum) * 1.3; b = lum + (b - lum) * 1.3;
          break;
        case 'pencil_sketch':
          const edge = Math.abs(r - g) + Math.abs(g - b);
          const pVal = 255 - Math.min(255, edge * 4);
          r = pVal; g = pVal; b = pVal;
          break;
        case 'neon_duotone':
          r = lum > 128 ? 255 : 30;
          g = lum > 128 ? 50 : 200;
          b = lum > 128 ? 180 : 255;
          break;
        default:
          break;
      }

      d[i] = Math.max(0, Math.min(255, r));
      d[i + 1] = Math.max(0, Math.min(255, g));
      d[i + 2] = Math.max(0, Math.min(255, b));
    }

    active.ctx.putImageData(imgData, 0, 0);
    renderLayersToMainCanvas();
    renderLayersListUI();
    pushHistoryState('Filter: ' + filterKey);
    if (typeof showToast === 'function') {
      showToast(`✨ Filter Applied: ${filterKey.replace(/_/g, ' ')}`, 'success');
    }
  };

  window.filterStudioCategories = function(category) {
    State.activeFilterCategory = category;
    document.querySelectorAll('.studioFilterCatBtn').forEach(btn => {
      btn.classList.toggle('activeCat', btn.dataset.cat === category);
    });
    document.querySelectorAll('.studioFilterCard').forEach(card => {
      const cardCat = card.dataset.cat;
      card.style.display = (category === 'all' || cardCat === category) ? 'block' : 'none';
    });
  };

  // ==============================================================
  // 📏 PHOTO RESIZE & 300 DPI RESAMPLE ENGINE
  // ==============================================================
  window.openResizeModal = function() {
    const modal = document.getElementById('studioResizeModal');
    if (modal) modal.style.display = 'flex';
    const wInput = document.getElementById('studioResizeW');
    const hInput = document.getElementById('studioResizeH');
    if (wInput) wInput.value = State.width;
    if (hInput) hInput.value = State.height;
  };

  window.closeResizeModal = function() {
    const modal = document.getElementById('studioResizeModal');
    if (modal) modal.style.display = 'none';
  };

  window.onResizeDimensionInput = function(changed) {
    const wEl = document.getElementById('studioSideResizeW');
    const hEl = document.getElementById('studioSideResizeH');
    if (!wEl || !hEl) return;

    let w = Number(wEl.value);
    let h = Number(hEl.value);
    const aspect = State.width / State.height;

    if (State.resizeLockRatio) {
      if (changed === 'w' && w > 0) {
        hEl.value = Math.round(w / aspect);
      } else if (changed === 'h' && h > 0) {
        wEl.value = Math.round(h * aspect);
      }
    }
  };

  window.applyStudioResize = function() {
    const wEl = document.getElementById('studioSideResizeW');
    const hEl = document.getElementById('studioSideResizeH');
    const targetW = wEl ? Number(wEl.value) : State.width;
    const targetH = hEl ? Number(hEl.value) : State.height;

    if (targetW <= 10 || targetH <= 10) return;

    // High quality bicubic resample across all layers
    for (let i = 0; i < State.layers.length; i++) {
      const layer = State.layers[i];
      const temp = document.createElement('canvas');
      temp.width = State.width;
      temp.height = State.height;
      temp.getContext('2d').drawImage(layer.canvas, 0, 0);

      layer.canvas.width = targetW;
      layer.canvas.height = targetH;
      layer.ctx.imageSmoothingEnabled = true;
      layer.ctx.imageSmoothingQuality = 'high';
      layer.ctx.drawImage(temp, 0, 0, targetW, targetH);
    }

    State.width = targetW;
    State.height = targetH;
    State.canvas.width = targetW;
    State.canvas.height = targetH;
    State.overlayCanvas.width = targetW;
    State.overlayCanvas.height = targetH;

    renderLayersToMainCanvas();
    renderLayersListUI();
    pushHistoryState(`Resize ${targetW}×${targetH}px`);
    fitCanvasToView();
    updateDimensionBadges();
    window.closeResizeModal();

    if (typeof showToast === 'function') {
      showToast(`📏 Canvas Resampled: ${targetW} × ${targetH}px (${State.currentDpi} DPI)`, 'success');
    }
  };

  window.setResizePreset = function(preset) {
    const wEl = document.getElementById('studioSideResizeW');
    const hEl = document.getElementById('studioSideResizeH');
    if (!wEl || !hEl) return;

    const presets = {
      passport_300dpi: { w: 413, h: 531, dpi: 300, name: 'Indian Passport (35×45mm @ 300 DPI)' },
      stamp_300dpi: { w: 236, h: 295, dpi: 300, name: 'Stamp Size (20×25mm @ 300 DPI)' },
      pan_300dpi: { w: 295, h: 413, dpi: 300, name: 'PAN Card Photo (25×35mm @ 300 DPI)' },
      pvc_300dpi: { w: 1004, h: 650, dpi: 300, name: 'PVC / Aadhaar (8.5×5.5cm @ 300 DPI)' },
      photo_4x6: { w: 1800, h: 1200, dpi: 300, name: '4×6 Studio Print (300 DPI)' },
      photo_5x7: { w: 1500, h: 2100, dpi: 300, name: '5×7 Portrait Print (300 DPI)' },
      a4_print: { w: 2480, h: 3508, dpi: 300, name: 'A4 Document Print (300 DPI)' },
      insta_square: { w: 1080, h: 1080, dpi: 72, name: 'Instagram Square (1080×1080)' },
      insta_reel: { w: 1080, h: 1920, dpi: 72, name: 'Reel / Story (1080×1920)' },
      youtube_thumb: { w: 1280, h: 720, dpi: 72, name: 'YouTube HD Thumbnail (1280×720)' }
    };

    if (presets[preset]) {
      const p = presets[preset];
      wEl.value = p.w;
      hEl.value = p.h;
      State.currentDpi = p.dpi;
      const dpiSelect = document.getElementById('studioDpiSelect');
      if (dpiSelect) dpiSelect.value = String(p.dpi);
      window.applyStudioResize();
    }
  };

  function updateDimensionBadges() {
    const badge = document.getElementById('studioCurrentDimsBadge');
    if (badge) {
      badge.textContent = `${State.width} × ${State.height} px`;
    }
    const sideW = document.getElementById('studioSideResizeW');
    const sideH = document.getElementById('studioSideResizeH');
    if (sideW) sideW.value = State.width;
    if (sideH) sideH.value = State.height;
  }

  // ==============================================================
  // ✍️ TEXT, STAMP & WATERMARK ENGINE
  // ==============================================================
  window.addStudioText = function(customText) {
    const active = getActiveLayer();
    if (!active || active.locked) {
      if (typeof showToast === 'function') showToast('⚠️ Layer locked! Unlock layer to add text', 'warning');
      return;
    }

    const textVal = customText || document.getElementById('studioTextInput').value || 'Muzammil Online Service';
    const size = Number(document.getElementById('studioTextSizeInput').value || 48);
    const color = document.getElementById('studioTextColorInput').value || '#ffffff';
    const font = document.getElementById('studioTextFontSelect').value || 'system-ui, sans-serif';

    active.ctx.save();
    active.ctx.font = `bold ${size}px ${font}`;
    active.ctx.fillStyle = color;
    active.ctx.textAlign = 'center';
    active.ctx.textBaseline = 'middle';
    active.ctx.shadowColor = 'rgba(0,0,0,0.85)';
    active.ctx.shadowBlur = 8;
    active.ctx.shadowOffsetX = 2;
    active.ctx.shadowOffsetY = 2;

    const posX = State.hasSelection && State.selectionRect ? State.selectionRect.x + State.selectionRect.w / 2 : State.width / 2;
    const posY = State.hasSelection && State.selectionRect ? State.selectionRect.y + State.selectionRect.h / 2 : State.height * 0.85;

    active.ctx.fillText(textVal, posX, posY);
    active.ctx.restore();

    renderLayersToMainCanvas();
    renderLayersListUI();
    pushHistoryState('Add Text: ' + textVal.slice(0, 12));
    if (typeof showToast === 'function') {
      showToast('✍️ Watermark placed on photo!', 'success');
    }
  };

  // ==============================================================
  // 📜 UNDO / REDO HISTORY STACK (Multi-Layer Snapshots)
  // ==============================================================
  function pushHistoryState(actionName) {
    if (!State.imageLoaded) return;

    if (State.historyIndex < State.history.length - 1) {
      State.history = State.history.slice(0, State.historyIndex + 1);
    }

    // Save snapshot of all layers
    const layersSnapshot = State.layers.map(l => ({
      id: l.id,
      name: l.name,
      visible: l.visible,
      locked: l.locked,
      opacity: l.opacity,
      blendMode: l.blendMode,
      data: l.ctx.getImageData(0, 0, State.width, State.height)
    }));

    State.history.push({
      action: actionName,
      layers: layersSnapshot,
      activeLayerId: State.activeLayerId,
      width: State.width,
      height: State.height
    });

    if (State.history.length > State.maxHistory) {
      State.history.shift();
    } else {
      State.historyIndex++;
    }

    updateHistoryButtons();
  }

  window.photoStudioUndo = function() {
    if (State.historyIndex > 0) {
      State.historyIndex--;
      restoreHistoryState(State.history[State.historyIndex]);
      updateHistoryButtons();
    }
  };

  window.photoStudioRedo = function() {
    if (State.historyIndex < State.history.length - 1) {
      State.historyIndex++;
      restoreHistoryState(State.history[State.historyIndex]);
      updateHistoryButtons();
    }
  };

  function restoreHistoryState(state) {
    if (!state || !state.layers) return;

    if (State.width !== state.width || State.height !== state.height) {
      State.width = state.width;
      State.height = state.height;
      State.canvas.width = state.width;
      State.canvas.height = state.height;
      State.overlayCanvas.width = state.width;
      State.overlayCanvas.height = state.height;
      fitCanvasToView();
      updateDimensionBadges();
    }

    // Reconstruct layers from snapshot
    State.layers = state.layers.map(ls => {
      const c = document.createElement('canvas');
      c.width = state.width;
      c.height = state.height;
      const ctx = c.getContext('2d', { willReadFrequently: true });
      ctx.putImageData(ls.data, 0, 0);
      return {
        id: ls.id,
        name: ls.name,
        canvas: c,
        ctx: ctx,
        visible: ls.visible,
        locked: ls.locked,
        opacity: ls.opacity,
        blendMode: ls.blendMode
      };
    });

    State.activeLayerId = state.activeLayerId || (State.layers[0] ? State.layers[0].id : null);
    renderLayersToMainCanvas();
    renderLayersListUI();
  }

  function updateHistoryButtons() {
    const undoBtn = document.getElementById('studioUndoBtn');
    const redoBtn = document.getElementById('studioRedoBtn');
    if (undoBtn) undoBtn.disabled = State.historyIndex <= 0;
    if (redoBtn) redoBtn.disabled = State.historyIndex >= State.history.length - 1;
  }

  // ==============================================================
  // 💾 EXPORTS, PRINT & APPLICATION BRIDGES
  // ==============================================================
  window.downloadStudioImage = function(format = 'png') {
    if (!State.imageLoaded) return;
    renderLayersToMainCanvas();

    const mime = format === 'jpg' || format === 'jpeg' ? 'image/jpeg' : 'image/png';
    const quality = format === 'jpg' ? 0.95 : undefined;

    let dataUrl;
    if (format === 'jpg') {
      // Put white background behind transparent areas for JPG
      const temp = document.createElement('canvas');
      temp.width = State.width;
      temp.height = State.height;
      const tctx = temp.getContext('2d');
      tctx.fillStyle = '#ffffff';
      tctx.fillRect(0, 0, State.width, State.height);
      tctx.drawImage(State.canvas, 0, 0);
      dataUrl = temp.toDataURL(mime, quality);
    } else {
      dataUrl = State.canvas.toDataURL(mime);
    }

    const a = document.createElement('a');
    a.href = dataUrl;
    a.download = `PhotoshopStudio_${Date.now()}.${format}`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);

    if (typeof showToast === 'function') {
      showToast(`💾 Saved Studio Photo (${format.toUpperCase()})`, 'success');
    }
  };

  window.printStudioImage = function() {
    if (!State.imageLoaded) return;
    renderLayersToMainCanvas();
    const dataUrl = State.canvas.toDataURL('image/png');

    const win = window.open('', '_blank', 'width=900,height=700');
    if (!win) {
      alert('Popup blocker detected. Allow popups to print.');
      return;
    }
    win.document.write(`
      <!DOCTYPE html>
      <html>
      <head>
        <title>Print Photo - Photoshop Studio Pro</title>
        <style>
          @page { margin: 0; }
          body { margin: 0; padding: 0; display: flex; align-items: center; justify-content: center; background: #fff; }
          img { max-width: 100vw; max-height: 100vh; object-fit: contain; }
        </style>
      </head>
      <body onload="window.print();window.close();">
        <img src="${dataUrl}">
      </body>
      </html>
    `);
    win.document.close();
  };

  // Bridge: Send Edited Photo Directly to Passport 4×6 8-copy Sheet Maker
  window.sendStudioPhotoToPassport = function() {
    if (!State.imageLoaded) return;
    renderLayersToMainCanvas();
    const dataUrl = State.canvas.toDataURL('image/png');

    const img = new Image();
    img.onload = function() {
      if (typeof window.show === 'function') {
        window.show('passportPhoto');
        window.__passportImage = img;
        if (typeof window.__passportImageId === 'number') window.__passportImageId++;
        if (typeof window.passportDraw === 'function') window.passportDraw();
        if (typeof window.updatePassportQualityBadge === 'function') window.updatePassportQualityBadge();
        if (typeof showToast === 'function') {
          showToast('📸 Studio photo sent to Passport 4×6 Sheet Maker!', 'success');
        }
      }
    };
    img.src = dataUrl;
  };

  // Bridge: Send to PVC Card 4×6 Maker
  window.sendStudioPhotoToPvc = function() {
    if (!State.imageLoaded) return;
    renderLayersToMainCanvas();
    const dataUrl = State.canvas.toDataURL('image/png');

    if (typeof window.show === 'function') {
      window.show('pvcCard');
      if (typeof showToast === 'function') {
        showToast('🪪 Ready for PVC Card 4×6 placement!', 'info');
      }
    }
  };

  // ==============================================================
  // 🐜 OVERLAY RENDERING (Selection Marching Ants, Brushes, Crop)
  // ==============================================================
  function animateMarchingAnts() {
    State.marchingAntsOffset = (State.marchingAntsOffset + 0.5) % 16;
    if (State.hasSelection || State.isCropping || State.activeTool === 'brush' || State.activeTool === 'eraser' || State.activeTool === 'bg_eraser' || State.activeTool === 'swipe_clean' || State.activeTool === 'healer' || State.activeTool === 'dodge_burn') {
      renderOverlay();
    }
    State.animationId = requestAnimationFrame(animateMarchingAnts);
  }

  function renderOverlay() {
    const octx = State.overlayCtx;
    if (!octx || !State.overlayCanvas) return;

    octx.clearRect(0, 0, State.width, State.height);

    // 0. Studio Alignment Grid Guides (When Grid is ON)
    if (State.controls && State.controls.grid) {
      octx.save();
      octx.strokeStyle = 'rgba(56, 189, 248, 0.35)';
      octx.lineWidth = 1;
      octx.setLineDash([4, 4]);

      // 3x3 Rule of Thirds
      const x1 = Math.round(State.width / 3);
      const x2 = Math.round((State.width * 2) / 3);
      const y1 = Math.round(State.height / 3);
      const y2 = Math.round((State.height * 2) / 3);

      octx.beginPath();
      octx.moveTo(x1, 0); octx.lineTo(x1, State.height);
      octx.moveTo(x2, 0); octx.lineTo(x2, State.height);
      octx.moveTo(0, y1); octx.lineTo(State.width, y1);
      octx.moveTo(0, y2); octx.lineTo(State.width, y2);

      // Center crosshair
      const cx = Math.round(State.width / 2);
      const cy = Math.round(State.height / 2);
      octx.moveTo(cx - 25, cy); octx.lineTo(cx + 25, cy);
      octx.moveTo(cx, cy - 25); octx.lineTo(cx, cy + 25);
      octx.stroke();

      // Subtle passport head oval guide
      octx.strokeStyle = 'rgba(16, 185, 129, 0.4)';
      octx.beginPath();
      octx.ellipse(cx, cy * 0.75, State.width * 0.22, State.height * 0.26, 0, 0, Math.PI * 2);
      octx.stroke();

      octx.restore();
    }

    // 1. Draw Selection Marquee (Marching Ants)
    if (State.hasSelection) {
      octx.save();
      octx.lineWidth = 1.5;
      octx.setLineDash([6, 6]);
      octx.lineDashOffset = -State.marchingAntsOffset;

      if (State.selectionType === 'rect' && State.selectionRect) {
        octx.strokeStyle = '#000000';
        octx.strokeRect(State.selectionRect.x, State.selectionRect.y, State.selectionRect.w, State.selectionRect.h);
        octx.strokeStyle = '#ffffff';
        octx.lineDashOffset = -State.marchingAntsOffset + 6;
        octx.strokeRect(State.selectionRect.x, State.selectionRect.y, State.selectionRect.w, State.selectionRect.h);
      } else if (State.selectionType === 'ellipse' && State.selectionRect) {
        const cx = State.selectionRect.x + State.selectionRect.w / 2;
        const cy = State.selectionRect.y + State.selectionRect.h / 2;
        const rx = Math.abs(State.selectionRect.w / 2);
        const ry = Math.abs(State.selectionRect.h / 2);

        octx.beginPath();
        octx.ellipse(cx, cy, rx, ry, 0, 0, Math.PI * 2);
        octx.strokeStyle = '#000000';
        octx.stroke();

        octx.beginPath();
        octx.ellipse(cx, cy, rx, ry, 0, 0, Math.PI * 2);
        octx.strokeStyle = '#ffffff';
        octx.lineDashOffset = -State.marchingAntsOffset + 6;
        octx.stroke();
      } else if (State.selectionType === 'lasso' && State.lassoPoints.length > 1) {
        octx.beginPath();
        octx.moveTo(State.lassoPoints[0].x, State.lassoPoints[0].y);
        for (let i = 1; i < State.lassoPoints.length; i++) {
          octx.lineTo(State.lassoPoints[i].x, State.lassoPoints[i].y);
        }
        octx.strokeStyle = '#000000';
        octx.stroke();
        octx.strokeStyle = '#ffffff';
        octx.lineDashOffset = -State.marchingAntsOffset + 6;
        octx.stroke();
      }
      octx.restore();
    }

    // 2. Draw Interactive Crop Box & Rule of Thirds Grid
    if (State.isCropping) {
      const b = State.cropBox;
      octx.save();
      // Dark translucent mask outside crop area
      octx.fillStyle = 'rgba(0, 0, 0, 0.65)';
      octx.fillRect(0, 0, State.width, b.y);
      octx.fillRect(0, b.y + b.h, State.width, State.height - (b.y + b.h));
      octx.fillRect(0, b.y, b.x, b.h);
      octx.fillRect(b.x + b.w, b.y, State.width - (b.x + b.w), b.h);

      // Crop border
      octx.strokeStyle = '#38bdf8';
      octx.lineWidth = 2;
      octx.strokeRect(b.x, b.y, b.w, b.h);

      // Rule of thirds grid
      octx.strokeStyle = 'rgba(255, 255, 255, 0.35)';
      octx.lineWidth = 1;
      octx.beginPath();
      octx.moveTo(b.x + b.w / 3, b.y);
      octx.lineTo(b.x + b.w / 3, b.y + b.h);
      octx.moveTo(b.x + (b.w * 2) / 3, b.y);
      octx.lineTo(b.x + (b.w * 2) / 3, b.y + b.h);
      octx.moveTo(b.x, b.y + b.h / 3);
      octx.lineTo(b.x + b.w, b.y + b.h / 3);
      octx.moveTo(b.x, b.y + (b.h * 2) / 3);
      octx.lineTo(b.x + b.w, b.y + (b.h * 2) / 3);
      octx.stroke();

      // Corner handles
      octx.fillStyle = '#ffffff';
      const handleSz = 8;
      const corners = [
        [b.x, b.y], [b.x + b.w, b.y],
        [b.x, b.y + b.h], [b.x + b.w, b.y + b.h]
      ];
      corners.forEach(c => {
        octx.fillRect(c[0] - handleSz / 2, c[1] - handleSz / 2, handleSz, handleSz);
      });
      octx.restore();
    }

    // 3. Photoshop Circular Brush Cursor with Crosshair
    const showBrushCircle = (
      State.activeTool === 'brush' ||
      State.activeTool === 'eraser' ||
      State.activeTool === 'healer' ||
      State.activeTool === 'dodge_burn' ||
      State.activeTool === 'bg_eraser' ||
      State.activeTool === 'swipe_clean'
    );

    if (showBrushCircle && State.cursorX > 0 && State.cursorY > 0) {
      octx.save();
      const radius = State.brushSize / 2;

      // Outer ring
      octx.beginPath();
      octx.arc(State.cursorX, State.cursorY, radius, 0, Math.PI * 2);
      octx.strokeStyle = (State.activeTool === 'swipe_clean' || State.activeTool === 'bg_eraser') ? '#10b981' : '#ffffff';
      octx.lineWidth = 1.5;
      octx.stroke();

      // Inner hardness ring
      if (State.brushHardness < 0.95 && State.brushHardness > 0.05) {
        octx.beginPath();
        octx.arc(State.cursorX, State.cursorY, radius * State.brushHardness, 0, Math.PI * 2);
        octx.strokeStyle = 'rgba(255, 255, 255, 0.4)';
        octx.setLineDash([2, 2]);
        octx.stroke();
      }

      // Center crosshair
      octx.beginPath();
      octx.moveTo(State.cursorX - 4, State.cursorY);
      octx.lineTo(State.cursorX + 4, State.cursorY);
      octx.moveTo(State.cursorX, State.cursorY - 4);
      octx.lineTo(State.cursorX, State.cursorY + 4);
      octx.strokeStyle = '#ffffff';
      octx.lineWidth = 1;
      octx.stroke();

      octx.restore();
    }
  }

  // ==============================================================
  // ⌨️ KEYBOARD SHORTCUTS
  // ==============================================================
  function setupHotkeys() {
    window.addEventListener('keydown', (e) => {
      if (!State.isOpen) return;

      // Ignore if typing in text input
      if (e.target && (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA' || e.target.tagName === 'SELECT')) {
        return;
      }

      const key = e.key.toLowerCase();

      // Undo / Redo
      if ((e.ctrlKey || e.metaKey) && key === 'z') {
        e.preventDefault();
        if (e.shiftKey) window.photoStudioRedo();
        else window.photoStudioUndo();
      } else if ((e.ctrlKey || e.metaKey) && key === 'y') {
        e.preventDefault();
        window.photoStudioRedo();
      }

      // Fullscreen
      if (key === 'f') {
        window.toggleStudioFullscreen();
      }

      // Tools
      if (key === 'm') window.setStudioTool('select_rect');
      if (key === 'o') window.setStudioTool('select_ellipse');
      if (key === 'l') window.setStudioTool('select_lasso');
      if (key === 'w') window.setStudioTool('magic_wand');
      if (key === 's') window.setStudioTool('swipe_clean');
      if (key === 'b') window.setStudioTool('brush');
      if (key === 'e') window.setStudioTool('eraser');
      if (key === 'c') window.setStudioTool('crop');
      if (key === 'i') window.setStudioTool('eyedropper');
      if (key === 't') window.setStudioTool('text');
      if (key === 'h' || e.code === 'Space') window.setStudioTool('hand');

      // Selection Actions
      if (e.key === 'Delete' || e.key === 'Backspace') {
        if (State.hasSelection) {
          e.preventDefault();
          window.deleteStudioSelection();
        }
      }
      if (e.key === 'Escape') {
        if (State.isCropping) window.cancelStudioCrop();
        else if (State.hasSelection) window.deselectStudioSelection();
        else window.closeStudioInspector();
      }
    });
  }

  // Auto-init on page load
  window.addEventListener('DOMContentLoaded', () => {
    initStudio();
  });

})();
