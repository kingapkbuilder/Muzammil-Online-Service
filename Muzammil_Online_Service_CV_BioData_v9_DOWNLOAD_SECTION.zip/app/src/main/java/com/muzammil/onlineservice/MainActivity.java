package com.muzammil.onlineservice;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.Context;
import android.database.Cursor;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.view.Gravity;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.ValueCallback;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.webkit.JavascriptInterface;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import android.content.Intent;
import android.net.Uri;
import android.os.Environment;
import android.provider.Settings;
import android.widget.Toast;
import androidx.core.content.FileProvider;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;

public class MainActivity extends Activity {
    private SharedPreferences prefs;
    private final ExecutorService aiExecutor = Executors.newSingleThreadExecutor();
    private WebView w;
    private ValueCallback<Uri[]> uploadCallback;
    private static final int FILE_PICKER = 4101;
    private TextView clock;
    private final android.os.Handler clockHandler = new android.os.Handler();
    private final Runnable clockRunnable = new Runnable() {
        @Override public void run() {
            if (clock != null) {
                clock.setText(new SimpleDateFormat("hh:mm:ss a", Locale.ENGLISH).format(new Date()));
            }
            clockHandler.postDelayed(this, 1000);
        }
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);

        prefs = getSharedPreferences("mos_settings", MODE_PRIVATE);
        if (android.os.Build.VERSION.SDK_INT >= 23 && android.os.Build.VERSION.SDK_INT <= 28 &&
            checkSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE") != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.WRITE_EXTERNAL_STORAGE"}, 5101);
        }

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.WHITE);

        w = new WebView(this);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setLoadsImagesAutomatically(true);
        s.setBlockNetworkImage(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(false);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);

        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(w, true);

        w.addJavascriptInterface(new AIBridge(), "AndroidAI");
        w.addJavascriptInterface(new DownloadBridge(), "AndroidDownload");

        w.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) { return false; }
            @Override public void onPageFinished(WebView view, String url) {
                view.evaluateJavascript("document.documentElement.style.webkitTapHighlightColor='transparent';", null);
                injectDownloadBridge(view);
            }
        });

        w.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int progress) {
                view.evaluateJavascript("var x=document.getElementById('webLoading'); if(x)x.style.display=" + (progress < 100 ? "'block'" : "'none'") + ";", null);
            }
            @Override public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback, FileChooserParams fileChooserParams) {
                if (uploadCallback != null) uploadCallback.onReceiveValue(null);
                uploadCallback = filePathCallback;
                try {
                    Intent i = fileChooserParams.createIntent();
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    startActivityForResult(i, FILE_PICKER);
                    return true;
                } catch (Exception e) {
                    uploadCallback = null;
                    Toast.makeText(MainActivity.this, "File picker open nahi hua", Toast.LENGTH_SHORT).show();
                    return false;
                }
            }
        });

        w.setDownloadListener(new DownloadListener() {
            @Override public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimetype, long contentLength) {
                try {
                    DownloadManager.Request req = new DownloadManager.Request(Uri.parse(url));
                    if (mimetype != null && !mimetype.isEmpty()) req.setMimeType(mimetype);
                    req.addRequestHeader("User-Agent", userAgent != null ? userAgent : s.getUserAgentString());
                    String cookie = CookieManager.getInstance().getCookie(url);
                    if (cookie != null && !cookie.isEmpty()) req.addRequestHeader("Cookie", cookie);
                    String filename = URLUtil.guessFileName(url, contentDisposition, mimetype);
                    req.setTitle(filename);
                    req.setDescription("Muzammil Online Service");
                    req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    req.setAllowedOverMetered(true);
                    req.setAllowedOverRoaming(true);
                    req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, filename);
                    ((DownloadManager)getSystemService(Context.DOWNLOAD_SERVICE)).enqueue(req);
                    Toast.makeText(MainActivity.this, "Download started: " + filename, Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Download start nahi hua", Toast.LENGTH_LONG).show();
                }
            }
        });

        // Native clock is above the WebView, so it remains visible even while any portal is open.
        clock = new TextView(this);
        clock.setTextColor(Color.WHITE);
        clock.setTextSize(15);
        clock.setGravity(Gravity.CENTER);
        clock.setTypeface(null, android.graphics.Typeface.BOLD);
        clock.setText("--:--:-- --");
        clock.setBackgroundColor(Color.rgb(15, 45, 100));
        clock.setElevation(12f);

        FrameLayout.LayoutParams webLp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        webLp.topMargin = dp(42);
        root.addView(w, webLp);
        FrameLayout.LayoutParams clockLp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(42));
        clockLp.gravity = Gravity.TOP;
        root.addView(clock, clockLp);

        setContentView(root);
        clockHandler.post(clockRunnable);
        w.loadUrl("file:///android_asset/index.html");
    }



    // Handles JavaScript/blob/data downloads that Android WebView's DownloadListener does not receive.
    private void injectDownloadBridge(WebView view) {
        String js =
            "(function(){" +
            "if(window.__mosDownloadHook)return;window.__mosDownloadHook=true;" +
            "document.addEventListener('click',function(ev){" +
            "var a=ev.target.closest?ev.target.closest('a'):null;if(!a)return;" +
            "var u=a.href||a.getAttribute('href')||'';var n=a.getAttribute('download')||'';" +
            "if(!/^blob:|^data:/i.test(u))return;" +
            "ev.preventDefault();ev.stopPropagation();" +
            "if(/^data:/i.test(u)){AndroidDownload.saveDataUrl(u,n);}" +
            "else{fetch(u).then(function(r){return r.blob()}).then(function(b){" +
            "var fr=new FileReader();fr.onloadend=function(){AndroidDownload.saveBase64(fr.result,n,b.type||'application/octet-stream');};fr.readAsDataURL(b);" +
            "}).catch(function(e){AndroidDownload.failed(String(e));});}" +
            "},true);})();";
        view.evaluateJavascript(js, null);
    }

    public class DownloadBridge {
        @JavascriptInterface public void saveDataUrl(String dataUrl, String filename) {
            try {
                int comma=dataUrl.indexOf(',');
                String meta=comma>0?dataUrl.substring(0,comma):"";
                String payload=comma>0?dataUrl.substring(comma+1):dataUrl;
                String mime="application/octet-stream";
                java.util.regex.Matcher mm=java.util.regex.Pattern.compile("data:([^;]+)",java.util.regex.Pattern.CASE_INSENSITIVE).matcher(meta);
                if(mm.find()) mime=mm.group(1);
                boolean b64=meta.toLowerCase(Locale.ENGLISH).contains(";base64");
                byte[] bytes=b64?Base64.decode(payload,Base64.DEFAULT):java.net.URLDecoder.decode(payload,"UTF-8").getBytes(StandardCharsets.UTF_8);
                saveToDownloads(bytes,safeFileName(filename,mime),mime);
            } catch(Exception e){ failed(e.toString()); }
        }
        @JavascriptInterface public void saveBase64(String dataUrl,String filename,String mime) {
            try {
                int comma=dataUrl.indexOf(',');
                String payload=comma>0?dataUrl.substring(comma+1):dataUrl;
                byte[] bytes=Base64.decode(payload,Base64.DEFAULT);
                saveToDownloads(bytes,safeFileName(filename,mime),mime==null||mime.isEmpty()?"application/octet-stream":mime);
            } catch(Exception e){ failed(e.toString()); }
        }
        @JavascriptInterface public String listDownloads() {
            try {
                JSONArray arr = new JSONArray();
                if (android.os.Build.VERSION.SDK_INT >= 29) {
                    String[] proj = new String[]{MediaStore.Downloads._ID, MediaStore.Downloads.DISPLAY_NAME, MediaStore.Downloads.MIME_TYPE, MediaStore.Downloads.SIZE, MediaStore.Downloads.DATE_ADDED};
                    try (Cursor c = getContentResolver().query(MediaStore.Downloads.EXTERNAL_CONTENT_URI, proj, null, null, MediaStore.Downloads.DATE_ADDED + " DESC")) {
                        if (c != null) while (c.moveToNext()) {
                            JSONObject o = new JSONObject();
                            long id=c.getLong(c.getColumnIndexOrThrow(MediaStore.Downloads._ID));
                            o.put("name", c.getString(c.getColumnIndexOrThrow(MediaStore.Downloads.DISPLAY_NAME)));
                            o.put("mime", c.getString(c.getColumnIndexOrThrow(MediaStore.Downloads.MIME_TYPE)));
                            o.put("size", c.getLong(c.getColumnIndexOrThrow(MediaStore.Downloads.SIZE)));
                            o.put("date", c.getLong(c.getColumnIndexOrThrow(MediaStore.Downloads.DATE_ADDED))*1000L);
                            o.put("uri", ContentUris.withAppendedId(MediaStore.Downloads.EXTERNAL_CONTENT_URI,id).toString());
                            arr.put(o);
                        }
                    }
                } else {
                    File dir=Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                    File[] fs=dir.listFiles();
                    if(fs!=null){
                        Arrays.sort(fs,(a,b)->Long.compare(b.lastModified(),a.lastModified()));
                        for(File f:fs){ if(!f.isFile()) continue; JSONObject o=new JSONObject(); o.put("name",f.getName()); o.put("mime",guessMime(f.getName())); o.put("size",f.length()); o.put("date",f.lastModified()); arr.put(o); }
                    }
                }
                return arr.toString();
            } catch(Exception e){ return "[]"; }
        }

        @JavascriptInterface public void shareDownload(String name) {
            runOnUiThread(() -> {
                try {
                    Uri uri=null; String mime="*/*";
                    if(android.os.Build.VERSION.SDK_INT>=29){
                        String[] p={MediaStore.Downloads._ID,MediaStore.Downloads.MIME_TYPE};
                        try(Cursor c=getContentResolver().query(MediaStore.Downloads.EXTERNAL_CONTENT_URI,p,MediaStore.Downloads.DISPLAY_NAME+"=?",new String[]{name},null)){
                            if(c!=null && c.moveToFirst()){
                                long id=c.getLong(c.getColumnIndexOrThrow(MediaStore.Downloads._ID));
                                mime=c.getString(c.getColumnIndexOrThrow(MediaStore.Downloads.MIME_TYPE));
                                uri=ContentUris.withAppendedId(MediaStore.Downloads.EXTERNAL_CONTENT_URI,id);
                            }
                        }
                    } else {
                        File f=new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),name);
                        if(f.exists()){ uri=FileProvider.getUriForFile(MainActivity.this,getPackageName()+".fileprovider",f); mime=guessMime(name); }
                    }
                    if(uri==null){Toast.makeText(MainActivity.this,"File nahi mila",Toast.LENGTH_SHORT).show();return;}
                    Intent s=new Intent(Intent.ACTION_SEND); s.setType(mime==null?"*/*":mime); s.putExtra(Intent.EXTRA_STREAM,uri); s.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION); startActivity(Intent.createChooser(s,"Share file"));
                }catch(Exception e){Toast.makeText(MainActivity.this,"Share nahi hua",Toast.LENGTH_SHORT).show();}
            });
        }

        @JavascriptInterface public void openDownload(String name) {
            runOnUiThread(() -> {
                try {
                    Uri uri=null; String mime="*/*";
                    if(android.os.Build.VERSION.SDK_INT>=29){
                        String[] p={MediaStore.Downloads._ID,MediaStore.Downloads.MIME_TYPE};
                        try(Cursor c=getContentResolver().query(MediaStore.Downloads.EXTERNAL_CONTENT_URI,p,MediaStore.Downloads.DISPLAY_NAME+"=?",new String[]{name},null)){
                            if(c!=null && c.moveToFirst()){ long id=c.getLong(c.getColumnIndexOrThrow(MediaStore.Downloads._ID)); mime=c.getString(c.getColumnIndexOrThrow(MediaStore.Downloads.MIME_TYPE)); uri=ContentUris.withAppendedId(MediaStore.Downloads.EXTERNAL_CONTENT_URI,id); }
                        }
                    } else { File f=new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),name); if(f.exists()){uri=FileProvider.getUriForFile(MainActivity.this,getPackageName()+".fileprovider",f);mime=guessMime(name);} }
                    if(uri==null){Toast.makeText(MainActivity.this,"File nahi mila",Toast.LENGTH_SHORT).show();return;}
                    Intent v=new Intent(Intent.ACTION_VIEW);v.setDataAndType(uri,mime==null?"*/*":mime);v.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(v);
                }catch(Exception e){Toast.makeText(MainActivity.this,"File open nahi hua",Toast.LENGTH_SHORT).show();}
            });
        }

        private String guessMime(String name){String n=name==null?"":name.toLowerCase(Locale.ENGLISH);if(n.endsWith(".pdf"))return "application/pdf";if(n.endsWith(".jpg")||n.endsWith(".jpeg"))return "image/jpeg";if(n.endsWith(".png"))return "image/png";if(n.endsWith(".json"))return "application/json";return "application/octet-stream";}

        @JavascriptInterface public void failed(String message) {
            runOnUiThread(() -> Toast.makeText(MainActivity.this,"Download start nahi hua",Toast.LENGTH_LONG).show());
        }
    }

    private String safeFileName(String name,String mime) {
        String n=name==null?"":name.trim();
        if(n.isEmpty()||n.equalsIgnoreCase("undefined")||n.equalsIgnoreCase("null")) {
            if("application/pdf".equalsIgnoreCase(mime)) n="Muzammil_Download.pdf";
            else if(mime!=null&&mime.toLowerCase(Locale.ENGLISH).contains("png")) n="Muzammil_Download.png";
            else if(mime!=null&&(mime.toLowerCase(Locale.ENGLISH).contains("jpeg")||mime.toLowerCase(Locale.ENGLISH).contains("jpg"))) n="Muzammil_Download.jpg";
            else n="Muzammil_Download";
        }
        n=n.replaceAll("[\\\\/:*?\"<>|]","_");
        String lower=n.toLowerCase(Locale.ENGLISH);
        if("application/pdf".equalsIgnoreCase(mime)&&!lower.endsWith(".pdf"))n+=".pdf";
        else if(mime!=null&&mime.toLowerCase(Locale.ENGLISH).contains("png")&&!lower.endsWith(".png"))n+=".png";
        else if(mime!=null&&(mime.toLowerCase(Locale.ENGLISH).contains("jpeg")||mime.toLowerCase(Locale.ENGLISH).contains("jpg"))&&!lower.endsWith(".jpg"))n+=".jpg";
        return n;
    }

    private void saveToDownloads(byte[] bytes,String filename,String mime)throws Exception{
        if(bytes==null||bytes.length==0)throw new Exception("empty file");
        if(android.os.Build.VERSION.SDK_INT>=29){
            ContentValues v=new ContentValues();
            v.put(MediaStore.Downloads.DISPLAY_NAME,filename);
            v.put(MediaStore.Downloads.MIME_TYPE,mime);
            v.put(MediaStore.Downloads.IS_PENDING,1);
            Uri uri=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);
            if(uri==null)throw new Exception("Downloads storage unavailable");
            try(OutputStream os=getContentResolver().openOutputStream(uri)){
                if(os==null)throw new Exception("output unavailable");
                os.write(bytes);
            }
            v.clear();v.put(MediaStore.Downloads.IS_PENDING,0);
            getContentResolver().update(uri,v,null,null);
        }else{
            File dir=Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            if(!dir.exists()&&!dir.mkdirs())throw new Exception("Downloads folder unavailable");
            File file=new File(dir,filename);
            try(OutputStream os=new java.io.FileOutputStream(file)){os.write(bytes);}
            android.media.MediaScannerConnection.scanFile(this,new String[]{file.getAbsolutePath()},new String[]{mime},null);
        }
        runOnUiThread(() -> { Toast.makeText(MainActivity.this,"Download complete: "+filename,Toast.LENGTH_SHORT).show(); runJs("window.refreshDownloads && window.refreshDownloads();"); });
    }

    public class AIBridge {
        @JavascriptInterface public boolean hasApiKey() { return prefs.getString("openai_key", "").trim().length() > 0; }
        @JavascriptInterface public void saveApiKey(String key) {
            if (key == null) key = "";
            prefs.edit().putString("openai_key", key.trim()).apply();
        }
        @JavascriptInterface public void clearApiKey() { prefs.edit().remove("openai_key").apply(); }
        @JavascriptInterface public void ask(String prompt) {
            final String p = prompt == null ? "" : prompt.trim();
            final String key = prefs.getString("openai_key", "").trim();
            if (key.isEmpty()) {
                runJs("window.aiReply && window.aiReply('API key set nahi hai. AI Bot me OpenAI API key add karein.');");
                return;
            }
            if (p.isEmpty()) return;
            aiExecutor.execute(() -> {
                String answer;
                try { answer = callOpenAI(key, p); }
                catch (Exception e) { answer = "AI connection error: " + (e.getMessage() == null ? "unknown error" : e.getMessage()); }
                final String safe = jsQuote(answer);
                runJs("window.aiReply && window.aiReply(" + safe + ");");
            });
        }
    }

    private void runJs(final String js) {
        runOnUiThread(() -> { if (w != null) w.evaluateJavascript(js, null); });
    }

    private String callOpenAI(String key, String prompt) throws Exception {
        URL url = new URL("https://api.openai.com/v1/responses");
        HttpURLConnection c = (HttpURLConnection) url.openConnection();
        c.setRequestMethod("POST"); c.setDoOutput(true); c.setConnectTimeout(20000); c.setReadTimeout(60000);
        c.setRequestProperty("Authorization", "Bearer " + key);
        c.setRequestProperty("Content-Type", "application/json");
        JSONObject body = new JSONObject();
        body.put("model", "gpt-5.6-luna");
        body.put("input", prompt);
        try (OutputStream os = c.getOutputStream()) { os.write(body.toString().getBytes(StandardCharsets.UTF_8)); }
        int code = c.getResponseCode();
        InputStream stream = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
        String text = readAll(stream);
        if (code < 200 || code >= 300) {
            try { JSONObject er = new JSONObject(text); JSONObject e = er.optJSONObject("error"); throw new Exception(e != null ? e.optString("message", "API error") : "HTTP " + code); }
            catch (org.json.JSONException je) { throw new Exception("HTTP " + code); }
        }
        JSONObject r = new JSONObject(text);
        String out = r.optString("output_text", "");
        if (!out.isEmpty()) return out;
        JSONArray output = r.optJSONArray("output");
        if (output != null) {
            StringBuilder sb = new StringBuilder();
            for (int i=0;i<output.length();i++) {
                JSONObject item=output.optJSONObject(i); JSONArray content=item==null?null:item.optJSONArray("content");
                if(content!=null) for(int j=0;j<content.length();j++){ JSONObject part=content.optJSONObject(j); if(part!=null){ String t=part.optString("text",""); if(!t.isEmpty()){if(sb.length()>0)sb.append("\n");sb.append(t);}}}
            }
            if(sb.length()>0)return sb.toString();
        }
        return "AI ne koi text response nahi diya.";
    }

    private String readAll(InputStream in) throws Exception {
        if (in == null) return "";
        StringBuilder sb=new StringBuilder(); try(BufferedReader br=new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))){String line;while((line=br.readLine())!=null)sb.append(line);}
        return sb.toString();
    }

    private String jsQuote(String s) {
        if(s==null)s=""; return JSONObject.quote(s);
    }

    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    // Called by the PDF/Bio Data Maker. Android's print dialog supports Save as PDF.
    public void printWebPage(String jobName) {
        try {
            PrintManager pm = (PrintManager)getSystemService(Context.PRINT_SERVICE);
            android.print.PrintDocumentAdapter adapter = w.createPrintDocumentAdapter(jobName == null ? "Muzammil PDF" : jobName);
            pm.print(jobName == null ? "Muzammil PDF" : jobName, adapter, new PrintAttributes.Builder()
                    .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                    .setColorMode(PrintAttributes.COLOR_MODE_COLOR)
                    .setMinMargins(PrintAttributes.Margins.NO_MARGINS).build());
        } catch (Exception e) {
            Toast.makeText(this, "PDF print open nahi hua", Toast.LENGTH_LONG).show();
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_PICKER) {
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null) {
                Uri u = data.getData();
                if (u != null) results = new Uri[]{u};
            }
            if (uploadCallback != null) uploadCallback.onReceiveValue(results);
            uploadCallback = null;
        }
    }

    @Override public void onBackPressed() { if (w != null && w.canGoBack()) w.goBack(); else super.onBackPressed(); }
    @Override protected void onDestroy() {
        clockHandler.removeCallbacks(clockRunnable);
        aiExecutor.shutdownNow();
        if (w != null) { w.stopLoading(); w.loadUrl("about:blank"); w.removeAllViews(); w.destroy(); w = null; }
        super.onDestroy();
    }


}
