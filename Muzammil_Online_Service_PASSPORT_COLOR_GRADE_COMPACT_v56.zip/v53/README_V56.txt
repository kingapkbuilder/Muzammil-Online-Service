Muzammil Online Service - Passport Photo v56

Compact passport controls and larger Color Grade + Beauty panel.
Added Exposure, Tint, Fade, Vignette and explanations for each control.
Kept background removal, background colors, Court Professional, tap/drag, zoom, 4x6 8-copy JPG/print.
Version 5.6.
