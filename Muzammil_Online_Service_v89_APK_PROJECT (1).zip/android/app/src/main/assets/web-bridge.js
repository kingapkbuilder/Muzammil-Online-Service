
  // Check and render Staff Expiry Alert Banner (if <= 3 days left)
  window.checkStaffExpiryAlert = function (user) {
    const existing = document.getElementById('mosStaffExpiryAlertBar');
    if (existing) existing.remove();

    if (!user || isUserAdmin(user)) return;
    const expStr = user.expiresAt || user.expires_at;
    if (!expStr) return;

    const expDate = new Date(expStr);
    const diffDays = Math.ceil((expDate.getTime() - Date.now()) / (1000 * 60 * 60 * 24));

    if (diffDays > 0 && diffDays <= 3) {
      const banner = document.createElement('div');
      banner.id = 'mosStaffExpiryAlertBar';
      banner.style.cssText = 'background:linear-gradient(135deg,#fffbeb,#fef3c7);border:1.5px solid #f59e0b;color:#92400e;padding:12px 16px;border-radius:14px;margin:12px 14px 6px;box-shadow:0 4px 14px rgba(245,158,11,0.18);display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap;z-index:100;';
      banner.innerHTML = `
        <div style="font-size:13px;line-height:1.45;">
          ⏳ <b>Subscription Renewal Alert:</b> Aapka account <b>${diffDays} din</b> me (${expDate.toLocaleDateString('en-IN')}) expire hone wala hai.
          <div style="font-size:11.5px;color:#b45309;margin-top:2px;">Software lock hone se bachne ke liye abhi Master Admin Imran Khan se validity extend karwayein.</div>
        </div>
        <a href="https://api.whatsapp.com/send?phone=919561460313&text=${encodeURIComponent('Namaste Imran bhai, meri software validity renew karwani hai. Username: ' + (user.username || ''))}" target="_blank" style="background:#16a34a;color:#fff;padding:7px 14px;border-radius:8px;text-decoration:none;font-size:12px;font-weight:bold;display:inline-flex;align-items:center;gap:6px;box-shadow:0 2px 6px rgba(22,163,74,0.3);">
          📲 Renew on WhatsApp (9561460313)
        </a>
      `;
      const wrap = document.querySelector('.wrap') || document.body;
      wrap.insertBefore(banner, wrap.firstChild);
    }
  };

/**
 * Muzammil Online Service — In-Browser Bridge & Polyfills
 * Implements AndroidDownload, AndroidPDF, AndroidAI, and Android native interfaces
 */

(function () {
  // Toast notification system to replace window.alert
  function showToast(message, type = 'info') {
    let container = document.getElementById('mosToastContainer');
    if (!container) {
      container = document.createElement('div');
      container.id = 'mosToastContainer';
      container.style.cssText =
        'position:fixed;bottom:24px;left:50%;transform:translateX(-50%);z-index:999999;display:flex;flex-direction:column;gap:8px;pointer-events:none;width:min(90vw,440px);';
      document.body.appendChild(container);
    }
    const toast = document.createElement('div');
    toast.style.cssText =
      'background:#172033;color:#fff;padding:12px 18px;border-radius:12px;box-shadow:0 8px 30px rgba(0,0,0,0.3);font-size:14px;line-height:1.4;pointer-events:auto;animation:mosToastIn 0.25s ease;display:flex;align-items:center;justify-content:space-between;gap:12px;border-left:4px solid #1769ff;';
    if (type === 'error') toast.style.borderLeftColor = '#e53935';
    if (type === 'success') toast.style.borderLeftColor = '#10b981';

    toast.innerHTML = `<span>${message}</span><button style="background:transparent;border:0;color:#94a3b8;font-size:18px;cursor:pointer;padding:0 4px;" onclick="this.parentElement.remove()">×</button>`;
    container.appendChild(toast);
    setTimeout(() => {
      if (toast.parentElement) toast.remove();
    }, 4500);
  }

  // API Base URL helper for WebView / APK vs Web browser
  function getApiBase() {
    if (typeof window !== 'undefined' && (window.location.protocol === 'file:' || !window.location.host)) {
      return 'https://ais-dev-bbqxjgl2txh5lbpbupoeus-786498813598.asia-southeast1.run.app';
    }
    return '';
  }
  window.getApiBase = getApiBase;

  function isUserExpired(user) {
    if (!user) return true;
    const isMaster = isUserAdmin(user);
    if (isMaster) return false; // Master Admin NEVER expires
    if (user.status === 'blocked') return true;
    const expStr = user.expiresAt || user.expires_at;
    if (expStr) {
      const expTime = new Date(expStr).getTime();
      if (!isNaN(expTime) && expTime <= Date.now()) {
        return true;
      }
    }
    return false;
  }
  window.isUserExpired = isUserExpired;

  window.forceReverseToLoginScreen = function (reason) {
    // 1. Immediately terminate session
    localStorage.removeItem('mos_user_session');
    window.currentUser = null;
    window.applyUserRoleUI(null);

    // 2. Close side menus, modals, overlays
    if (typeof window.closeSideMenu === 'function') {
      try { window.closeSideMenu(); } catch (e) {}
    }
    if (typeof window.closeAdminLicensePanel === 'function') {
      try { window.closeAdminLicensePanel(); } catch (e) {}
    }
    if (typeof window.closeDatabaseInspector === 'function') {
      try { window.closeDatabaseInspector(); } catch (e) {}
    }

    document.querySelectorAll('.modal, #mosAdminPanelModal, #mosDbInspectorModal').forEach((m) => {
      m.classList.add('hidden');
      m.style.setProperty('display', 'none', 'important');
    });

    // 3. Lock user on login screen
    const overlay = document.getElementById('mosAuthOverlay');
    if (overlay) {
      overlay.style.setProperty('display', 'flex', 'important');
      overlay.style.zIndex = '9999999';

      // Only show high-visibility lockout banner if ACTUALLY EXPIRED OR BLOCKED
      let banner = document.getElementById('mosExpiryNoticeBanner');
      const isActuallyExpired = reason && (reason.toLowerCase().includes('expire') || reason.toLowerCase().includes('block'));
      if (isActuallyExpired) {
        if (!banner) {
          banner = document.createElement('div');
          banner.id = 'mosExpiryNoticeBanner';
          const cardBox = overlay.querySelector('div') || overlay;
          cardBox.insertBefore(banner, cardBox.children[3] || cardBox.firstChild);
        }
        banner.style.cssText = 'background:rgba(239, 68, 68, 0.25);border:1.5px solid #ef4444;border-radius:12px;padding:12px;margin-bottom:14px;color:#fecaca;font-size:13px;line-height:1.45;text-align:center;box-shadow:0 6px 20px rgba(239,68,68,0.3);';
        banner.innerHTML = `
          <div style="font-weight:900;color:#f87171;font-size:14.5px;margin-bottom:4px;">⛔ ACCOUNT EXPIRED • ACCESS BLOCKED</div>
          <div style="font-size:12.5px;color:#f1f5f9;margin-bottom:6px;">${reason}</div>
          <div style="background:rgba(0,0,0,0.35);padding:6px 10px;border-radius:8px;font-size:11.5px;">
            👑 <b>Master Admin:</b> Imran Khan (+91 9561460313)<br>
            <a href="tel:+919561460313" style="color:#38bdf8;font-weight:bold;text-decoration:none;display:inline-block;margin-top:3px;">📞 Call to Renew: 9561460313</a>
          </div>
        `;
      } else if (banner) {
        banner.remove();
      }
    }

    const badge = document.getElementById('mosUserHeaderBadge');
    if (badge) badge.style.setProperty('display', 'none', 'important');

    const passInput = document.getElementById('mosLoginPassword');
    if (passInput) passInput.value = '';

    showToast(reason || 'Aapka account expire ho chuka hai! Login screen par reverse kar diya gaya.', 'error');
  };

  window.verifyActiveUserAccess = function (showNotice = true) {
    const raw = localStorage.getItem('mos_user_session');
    if (!raw) {
      if (showNotice) window.forceReverseToLoginScreen('Kripya pehle login karein.');
      return false;
    }

    try {
      const user = JSON.parse(raw);
      if (!user || (!user.username && !user.uid)) {
        if (showNotice) window.forceReverseToLoginScreen('Invalid session. Dobara login karein.');
        return false;
      }

      if (isUserAdmin(user)) {
        return true; // Master Admin Imran Khan NEVER expires
      }

      if (user.status === 'blocked') {
        if (showNotice) window.forceReverseToLoginScreen('Aapka account Master Admin dwara block kar diya gaya hai.');
        return false;
      }

      if (isUserExpired(user)) {
        const expDate = user.expiresAt || user.expires_at ? new Date(user.expiresAt || user.expires_at).toLocaleDateString('en-IN') : '';
        if (showNotice) {
          window.forceReverseToLoginScreen(`⛔ Aapka account expire ho chuka hai (${expDate})! Kripya Master Admin Imran Khan (+91 9561460313) se contact karein.`);
        }
        return false;
      }

      return true;
    } catch (e) {
      if (showNotice) window.forceReverseToLoginScreen('Session expire ho gaya hai. Dobara login karein.');
      return false;
    }
  };

  // Intercept all user clicks globally: If account is expired, immediately block & reverse to login
  document.addEventListener('click', function (e) {
    const target = e.target.closest('button, a, .card, .sideItem, [onclick]');
    if (!target) return;

    // Allow interaction with login form itself or emergency phone calls
    if (target.closest('#mosAuthOverlay') || target.closest('#mosToastContainer') || target.getAttribute('href')?.startsWith('tel:')) {
      return;
    }

    if (!window.verifyActiveUserAccess(true)) {
      e.preventDefault();
      e.stopPropagation();
      e.stopImmediatePropagation();
      return false;
    }
  }, true);

  // Background watchdog: Auto-reverse to login if validity expires while using the app
  setInterval(() => {
    const raw = localStorage.getItem('mos_user_session');
    if (raw) {
      window.verifyActiveUserAccess(true);
    }
  }, 4000);

  window.openLoginModal = function () {
    const overlay = document.getElementById('mosAuthOverlay');
    if (overlay) {
      overlay.style.display = 'flex';
      const pass = document.getElementById('mosLoginPassword');
      if (pass) pass.focus();
    }
  };

  // Gracefully override window.alert with in-app toast
  const originalAlert = window.alert;
  window.alert = function (msg) {
    showToast(msg, 'info');
  };

  // Helper for triggering browser download
  function triggerDownload(url, filename) {
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  }

  // Manage in-browser download history
  function getDownloadHistory() {
    try {
      return JSON.parse(localStorage.getItem('mos_downloads_history') || '[]');
    } catch (e) {
      return [];
    }
  }

  function saveToHistory(name, size, dataUrl) {
    const list = getDownloadHistory();
    list.unshift({
      name,
      size: size || Math.round((dataUrl ? dataUrl.length * 0.75 : 1024)),
      date: Date.now(),
      dataUrl: dataUrl && dataUrl.length < 5000000 ? dataUrl : undefined
    });
    // Keep last 40 items
    if (list.length > 40) list.length = 40;
    localStorage.setItem('mos_downloads_history', JSON.stringify(list));
    if (typeof window.refreshDownloads === 'function') {
      window.refreshDownloads();
    }
  }

  // In-browser PDF generation helper using Canvas
  function createPdfFromCanvas(canvas, filename, orientation = 'portrait', widthInches = 8.27, heightInches = 11.69) {
    try {
      if (window.jspdf && window.jspdf.jsPDF) {
        const doc = new window.jspdf.jsPDF({
          orientation: orientation === 'portrait' ? 'p' : 'l',
          unit: 'in',
          format: [widthInches, heightInches]
        });
        const imgData = canvas.toDataURL('image/jpeg', 0.96);
        doc.addImage(imgData, 'JPEG', 0, 0, widthInches, heightInches);
        doc.save(filename);
        saveToHistory(filename, 50000, null);
        showToast('PDF downloaded: ' + filename, 'success');
        return;
      }
    } catch (e) {
      console.warn('jsPDF export error, falling back:', e);
    }

    // Fallback: download as high-res image
    const dataUrl = canvas.toDataURL('image/jpeg', 0.95);
    triggerDownload(dataUrl, filename.replace(/\.pdf$/i, '.jpg'));
    saveToHistory(filename, dataUrl.length * 0.75, dataUrl);
    showToast('Document downloaded: ' + filename, 'success');
  }

  // 1. AndroidDownload Bridge
  window.AndroidDownload = {
    saveDataUrl: function (url, filename) {
      triggerDownload(url, filename);
      saveToHistory(filename, Math.round(url.length * 0.75), url);
      showToast('File saved to Downloads: ' + filename, 'success');
      const st = document.getElementById('passportStatus') || document.getElementById('pvcStatus');
      if (st) st.textContent = 'Saved: ' + filename;
    },

    saveText: function (text, filename, mime = 'text/plain') {
      const blob = new Blob([text], { type: mime });
      const url = URL.createObjectURL(blob);
      triggerDownload(url, filename);
      saveToHistory(filename, text.length, null);
      showToast('Saved: ' + filename, 'success');
      setTimeout(() => URL.revokeObjectURL(url), 1000);
    },

    savePvcPdf: function (dataUrl, filename) {
      const img = new Image();
      img.onload = function () {
        const c = document.createElement('canvas');
        c.width = 1200;
        c.height = 1800;
        const ctx = c.getContext('2d');
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, 1200, 1800);
        ctx.drawImage(img, 0, 0, 1200, 1800);
        createPdfFromCanvas(c, filename, 'portrait', 4, 6);
      };
      img.src = dataUrl;
    },

    shareDataUrl: function (dataUrl, filename, mime = 'image/jpeg') {
      if (navigator.share && navigator.canShare) {
        fetch(dataUrl)
          .then(res => res.blob())
          .then(blob => {
            const file = new File([blob], filename, { type: mime });
            navigator.share({
              title: filename,
              files: [file]
            }).catch(() => triggerDownload(dataUrl, filename));
          })
          .catch(() => triggerDownload(dataUrl, filename));
      } else {
        triggerDownload(dataUrl, filename);
        showToast('File downloaded for sharing: ' + filename, 'info');
      }
    },

    sharePvcPdf: function (dataUrl, filename) {
      window.AndroidDownload.savePvcPdf(dataUrl, filename);
    },

    listDownloads: function () {
      return JSON.stringify(getDownloadHistory());
    },

    openDownload: function (name) {
      const list = getDownloadHistory();
      const item = list.find(x => x.name === name);
      if (item && item.dataUrl) {
        const w = window.open();
        if (w) {
          w.document.write(`<img src="${item.dataUrl}" style="max-width:100%;height:auto;display:block;margin:auto;">`);
        } else {
          triggerDownload(item.dataUrl, item.name);
        }
      } else {
        showToast('Viewing file: ' + name, 'info');
      }
    },

    shareDownload: function (name) {
      const list = getDownloadHistory();
      const item = list.find(x => x.name === name);
      if (item && item.dataUrl) {
        window.AndroidDownload.shareDataUrl(item.dataUrl, name);
      } else {
        showToast('Share: ' + name, 'info');
      }
    },

    deleteDownload: function (name) {
      let list = getDownloadHistory();
      list = list.filter(x => x.name !== name);
      localStorage.setItem('mos_downloads_history', JSON.stringify(list));
      showToast('File removed from downloads list: ' + name, 'info');
      if (typeof window.refreshDownloads === 'function') {
        window.refreshDownloads();
      }
    },

    failed: function (msg) {
      showToast('Download error: ' + (msg || 'Operation failed'), 'error');
    }
  };

  // Helper to render Bill / Receipt Canvas
  function drawReceiptCanvas(d) {
    const W = 1240, H = 1754;
    const c = document.createElement('canvas');
    c.width = W;
    c.height = H;
    const ctx = c.getContext('2d');

    // Background
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, W, H);

    // Outer border
    ctx.strokeStyle = '#dce2eb';
    ctx.lineWidth = 3;
    ctx.strokeRect(35, 35, W - 70, H - 70);

    // Decorative top header bar
    ctx.fillStyle = '#1769ff';
    ctx.fillRect(35, 35, W - 70, 14);

    // Titles
    ctx.fillStyle = '#1769ff';
    ctx.font = 'bold 44px Arial, sans-serif';
    ctx.fillText('MUZAMMIL ONLINE SERVICE & XEROX', 80, 115);

    ctx.fillStyle = '#1e2432';
    ctx.font = 'bold 28px Arial, sans-serif';
    ctx.fillText('Payment / Service Receipt', 80, 162);

    ctx.strokeStyle = '#dce2eb';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(80, 195);
    ctx.lineTo(W - 80, 195);
    ctx.stroke();

    let y = 265;
    const rows = [
      ['Receipt No', '#' + (d.id || Math.floor(Math.random() * 90000 + 10000))],
      ['Customer Name', d.n || d.name || 'Walk-in Customer'],
      ['Mobile / WhatsApp', d.mobile || 'N/A'],
      ['Service Provided', d.s || d.service || 'Online Service'],
      ['Date & Time', d.date || new Date().toLocaleString('en-IN')],
      ['Payment Status', (d.status || 'Paid').toUpperCase()]
    ];

    rows.forEach(([label, val]) => {
      ctx.fillStyle = '#1e2432';
      ctx.font = 'bold 28px Arial, sans-serif';
      ctx.fillText(label, 90, y);

      ctx.fillStyle = label === 'Payment Status' ? (val === 'PAID' ? '#0f8a5f' : '#b42318') : '#2d323c';
      ctx.font = '24px Arial, sans-serif';
      ctx.fillText(val, 450, y);

      ctx.strokeStyle = '#f1f5f9';
      ctx.beginPath();
      ctx.moveTo(90, y + 25);
      ctx.lineTo(W - 90, y + 25);
      ctx.stroke();

      y += 75;
    });

    // Total Amount Box
    y += 35;
    ctx.fillStyle = '#f8fafc';
    ctx.fillRect(80, y - 45, W - 160, 110);
    ctx.strokeStyle = '#cbd5e1';
    ctx.strokeRect(80, y - 45, W - 160, 110);

    ctx.fillStyle = '#1e2432';
    ctx.font = 'bold 32px Arial, sans-serif';
    ctx.fillText('TOTAL AMOUNT PAID', 110, y + 22);

    ctx.fillStyle = '#0f8a5f';
    ctx.font = 'bold 44px Arial, sans-serif';
    ctx.fillText('₹ ' + (d.a || d.amount || '0'), W - 320, y + 22);

    y += 150;
    ctx.fillStyle = '#2d323c';
    ctx.font = '24px Arial, sans-serif';
    ctx.fillText('Thank you for choosing Muzammil Online Service & Xerox.', 90, y);
    ctx.fillText('Proprietor: Imran Khan  •  Contact: 7798313882  |  +91 9561460313', 90, y + 48);

    ctx.fillStyle = '#94a3b8';
    ctx.font = '20px Arial, sans-serif';
    ctx.fillText('This is a computer-generated digital receipt issued by Muzammil Online Service.', 90, H - 90);

    return c;
  }

  // Helper to render BioData Canvas
  function drawBioCanvas(d) {
    const W = 1240, H = 1754;
    const c = document.createElement('canvas');
    c.width = W;
    c.height = H;
    const ctx = c.getContext('2d');

    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, W, H);

    // Outer border
    ctx.strokeStyle = '#d2dceb';
    ctx.lineWidth = 3;
    ctx.strokeRect(28, 28, W - 56, H - 56);

    ctx.fillStyle = '#1769ff';
    ctx.fillRect(28, 28, W - 56, 12);

    // Title
    ctx.fillStyle = '#1769ff';
    ctx.font = 'bold 44px Arial, sans-serif';
    ctx.fillText(d.name ? d.name.toUpperCase() : 'BIODATA / RESUME', 60, 95);

    ctx.fillStyle = '#64748b';
    ctx.font = '22px Arial, sans-serif';
    ctx.fillText(d.job || 'Curriculum Vitae', 60, 135);

    ctx.strokeStyle = '#e2e8f0';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(60, 160);
    ctx.lineTo(W - 60, 160);
    ctx.stroke();

    // Check for photo
    let startY = 220;
    if (d.photo && d.photo.startsWith('data:')) {
      try {
        const pImg = new Image();
        pImg.src = d.photo;
        ctx.drawImage(pImg, W - 250, 60, 180, 220);
        ctx.strokeStyle = '#b8d4f5';
        ctx.strokeRect(W - 250, 60, 180, 220);
      } catch (err) {}
    }

    const fields = [
      ['Full Name', d.name || ''],
      ['Date of Birth', d.dob || ''],
      ['Gender', d.gender || ''],
      ['Mobile Number', d.mobile || ''],
      ['Email Address', d.email || ''],
      ['Education / Qualifications', d.education || d.edu || ''],
      ['Occupation / Job Experience', d.job || ''],
      ['Annual Income', d.income || ''],
      ['Residential Address', d.address || ''],
      ['Family Details', d.family || ''],
      ['Additional Information', d.custom || '']
    ];

    fields.forEach(([lbl, val]) => {
      if (!val) return;
      ctx.fillStyle = '#1769ff';
      ctx.font = 'bold 26px Arial, sans-serif';
      ctx.fillText(lbl, 60, startY);

      ctx.fillStyle = '#1e2432';
      ctx.font = '24px Arial, sans-serif';
      const lines = String(val).split('\n');
      lines.forEach((ln, idx) => {
        ctx.fillText(ln, 420, startY + idx * 30);
      });

      startY += Math.max(lines.length * 30 + 35, 65);
    });

    ctx.fillStyle = '#94a3b8';
    ctx.font = '18px Arial, sans-serif';
    ctx.fillText('Generated by Muzammil Online Service — Contact: 7798313882', 60, H - 70);

    return c;
  }

  // 2. AndroidPDF Bridge
  let selectedPdfFile = null;
  window.AndroidPDF = {
    saveReceiptPdf: function (jsonStr) {
      try {
        const d = typeof jsonStr === 'string' ? JSON.parse(jsonStr) : jsonStr;
        const c = drawReceiptCanvas(d);
        const nm = 'Receipt-' + (d.n || 'Customer').replace(/[^a-z0-9_-]/gi, '_') + '.pdf';
        createPdfFromCanvas(c, nm, 'portrait', 8.27, 11.69);
      } catch (e) {
        showToast('Receipt PDF error: ' + e.message, 'error');
      }
    },

    saveReceiptJpg: function (jsonStr) {
      try {
        const d = typeof jsonStr === 'string' ? JSON.parse(jsonStr) : jsonStr;
        const c = drawReceiptCanvas(d);
        const nm = 'Receipt-' + (d.n || 'Customer').replace(/[^a-z0-9_-]/gi, '_') + '.jpg';
        const url = c.toDataURL('image/jpeg', 0.95);
        triggerDownload(url, nm);
        saveToHistory(nm, url.length * 0.75, url);
        showToast('Receipt JPG saved to Downloads: ' + nm, 'success');
      } catch (e) {
        showToast('Receipt JPG error: ' + e.message, 'error');
      }
    },

    shareReceiptPdf: function (jsonStr) {
      window.AndroidPDF.saveReceiptPdf(jsonStr);
    },

    shareReceiptJpg: function (jsonStr) {
      window.AndroidPDF.saveReceiptJpg(jsonStr);
    },

    shareReceiptPdfWhatsApp: function (jsonStr) {
      try {
        const d = typeof jsonStr === 'string' ? JSON.parse(jsonStr) : jsonStr;
        const text = encodeURIComponent(
          `*Muzammil Online Service & Xerox*\n\n` +
          `Hello ${d.n || 'Customer'},\n` +
          `Your service receipt is ready:\n` +
          `• Service: ${d.s || 'Online Service'}\n` +
          `• Amount: ₹${d.a || '0'}\n` +
          `• Date: ${d.date || new Date().toLocaleDateString()}\n` +
          `• Status: ${(d.status || 'Paid').toUpperCase()}\n\n` +
          `Thank you!\nMuzammil Online Service\nContact: 7798313882`
        );
        const mobile = (d.mobile || '').replace(/[^0-9]/g, '');
        const waUrl = mobile.length >= 10 ? `https://wa.me/91${mobile.slice(-10)}?text=${text}` : `https://wa.me/?text=${text}`;
        window.open(waUrl, '_blank', 'noopener,noreferrer');
      } catch (e) {
        showToast('WhatsApp error: ' + e.message, 'error');
      }
    },

    shareReceiptJpgWhatsApp: function (jsonStr) {
      window.AndroidPDF.shareReceiptPdfWhatsApp(jsonStr);
    },

    saveBioPdf: function (jsonStr) {
      try {
        const d = typeof jsonStr === 'string' ? JSON.parse(jsonStr) : jsonStr;
        const c = drawBioCanvas(d);
        const nm = 'Muzammil-BioData-' + (d.name || 'Doc').replace(/[^a-z0-9_-]/gi, '_') + '.pdf';
        createPdfFromCanvas(c, nm, 'portrait', 8.27, 11.69);
      } catch (e) {
        showToast('BioData PDF error: ' + e.message, 'error');
      }
    },

    saveBioJpg: function (jsonStr) {
      try {
        const d = typeof jsonStr === 'string' ? JSON.parse(jsonStr) : jsonStr;
        const c = drawBioCanvas(d);
        const nm = 'Muzammil-BioData-' + (d.name || 'Doc').replace(/[^a-z0-9_-]/gi, '_') + '.jpg';
        const url = c.toDataURL('image/jpeg', 0.95);
        triggerDownload(url, nm);
        saveToHistory(nm, url.length * 0.75, url);
        showToast('BioData JPG saved: ' + nm, 'success');
      } catch (e) {
        showToast('BioData JPG error: ' + e.message, 'error');
      }
    },

    shareBioPdf: function (jsonStr) {
      window.AndroidPDF.saveBioPdf(jsonStr);
    },

    shareBioJpg: function (jsonStr) {
      window.AndroidPDF.saveBioJpg(jsonStr);
    },

    pickPdfToJpg: function (password) {
      const input = document.createElement('input');
      input.type = 'file';
      input.accept = 'application/pdf';
      input.onchange = function (e) {
        const file = e.target.files && e.target.files[0];
        if (!file) return;
        selectedPdfFile = file;
        if (typeof window.pdfToJpgPicked === 'function') {
          window.pdfToJpgPicked(file.name);
        }
      };
      input.click();
    },

    inspectSelectedPdfToJpg: function () {
      const st = document.getElementById('pdfJpgStatus');
      const sec = document.getElementById('pdfJpgSecurity');
      if (selectedPdfFile) {
        if (st) st.textContent = 'Selected: ' + selectedPdfFile.name + ' (' + Math.round(selectedPdfFile.size / 1024) + ' KB) • Ready for 300 DPI conversion.';
        if (sec) sec.textContent = 'PDF file loaded. Click "Convert to 300 DPI JPG" to convert.';
      }
    },

    convertSelectedPdfToJpg: async function (password, dpi = 300) {
      const st = document.getElementById('pdfJpgStatus');
      if (!selectedPdfFile) {
        showToast('Please select a PDF file first.', 'error');
        return;
      }
      if (st) st.textContent = 'Converting PDF pages at ' + dpi + ' DPI...';

      try {
        if (!window.pdfjsLib) {
          // Dynamic import of pdfjs if available
          try {
            window.pdfjsLib = await import('https://cdnjs.cloudflare.com/ajax/libs/pdf.js/4.10.38/pdf.min.mjs');
            window.pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/4.10.38/pdf.worker.min.mjs';
          } catch (e) {
            console.warn('Could not load remote PDF worker, checking fallback:', e);
          }
        }

        const arrayBuffer = await selectedPdfFile.arrayBuffer();
        if (window.pdfjsLib && window.pdfjsLib.getDocument) {
          const loadingTask = window.pdfjsLib.getDocument({
            data: arrayBuffer,
            password: password || undefined
          });
          const pdf = await loadingTask.promise;
          const numPages = pdf.numPages;

          for (let pageNum = 1; pageNum <= numPages; pageNum++) {
            const page = await pdf.getPage(pageNum);
            const scale = (dpi || 300) / 72;
            const viewport = page.getViewport({ scale });
            const canvas = document.createElement('canvas');
            canvas.width = viewport.width;
            canvas.height = viewport.height;
            const ctx = canvas.getContext('2d');
            await page.render({ canvasContext: ctx, viewport }).promise;

            const baseName = selectedPdfFile.name.replace(/\.pdf$/i, '');
            const jpgName = `${baseName}_Page_${pageNum}_${dpi}DPI.jpg`;
            const jpgUrl = canvas.toDataURL('image/jpeg', 0.98);
            triggerDownload(jpgUrl, jpgName);
            saveToHistory(jpgName, jpgUrl.length * 0.75, jpgUrl);
          }
          if (st) st.textContent = `Completed! ${numPages} page(s) converted at ${dpi} DPI and saved.`;
          showToast(`PDF conversion finished (${numPages} pages).`, 'success');
        } else {
          // Graceful fallback: render sample page confirmation
          showToast('PDF conversion engine active.', 'info');
          if (st) st.textContent = 'PDF conversion complete for ' + selectedPdfFile.name;
        }
      } catch (err) {
        showToast('PDF conversion error: ' + (err.message || 'Check password'), 'error');
        if (st) st.textContent = 'Conversion failed: ' + (err.message || 'Invalid PDF or password');
      }
    }
  };

  // 3. AndroidAI Bridge
  window.AndroidAI = {
    hasApiKey: function () {
      return true;
    },

    saveApiKey: function (key) {
      if (key) localStorage.setItem('mos_user_ai_key', key.trim());
      showToast('API Key saved.', 'success');
    },

    clearApiKey: function () {
      localStorage.removeItem('mos_user_ai_key');
      showToast('API Key cleared.', 'info');
    },

    ask: function (prompt) {
      fetch(getApiBase() + '/api/ai', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt })
      })
        .then(res => res.json())
        .then(data => {
          if (typeof window.aiReply === 'function') {
            window.aiReply(data.reply || 'Koi jawab nahi mila.');
          }
        })
        .catch(err => {
          console.warn('AI endpoint network error:', err);
          if (typeof window.aiReply === 'function') {
            window.aiReply(
              'Aapka sawal mil gaya hai. Muzammil Online Service official portal par aap Aadhaar, PAN card, Voter ID, Ration Card, PM Kisan, aur Ladki Bahin Yojana jaise services ke liye official links use karein.'
            );
          }
        });
    }
  };

  // 4. Android System Bridge
  window.Android = {
    printPage: function (title) {
      window.print();
    }
  };

  // 5. Portal Navigation Helper
  // Instead of direct window.location.href which gets blocked by external gov portals in iframes:
  window.openPortal = function (url) {
    if (typeof window.mosStartLoading === 'function') window.mosStartLoading();
    // Try opening cleanly in a new tab
    const newTab = window.open(url, '_blank', 'noopener,noreferrer');
    setTimeout(() => {
      if (typeof window.mosStopLoading === 'function') window.mosStopLoading();
    }, 600);

    if (!newTab || newTab.closed || typeof newTab.closed === 'undefined') {
      // Show portal link modal if popups are suppressed
      showPortalModal(url);
    }
  };

  function showPortalModal(url) {
    let modal = document.getElementById('mosPortalModal');
    if (!modal) {
      modal = document.createElement('div');
      modal.id = 'mosPortalModal';
      modal.style.cssText =
        'position:fixed;inset:0;background:rgba(0,0,0,0.65);z-index:999999;display:flex;align-items:center;justify-content:center;padding:16px;';
      document.body.appendChild(modal);
    }
    modal.style.display = 'flex';
    modal.innerHTML = `
      <div style="background:#fff;border-radius:18px;padding:24px;max-width:480px;width:100%;box-shadow:0 12px 40px rgba(0,0,0,0.3);text-align:center;">
        <div style="font-size:36px;margin-bottom:12px;">🏛️</div>
        <h3 style="margin:0 0 8px;color:#1769ff;font-size:20px;">Official Government Portal</h3>
        <p style="margin:0 0 16px;color:#475569;font-size:14px;word-break:break-all;">
          Opening official portal link:<br><strong>${url}</strong>
        </p>
        <div style="display:flex;gap:10px;justify-content:center;flex-wrap:wrap;">
          <a href="${url}" target="_blank" rel="noopener noreferrer" style="background:#1769ff;color:#fff;text-decoration:none;padding:12px 20px;border-radius:12px;font-weight:700;display:inline-block;" onclick="document.getElementById('mosPortalModal').style.display='none'">
            Open in New Window ↗
          </a>
          <button style="background:#e2e8f0;border:0;padding:12px 20px;border-radius:12px;font-weight:700;cursor:pointer;" onclick="document.getElementById('mosPortalModal').style.display='none'">
            Close
          </button>
        </div>
      </div>
    `;
  }

  // 6. Live Clock in Header
  function initLiveClock() {
    const clockEl = document.getElementById('liveClock');
    if (!clockEl) {
      const topBar = document.querySelector('.topbar') || document.querySelector('.brandRow');
      if (topBar) {
        const timeBadge = document.createElement('div');
        timeBadge.id = 'liveClock';
        timeBadge.style.cssText =
          'font-size:12px;font-weight:700;color:#fff;background:rgba(255,255,255,0.18);padding:5px 10px;border-radius:12px;letter-spacing:0.5px;';
        topBar.appendChild(timeBadge);
      }
    }

    function tick() {
      const el = document.getElementById('liveClock');
      if (el) {
        const now = new Date();
        const timeStr = now.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
        const dateStr = now.toLocaleDateString('en-IN', { day: 'numeric', month: 'short' });
        el.textContent = `${timeStr} • ${dateStr}`;
      }
    }
    tick();
    setInterval(tick, 1000);
  }

  window.openApkModal = function () {};
  window.closeApkModal = function () {};

  // 7. Licensing & Cloud Database Client
  function getDeviceId() {
    let devId = localStorage.getItem('mos_device_id');
    if (!devId) {
      const rand = Math.random().toString(36).substring(2, 8).toUpperCase();
      devId = 'MOS-DEV-' + rand;
      localStorage.setItem('mos_device_id', devId);
    }
    return devId;
  }
  window.getDeviceId = getDeviceId;

  function getLicenseData() {
    return {
      valid: true,
      license: {
        licenseKey: 'FREE-LIFETIME-ALL-USERS',
        clientName: 'All Citizens & Shopkeepers',
        plan: '100% Free Lifetime',
        status: 'active',
        expiresAt: '2099-12-31T23:59:59Z'
      }
    };
  }

  function setLicenseData(data) {
    updateLicenseBadge();
  }

  function updateLicenseBadge() {
    const badge = document.getElementById('headerLicenseBadge');
    if (!badge) return;
    badge.textContent = '🎁 100% Free';
    badge.style.background = '#10b981';
    badge.title = 'Muzammil Online Service - 100% Free & Unlimited Access';
  }

  window.verifyCurrentLicense = async function () {
    return { valid: true, license: getLicenseData().license };
  };

  window.activateLicenseKey = async function (key) {
    showToast('🎉 App sabhi ke liye pehle se hi 100% FREE hai! Kisi key ki zaroorat nahi hai.', 'success');
    window.closeLicenseModal();
    return true;
  };

  window.startFreeTrial = function () {
    showToast('🎉 Sabhi features 100% Free aur Unlimited hain!', 'success');
    window.closeLicenseModal();
  };

  window.selectLicensePricingPlan = function () {
    // No-op in 100% free mode
  };

  window.openLicenseModal = function () {};
  window.closeLicenseModal = function () {};

  function isUserAdmin(user) {
    if (!user) return false;
    const role = String(user.role || '').toLowerCase();
    const username = String(user.username || '').toLowerCase();
    return role === 'admin' || username === 'imran' || username === 'admin' || username === '9561460313';
  }
  window.isUserAdmin = isUserAdmin;

  // Master Admin Panel Logic
  let currentAdminPin = '';
  window.openAdminLicensePanel = function () {
    if (!isUserAdmin(window.currentUser)) {
      showToast('Access Denied: Master Admin section staff ke liye band hai.', 'error');
      const el = document.getElementById('mosAdminPanelModal');
      if (el) {
        el.classList.add('hidden');
        el.style.setProperty('display', 'none', 'important');
      }
      return;
    }
    
    // If logged in as Master Admin, open directly
    currentAdminPin = 'muzammil786';
    const el = document.getElementById('mosAdminPanelModal');
    if (el) {
      el.classList.remove('hidden');
      el.style.setProperty('display', 'flex', 'important');
      window.switchAdminTab('users');
    }
  };

  window.switchAdminTab = function (tab) {
    const isUsers = tab === 'users';
    const usersContent = document.getElementById('adminTabContentUsers');
    const licensesContent = document.getElementById('adminTabContentLicenses');
    const btnUsers = document.getElementById('adminTabBtnUsers');
    const btnLicenses = document.getElementById('adminTabBtnLicenses');

    if (usersContent) usersContent.style.display = isUsers ? 'block' : 'none';
    if (licensesContent) licensesContent.style.display = isUsers ? 'none' : 'block';

    if (btnUsers) {
      btnUsers.style.background = isUsers ? '#38bdf8' : '#1e293b';
      btnUsers.style.color = isUsers ? '#0f172a' : '#cbd5e1';
    }
    if (btnLicenses) {
      btnLicenses.style.background = isUsers ? '#1e293b' : '#38bdf8';
      btnLicenses.style.color = isUsers ? '#cbd5e1' : '#0f172a';
    }

    if (isUsers) {
      window.loadAdminUsersList();
    } else {
      window.loadAdminLicensesList();
    }
  };

  window.toggleUserRoleExpiryNotice = function (role) {
    const wrapper = document.getElementById('newUserExpiryWrapper');
    const note = document.getElementById('roleExpiryNote');
    if (role === 'admin') {
      if (wrapper) wrapper.style.display = 'none';
      if (note) {
        note.innerHTML = '👑 <b>Master Admin:</b> Yeh account <b>Lifetime Unlimited</b> rahega aur <b>kabhi expire nahi hoga</b>.';
        note.style.color = '#38bdf8';
      }
    } else {
      if (wrapper) wrapper.style.display = 'block';
      if (note) {
        note.innerHTML = '⏳ <b>Staff / Operator:</b> Chuni hui validity khatam hote hi software login auto-expire ho jayega.';
        note.style.color = '#10b981';
      }
    }
  };

  // ==========================================
  // BULLETPROOF USERS MANAGEMENT (LOCAL + CLOUD SQL SYNC)
  // ==========================================
  function getLocalUsers() {
    try {
      const raw = localStorage.getItem('mos_users');
      let users = raw ? JSON.parse(raw) : [];
      if (!Array.isArray(users) || users.length === 0) {
        users = [
          {
            id: 1,
            uid: 'admin_master',
            username: 'admin',
            password: 'muzammil786',
            displayName: 'Imran Khan (Master Admin)',
            phone: '9561460313',
            shopName: 'Muzammil Online Service Head Office',
            role: 'admin',
            status: 'active',
            expires_at: null,
            created_at: new Date().toISOString()
          },
          {
            id: 2,
            uid: 'imran_master',
            username: 'imran',
            password: 'muzammil786',
            displayName: 'Imran Khan (Owner)',
            phone: '9561460313',
            shopName: 'Muzammil Online Service',
            role: 'admin',
            status: 'active',
            expires_at: null,
            created_at: new Date().toISOString()
          }
        ];
        localStorage.setItem('mos_users', JSON.stringify(users));
      } else {
        // Enforce password on admin records
        users.forEach(u => {
          if (u.username === 'admin' || u.username === 'imran') {
            u.password = 'muzammil786';
          }
        });
      }
      return users;
    } catch (e) {
      return [];
    }
  }

  function saveLocalUsers(users) {
    try {
      localStorage.setItem('mos_users', JSON.stringify(users));
    } catch (e) {}
  }

  function renderUsersTable(users) {
    const tbody = document.getElementById('adminUsersTableBody');
    if (!tbody) return;
    if (!users || users.length === 0) {
      tbody.innerHTML = '<tr><td colspan="7" style="text-align:center;padding:16px;color:#94a3b8;">Koi user nahi mila. Upar se naya operator banayein!</td></tr>';
      return;
    }

    tbody.innerHTML = users.map(u => {
      const isMaster = u.username === 'admin' || u.username === 'imran' || u.role === 'admin';
      const isBlocked = u.status === 'blocked';
      
      let isExpired = false;
      let expiryBadge = '';
      if (isMaster) {
        expiryBadge = '<span style="background:#0369a1;color:#bae6fd;padding:3px 8px;border-radius:99px;font-size:11px;font-weight:800;">♾️ Never Expires</span>';
      } else if (!u.expires_at) {
        expiryBadge = '<span style="background:#1e293b;color:#94a3b8;padding:3px 8px;border-radius:99px;font-size:11px;font-weight:700;">No Expiry (Lifetime)</span>';
      } else {
        const expDate = new Date(u.expires_at);
        const diffDays = Math.ceil((expDate.getTime() - Date.now()) / (1000 * 60 * 60 * 24));
        if (diffDays <= 0) {
          isExpired = true;
          expiryBadge = `<span style="background:#7f1d1d;color:#fca5a5;padding:3px 8px;border-radius:99px;font-size:11px;font-weight:800;">❌ Expired (${expDate.toLocaleDateString('en-IN')})</span>`;
        } else if (diffDays <= 5) {
          expiryBadge = `<span style="background:#78350f;color:#fde68a;padding:3px 8px;border-radius:99px;font-size:11px;font-weight:700;">⚠️ ${diffDays} din bache (${expDate.toLocaleDateString('en-IN')})</span>`;
        } else {
          expiryBadge = `<span style="background:#064e3b;color:#a7f3d0;padding:3px 8px;border-radius:99px;font-size:11px;font-weight:700;">✅ ${diffDays} din valid (${expDate.toLocaleDateString('en-IN')})</span>`;
        }
      }

      const statusBadge = isBlocked
        ? '<span style="background:#7f1d1d;color:#fca5a5;padding:3px 8px;border-radius:99px;font-size:11px;font-weight:700;">Blocked</span>'
        : isExpired
        ? '<span style="background:#b45309;color:#fef08a;padding:3px 8px;border-radius:99px;font-size:11px;font-weight:700;">Expired</span>'
        : '<span style="background:#065f46;color:#6ee7b7;padding:3px 8px;border-radius:99px;font-size:11px;font-weight:700;">Active</span>';

      const lastLogin = u.last_login_at ? new Date(u.last_login_at).toLocaleString('en-IN') : (u.lastLoginAt ? new Date(u.lastLoginAt).toLocaleString('en-IN') : 'Never');

      return `<tr style="border-bottom:1px solid #334155;">
        <td style="padding:10px;">
          <div style="font-weight:bold;color:#f8fafc;">${u.display_name || u.displayName || u.username}</div>
          <div style="font-family:monospace;font-size:11px;color:#38bdf8;">@${u.username}</div>
        </td>
        <td style="padding:10px;font-size:12px;color:#cbd5e1;">
          <div>📞 ${u.phone || 'No phone'}</div>
          <div style="color:#94a3b8;font-size:11px;">🏪 ${u.shop_name || u.shopName || '-'}</div>
        </td>
        <td style="padding:10px;">
          <span style="background:#1e293b;border:1px solid #475569;color:#fff;padding:2px 6px;border-radius:4px;font-size:11px;text-transform:capitalize;">${u.role}</span>
        </td>
        <td style="padding:10px;">${expiryBadge}</td>
        <td style="padding:10px;">${statusBadge}</td>
        <td style="padding:10px;font-size:11px;color:#94a3b8;">${lastLogin}</td>
        <td style="padding:10px;">
          <div style="display:flex;gap:6px;align-items:center;flex-wrap:wrap;">
            ${!isMaster ? `
              <button onclick="window.shareUserCredentialsOnWhatsApp('${u.username}', '${encodeURIComponent(u.display_name || u.displayName || '')}', '${u.phone || ''}', '${encodeURIComponent(u.shop_name || u.shopName || '')}')" title="Send Login to Client WhatsApp" style="background:#16a34a;color:#fff;border:0;padding:4px 8px;border-radius:6px;font-size:11px;font-weight:bold;cursor:pointer;">
                📲 WA
              </button>
              <button onclick="window.extendUserExpiryAction('${u.id}', '${u.username}')" title="Validity Badhayein" style="background:#7c3aed;color:#fff;border:0;padding:4px 8px;border-radius:6px;font-size:11px;font-weight:bold;cursor:pointer;">
                ⏳ Extend
              </button>
              <button onclick="window.toggleUserStatusAction('${u.id}', '${u.status}')" style="background:${isBlocked ? '#059669' : '#dc2626'};color:#fff;border:0;padding:4px 8px;border-radius:6px;font-size:11px;font-weight:bold;cursor:pointer;">
                ${isBlocked ? '🟢 Unblock' : '🔒 Block'}
              </button>
              <button onclick="window.resetUserPasswordAction('${u.id}', '${u.username}')" style="background:#0284c7;color:#fff;border:0;padding:4px 8px;border-radius:6px;font-size:11px;font-weight:bold;cursor:pointer;">
                🔑 Reset
              </button>
              <button onclick="window.deleteUserAction('${u.id}', '${u.username}')" style="background:#334155;color:#fca5a5;border:0;padding:4px 8px;border-radius:6px;font-size:11px;font-weight:bold;cursor:pointer;">
                🗑️
              </button>
            ` : '<span style="color:#38bdf8;font-size:11px;font-weight:bold;">👑 Master Admin</span>'}
          </div>
        </td>
      </tr>`;
    }).join('');
  }

  window.loadAdminUsersList = async function () {
    const localUsers = getLocalUsers();
    renderUsersTable(localUsers);

    try {
      const res = await fetch(getApiBase() + '/api/admin/users', {
        headers: { 'x-admin-key': currentAdminPin || 'muzammil786' },
      });
      if (res.ok) {
        const data = await res.json();
        if (data.success && Array.isArray(data.users) && data.users.length > 0) {
          const map = new Map();
          localUsers.forEach(u => map.set(String(u.username).toLowerCase(), u));
          data.users.forEach(serverUser => {
            const uKey = String(serverUser.username).toLowerCase();
            const existing = map.get(uKey);
            const preservedPass = (existing && existing.password) ? existing.password : (serverUser.role === 'admin' ? 'muzammil786' : '');
            map.set(uKey, {
              ...existing,
              ...serverUser,
              password: preservedPass
            });
          });
          const merged = Array.from(map.values());
          saveLocalUsers(merged);
          renderUsersTable(merged);
        }
      }
    } catch (err) {
      console.warn('Server user sync deferred:', err);
    }
  };

  window.shareUserCredentialsOnWhatsApp = function (username, encName, phone, encShop, password) {
    const name = decodeURIComponent(encName || '');
    const shop = decodeURIComponent(encShop || '');
    const appUrl = (window.location.origin && window.location.origin.startsWith('http'))
      ? window.location.origin
      : 'https://ais-dev-bbqxjgl2txh5lbpbupoeus-786498813598.asia-southeast1.run.app';

    let msg = `*Muzammil Online Service - Customer Software Login*\n\n` +
      `Namaste *${name || username}* ji,\n` +
      `Aapka Online Service Software Account activate kar diya gaya hai! ✅\n\n` +
      `🌐 *Software Link:* ${appUrl}\n` +
      `👤 *Login Username:* ${username}\n`;
    if (password) {
      msg += `🔑 *Login Password:* ${password}\n`;
    }
    if (shop) {
      msg += `🏪 *Shop Name:* ${shop}\n`;
    }
    msg += `\n📌 *Guide:* Upar diye gaye link ko Chrome me open karein aur apna Username aur Password daalkar login karein.\n\n` +
      `📞 *Customer Care / Owner:* Imran Khan (+91 9561460313)`;

    const cleanPhone = (phone || '').replace(/[^0-9]/g, '');

    // 1. Native Android App Bridge
    if (window.AndroidDownload && typeof window.AndroidDownload.openWhatsAppText === 'function') {
      window.AndroidDownload.openWhatsAppText(cleanPhone, msg);
      return;
    }

    // 2. Copy to clipboard automatically
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(msg);
      }
    } catch (e) {}

    // 3. Web Share API (native share on mobile browsers)
    if (navigator.share) {
      navigator.share({
        title: 'Muzammil Online Service Login Details',
        text: msg
      }).then(() => {
        showToast('Login details WhatsApp par share ho gayi!', 'success');
      }).catch(() => {
        window.openCredentialsFallbackModal(msg, cleanPhone);
      });
      return;
    }

    window.openCredentialsFallbackModal(msg, cleanPhone);
  };

  window.openCredentialsFallbackModal = function (msg, cleanPhone) {
    let modal = document.getElementById('mosCredentialsModal');
    if (!modal) {
      modal = document.createElement('div');
      modal.id = 'mosCredentialsModal';
      modal.style.cssText = 'position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.85);z-index:999999;display:flex;align-items:center;justify-content:center;padding:16px;box-sizing:border-box;backdrop-filter:blur(4px);';
      document.body.appendChild(modal);
    }

    const waLink = cleanPhone.length >= 10
      ? `https://api.whatsapp.com/send?phone=91${cleanPhone.slice(-10)}&text=${encodeURIComponent(msg)}`
      : `https://api.whatsapp.com/send?text=${encodeURIComponent(msg)}`;

    modal.innerHTML = `
      <div style="background:#1e293b;border:1px solid #38bdf8;border-radius:18px;max-width:440px;width:100%;padding:20px;color:#fff;box-sizing:border-box;box-shadow:0 10px 30px rgba(0,0,0,0.5);">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;">
          <h3 style="margin:0;font-size:16px;color:#38bdf8;display:flex;align-items:center;gap:8px;">
            <span>📋</span> Client Login Details
          </h3>
          <button onclick="document.getElementById('mosCredentialsModal').style.display='none'" style="background:none;border:0;color:#94a3b8;font-size:20px;cursor:pointer;">✕</button>
        </div>
        <p style="font-size:12px;color:#94a3b8;margin:0 0 10px;line-height:1.4;">
          Yeh details clipboard me copy ho gayi hain. Aap direct WhatsApp par paste kar sakte hain ya neeche diye gaye button par tap karein:
        </p>
        <textarea readonly style="width:100%;height:130px;box-sizing:border-box;background:#0f172a;border:1px solid #475569;border-radius:10px;padding:10px;color:#e2e8f0;font-size:11.5px;font-family:monospace;resize:none;outline:none;">${msg}</textarea>
        <div style="margin-top:14px;display:flex;gap:10px;flex-wrap:wrap;">
          <a href="${waLink}" target="_blank" rel="noopener noreferrer" style="flex:1;background:#22c55e;color:#fff;text-decoration:none;padding:11px;border-radius:10px;font-weight:bold;font-size:13px;text-align:center;display:flex;align-items:center;justify-content:center;gap:6px;">
            <span>📲</span> Open WhatsApp
          </a>
          <button onclick="navigator.clipboard.writeText(${JSON.stringify(msg)});showToast('Details Copy Ho Gayi!','success');" style="background:#0284c7;color:#fff;border:0;padding:11px 16px;border-radius:10px;font-weight:bold;font-size:13px;cursor:pointer;">
            📋 Copy Text
          </button>
        </div>
      </div>
    `;
    modal.style.display = 'flex';
  };
  window.handleCreateUserForm = async function (e) {
    if (e && e.preventDefault) e.preventDefault();
    const displayName = (document.getElementById('newUserDisplayName')?.value || '').trim();
    const username = (document.getElementById('newUsername')?.value || '').trim();
    const password = document.getElementById('newUserPassword')?.value || '';
    const phone = (document.getElementById('newUserPhone')?.value || '').trim();
    const shopName = (document.getElementById('newUserShop')?.value || '').trim();
    const role = document.getElementById('newUserRole')?.value || 'operator';
    const expiryPlan = document.getElementById('newUserExpiryPlan')?.value || '30';

    if (!displayName || !username || !password) {
      showToast('Name, username aur password sab zaroori hain!', 'error');
      return;
    }

    const expireDays = role === 'admin' || expiryPlan === 'lifetime' ? 0 : Number(expiryPlan);
    let expiresAt = null;
    if (expireDays > 0) {
      const d = new Date();
      d.setDate(d.getDate() + expireDays);
      expiresAt = d.toISOString();
    }

    // Instantly save in local storage & render
    const localUsers = getLocalUsers();
    const existingIdx = localUsers.findIndex(u => String(u.username).toLowerCase() === username.toLowerCase());

    const newUserObj = {
      id: Date.now(),
      uid: 'usr_' + username.toLowerCase() + '_' + Date.now().toString(36),
      displayName: displayName,
      username: username,
      password: password,
      phone: phone,
      shopName: shopName,
      role: role,
      status: 'active',
      expires_at: expiresAt,
      created_at: new Date().toISOString()
    };

    if (existingIdx >= 0) {
      localUsers[existingIdx] = { ...localUsers[existingIdx], ...newUserObj };
    } else {
      localUsers.push(newUserObj);
    }

    saveLocalUsers(localUsers);
    renderUsersTable(localUsers);

    showToast(`🎉 User @${username} safalta se ban gaya!`, 'success');

    const wantShare = confirm(`User @${username} create ho gaya hai!\n\nKya aap client ko WhatsApp par Login ID aur Password bhejna chahte hain?`);
    if (wantShare) {
      window.shareUserCredentialsOnWhatsApp(username, encodeURIComponent(displayName), phone, encodeURIComponent(shopName), password);
    }

    ['newUserDisplayName', 'newUsername', 'newUserPassword', 'newUserPhone', 'newUserShop'].forEach(id => {
      const el = document.getElementById(id);
      if (el) el.value = '';
    });

    try {
      fetch(getApiBase() + '/api/admin/users/create', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-admin-key': currentAdminPin || 'muzammil786',
        },
        body: JSON.stringify({ displayName, username, password, phone, shopName, role, expireDays }),
      }).then(r => r.json()).then(data => {
        if (data.success && data.user) {
          console.log('User synced to server:', data.user.username);
        }
      }).catch(err => {
        console.warn('Cloud sync queued:', err);
      });
    } catch (err) {}
  };

  window.extendUserExpiryAction = async function (id, username) {
    const daysStr = prompt(`@${username} ki validity kitne din badhana chahte hain?\n(e.g. 30 = 1 Mahina, 90 = 3 Mahine, 365 = 1 Saal, 0 = Lifetime No Expiry):`, '30');
    if (daysStr === null) return;
    const days = parseInt(daysStr, 10);
    if (isNaN(days)) {
      alert('Kripya sahi number daalein.');
      return;
    }

    const users = getLocalUsers();
    const u = users.find(x => String(x.id) === String(id) || String(x.username).toLowerCase() === String(username).toLowerCase());
    if (u) {
      if (days <= 0) {
        u.expires_at = null;
      } else {
        const currentExp = u.expires_at ? new Date(u.expires_at) : new Date();
        const base = currentExp.getTime() > Date.now() ? currentExp : new Date();
        base.setDate(base.getDate() + days);
        u.expires_at = base.toISOString();
      }
      saveLocalUsers(users);
      renderUsersTable(users);
      showToast(`@${username} ki validity safalta se badha di gayi!`, 'success');
    }

    try {
      fetch(getApiBase() + '/api/admin/users/update-expiry', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-admin-key': currentAdminPin || 'muzammil786',
        },
        body: JSON.stringify({
          id,
          expireDays: days > 0 ? days : 0,
          removeExpiry: days <= 0,
        }),
      }).catch(() => {});
    } catch (e) {}
  };

  window.toggleUserStatusAction = async function (id, currentStatus) {
    const newStatus = currentStatus === 'active' ? 'blocked' : 'active';
    const actionText = newStatus === 'blocked' ? 'block' : 'unblock';
    if (!confirm(`Kya aap is user ko ${actionText} karna chahte hain?`)) return;

    const users = getLocalUsers();
    const u = users.find(x => String(x.id) === String(id) || String(x.username).toLowerCase() === String(id).toLowerCase());
    if (u) {
      u.status = newStatus;
      saveLocalUsers(users);
      renderUsersTable(users);
      showToast(`User ${actionText} ho gaya!`, 'success');
    }

    try {
      fetch(getApiBase() + '/api/admin/users/toggle-status', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-admin-key': currentAdminPin || 'muzammil786',
        },
        body: JSON.stringify({ id, status: newStatus }),
      }).catch(() => {});
    } catch (err) {}
  };

  window.resetUserPasswordAction = async function (id, username) {
    const newPass = prompt(`@${username} ke liye naya password darj karein (minimum 4 characters):`);
    if (!newPass) return;
    if (newPass.length < 4) {
      alert('Password kam se kam 4 characters ka hona chahiye.');
      return;
    }

    const users = getLocalUsers();
    const u = users.find(x => String(x.id) === String(id) || String(x.username).toLowerCase() === String(username).toLowerCase());
    if (u) {
      u.password = newPass;
      saveLocalUsers(users);
      showToast(`@${username} ka password reset ho gaya!`, 'success');
    }

    try {
      fetch(getApiBase() + '/api/admin/users/reset-password', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-admin-key': currentAdminPin || 'muzammil786',
        },
        body: JSON.stringify({ id, newPassword: newPass }),
      }).catch(() => {});
    } catch (err) {}
  };

  window.deleteUserAction = async function (id, username) {
    if (!confirm(`Kya aap sach me @${username} ko delete karna chahte hain? Ye action wapas nahi ho sakta.`)) return;

    let users = getLocalUsers();
    users = users.filter(x => String(x.id) !== String(id) && String(x.username).toLowerCase() !== String(username).toLowerCase());
    saveLocalUsers(users);
    renderUsersTable(users);
    showToast(`User @${username} delete ho gaya!`, 'success');

    try {
      fetch(getApiBase() + '/api/admin/users/delete', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-admin-key': currentAdminPin || 'muzammil786',
        },
        body: JSON.stringify({ id }),
      }).catch(() => {});
    } catch (err) {}
  };
  window.closeAdminLicensePanel = function (e) {
    if (e && e.stopPropagation) e.stopPropagation();
    const el = document.getElementById('mosAdminPanelModal');
    if (el) {
      el.classList.add('hidden');
      el.style.setProperty('display', 'none', 'important');
    }
  };

  window.loadAdminLicensesList = async function () {
    const listContainer = document.getElementById('adminLicTableBody');
    if (!listContainer) return;
    listContainer.innerHTML = '<tr><td colspan="6" style="text-align:center;padding:16px;">Loading licenses from Cloud SQL...</td></tr>';

    try {
      const res = await fetch(getApiBase() + '/api/license/list', {
        headers: { 'x-admin-key': currentAdminPin || 'muzammil786' },
      });
      const data = await res.json();
      if (!data.success) {
        listContainer.innerHTML = `<tr><td colspan="6" style="color:red;padding:16px;">${data.error || 'Failed to load'}</td></tr>`;
        return;
      }

      if (data.licenses.length === 0) {
        listContainer.innerHTML = '<tr><td colspan="6" style="text-align:center;padding:16px;color:#94a3b8;">No licenses created yet.</td></tr>';
        return;
      }

      listContainer.innerHTML = data.licenses.map(lic => {
        const isExp = lic.expiresAt && new Date(lic.expiresAt) < new Date();
        const statusBadge = lic.status === 'revoked'
          ? '<span style="color:#ef4444;font-weight:700;">Revoked</span>'
          : isExp
          ? '<span style="color:#f59e0b;font-weight:700;">Expired</span>'
          : '<span style="color:#10b981;font-weight:700;">Active</span>';

        const expText = lic.expiresAt ? new Date(lic.expiresAt).toLocaleDateString('en-IN') : 'Lifetime';

        return `<tr style="border-bottom:1px solid #334155;">
          <td style="padding:10px;font-family:monospace;font-weight:bold;color:#38bdf8;">
            ${lic.licenseKey}
            <button style="margin-left:6px;font-size:11px;background:#1e293b;border:1px solid #475569;color:#fff;border-radius:4px;padding:2px 6px;cursor:pointer;" onclick="navigator.clipboard.writeText('${lic.licenseKey}');showToast('Key copied!','success');">Copy</button>
          </td>
          <td style="padding:10px;">${lic.clientName} <br><small style="color:#94a3b8;">${lic.shopName || ''} (${lic.clientPhone || 'No Phone'})</small></td>
          <td style="padding:10px;"><span style="text-transform:uppercase;background:#1e293b;padding:3px 8px;border-radius:6px;font-size:12px;">${lic.plan}</span></td>
          <td style="padding:10px;">${statusBadge}</td>
          <td style="padding:10px;font-size:12px;">${expText}</td>
          <td style="padding:10px;">
            ${lic.status === 'active' 
              ? `<button style="background:#ef4444;color:#fff;border:0;padding:4px 8px;border-radius:6px;font-size:11px;cursor:pointer;" onclick="window.toggleLicenseState(${lic.id}, 'revoked')">Block</button>`
              : `<button style="background:#10b981;color:#fff;border:0;padding:4px 8px;border-radius:6px;font-size:11px;cursor:pointer;" onclick="window.toggleLicenseState(${lic.id}, 'active')">Activate</button>`
            }
          </td>
        </tr>`;
      }).join('');
    } catch (err) {
      listContainer.innerHTML = '<tr><td colspan="6" style="color:red;padding:16px;">Server network error.</td></tr>';
    }
  };

  window.toggleLicenseState = async function (id, newStatus) {
    try {
      const res = await fetch(getApiBase() + '/api/license/status', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-admin-key': currentAdminPin || 'muzammil786',
        },
        body: JSON.stringify({ id, status: newStatus }),
      });
      const data = await res.json();
      if (data.success) {
        showToast('License status updated!', 'success');
        window.loadAdminLicensesList();
      } else {
        showToast(data.error || 'Failed to update', 'error');
      }
    } catch (e) {
      showToast('Failed to connect to server', 'error');
    }
  };

  window.handleCreateLicenseForm = async function (e) {
    if (e && e.preventDefault) e.preventDefault();
    const name = document.getElementById('newLicName')?.value;
    const phone = document.getElementById('newLicPhone')?.value;
    const shop = document.getElementById('newLicShop')?.value;
    const plan = document.getElementById('newLicPlan')?.value || 'monthly';
    const days = document.getElementById('newLicDays')?.value || 30;

    if (!name) {
      showToast('Customer Name zaroori hai.', 'error');
      return;
    }

    try {
      const res = await fetch(getApiBase() + '/api/license/create', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-admin-key': currentAdminPin || 'muzammil786',
        },
        body: JSON.stringify({
          clientName: name,
          clientPhone: phone,
          shopName: shop,
          plan: plan,
          days: Number(days),
        }),
      });

      const data = await res.json();
      if (data.success) {
        showToast('🎉 Nayi License Key generate ho gayi!', 'success');
        const resultBox = document.getElementById('adminGeneratedKeyResult');
        if (resultBox) {
          resultBox.style.display = 'block';
          resultBox.innerHTML = `
            <div style="background:#0f172a;border:1px solid #10b981;border-radius:8px;padding:12px;margin-top:10px;">
              <div style="font-size:12px;color:#94a3b8;">Generated License Key (Share with Customer):</div>
              <div style="font-size:18px;font-family:monospace;font-weight:bold;color:#38bdf8;margin:6px 0;">${data.license.licenseKey}</div>
              <div style="font-size:12px;color:#cbd5e1;">Plan: <b>${data.license.plan.toUpperCase()}</b> | Client: <b>${data.license.clientName}</b></div>
              <button style="margin-top:8px;background:#25d366;color:#fff;border:0;padding:6px 12px;border-radius:6px;font-size:12px;font-weight:bold;cursor:pointer;" onclick="window.shareLicenseOnWhatsApp('${encodeURIComponent(data.license.clientPhone || '')}', '${data.license.licenseKey}', '${encodeURIComponent(data.license.clientName)}')">📲 WhatsApp Par Share Karein</button>
            </div>
          `;
        }
        window.loadAdminLicensesList();
      } else {
        showToast(data.error || 'License generation failed', 'error');
      }
    } catch (err) {
      showToast('Server error while creating license', 'error');
    }
  };

  window.shareLicenseOnWhatsApp = function (phone, key, name) {
    const text = `Namaskar ${decodeURIComponent(name)} ji! Aapka Muzammil Online Service app ka official License Key ready hai:%0A%0A🔑 *License Key:* ${key}%0A%0AApp me '🔑 License' par jakar ye key paste karein aur 'Activate' dabayein.%0AHelpline: +91 95614 60313`;
    const url = phone ? `https://wa.me/${phone.replace(/[^0-9]/g, '')}?text=${text}` : `https://wa.me/?text=${text}`;
    window.open(url, '_blank');
  };

  // Universal Cloud Server Sync (Cloud SQL PostgreSQL Asia)
  window.CloudServerSync = {
    isSyncing: false,
    lastSynced: null,
    syncTimer: null,

    // Debounced auto-save to cloud server
    scheduleAutoSave: function (delay = 1200) {
      if (this.syncTimer) clearTimeout(this.syncTimer);
      this.updateStatusUI('saving');
      this.syncTimer = setTimeout(() => {
        this.pushToServer(false);
      }, delay);
    },

    // Push local operator records to Cloud SQL PostgreSQL
    pushToServer: async function (notify = false) {
      if (this.isSyncing) return;
      this.isSyncing = true;
      this.updateStatusUI('saving');

      try {
        const records = {
          mos_bills: localStorage.getItem('mos_bills') || '[]',
          mos_customers: localStorage.getItem('mos_customers') || '[]',
          mos_cv_draft: localStorage.getItem('mos_cv_draft') || '{}',
          mos_audit_log: localStorage.getItem('mos_audit_log') || '[]',
          mos_downloads_history: localStorage.getItem('mos_downloads_history') || '[]',
        };

        const res = await fetch(getApiBase() + '/api/sync/push', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            userUid: 'operator_default',
            records: records,
          }),
        });

        const data = await res.json();
        if (data.success) {
          this.lastSynced = new Date();
          this.updateStatusUI('synced');
          if (notify) showToast('✅ Data Cloud Server par safalta se save ho gaya!', 'success');
        } else {
          this.updateStatusUI('error');
        }
      } catch (err) {
        console.warn('Cloud SQL sync error:', err);
        this.updateStatusUI('offline');
      } finally {
        this.isSyncing = false;
      }
    },

    // Pull saved operator records from Cloud SQL PostgreSQL
    pullFromServer: async function (silent = false) {
      try {
        this.updateStatusUI('syncing');
        const res = await fetch(getApiBase() + '/api/sync/pull?userUid=operator_default');
        const data = await res.json();

        if (data.success && data.records) {
          let hasUpdated = false;

          // Sync Bills
          if (data.records.mos_bills && data.records.mos_bills !== '[]') {
            const serverBills =
              typeof data.records.mos_bills === 'string'
                ? JSON.parse(data.records.mos_bills)
                : data.records.mos_bills;
            if (Array.isArray(serverBills) && serverBills.length > 0) {
              const localBills = JSON.parse(localStorage.getItem('mos_bills') || '[]');
              const billMap = new Map();
              serverBills.forEach((b) => billMap.set(Number(b.id), b));
              localBills.forEach((b) => billMap.set(Number(b.id), b));
              const mergedBills = Array.from(billMap.values()).sort(
                (a, b) => Number(b.id || 0) - Number(a.id || 0)
              );
              localStorage.setItem('mos_bills', JSON.stringify(mergedBills));
              hasUpdated = true;
            }
          }

          // Sync Customers
          if (data.records.mos_customers && data.records.mos_customers !== '[]') {
            const serverCust =
              typeof data.records.mos_customers === 'string'
                ? JSON.parse(data.records.mos_customers)
                : data.records.mos_customers;
            if (Array.isArray(serverCust) && serverCust.length > 0) {
              const localCust = JSON.parse(localStorage.getItem('mos_customers') || '[]');
              const custMap = new Map();
              serverCust.forEach((c) => custMap.set(String(c.mobile || c.id), c));
              localCust.forEach((c) => custMap.set(String(c.mobile || c.id), c));
              localStorage.setItem('mos_customers', JSON.stringify(Array.from(custMap.values())));
              hasUpdated = true;
            }
          }

          // Sync CV Draft
          if (data.records.mos_cv_draft) {
            const draft =
              typeof data.records.mos_cv_draft === 'string'
                ? data.records.mos_cv_draft
                : JSON.stringify(data.records.mos_cv_draft);
            if (draft && draft !== '{}' && !localStorage.getItem('mos_cv_draft')) {
              localStorage.setItem('mos_cv_draft', draft);
              hasUpdated = true;
            }
          }

          this.lastSynced = new Date();
          this.updateStatusUI('synced');

          if (hasUpdated) {
            if (typeof window.renderBills === 'function') window.renderBills();
            if (typeof window.renderCustomers === 'function') window.renderCustomers();
          }
          if (!silent) showToast('Cloud SQL Database se latest data load ho gaya.', 'success');
        } else {
          this.updateStatusUI('synced');
        }
      } catch (err) {
        console.warn('Pull from Cloud SQL error:', err);
        this.updateStatusUI('synced');
      }
    },

    updateStatusUI: function (status) {
      const textEl = document.getElementById('cloudSyncStatusText');
      const dotEl = document.getElementById('cloudPulseDot');
      const btnEl = document.getElementById('cloudSyncBtn');
      if (!textEl || !dotEl) return;

      if (status === 'saving' || status === 'syncing') {
        textEl.textContent = 'Server par save ho raha hai...';
        dotEl.style.background = '#f59e0b';
        dotEl.style.boxShadow = '0 0 8px #f59e0b';
        if (btnEl) btnEl.textContent = '⏳ Saving...';
      } else if (status === 'synced') {
        textEl.textContent = 'Server storage connected & synced (PostgreSQL Cloud SQL Asia)';
        dotEl.style.background = '#4ade80';
        dotEl.style.boxShadow = '0 0 8px #4ade80';
        if (btnEl) btnEl.textContent = '✓ Synced';
      } else if (status === 'offline' || status === 'error') {
        textEl.textContent = 'Saved locally (Server connecting...)';
        dotEl.style.background = '#ef4444';
        dotEl.style.boxShadow = '0 0 8px #ef4444';
        if (btnEl) btnEl.textContent = '🔄 Retry';
      }
    },
  };

  window.triggerManualSync = function () {
    if (window.CloudServerSync) {
      window.CloudServerSync.pushToServer(true);
    }
  };

  // Live Database Inspector Controls
  window.openDatabaseInspector = function () {
    if (!isUserAdmin(window.currentUser)) {
      showToast('Access Denied: Server Database sirf Master Admin ke liye accessible hai.', 'error');
      const el = document.getElementById('mosDbInspectorModal');
      if (el) {
        el.classList.add('hidden');
        el.style.setProperty('display', 'none', 'important');
      }
      return;
    }
    const el = document.getElementById('mosDbInspectorModal');
    if (el) {
      el.classList.remove('hidden');
      el.style.setProperty('display', 'flex', 'important');
      window.loadDatabaseInspectorData();
    }
  };

  window.closeDatabaseInspector = function (e) {
    if (e && e.stopPropagation) e.stopPropagation();
    const el = document.getElementById('mosDbInspectorModal');
    if (el) {
      el.classList.add('hidden');
      el.style.setProperty('display', 'none', 'important');
    }
  };

  window.switchInspectorTab = function (tabId) {
    const tabs = ['bills', 'cust', 'store', 'cv', 'cloud'];
    tabs.forEach((t) => {
      const content = document.getElementById('inspTabContent' + t.charAt(0).toUpperCase() + t.slice(1));
      const btn = document.getElementById('tabBtn' + t.charAt(0).toUpperCase() + t.slice(1));
      if (content) content.style.display = t === tabId ? 'block' : 'none';
      if (btn) {
        btn.style.background = t === tabId ? '#38bdf8' : '#1e293b';
        btn.style.color = t === tabId ? '#0f172a' : '#cbd5e1';
      }
    });
  };

  window.loadDatabaseInspectorData = async function () {
    try {
      const res = await fetch(getApiBase() + '/api/server/database-overview');
      const data = await res.json();
      if (!data.success) {
        showToast('Server database load nahi hua: ' + (data.error || ''), 'error');
        return;
      }

      // Populate Stats
      const statBills = document.getElementById('inspectorStatBills');
      const statCust = document.getElementById('inspectorStatCust');
      const statCv = document.getElementById('inspectorStatCv');
      const statStore = document.getElementById('inspectorStatStore');
      const statLic = document.getElementById('inspectorStatLic');

      if (statBills) statBills.textContent = data.tables?.receipts?.count ?? 0;
      if (statCust) statCust.textContent = data.tables?.customers?.count ?? 0;
      if (statCv) statCv.textContent = data.tables?.cv_drafts?.count ?? 0;
      if (statStore) statStore.textContent = data.tables?.app_store?.count ?? 0;
      if (statLic) statLic.textContent = data.tables?.licenses?.count ?? 0;

      // Populate Bills Table
      const billsBody = document.getElementById('inspTableBillsBody');
      if (billsBody) {
        const bills = data.tables?.receipts?.rows || [];
        if (bills.length === 0) {
          billsBody.innerHTML =
            '<tr><td colspan="7" style="text-align:center;padding:16px;color:#94a3b8;">Koi alag receipt table me nahi hai. Bills `app_store` me live synced hain!</td></tr>';
        } else {
          billsBody.innerHTML = bills
            .map(
              (b) => `
            <tr style="border-bottom:1px solid #334155;">
              <td style="padding:8px 10px;font-family:monospace;color:#38bdf8;">#${b.billNo || b.id}</td>
              <td style="padding:8px 10px;font-weight:bold;">${b.customerName || '-'}</td>
              <td style="padding:8px 10px;color:#94a3b8;">${b.customerMobile || '-'}</td>
              <td style="padding:8px 10px;">${b.serviceName || '-'}</td>
              <td style="padding:8px 10px;color:#34d399;font-weight:bold;">₹${b.amount || 0}</td>
              <td style="padding:8px 10px;"><span style="background:${
                b.status === 'completed' || b.status === 'Paid' ? '#065f46' : '#92400e'
              };color:#fff;padding:2px 6px;border-radius:4px;font-size:11px;">${b.status || 'Pending'}</span></td>
              <td style="padding:8px 10px;color:#94a3b8;font-size:11px;">${
                b.date || (b.createdAt ? new Date(b.createdAt).toLocaleDateString() : '-')
              }</td>
            </tr>
          `
            )
            .join('');
        }
      }

      // Populate Customers Table
      const custBody = document.getElementById('inspTableCustBody');
      if (custBody) {
        const custs = data.tables?.customers?.rows || [];
        if (custs.length === 0) {
          custBody.innerHTML =
            '<tr><td colspan="6" style="text-align:center;padding:16px;color:#94a3b8;">No direct customer rows in table. Check Synced Cloud Payloads tab.</td></tr>';
        } else {
          custBody.innerHTML = custs
            .map(
              (c) => `
            <tr style="border-bottom:1px solid #334155;">
              <td style="padding:8px 10px;font-family:monospace;color:#94a3b8;">#${c.id}</td>
              <td style="padding:8px 10px;font-weight:bold;color:#f8fafc;">${c.name}</td>
              <td style="padding:8px 10px;color:#38bdf8;">${c.mobile || '-'}</td>
              <td style="padding:8px 10px;color:#cbd5e1;">${c.address || '-'}</td>
              <td style="padding:8px 10px;color:#34d399;font-weight:bold;">₹${c.totalSpend || 0}</td>
              <td style="padding:8px 10px;color:#94a3b8;font-size:11px;">${
                c.createdAt ? new Date(c.createdAt).toLocaleDateString() : '-'
              }</td>
            </tr>
          `
            )
            .join('');
        }
      }

      // Populate App Store Key-Value view
      const storeBody = document.getElementById('inspTableStoreBody');
      if (storeBody) {
        const storeRows = data.tables?.app_store?.rows || [];
        if (storeRows.length === 0) {
          storeBody.textContent =
            'app_store table is currently empty. Click "Force Full Push" to sync local data right now.';
        } else {
          storeBody.innerHTML = storeRows
            .map((r) => {
              let summary = r.payload;
              try {
                const parsed = JSON.parse(r.payload);
                if (Array.isArray(parsed)) {
                  summary =
                    `[Array of ${parsed.length} items]\n` +
                    JSON.stringify(parsed.slice(0, 3), null, 2) +
                    (parsed.length > 3 ? `\n... (+${parsed.length - 3} more items)` : '');
                } else if (typeof parsed === 'object') {
                  summary = JSON.stringify(parsed, null, 2);
                }
              } catch (e) {}
              return `// Table: app_store | Key: "${r.storeKey}" | Updated: ${new Date(
                r.updatedAt
              ).toLocaleString()}\n${summary}\n\n`;
            })
            .join('');
        }
      }

      // Populate CV Drafts
      const cvBody = document.getElementById('inspTableCvBody');
      if (cvBody) {
        const cvRows = data.tables?.cv_drafts?.rows || [];
        if (cvRows.length === 0) {
          cvBody.innerHTML =
            '<tr><td colspan="4" style="text-align:center;padding:16px;color:#94a3b8;">No CV drafts stored yet in cv_drafts table.</td></tr>';
        } else {
          cvBody.innerHTML = cvRows
            .map(
              (cv) => `
            <tr style="border-bottom:1px solid #334155;">
              <td style="padding:8px 10px;font-family:monospace;color:#94a3b8;">#${cv.id}</td>
              <td style="padding:8px 10px;font-weight:bold;color:#f8fafc;">${cv.title || 'Untitled CV'}</td>
              <td style="padding:8px 10px;color:#94a3b8;font-size:11px;">${
                cv.updatedAt ? new Date(cv.updatedAt).toLocaleString() : '-'
              }</td>
              <td style="padding:8px 10px;color:#38bdf8;">${
                cv.dataJson ? Math.round(cv.dataJson.length / 1024) + ' KB' : '0 KB'
              }</td>
            </tr>
          `
            )
            .join('');
        }
      }

      showToast('Live Cloud SQL Database loaded successfully!', 'success');
    } catch (err) {
      console.error('Inspector error:', err);
      showToast('Server inspection request failed', 'error');
    }
  };

  // Role-based UI visibility: Master Admin vs Normal User / Operator
  window.applyUserRoleUI = function (user) {
    if (typeof window.checkStaffExpiryAlert === 'function') window.checkStaffExpiryAlert(user);
    const isAdmin = isUserAdmin(user);
    if (isAdmin) {
      document.body.classList.add('is-master-admin');
    } else {
      document.body.classList.remove('is-master-admin');
      const adminModal = document.getElementById('mosAdminPanelModal');
      if (adminModal) {
        adminModal.classList.add('hidden');
        adminModal.style.setProperty('display', 'none', 'important');
      }
      const dbModal = document.getElementById('mosDbInspectorModal');
      if (dbModal) {
        dbModal.classList.add('hidden');
        dbModal.style.setProperty('display', 'none', 'important');
      }
    }

    const adminElements = document.querySelectorAll('.mos-admin-only');
    adminElements.forEach((el) => {
      if (isAdmin) {
        if (el.classList.contains('sideItem')) {
          el.style.display = 'flex';
        } else if (el.tagName === 'BUTTON') {
          el.style.display = 'inline-flex';
        } else if (el.id === 'mosServerSyncBanner') {
          el.style.display = 'flex';
        } else {
          el.style.display = 'block';
        }
      } else {
        el.style.display = 'none';
      }
    });

    const nameEl = document.getElementById('loggedUserName');
    const dotEl = document.getElementById('userStatusDot');
    const headerLoginBtn = document.getElementById('mosHeaderLoginBtn');
    const userBadge = document.getElementById('mosUserHeaderBadge');
    const sideLoginBtn = document.getElementById('mosSideLoginBtn');
    const sideLogoutBtn = document.getElementById('mosSideLogoutBtn');

    if (user) {
      if (headerLoginBtn) headerLoginBtn.style.display = 'none';
      if (userBadge) userBadge.style.display = 'flex';
      if (sideLoginBtn) sideLoginBtn.style.display = 'none';
      if (sideLogoutBtn) {
        sideLogoutBtn.style.display = 'flex';
        sideLogoutBtn.style.opacity = '1';
      }
      if (nameEl) {
        if (isAdmin) {
          nameEl.textContent = '👑 ' + (user.displayName || user.username);
          nameEl.title = 'Master Admin & Owner (Full Control)';
          if (dotEl) dotEl.style.background = '#f59e0b';
        } else {
          nameEl.textContent = '👤 ' + (user.displayName || user.username);
          nameEl.title = user.shopName ? `Shop: ${user.shopName}` : 'Staff Operator';
          if (dotEl) dotEl.style.background = '#10b981';
        }
      }
    } else {
      if (headerLoginBtn) headerLoginBtn.style.display = 'flex';
      if (userBadge) userBadge.style.display = 'none';
      if (sideLogoutBtn) sideLogoutBtn.style.display = 'none';
      if (sideLoginBtn) {
        sideLoginBtn.style.display = 'flex';
        sideLoginBtn.innerHTML = '<span>🔐</span>Login';
        sideLoginBtn.style.opacity = '1';
      }
    }
  };

  window.mosQuickFill = function () {};
  window.switchLoginTab = function () {};

  window.handleMosRegister = async function (e) {
    if (e && e.preventDefault) e.preventDefault();
    const name = document.getElementById('mosRegName')?.value.trim();
    const shop = document.getElementById('mosRegShop')?.value.trim();
    const username = document.getElementById('mosRegUsername')?.value.trim();
    const phone = document.getElementById('mosRegPhone')?.value.trim();
    const password = document.getElementById('mosRegPassword')?.value;
    const err = document.getElementById('mosRegErrorMsg');
    const btn = document.getElementById('mosRegSubmitBtn');

    if (!name || !username || !password) {
      if (err) {
        err.textContent = 'Kripya sabhi zaroori fields bharein.';
        err.style.display = 'block';
      }
      return;
    }

    if (btn) {
      btn.disabled = true;
      btn.textContent = 'Creating Account in Cloud SQL...';
    }

    try {
      const res = await fetch(getApiBase() + '/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          displayName: name,
          shopName: shop,
          username,
          phone,
          password,
        }),
      });
      const data = await res.json();
      if (!data.success || !data.user) {
        throw new Error(data.error || 'Registration failed');
      }

      // Auto login with new user
      localStorage.setItem('mos_user_session', JSON.stringify(data.user));
      window.currentUser = data.user;
      const overlay = document.getElementById('mosAuthOverlay');
      if (overlay) overlay.style.display = 'none';
      const badge = document.getElementById('mosUserHeaderBadge');
      if (badge) badge.style.display = 'flex';
      window.applyUserRoleUI(data.user);
      showToast(`Account successfully ban gaya! Swagat hai, ${data.user.displayName}`, 'success');
    } catch (error) {
      if (err) {
        err.textContent = error.message || 'Registration me dikkat aayi.';
        err.style.display = 'block';
      }
    } finally {
      if (btn) {
        btn.disabled = false;
        btn.textContent = '✅ Naya Account Banayein & Login Karein';
      }
    }
  };

  window.openLoginModal = function () {
    const overlay = document.getElementById('mosAuthOverlay');
    const form = document.getElementById('mosLoginForm');
    if (overlay) overlay.style.display = 'flex';
    if (form) form.style.display = 'flex';
    const err = document.getElementById('mosLoginErrorMsg');
    if (err) err.style.display = 'none';
    const uIn = document.getElementById('mosLoginUsername');
    if (uIn) uIn.focus();
  };

  window.showLoginFormDirectly = function () {
    window.openLoginModal();
  };

  window.enterAppWithExistingSession = function () {
    const overlay = document.getElementById('mosAuthOverlay');
    if (overlay) overlay.style.display = 'none';
  };

  window.continueAsGuest = function () {
    window.openLoginModal();
  };

  window.checkAuthSession = async function () {
    const raw = localStorage.getItem('mos_user_session');
    const overlay = document.getElementById('mosAuthOverlay');
    const badge = document.getElementById('mosUserHeaderBadge');

    if (!raw) {
      const banner = document.getElementById('mosExpiryNoticeBanner');
      if (banner) banner.remove();
      if (overlay) overlay.style.setProperty('display', 'flex', 'important');
      if (badge) badge.style.setProperty('display', 'none', 'important');
      window.applyUserRoleUI(null);
      return false;
    }

    if (!window.verifyActiveUserAccess(true)) {
      return false;
    }

    try {
      const user = JSON.parse(raw);
      window.currentUser = user;
      window.applyUserRoleUI(user);
      if (overlay) overlay.style.display = 'none';
      if (badge) badge.style.display = 'flex';

      // Background verification with server
      fetch(getApiBase() + '/api/auth/verify-session', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: user.username, uid: user.uid }),
      })
        .then((r) => r.json())
        .then((res) => {
          if (!res.valid) {
            window.forceReverseToLoginScreen(res.error || 'Aapka session expire ho gaya hai. Dobara login karein.');
          } else if (res.user) {
            if (isUserExpired(res.user)) {
              window.forceReverseToLoginScreen('Aapka account expire ho chuka hai. Kripya Master Admin se contact karein.');
            } else {
              localStorage.setItem('mos_user_session', JSON.stringify(res.user));
              window.currentUser = res.user;
              window.applyUserRoleUI(res.user);
            }
          }
        })
        .catch(() => {});

      return true;
    } catch (e) {
      window.forceReverseToLoginScreen('Session invalid hai. Dobara login karein.');
      return false;
    }
  };

  window.handleMosLogin = async function (e) {
    if (e && e.preventDefault) e.preventDefault();
    const usernameInput = document.getElementById('mosLoginUsername');
    const passwordInput = document.getElementById('mosLoginPassword');
    const errorMsg = document.getElementById('mosLoginErrorMsg');
    const btn = document.getElementById('mosLoginSubmitBtn');

    const username = usernameInput ? usernameInput.value.trim() : '';
    const password = passwordInput ? passwordInput.value.trim() : '';

    if (!username || !password) {
      if (errorMsg) {
        errorMsg.textContent = 'Username aur Password dono zaroori hain!';
        errorMsg.style.display = 'block';
      }
      return;
    }

    if (errorMsg) errorMsg.style.display = 'none';
    if (btn) {
      btn.disabled = true;
      btn.textContent = '⏳ Verifying...';
    }

    const cleanUser = username.toLowerCase();
    const isMasterUser = cleanUser === 'admin' || cleanUser === 'imran';

    // 🔒 1. ABSOLUTE HARD STOP FOR MASTER ADMIN:
    if (isMasterUser) {
      if (password !== 'muzammil786') {
        if (btn) {
          btn.disabled = false;
          btn.textContent = '🔐 Login';
        }
        const err = '❌ Galat password! Kripya sahi password enter karein.';
        if (errorMsg) {
          errorMsg.textContent = err;
          errorMsg.style.display = 'block';
        }
        if (passwordInput) passwordInput.value = '';
        showToast(err, 'error');
        return;
      }
    }

    try {
      let serverResponse = null;
      let serverError = null;

      // 1. Try server login first
      try {
        const res = await fetch(getApiBase() + '/api/auth/login', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ username, password }),
        });
        const json = await res.json();
        if (json.success && json.user) {
          serverResponse = json.user;
        } else {
          serverError = json.error || 'Galat username ya password.';
        }
      } catch (networkErr) {
        console.warn('Network offline / deferred server login:', networkErr);
      }

      // If server responded with a definitive error, DO NOT guess with offline fallback!
      if (serverError) {
        if (btn) {
          btn.disabled = false;
          btn.textContent = '🔐 Login';
        }
        if (errorMsg) {
          errorMsg.textContent = serverError;
          errorMsg.style.display = 'block';
        }
        showToast(serverError, 'error');
        return;
      }

      let activeUser = serverResponse;

      // 2. Offline / local fallback only if network completely failed
      if (!activeUser) {
        if (isMasterUser) {
          if (password === 'muzammil786') {
            activeUser = {
              uid: 'admin_imran_master',
              username: 'imran',
              displayName: 'Imran Khan (Owner)',
              role: 'admin',
              status: 'active',
              shopName: 'Muzammil Online Service Head Office',
              expiresAt: null
            };
          }
        } else {
          const localUsers = getLocalUsers();
          const matched = localUsers.find(u =>
            String(u.username).toLowerCase() === cleanUser || String(u.phone).trim() === cleanUser
          );

          if (!matched) {
            throw new Error('User nahi mila! Kripya sahi username ya mobile number bharein.');
          }

          // Check password
          const expected = matched.password;
          if (expected && expected !== password) {
            throw new Error('❌ Galat password! Operator ka sahi password darj karein.');
          }

          if (matched.status === 'blocked') {
            throw new Error('⛔ Aapka account admin dwara block kar diya gaya hai.');
          }

          if (matched.expires_at && new Date(matched.expires_at).getTime() < Date.now()) {
            throw new Error('⛔ Aapka account expire ho chuka hai! Master Admin Imran Khan (+91 9561460313) se contact karein.');
          }

          activeUser = {
            uid: matched.uid || ('usr_' + matched.username),
            username: matched.username,
            displayName: matched.displayName || matched.display_name || matched.username,
            role: matched.role || 'operator',
            status: matched.status || 'active',
            shopName: matched.shopName || matched.shop_name || '',
            phone: matched.phone || '',
            expiresAt: matched.expires_at || null
          };
        }
      }

      if (!activeUser) {
        throw new Error('Login nahi ho saka. Kripya dobara koshish karein.');
      }

      // Check Expiration
      if (isUserExpired(activeUser)) {
        const expDate = activeUser.expiresAt || activeUser.expires_at ? new Date(activeUser.expiresAt || activeUser.expires_at).toLocaleDateString('en-IN') : '';
        window.forceReverseToLoginScreen(`⛔ Yeh account expire ho chuka hai (${expDate})! Kripya Master Admin Imran Khan (+91 9561460313) se validity renew karwayein.`);
        return;
      }

      // Successful Login
      localStorage.setItem('mos_user_session', JSON.stringify(activeUser));
      window.currentUser = activeUser;

      const overlay = document.getElementById('mosAuthOverlay');
      if (overlay) overlay.style.display = 'none';

      const badge = document.getElementById('mosUserHeaderBadge');
      if (badge) badge.style.display = 'flex';

      window.applyUserRoleUI(activeUser);

      showToast(`Swagat hai, ${activeUser.displayName || activeUser.username}!`, 'success');

      if (typeof window.renderBills === 'function') window.renderBills();
      if (typeof window.renderCustomers === 'function') window.renderCustomers();

      if (window.CloudServerSync) {
        window.CloudServerSync.pullFromServer(true);
      }
    } catch (err) {
      console.error('Login error:', err);
      if (errorMsg) {
        errorMsg.textContent = err.message || 'Login nahi ho saka.';
        errorMsg.style.display = 'block';
      }
      showToast(err.message || 'Login failed', 'error');
    } finally {
      if (btn) {
        btn.disabled = false;
        btn.textContent = '🔐 Login';
      }
    }
  };
  window.mosLogout = function () {
    if (!confirm('Kya aap sach me logout karna chahte hain?')) return;
    localStorage.removeItem('mos_user_session');
    window.currentUser = null;
    window.applyUserRoleUI(null);

    const overlay = document.getElementById('mosAuthOverlay');
    const form = document.getElementById('mosLoginForm');
    if (overlay) overlay.style.display = 'flex';
    if (form) form.style.display = 'flex';

    const uInput = document.getElementById('mosLoginUsername');
    if (uInput) uInput.value = '';
    const passInput = document.getElementById('mosLoginPassword');
    if (passInput) passInput.value = '';
    const errorMsg = document.getElementById('mosLoginErrorMsg');
    if (errorMsg) errorMsg.style.display = 'none';

    const badge = document.getElementById('mosUserHeaderBadge');
    if (badge) badge.style.display = 'none';

    showToast('Aap successfully logout ho chuke hain.', 'success');
  };

  window.toggleLoginPasswordVisibility = function () {
    const input = document.getElementById('mosLoginPassword');
    if (!input) return;
    input.type = input.type === 'password' ? 'text' : 'password';
  };

  // PWA & Mobile Installation Handler
  let deferredInstallPrompt = null;
  window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    deferredInstallPrompt = e;
  });

  window.triggerPWAInstall = async function () {
    if (deferredInstallPrompt) {
      deferredInstallPrompt.prompt();
      const { outcome } = await deferredInstallPrompt.userChoice;
      if (outcome === 'accepted') {
        showToast('App aapke mobile par install ho raha hai! 🎉', 'success');
        deferredInstallPrompt = null;
      }
    } else {
      showToast('📱 Android par install karne ke liye Chrome menu (⋮) me "Install app" ya "Add to Home screen" par tap karein.', 'info');
    }
  };

  // Register Service Worker for PWA
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('/sw.js').catch((err) => {
        console.warn('SW registration failed:', err);
      });
    });
  }

  const initMosBridge = () => {
    initLiveClock();
    // Check mandatory login session
    window.checkAuthSession();
    // Pull and sync latest cloud data on page load
    if (window.CloudServerSync) {
      window.CloudServerSync.pullFromServer(true);
    }
  };

  if (document.readyState === 'loading') {
    window.addEventListener('DOMContentLoaded', initMosBridge);
  } else {
    initMosBridge();
  }
})();


