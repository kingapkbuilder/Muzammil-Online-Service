plugins { id("com.android.application") }
android {
    namespace="com.muzammil.onlineservice"
    compileSdk=35
    defaultConfig {
        applicationId="com.muzammil.onlineservice"
        minSdk=24
        targetSdk=35
        versionCode = 41
        versionName = "4.4"
    }
}


dependencies { implementation("androidx.core:core:1.15.0") }
