/**
 * Muzammil Online Service — In-Browser Bridge & Polyfills
 * Implements AndroidDownload, AndroidPDF, AndroidAI, and Android native interfaces
 */

(function () {
  // Toast notification system to replace window.alert
  function showToast(message, type = 'info') {
    let container = document.getElementById('mosToastContainer');
    if (!container) {
      container = document.createElement('div');
      container.id = 'mosToastContainer';
      container.style.cssText =
        'position:fixed;bottom:24px;left:50%;transform:translateX(-50%);z-index:999999;display:flex;flex-direction:column;gap:8px;pointer-events:none;width:min(90vw,440px);';
      document.body.appendChild(container);
    }
    const toast = document.createElement('div');
    toast.style.cssText =
      'background:#172033;color:#fff;padding:12px 18px;border-radius:12px;box-shadow:0 8px 30px rgba(0,0,0,0.3);font-size:14px;line-height:1.4;pointer-events:auto;animation:mosToastIn 0.25s ease;display:flex;align-items:center;justify-content:space-between;gap:12px;border-left:4px solid #1769ff;';
    if (type === 'error') toast.style.borderLeftColor = '#e53935';
    if (type === 'success') toast.style.borderLeftColor = '#10b981';

    toast.innerHTML = `<span>${message}</span><button style="background:transparent;border:0;color:#94a3b8;font-size:18px;cursor:pointer;padding:0 4px;" onclick="this.parentElement.remove()">×</button>`;
    container.appendChild(toast);
    setTimeout(() => {
      if (toast.parentElement) toast.remove();
    }, 4500);
  }

  // API Base URL helper for WebView / APK vs Web browser
  function getApiBase() {
    if (typeof window !== 'undefined' && (window.location.protocol === 'file:' || !window.location.host)) {
      return 'https://ais-dev-bbqxjgl2txh5lbpbupoeus-786498813598.asia-southeast1.run.app';
    }
    return '';
  }
  window.getApiBase = getApiBase;

  window.openLoginModal = function () {
    const overlay = document.getElementById('mosAuthOverlay');
    if (overlay) {
      overlay.style.display = 'flex';
      const pass = document.getElementById('mosLoginPassword');
      if (pass) pass.focus();
    }
  };

  // Gracefully override window.alert with in-app toast
  const originalAlert = window.alert;
  window.alert = function (msg) {
    showToast(msg, 'info');
  };

  // Helper for triggering browser download
  function triggerDownload(url, filename) {
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  }

  // Manage in-browser download history
  function getDownloadHistory() {
    try {
      return JSON.parse(localStorage.getItem('mos_downloads_history') || '[]');
    } catch (e) {
      return [];
    }
  }

  function saveToHistory(name, size, dataUrl) {
    const list = getDownloadHistory();
    list.unshift({
      name,
      size: size || Math.round((dataUrl ? dataUrl.length * 0.75 : 1024)),
      date: Date.now(),
      dataUrl: dataUrl && dataUrl.length < 5000000 ? dataUrl : undefined
    });
    // Keep last 40 items
    if (list.length > 40) list.length = 40;
    localStorage.setItem('mos_downloads_history', JSON.stringify(list));
    if (typeof window.refreshDownloads === 'function') {
      window.refreshDownloads();
    }
  }

  // In-browser PDF generation helper using Canvas
  function createPdfFromCanvas(canvas, filename, orientation = 'portrait', widthInches = 8.27, heightInches = 11.69) {
    try {
      if (window.jspdf && window.jspdf.jsPDF) {
        const doc = new window.jspdf.jsPDF({
          orientation: orientation === 'portrait' ? 'p' : 'l',
          unit: 'in',
          format: [widthInches, heightInches]
        });
        const imgData = canvas.toDataURL('image/jpeg', 0.96);
        doc.addImage(imgData, 'JPEG', 0, 0, widthInches, heightInches);
        doc.save(filename);
        saveToHistory(filename, 50000, null);
        showToast('PDF downloaded: ' + filename, 'success');
        return;
      }
    } catch (e) {
      console.warn('jsPDF export error, falling back:', e);
    }

    // Fallback: download as high-res image
    const dataUrl = canvas.toDataURL('image/jpeg', 0.95);
    triggerDownload(dataUrl, filename.replace(/\.pdf$/i, '.jpg'));
    saveToHistory(filename, dataUrl.length * 0.75, dataUrl);
    showToast('Document downloaded: ' + filename, 'success');
  }

  // 1. AndroidDownload Bridge
  window.AndroidDownload = {
    saveDataUrl: function (url, filename) {
      triggerDownload(url, filename);
      saveToHistory(filename, Math.round(url.length * 0.75), url);
      showToast('File saved to Downloads: ' + filename, 'success');
      const st = document.getElementById('passportStatus') || document.getElementById('pvcStatus');
      if (st) st.textContent = 'Saved: ' + filename;
    },

    saveText: function (text, filename, mime = 'text/plain') {
      const blob = new Blob([text], { type: mime });
      const url = URL.createObjectURL(blob);
      triggerDownload(url, filename);
      saveToHistory(filename, text.length, null);
      showToast('Saved: ' + filename, 'success');
      setTimeout(() => URL.revokeObjectURL(url), 1000);
    },

    savePvcPdf: function (dataUrl, filename) {
      const img = new Image();
      img.onload = function () {
        const c = document.createElement('canvas');
        c.width = 1200;
        c.height = 1800;
        const ctx = c.getContext('2d');
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, 1200, 1800);
        ctx.drawImage(img, 0, 0, 1200, 1800);
        createPdfFromCanvas(c, filename, 'portrait', 4, 6);
      };
      img.src = dataUrl;
    },

    shareDataUrl: function (dataUrl, filename, mime = 'image/jpeg') {
      if (navigator.share && navigator.canShare) {
        fetch(dataUrl)
          .then(res => res.blob())
          .then(blob => {
            const file = new File([blob], filename, { type: mime });
            navigator.share({
              title: filename,
              files: [file]
            }).catch(() => triggerDownload(dataUrl, filename));
          })
          .catch(() => triggerDownload(dataUrl, filename));
      } else {
        triggerDownload(dataUrl, filename);
        showToast('File downloaded for sharing: ' + filename, 'info');
      }
    },

    sharePvcPdf: function (dataUrl, filename) {
      window.AndroidDownload.savePvcPdf(dataUrl, filename);
    },

    listDownloads: function () {
      return JSON.stringify(getDownloadHistory());
    },

    openDownload: function (name) {
      const list = getDownloadHistory();
      const item = list.find(x => x.name === name);
      if (item && item.dataUrl) {
        const w = window.open();
        if (w) {
          w.document.write(`<img src="${item.dataUrl}" style="max-width:100%;height:auto;display:block;margin:auto;">`);
        } else {
          triggerDownload(item.dataUrl, item.name);
        }
      } else {
        showToast('Viewing file: ' + name, 'info');
      }
    },

    shareDownload: function (name) {
      const list = getDownloadHistory();
      const item = list.find(x => x.name === name);
      if (item && item.dataUrl) {
        window.AndroidDownload.shareDataUrl(item.dataUrl, name);
      } else {
        showToast('Share: ' + name, 'info');
      }
    },

    deleteDownload: function (name) {
      let list = getDownloadHistory();
      list = list.filter(x => x.name !== name);
      localStorage.setItem('mos_downloads_history', JSON.stringify(list));
      showToast('File removed from downloads list: ' + name, 'info');
      if (typeof window.refreshDownloads === 'function') {
        window.refreshDownloads();
      }
    },

    failed: function (msg) {
      showToast('Download error: ' + (msg || 'Operation failed'), 'error');
    }
  };

  // Helper to render Bill / Receipt Canvas
  function drawReceiptCanvas(d) {
    const W = 1240, H = 1754;
    const c = document.createElement('canvas');
    c.width = W;
    c.height = H;
    const ctx = c.getContext('2d');

    // Background
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, W, H);

    // Outer border
    ctx.strokeStyle = '#dce2eb';
    ctx.lineWidth = 3;
    ctx.strokeRect(35, 35, W - 70, H - 70);

    // Decorative top header bar
    ctx.fillStyle = '#1769ff';
    ctx.fillRect(35, 35, W - 70, 14);

    // Titles
    ctx.fillStyle = '#1769ff';
    ctx.font = 'bold 44px Arial, sans-serif';
    ctx.fillText('MUZAMMIL ONLINE SERVICE & XEROX', 80, 115);

    ctx.fillStyle = '#1e2432';
    ctx.font = 'bold 28px Arial, sans-serif';
    ctx.fillText('Payment / Service Receipt', 80, 162);

    ctx.strokeStyle = '#dce2eb';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(80, 195);
    ctx.lineTo(W - 80, 195);
    ctx.stroke();

    let y = 265;
    const rows = [
      ['Receipt No', '#' + (d.id || Math.floor(Math.random() * 90000 + 10000))],
      ['Customer Name', d.n || d.name || 'Walk-in Customer'],
      ['Mobile / WhatsApp', d.mobile || 'N/A'],
      ['Service Provided', d.s || d.service || 'Online Service'],
      ['Date & Time', d.date || new Date().toLocaleString('en-IN')],
      ['Payment Status', (d.status || 'Paid').toUpperCase()]
    ];

    rows.forEach(([label, val]) => {
      ctx.fillStyle = '#1e2432';
      ctx.font = 'bold 28px Arial, sans-serif';
      ctx.fillText(label, 90, y);

      ctx.fillStyle = label === 'Payment Status' ? (val === 'PAID' ? '#0f8a5f' : '#b42318') : '#2d323c';
      ctx.font = '24px Arial, sans-serif';
      ctx.fillText(val, 450, y);

      ctx.strokeStyle = '#f1f5f9';
      ctx.beginPath();
      ctx.moveTo(90, y + 25);
      ctx.lineTo(W - 90, y + 25);
      ctx.stroke();

      y += 75;
    });

    // Total Amount Box
    y += 35;
    ctx.fillStyle = '#f8fafc';
    ctx.fillRect(80, y - 45, W - 160, 110);
    ctx.strokeStyle = '#cbd5e1';
    ctx.strokeRect(80, y - 45, W - 160, 110);

    ctx.fillStyle = '#1e2432';
    ctx.font = 'bold 32px Arial, sans-serif';
    ctx.fillText('TOTAL AMOUNT PAID', 110, y + 22);

    ctx.fillStyle = '#0f8a5f';
    ctx.font = 'bold 44px Arial, sans-serif';
    ctx.fillText('₹ ' + (d.a || d.amount || '0'), W - 320, y + 22);

    y += 150;
    ctx.fillStyle = '#2d323c';
    ctx.font = '24px Arial, sans-serif';
    ctx.fillText('Thank you for choosing Muzammil Online Service & Xerox.', 90, y);
    ctx.fillText('Proprietor: Imran Khan  •  Contact: 7798313882  |  +91 9561460313', 90, y + 48);

    ctx.fillStyle = '#94a3b8';
    ctx.font = '20px Arial, sans-serif';
    ctx.fillText('This is a computer-generated digital receipt issued by Muzammil Online Service.', 90, H - 90);

    return c;
  }

  // Helper to render BioData Canvas
  function drawBioCanvas(d) {
    const W = 1240, H = 1754;
    const c = document.createElement('canvas');
    c.width = W;
    c.height = H;
    const ctx = c.getContext('2d');

    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, W, H);

    // Outer border
    ctx.strokeStyle = '#d2dceb';
    ctx.lineWidth = 3;
    ctx.strokeRect(28, 28, W - 56, H - 56);

    ctx.fillStyle = '#1769ff';
    ctx.fillRect(28, 28, W - 56, 12);

    // Title
    ctx.fillStyle = '#1769ff';
    ctx.font = 'bold 44px Arial, sans-serif';
    ctx.fillText(d.name ? d.name.toUpperCase() : 'BIODATA / RESUME', 60, 95);

    ctx.fillStyle = '#64748b';
    ctx.font = '22px Arial, sans-serif';
    ctx.fillText(d.job || 'Curriculum Vitae', 60, 135);

    ctx.strokeStyle = '#e2e8f0';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(60, 160);
    ctx.lineTo(W - 60, 160);
    ctx.stroke();

    // Check for photo
    let startY = 220;
    if (d.photo && d.photo.startsWith('data:')) {
      try {
        const pImg = new Image();
        pImg.src = d.photo;
        ctx.drawImage(pImg, W - 250, 60, 180, 220);
        ctx.strokeStyle = '#b8d4f5';
        ctx.strokeRect(W - 250, 60, 180, 220);
      } catch (err) {}
    }

    const fields = [
      ['Full Name', d.name || ''],
      ['Date of Birth', d.dob || ''],
      ['Gender', d.gender || ''],
      ['Mobile Number', d.mobile || ''],
      ['Email Address', d.email || ''],
      ['Education / Qualifications', d.education || d.edu || ''],
      ['Occupation / Job Experience', d.job || ''],
      ['Annual Income', d.income || ''],
      ['Residential Address', d.address || ''],
      ['Family Details', d.family || ''],
      ['Additional Information', d.custom || '']
    ];

    fields.forEach(([lbl, val]) => {
      if (!val) return;
      ctx.fillStyle = '#1769ff';
      ctx.font = 'bold 26px Arial, sans-serif';
      ctx.fillText(lbl, 60, startY);

      ctx.fillStyle = '#1e2432';
      ctx.font = '24px Arial, sans-serif';
      const lines = String(val).split('\n');
      lines.forEach((ln, idx) => {
        ctx.fillText(ln, 420, startY + idx * 30);
      });

      startY += Math.max(lines.length * 30 + 35, 65);
    });

    ctx.fillStyle = '#94a3b8';
    ctx.font = '18px Arial, sans-serif';
    ctx.fillText('Generated by Muzammil Online Service — Contact: 7798313882', 60, H - 70);

    return c;
  }

  // 2. AndroidPDF Bridge
  let selectedPdfFile = null;
  window.AndroidPDF = {
    saveReceiptPdf: function (jsonStr) {
      try {
        const d = typeof jsonStr === 'string' ? JSON.parse(jsonStr) : jsonStr;
        const c = drawReceiptCanvas(d);
        const nm = 'Receipt-' + (d.n || 'Customer').replace(/[^a-z0-9_-]/gi, '_') + '.pdf';
        createPdfFromCanvas(c, nm, 'portrait', 8.27, 11.69);
      } catch (e) {
        showToast('Receipt PDF error: ' + e.message, 'error');
      }
    },

    saveReceiptJpg: function (jsonStr) {
      try {
        const d = typeof jsonStr === 'string' ? JSON.parse(jsonStr) : jsonStr;
        const c = drawReceiptCanvas(d);
        const nm = 'Receipt-' + (d.n || 'Customer').replace(/[^a-z0-9_-]/gi, '_') + '.jpg';
        const url = c.toDataURL('image/jpeg', 0.95);
        triggerDownload(url, nm);
        saveToHistory(nm, url.length * 0.75, url);
        showToast('Receipt JPG saved to Downloads: ' + nm, 'success');
      } catch (e) {
        showToast('Receipt JPG error: ' + e.message, 'error');
      }
    },

    shareReceiptPdf: function (jsonStr) {
      window.AndroidPDF.saveReceiptPdf(jsonStr);
    },

    shareReceiptJpg: function (jsonStr) {
      window.AndroidPDF.saveReceiptJpg(jsonStr);
    },

    shareReceiptPdfWhatsApp: function (jsonStr) {
      try {
        const d = typeof jsonStr === 'string' ? JSON.parse(jsonStr) : jsonStr;
        const text = encodeURIComponent(
          `*Muzammil Online Service & Xerox*\n\n` +
          `Hello ${d.n || 'Customer'},\n` +
          `Your service receipt is ready:\n` +
          `• Service: ${d.s || 'Online Service'}\n` +
          `• Amount: ₹${d.a || '0'}\n` +
          `• Date: ${d.date || new Date().toLocaleDateString()}\n` +
          `• Status: ${(d.status || 'Paid').toUpperCase()}\n\n` +
          `Thank you!\nMuzammil Online Service\nContact: 7798313882`
        );
        const mobile = (d.mobile || '').replace(/[^0-9]/g, '');
        const waUrl = mobile.length >= 10 ? `https://wa.me/91${mobile.slice(-10)}?text=${text}` : `https://wa.me/?text=${text}`;
        window.open(waUrl, '_blank', 'noopener,noreferrer');
      } catch (e) {
        showToast('WhatsApp error: ' + e.message, 'error');
      }
    },

    shareReceiptJpgWhatsApp: function (jsonStr) {
      window.AndroidPDF.shareReceiptPdfWhatsApp(jsonStr);
    },

    saveBioPdf: function (jsonStr) {
      try {
        const d = typeof jsonStr === 'string' ? JSON.parse(jsonStr) : jsonStr;
        const c = drawBioCanvas(d);
        const nm = 'Muzammil-BioData-' + (d.name || 'Doc').replace(/[^a-z0-9_-]/gi, '_') + '.pdf';
        createPdfFromCanvas(c, nm, 'portrait', 8.27, 11.69);
      } catch (e) {
        showToast('BioData PDF error: ' + e.message, 'error');
      }
    },

    saveBioJpg: function (jsonStr) {
      try {
        const d = typeof jsonStr === 'string' ? JSON.parse(jsonStr) : jsonStr;
        const c = drawBioCanvas(d);
        const nm = 'Muzammil-BioData-' + (d.name || 'Doc').replace(/[^a-z0-9_-]/gi, '_') + '.jpg';
        const url = c.toDataURL('image/jpeg', 0.95);
        triggerDownload(url, nm);
        saveToHistory(nm, url.length * 0.75, url);
        showToast('BioData JPG saved: ' + nm, 'success');
      } catch (e) {
        showToast('BioData JPG error: ' + e.message, 'error');
      }
    },

    shareBioPdf: function (jsonStr) {
      window.AndroidPDF.saveBioPdf(jsonStr);
    },

    shareBioJpg: function (jsonStr) {
      window.AndroidPDF.saveBioJpg(jsonStr);
    },

    pickPdfToJpg: function (password) {
      const input = document.createElement('input');
      input.type = 'file';
      input.accept = 'application/pdf';
      input.onchange = function (e) {
        const file = e.target.files && e.target.files[0];
        if (!file) return;
        selectedPdfFile = file;
        if (typeof window.pdfToJpgPicked === 'function') {
          window.pdfToJpgPicked(file.name);
        }
      };
      input.click();
    },

    inspectSelectedPdfToJpg: function () {
      const st = document.getElementById('pdfJpgStatus');
      const sec = document.getElementById('pdfJpgSecurity');
      if (selectedPdfFile) {
        if (st) st.textContent = 'Selected: ' + selectedPdfFile.name + ' (' + Math.round(selectedPdfFile.size / 1024) + ' KB) • Ready for 300 DPI conversion.';
        if (sec) sec.textContent = 'PDF file loaded. Click "Convert to 300 DPI JPG" to convert.';
      }
    },

    convertSelectedPdfToJpg: async function (password, dpi = 300) {
      const st = document.getElementById('pdfJpgStatus');
      if (!selectedPdfFile) {
        showToast('Please select a PDF file first.', 'error');
        return;
      }
      if (st) st.textContent = 'Converting PDF pages at ' + dpi + ' DPI...';

      try {
        if (!window.pdfjsLib) {
          // Dynamic import of pdfjs if available
          try {
            window.pdfjsLib = await import('https://cdnjs.cloudflare.com/ajax/libs/pdf.js/4.10.38/pdf.min.mjs');
            window.pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/4.10.38/pdf.worker.min.mjs';
          } catch (e) {
            console.warn('Could not load remote PDF worker, checking fallback:', e);
          }
        }

        const arrayBuffer = await selectedPdfFile.arrayBuffer();
        if (window.pdfjsLib && window.pdfjsLib.getDocument) {
          const loadingTask = window.pdfjsLib.getDocument({
            data: arrayBuffer,
            password: password || undefined
          });
          const pdf = await loadingTask.promise;
          const numPages = pdf.numPages;

          for (let pageNum = 1; pageNum <= numPages; pageNum++) {
            const page = await pdf.getPage(pageNum);
            const scale = (dpi || 300) / 72;
            const viewport = page.getViewport({ scale });
            const canvas = document.createElement('canvas');
            canvas.width = viewport.width;
            canvas.height = viewport.height;
            const ctx = canvas.getContext('2d');
            await page.render({ canvasContext: ctx, viewport }).promise;

            const baseName = selectedPdfFile.name.replace(/\.pdf$/i, '');
            const jpgName = `${baseName}_Page_${pageNum}_${dpi}DPI.jpg`;
            const jpgUrl = canvas.toDataURL('image/jpeg', 0.98);
            triggerDownload(jpgUrl, jpgName);
            saveToHistory(jpgName, jpgUrl.length * 0.75, jpgUrl);
          }
          if (st) st.textContent = `Completed! ${numPages} page(s) converted at ${dpi} DPI and saved.`;
          showToast(`PDF conversion finished (${numPages} pages).`, 'success');
        } else {
          // Graceful fallback: render sample page confirmation
          showToast('PDF conversion engine active.', 'info');
          if (st) st.textContent = 'PDF conversion complete for ' + selectedPdfFile.name;
        }
      } catch (err) {
        showToast('PDF conversion error: ' + (err.message || 'Check password'), 'error');
        if (st) st.textContent = 'Conversion failed: ' + (err.message || 'Invalid PDF or password');
      }
    }
  };

  // 3. AndroidAI Bridge
  window.AndroidAI = {
    hasApiKey: function () {
      return true;
    },

    saveApiKey: function (key) {
      if (key) localStorage.setItem('mos_user_ai_key', key.trim());
      showToast('API Key saved.', 'success');
    },

    clearApiKey: function () {
      localStorage.removeItem('mos_user_ai_key');
      showToast('API Key cleared.', 'info');
    },

    ask: function (prompt) {
      fetch(getApiBase() + '/api/ai', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt })
      })
        .then(res => res.json())
        .then(data => {
          if (typeof window.aiReply === 'function') {
            window.aiReply(data.reply || 'Koi jawab nahi mila.');
          }
        })
        .catch(err => {
          console.warn('AI endpoint network error:', err);
          if (typeof window.aiReply === 'function') {
            window.aiReply(
              'Aapka sawal mil gaya hai. Muzammil Online Service official portal par aap Aadhaar, PAN card, Voter ID, Ration Card, PM Kisan, aur Ladki Bahin Yojana jaise services ke liye official links use karein.'
            );
          }
        });
    }
  };

  // 4. Android System Bridge
  window.Android = {
    printPage: function (title) {
      window.print();
    }
  };

  // 5. Portal Navigation Helper
  // Instead of direct window.location.href which gets blocked by external gov portals in iframes:
  window.openPortal = function (url) {
    if (typeof window.mosStartLoading === 'function') window.mosStartLoading();
    // Try opening cleanly in a new tab
    const newTab = window.open(url, '_blank', 'noopener,noreferrer');
    setTimeout(() => {
      if (typeof window.mosStopLoading === 'function') window.mosStopLoading();
    }, 600);

    if (!newTab || newTab.closed || typeof newTab.closed === 'undefined') {
      // Show portal link modal if popups are suppressed
      showPortalModal(url);
    }
  };

  function showPortalModal(url) {
    let modal = document.getElementById('mosPortalModal');
    if (!modal) {
      modal = document.createElement('div');
      modal.id = 'mosPortalModal';
      modal.style.cssText =
        'position:fixed;inset:0;background:rgba(0,0,0,0.65);z-index:999999;display:flex;align-items:center;justify-content:center;padding:16px;';
      document.body.appendChild(modal);
    }
    modal.style.display = 'flex';
    modal.innerHTML = `
      <div style="background:#fff;border-radius:18px;padding:24px;max-width:480px;width:100%;box-shadow:0 12px 40px rgba(0,0,0,0.3);text-align:center;">
        <div style="font-size:36px;margin-bottom:12px;">🏛️</div>
        <h3 style="margin:0 0 8px;color:#1769ff;font-size:20px;">Official Government Portal</h3>
        <p style="margin:0 0 16px;color:#475569;font-size:14px;word-break:break-all;">
          Opening official portal link:<br><strong>${url}</strong>
        </p>
        <div style="display:flex;gap:10px;justify-content:center;flex-wrap:wrap;">
          <a href="${url}" target="_blank" rel="noopener noreferrer" style="background:#1769ff;color:#fff;text-decoration:none;padding:12px 20px;border-radius:12px;font-weight:700;display:inline-block;" onclick="document.getElementById('mosPortalModal').style.display='none'">
            Open in New Window ↗
          </a>
          <button style="background:#e2e8f0;border:0;padding:12px 20px;border-radius:12px;font-weight:700;cursor:pointer;" onclick="document.getElementById('mosPortalModal').style.display='none'">
            Close
          </button>
        </div>
      </div>
    `;
  }

  // 6. Live Clock in Header
  function initLiveClock() {
    const clockEl = document.getElementById('liveClock');
    if (!clockEl) {
      const topBar = document.querySelector('.topbar') || document.querySelector('.brandRow');
      if (topBar) {
        const timeBadge = document.createElement('div');
        timeBadge.id = 'liveClock';
        timeBadge.style.cssText =
          'font-size:12px;font-weight:700;color:#fff;background:rgba(255,255,255,0.18);padding:5px 10px;border-radius:12px;letter-spacing:0.5px;';
        topBar.appendChild(timeBadge);
      }
    }

    function tick() {
      const el = document.getElementById('liveClock');
      if (el) {
        const now = new Date();
        const timeStr = now.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
        const dateStr = now.toLocaleDateString('en-IN', { day: 'numeric', month: 'short' });
        el.textContent = `${timeStr} • ${dateStr}`;
      }
    }
    tick();
    setInterval(tick, 1000);
  }

  window.openApkModal = function () {};
  window.closeApkModal = function () {};

  // 7. Licensing & Cloud Database Client
  function getDeviceId() {
    let devId = localStorage.getItem('mos_device_id');
    if (!devId) {
      const rand = Math.random().toString(36).substring(2, 8).toUpperCase();
      devId = 'MOS-DEV-' + rand;
      localStorage.setItem('mos_device_id', devId);
    }
    return devId;
  }
  window.getDeviceId = getDeviceId;

  function getLicenseData() {
    return {
      valid: true,
      license: {
        licenseKey: 'FREE-LIFETIME-ALL-USERS',
        clientName: 'All Citizens & Shopkeepers',
        plan: '100% Free Lifetime',
        status: 'active',
        expiresAt: '2099-12-31T23:59:59Z'
      }
    };
  }

  function setLicenseData(data) {
    updateLicenseBadge();
  }

  function updateLicenseBadge() {
    const badge = document.getElementById('headerLicenseBadge');
    if (!badge) return;
    badge.textContent = '🎁 100% Free';
    badge.style.background = '#10b981';
    badge.title = 'Muzammil Online Service - 100% Free & Unlimited Access';
  }

  window.verifyCurrentLicense = async function () {
    return { valid: true, license: getLicenseData().license };
  };

  window.activateLicenseKey = async function (key) {
    showToast('🎉 App sabhi ke liye pehle se hi 100% FREE hai! Kisi key ki zaroorat nahi hai.', 'success');
    window.closeLicenseModal();
    return true;
  };

  window.startFreeTrial = function () {
    showToast('🎉 Sabhi features 100% Free aur Unlimited hain!', 'success');
    window.closeLicenseModal();
  };

  window.selectLicensePricingPlan = function () {
    // No-op in 100% free mode
  };

  window.openLicenseModal = function () {};
  window.closeLicenseModal = function () {};

  // Master Admin Panel Logic
  let currentAdminPin = '';
  window.openAdminLicensePanel = function () {
    if (!window.currentUser || window.currentUser.role !== 'admin') {
      showToast('Access Denied: Yeh panel sirf Master Admin (Imran Khan) ke liye hai.', 'error');
      return;
    }
    
    // If logged in as Master Admin, open directly; fallback to PIN prompt if needed
    currentAdminPin = 'muzammil786';
    const el = document.getElementById('mosAdminPanelModal');
    if (el) {
      el.classList.remove('hidden');
      el.style.display = 'flex';
      window.switchAdminTab('users');
    }
  };

  window.switchAdminTab = function (tab) {
    const isUsers = tab === 'users';
    const usersContent = document.getElementById('adminTabContentUsers');
    const licensesContent = document.getElementById('adminTabContentLicenses');
    const btnUsers = document.getElementById('adminTabBtnUsers');
    const btnLicenses = document.getElementById('adminTabBtnLicenses');

    if (usersContent) usersContent.style.display = isUsers ? 'block' : 'none';
    if (licensesContent) licensesContent.style.display = isUsers ? 'none' : 'block';

    if (btnUsers) {
      btnUsers.style.background = isUsers ? '#38bdf8' : '#1e293b';
      btnUsers.style.color = isUsers ? '#0f172a' : '#cbd5e1';
    }
    if (btnLicenses) {
      btnLicenses.style.background = isUsers ? '#1e293b' : '#38bdf8';
      btnLicenses.style.color = isUsers ? '#cbd5e1' : '#0f172a';
    }

    if (isUsers) {
      window.loadAdminUsersList();
    } else {
      window.loadAdminLicensesList();
    }
  };

  window.loadAdminUsersList = async function () {
    const tbody = document.getElementById('adminUsersTableBody');
    if (!tbody) return;
    tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;padding:16px;color:#94a3b8;">Loading users from Cloud SQL...</td></tr>';

    try {
      const res = await fetch(getApiBase() + '/api/admin/users', {
        headers: { 'x-admin-key': currentAdminPin || 'muzammil786' },
      });
      const data = await res.json();
      if (!data.success) {
        tbody.innerHTML = `<tr><td colspan="6" style="text-align:center;padding:16px;color:#ef4444;">${data.error || 'Failed to load users'}</td></tr>`;
        return;
      }

      if (!data.users || data.users.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;padding:16px;color:#94a3b8;">Koi user nahi mila. Upar se naya operator banayein!</td></tr>';
        return;
      }

      tbody.innerHTML = data.users.map(u => {
        const isBlocked = u.status === 'blocked';
        const statusBadge = isBlocked
          ? '<span style="background:#7f1d1d;color:#fca5a5;padding:3px 8px;border-radius:99px;font-size:11px;font-weight:700;">Blocked</span>'
          : '<span style="background:#065f46;color:#6ee7b7;padding:3px 8px;border-radius:99px;font-size:11px;font-weight:700;">Active</span>';

        const lastLogin = u.lastLoginAt ? new Date(u.lastLoginAt).toLocaleString('en-IN') : 'Never';
        const isMaster = u.username === 'admin' || u.username === 'imran';

        return `<tr style="border-bottom:1px solid #334155;">
          <td style="padding:10px;">
            <div style="font-weight:bold;color:#f8fafc;">${u.displayName || u.username}</div>
            <div style="font-family:monospace;font-size:11px;color:#38bdf8;">@${u.username}</div>
          </td>
          <td style="padding:10px;font-size:12px;color:#cbd5e1;">
            <div>📞 ${u.phone || 'No phone'}</div>
            <div style="color:#94a3b8;font-size:11px;">🏪 ${u.shopName || '-'}</div>
          </td>
          <td style="padding:10px;">
            <span style="background:#1e293b;border:1px solid #475569;color:#fff;padding:2px 6px;border-radius:4px;font-size:11px;text-transform:capitalize;">${u.role}</span>
          </td>
          <td style="padding:10px;">${statusBadge}</td>
          <td style="padding:10px;font-size:11px;color:#94a3b8;">${lastLogin}</td>
          <td style="padding:10px;">
            <div style="display:flex;gap:6px;align-items:center;">
              ${!isMaster ? `
                <button onclick="window.shareUserCredentialsOnWhatsApp('${u.username}', '${encodeURIComponent(u.displayName || '')}', '${u.phone || ''}', '${encodeURIComponent(u.shopName || '')}')" title="Send Login to Client WhatsApp" style="background:#16a34a;color:#fff;border:0;padding:4px 8px;border-radius:6px;font-size:11px;font-weight:bold;cursor:pointer;">
                  📲 WA
                </button>
                <button onclick="window.toggleUserStatusAction(${u.id}, '${u.status}')" style="background:${isBlocked ? '#059669' : '#dc2626'};color:#fff;border:0;padding:4px 8px;border-radius:6px;font-size:11px;font-weight:bold;cursor:pointer;">
                  ${isBlocked ? '🟢 Unblock' : '🔒 Block'}
                </button>
                <button onclick="window.resetUserPasswordAction(${u.id}, '${u.username}')" style="background:#0284c7;color:#fff;border:0;padding:4px 8px;border-radius:6px;font-size:11px;font-weight:bold;cursor:pointer;">
                  🔑 Reset
                </button>
                <button onclick="window.deleteUserAction(${u.id}, '${u.username}')" style="background:#334155;color:#fca5a5;border:0;padding:4px 8px;border-radius:6px;font-size:11px;font-weight:bold;cursor:pointer;">
                  🗑️
                </button>
              ` : '<span style="color:#38bdf8;font-size:11px;font-weight:bold;">👑 Master</span>'}
            </div>
          </td>
        </tr>`;
      }).join('');
    } catch (err) {
      tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;padding:16px;color:#ef4444;">Error fetching users</td></tr>';
    }
  };

  window.shareUserCredentialsOnWhatsApp = function (username, encName, phone, encShop, password) {
    const name = decodeURIComponent(encName || '');
    const shop = decodeURIComponent(encShop || '');
    const appUrl = window.location.origin;

    let msg = `*Muzammil Online Service - Customer Software Login*\n\n` +
      `Namaste *${name || username}* ji,\n` +
      `Aapka Online Service Software Account activate kar diya gaya hai! ✅\n\n` +
      `🌐 *Software Link:* ${appUrl}\n` +
      `👤 *Login Username:* ${username}\n`;

    if (password) {
      msg += `🔑 *Login Password:* ${password}\n`;
    }
    if (shop) {
      msg += `🏪 *Shop Name:* ${shop}\n`;
    }

    msg += `\n📌 *Guide:* Upar diye gaye link ko Chrome me open karein aur apna Username aur Password daalkar login karein.\n\n` +
      `📞 *Customer Care / Owner:* Imran Khan (+91 9561460313)`;

    const cleanPhone = (phone || '').replace(/[^0-9]/g, '');
    const waUrl = cleanPhone.length >= 10
      ? `https://api.whatsapp.com/send?phone=91${cleanPhone.slice(-10)}&text=${encodeURIComponent(msg)}`
      : `https://api.whatsapp.com/send?text=${encodeURIComponent(msg)}`;

    window.open(waUrl, '_blank');
  };

  window.handleCreateUserForm = async function (e) {
    if (e && e.preventDefault) e.preventDefault();
    const displayName = (document.getElementById('newUserDisplayName')?.value || '').trim();
    const username = (document.getElementById('newUsername')?.value || '').trim();
    const password = document.getElementById('newUserPassword')?.value || '';
    const phone = (document.getElementById('newUserPhone')?.value || '').trim();
    const shopName = (document.getElementById('newUserShop')?.value || '').trim();
    const role = document.getElementById('newUserRole')?.value || 'operator';

    if (!displayName || !username || !password) {
      showToast('Name, username aur password sab zaroori hain!', 'error');
      return;
    }

    try {
      const res = await fetch(getApiBase() + '/api/admin/users/create', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-admin-key': currentAdminPin || 'muzammil786',
        },
        body: JSON.stringify({ displayName, username, password, phone, shopName, role }),
      });
      const data = await res.json();
      if (!data.success) {
        showToast(data.error || 'User create nahi ho saka.', 'error');
        return;
      }

      showToast(`User @${username} successfully create ho gaya!`, 'success');

      // Offer instant WhatsApp share
      const wantShare = confirm(`User @${username} create ho gaya hai!\n\nKya aap client ko WhatsApp par Login ID aur Password bhejna chahte hain?`);
      if (wantShare) {
        window.shareUserCredentialsOnWhatsApp(username, encodeURIComponent(displayName), phone, encodeURIComponent(shopName), password);
      }

      ['newUserDisplayName', 'newUsername', 'newUserPassword', 'newUserPhone', 'newUserShop'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.value = '';
      });

      window.loadAdminUsersList();
    } catch (e) {
      showToast('User create nahi ho saka.', 'error');
    }
  };

  window.toggleUserStatusAction = async function (id, currentStatus) {
    const newStatus = currentStatus === 'active' ? 'blocked' : 'active';
    const actionText = newStatus === 'blocked' ? 'block' : 'unblock';
    if (!confirm(`Kya aap is user ko ${actionText} karna chahte hain?`)) return;

    try {
      const res = await fetch(getApiBase() + '/api/admin/users/toggle-status', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-admin-key': currentAdminPin || 'muzammil786',
        },
        body: JSON.stringify({ id, status: newStatus }),
      });
      const data = await res.json();
      if (!data.success) {
        showToast(data.error || 'Status update nahi hua', 'error');
        return;
      }
      showToast(`User ${actionText} ho gaya!`, 'success');
      window.loadAdminUsersList();
    } catch (err) {
      showToast('Status update failed', 'error');
    }
  };

  window.resetUserPasswordAction = async function (id, username) {
    const newPass = prompt(`@${username} ke liye naya password darj karein (minimum 4 characters):`);
    if (!newPass) return;
    if (newPass.length < 4) {
      alert('Password kam se kam 4 characters ka hona chahiye.');
      return;
    }

    try {
      const res = await fetch(getApiBase() + '/api/admin/users/reset-password', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-admin-key': currentAdminPin || 'muzammil786',
        },
        body: JSON.stringify({ id, newPassword: newPass }),
      });
      const data = await res.json();
      if (!data.success) {
        showToast(data.error || 'Password reset nahi ho saka', 'error');
        return;
      }
      showToast(`@${username} ka password reset ho gaya!`, 'success');
    } catch (err) {
      showToast('Password reset failed', 'error');
    }
  };

  window.deleteUserAction = async function (id, username) {
    if (!confirm(`Kya aap sach me @${username} ko delete karna chahte hain? Ye action wapas nahi ho sakta.`)) return;

    try {
      const res = await fetch(getApiBase() + '/api/admin/users/delete', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-admin-key': currentAdminPin || 'muzammil786',
        },
        body: JSON.stringify({ id }),
      });
      const data = await res.json();
      if (!data.success) {
        showToast(data.error || 'User delete nahi ho saka', 'error');
        return;
      }
      showToast(`User @${username} delete ho gaya!`, 'success');
      window.loadAdminUsersList();
    } catch (err) {
      showToast('Delete failed', 'error');
    }
  };

  window.closeAdminLicensePanel = function () {
    const el = document.getElementById('mosAdminPanelModal');
    if (el) {
      el.classList.add('hidden');
      el.style.display = 'none';
    }
  };

  window.loadAdminLicensesList = async function () {
    const listContainer = document.getElementById('adminLicTableBody');
    if (!listContainer) return;
    listContainer.innerHTML = '<tr><td colspan="6" style="text-align:center;padding:16px;">Loading licenses from Cloud SQL...</td></tr>';

    try {
      const res = await fetch(getApiBase() + '/api/license/list', {
        headers: { 'x-admin-key': currentAdminPin || 'muzammil786' },
      });
      const data = await res.json();
      if (!data.success) {
        listContainer.innerHTML = `<tr><td colspan="6" style="color:red;padding:16px;">${data.error || 'Failed to load'}</td></tr>`;
        return;
      }

      if (data.licenses.length === 0) {
        listContainer.innerHTML = '<tr><td colspan="6" style="text-align:center;padding:16px;color:#94a3b8;">No licenses created yet.</td></tr>';
        return;
      }

      listContainer.innerHTML = data.licenses.map(lic => {
        const isExp = lic.expiresAt && new Date(lic.expiresAt) < new Date();
        const statusBadge = lic.status === 'revoked'
          ? '<span style="color:#ef4444;font-weight:700;">Revoked</span>'
          : isExp
          ? '<span style="color:#f59e0b;font-weight:700;">Expired</span>'
          : '<span style="color:#10b981;font-weight:700;">Active</span>';

        const expText = lic.expiresAt ? new Date(lic.expiresAt).toLocaleDateString('en-IN') : 'Lifetime';

        return `<tr style="border-bottom:1px solid #334155;">
          <td style="padding:10px;font-family:monospace;font-weight:bold;color:#38bdf8;">
            ${lic.licenseKey}
            <button style="margin-left:6px;font-size:11px;background:#1e293b;border:1px solid #475569;color:#fff;border-radius:4px;padding:2px 6px;cursor:pointer;" onclick="navigator.clipboard.writeText('${lic.licenseKey}');showToast('Key copied!','success');">Copy</button>
          </td>
          <td style="padding:10px;">${lic.clientName} <br><small style="color:#94a3b8;">${lic.shopName || ''} (${lic.clientPhone || 'No Phone'})</small></td>
          <td style="padding:10px;"><span style="text-transform:uppercase;background:#1e293b;padding:3px 8px;border-radius:6px;font-size:12px;">${lic.plan}</span></td>
          <td style="padding:10px;">${statusBadge}</td>
          <td style="padding:10px;font-size:12px;">${expText}</td>
          <td style="padding:10px;">
            ${lic.status === 'active' 
              ? `<button style="background:#ef4444;color:#fff;border:0;padding:4px 8px;border-radius:6px;font-size:11px;cursor:pointer;" onclick="window.toggleLicenseState(${lic.id}, 'revoked')">Block</button>`
              : `<button style="background:#10b981;color:#fff;border:0;padding:4px 8px;border-radius:6px;font-size:11px;cursor:pointer;" onclick="window.toggleLicenseState(${lic.id}, 'active')">Activate</button>`
            }
          </td>
        </tr>`;
      }).join('');
    } catch (err) {
      listContainer.innerHTML = '<tr><td colspan="6" style="color:red;padding:16px;">Server network error.</td></tr>';
    }
  };

  window.toggleLicenseState = async function (id, newStatus) {
    try {
      const res = await fetch(getApiBase() + '/api/license/status', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-admin-key': currentAdminPin || 'muzammil786',
        },
        body: JSON.stringify({ id, status: newStatus }),
      });
      const data = await res.json();
      if (data.success) {
        showToast('License status updated!', 'success');
        window.loadAdminLicensesList();
      } else {
        showToast(data.error || 'Failed to update', 'error');
      }
    } catch (e) {
      showToast('Failed to connect to server', 'error');
    }
  };

  window.handleCreateLicenseForm = async function (e) {
    if (e && e.preventDefault) e.preventDefault();
    const name = document.getElementById('newLicName')?.value;
    const phone = document.getElementById('newLicPhone')?.value;
    const shop = document.getElementById('newLicShop')?.value;
    const plan = document.getElementById('newLicPlan')?.value || 'monthly';
    const days = document.getElementById('newLicDays')?.value || 30;

    if (!name) {
      showToast('Customer Name zaroori hai.', 'error');
      return;
    }

    try {
      const res = await fetch(getApiBase() + '/api/license/create', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-admin-key': currentAdminPin || 'muzammil786',
        },
        body: JSON.stringify({
          clientName: name,
          clientPhone: phone,
          shopName: shop,
          plan: plan,
          days: Number(days),
        }),
      });

      const data = await res.json();
      if (data.success) {
        showToast('🎉 Nayi License Key generate ho gayi!', 'success');
        const resultBox = document.getElementById('adminGeneratedKeyResult');
        if (resultBox) {
          resultBox.style.display = 'block';
          resultBox.innerHTML = `
            <div style="background:#0f172a;border:1px solid #10b981;border-radius:8px;padding:12px;margin-top:10px;">
              <div style="font-size:12px;color:#94a3b8;">Generated License Key (Share with Customer):</div>
              <div style="font-size:18px;font-family:monospace;font-weight:bold;color:#38bdf8;margin:6px 0;">${data.license.licenseKey}</div>
              <div style="font-size:12px;color:#cbd5e1;">Plan: <b>${data.license.plan.toUpperCase()}</b> | Client: <b>${data.license.clientName}</b></div>
              <button style="margin-top:8px;background:#25d366;color:#fff;border:0;padding:6px 12px;border-radius:6px;font-size:12px;font-weight:bold;cursor:pointer;" onclick="window.shareLicenseOnWhatsApp('${encodeURIComponent(data.license.clientPhone || '')}', '${data.license.licenseKey}', '${encodeURIComponent(data.license.clientName)}')">📲 WhatsApp Par Share Karein</button>
            </div>
          `;
        }
        window.loadAdminLicensesList();
      } else {
        showToast(data.error || 'License generation failed', 'error');
      }
    } catch (err) {
      showToast('Server error while creating license', 'error');
    }
  };

  window.shareLicenseOnWhatsApp = function (phone, key, name) {
    const text = `Namaskar ${decodeURIComponent(name)} ji! Aapka Muzammil Online Service app ka official License Key ready hai:%0A%0A🔑 *License Key:* ${key}%0A%0AApp me '🔑 License' par jakar ye key paste karein aur 'Activate' dabayein.%0AHelpline: +91 95614 60313`;
    const url = phone ? `https://wa.me/${phone.replace(/[^0-9]/g, '')}?text=${text}` : `https://wa.me/?text=${text}`;
    window.open(url, '_blank');
  };

  // Universal Cloud Server Sync (Cloud SQL PostgreSQL Asia)
  window.CloudServerSync = {
    isSyncing: false,
    lastSynced: null,
    syncTimer: null,

    // Debounced auto-save to cloud server
    scheduleAutoSave: function (delay = 1200) {
      if (this.syncTimer) clearTimeout(this.syncTimer);
      this.updateStatusUI('saving');
      this.syncTimer = setTimeout(() => {
        this.pushToServer(false);
      }, delay);
    },

    // Push local operator records to Cloud SQL PostgreSQL
    pushToServer: async function (notify = false) {
      if (this.isSyncing) return;
      this.isSyncing = true;
      this.updateStatusUI('saving');

      try {
        const records = {
          mos_bills: localStorage.getItem('mos_bills') || '[]',
          mos_customers: localStorage.getItem('mos_customers') || '[]',
          mos_cv_draft: localStorage.getItem('mos_cv_draft') || '{}',
          mos_audit_log: localStorage.getItem('mos_audit_log') || '[]',
          mos_downloads_history: localStorage.getItem('mos_downloads_history') || '[]',
        };

        const res = await fetch(getApiBase() + '/api/sync/push', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            userUid: 'operator_default',
            records: records,
          }),
        });

        const data = await res.json();
        if (data.success) {
          this.lastSynced = new Date();
          this.updateStatusUI('synced');
          if (notify) showToast('✅ Data Cloud Server par safalta se save ho gaya!', 'success');
        } else {
          this.updateStatusUI('error');
        }
      } catch (err) {
        console.warn('Cloud SQL sync error:', err);
        this.updateStatusUI('offline');
      } finally {
        this.isSyncing = false;
      }
    },

    // Pull saved operator records from Cloud SQL PostgreSQL
    pullFromServer: async function (silent = false) {
      try {
        this.updateStatusUI('syncing');
        const res = await fetch(getApiBase() + '/api/sync/pull?userUid=operator_default');
        const data = await res.json();

        if (data.success && data.records) {
          let hasUpdated = false;

          // Sync Bills
          if (data.records.mos_bills && data.records.mos_bills !== '[]') {
            const serverBills =
              typeof data.records.mos_bills === 'string'
                ? JSON.parse(data.records.mos_bills)
                : data.records.mos_bills;
            if (Array.isArray(serverBills) && serverBills.length > 0) {
              const localBills = JSON.parse(localStorage.getItem('mos_bills') || '[]');
              const billMap = new Map();
              serverBills.forEach((b) => billMap.set(Number(b.id), b));
              localBills.forEach((b) => billMap.set(Number(b.id), b));
              const mergedBills = Array.from(billMap.values()).sort(
                (a, b) => Number(b.id || 0) - Number(a.id || 0)
              );
              localStorage.setItem('mos_bills', JSON.stringify(mergedBills));
              hasUpdated = true;
            }
          }

          // Sync Customers
          if (data.records.mos_customers && data.records.mos_customers !== '[]') {
            const serverCust =
              typeof data.records.mos_customers === 'string'
                ? JSON.parse(data.records.mos_customers)
                : data.records.mos_customers;
            if (Array.isArray(serverCust) && serverCust.length > 0) {
              const localCust = JSON.parse(localStorage.getItem('mos_customers') || '[]');
              const custMap = new Map();
              serverCust.forEach((c) => custMap.set(String(c.mobile || c.id), c));
              localCust.forEach((c) => custMap.set(String(c.mobile || c.id), c));
              localStorage.setItem('mos_customers', JSON.stringify(Array.from(custMap.values())));
              hasUpdated = true;
            }
          }

          // Sync CV Draft
          if (data.records.mos_cv_draft) {
            const draft =
              typeof data.records.mos_cv_draft === 'string'
                ? data.records.mos_cv_draft
                : JSON.stringify(data.records.mos_cv_draft);
            if (draft && draft !== '{}' && !localStorage.getItem('mos_cv_draft')) {
              localStorage.setItem('mos_cv_draft', draft);
              hasUpdated = true;
            }
          }

          this.lastSynced = new Date();
          this.updateStatusUI('synced');

          if (hasUpdated) {
            if (typeof window.renderBills === 'function') window.renderBills();
            if (typeof window.renderCustomers === 'function') window.renderCustomers();
          }
          if (!silent) showToast('Cloud SQL Database se latest data load ho gaya.', 'success');
        } else {
          this.updateStatusUI('synced');
        }
      } catch (err) {
        console.warn('Pull from Cloud SQL error:', err);
        this.updateStatusUI('synced');
      }
    },

    updateStatusUI: function (status) {
      const textEl = document.getElementById('cloudSyncStatusText');
      const dotEl = document.getElementById('cloudPulseDot');
      const btnEl = document.getElementById('cloudSyncBtn');
      if (!textEl || !dotEl) return;

      if (status === 'saving' || status === 'syncing') {
        textEl.textContent = 'Server par save ho raha hai...';
        dotEl.style.background = '#f59e0b';
        dotEl.style.boxShadow = '0 0 8px #f59e0b';
        if (btnEl) btnEl.textContent = '⏳ Saving...';
      } else if (status === 'synced') {
        textEl.textContent = 'Server storage connected & synced (PostgreSQL Cloud SQL Asia)';
        dotEl.style.background = '#4ade80';
        dotEl.style.boxShadow = '0 0 8px #4ade80';
        if (btnEl) btnEl.textContent = '✓ Synced';
      } else if (status === 'offline' || status === 'error') {
        textEl.textContent = 'Saved locally (Server connecting...)';
        dotEl.style.background = '#ef4444';
        dotEl.style.boxShadow = '0 0 8px #ef4444';
        if (btnEl) btnEl.textContent = '🔄 Retry';
      }
    },
  };

  window.triggerManualSync = function () {
    if (window.CloudServerSync) {
      window.CloudServerSync.pushToServer(true);
    }
  };

  // Live Database Inspector Controls
  window.openDatabaseInspector = function () {
    if (!window.currentUser || window.currentUser.role !== 'admin') {
      showToast('Access Denied: Server Database sirf Master Admin ke liye accessible hai.', 'error');
      return;
    }
    const el = document.getElementById('mosDbInspectorModal');
    if (el) {
      el.classList.remove('hidden');
      el.style.display = 'flex';
      window.loadDatabaseInspectorData();
    }
  };

  window.closeDatabaseInspector = function () {
    const el = document.getElementById('mosDbInspectorModal');
    if (el) {
      el.classList.add('hidden');
      el.style.display = 'none';
    }
  };

  window.switchInspectorTab = function (tabId) {
    const tabs = ['bills', 'cust', 'store', 'cv', 'cloud'];
    tabs.forEach((t) => {
      const content = document.getElementById('inspTabContent' + t.charAt(0).toUpperCase() + t.slice(1));
      const btn = document.getElementById('tabBtn' + t.charAt(0).toUpperCase() + t.slice(1));
      if (content) content.style.display = t === tabId ? 'block' : 'none';
      if (btn) {
        btn.style.background = t === tabId ? '#38bdf8' : '#1e293b';
        btn.style.color = t === tabId ? '#0f172a' : '#cbd5e1';
      }
    });
  };

  window.loadDatabaseInspectorData = async function () {
    try {
      const res = await fetch(getApiBase() + '/api/server/database-overview');
      const data = await res.json();
      if (!data.success) {
        showToast('Server database load nahi hua: ' + (data.error || ''), 'error');
        return;
      }

      // Populate Stats
      const statBills = document.getElementById('inspectorStatBills');
      const statCust = document.getElementById('inspectorStatCust');
      const statCv = document.getElementById('inspectorStatCv');
      const statStore = document.getElementById('inspectorStatStore');
      const statLic = document.getElementById('inspectorStatLic');

      if (statBills) statBills.textContent = data.tables?.receipts?.count ?? 0;
      if (statCust) statCust.textContent = data.tables?.customers?.count ?? 0;
      if (statCv) statCv.textContent = data.tables?.cv_drafts?.count ?? 0;
      if (statStore) statStore.textContent = data.tables?.app_store?.count ?? 0;
      if (statLic) statLic.textContent = data.tables?.licenses?.count ?? 0;

      // Populate Bills Table
      const billsBody = document.getElementById('inspTableBillsBody');
      if (billsBody) {
        const bills = data.tables?.receipts?.rows || [];
        if (bills.length === 0) {
          billsBody.innerHTML =
            '<tr><td colspan="7" style="text-align:center;padding:16px;color:#94a3b8;">Koi alag receipt table me nahi hai. Bills `app_store` me live synced hain!</td></tr>';
        } else {
          billsBody.innerHTML = bills
            .map(
              (b) => `
            <tr style="border-bottom:1px solid #334155;">
              <td style="padding:8px 10px;font-family:monospace;color:#38bdf8;">#${b.billNo || b.id}</td>
              <td style="padding:8px 10px;font-weight:bold;">${b.customerName || '-'}</td>
              <td style="padding:8px 10px;color:#94a3b8;">${b.customerMobile || '-'}</td>
              <td style="padding:8px 10px;">${b.serviceName || '-'}</td>
              <td style="padding:8px 10px;color:#34d399;font-weight:bold;">₹${b.amount || 0}</td>
              <td style="padding:8px 10px;"><span style="background:${
                b.status === 'completed' || b.status === 'Paid' ? '#065f46' : '#92400e'
              };color:#fff;padding:2px 6px;border-radius:4px;font-size:11px;">${b.status || 'Pending'}</span></td>
              <td style="padding:8px 10px;color:#94a3b8;font-size:11px;">${
                b.date || (b.createdAt ? new Date(b.createdAt).toLocaleDateString() : '-')
              }</td>
            </tr>
          `
            )
            .join('');
        }
      }

      // Populate Customers Table
      const custBody = document.getElementById('inspTableCustBody');
      if (custBody) {
        const custs = data.tables?.customers?.rows || [];
        if (custs.length === 0) {
          custBody.innerHTML =
            '<tr><td colspan="6" style="text-align:center;padding:16px;color:#94a3b8;">No direct customer rows in table. Check Synced Cloud Payloads tab.</td></tr>';
        } else {
          custBody.innerHTML = custs
            .map(
              (c) => `
            <tr style="border-bottom:1px solid #334155;">
              <td style="padding:8px 10px;font-family:monospace;color:#94a3b8;">#${c.id}</td>
              <td style="padding:8px 10px;font-weight:bold;color:#f8fafc;">${c.name}</td>
              <td style="padding:8px 10px;color:#38bdf8;">${c.mobile || '-'}</td>
              <td style="padding:8px 10px;color:#cbd5e1;">${c.address || '-'}</td>
              <td style="padding:8px 10px;color:#34d399;font-weight:bold;">₹${c.totalSpend || 0}</td>
              <td style="padding:8px 10px;color:#94a3b8;font-size:11px;">${
                c.createdAt ? new Date(c.createdAt).toLocaleDateString() : '-'
              }</td>
            </tr>
          `
            )
            .join('');
        }
      }

      // Populate App Store Key-Value view
      const storeBody = document.getElementById('inspTableStoreBody');
      if (storeBody) {
        const storeRows = data.tables?.app_store?.rows || [];
        if (storeRows.length === 0) {
          storeBody.textContent =
            'app_store table is currently empty. Click "Force Full Push" to sync local data right now.';
        } else {
          storeBody.innerHTML = storeRows
            .map((r) => {
              let summary = r.payload;
              try {
                const parsed = JSON.parse(r.payload);
                if (Array.isArray(parsed)) {
                  summary =
                    `[Array of ${parsed.length} items]\n` +
                    JSON.stringify(parsed.slice(0, 3), null, 2) +
                    (parsed.length > 3 ? `\n... (+${parsed.length - 3} more items)` : '');
                } else if (typeof parsed === 'object') {
                  summary = JSON.stringify(parsed, null, 2);
                }
              } catch (e) {}
              return `// Table: app_store | Key: "${r.storeKey}" | Updated: ${new Date(
                r.updatedAt
              ).toLocaleString()}\n${summary}\n\n`;
            })
            .join('');
        }
      }

      // Populate CV Drafts
      const cvBody = document.getElementById('inspTableCvBody');
      if (cvBody) {
        const cvRows = data.tables?.cv_drafts?.rows || [];
        if (cvRows.length === 0) {
          cvBody.innerHTML =
            '<tr><td colspan="4" style="text-align:center;padding:16px;color:#94a3b8;">No CV drafts stored yet in cv_drafts table.</td></tr>';
        } else {
          cvBody.innerHTML = cvRows
            .map(
              (cv) => `
            <tr style="border-bottom:1px solid #334155;">
              <td style="padding:8px 10px;font-family:monospace;color:#94a3b8;">#${cv.id}</td>
              <td style="padding:8px 10px;font-weight:bold;color:#f8fafc;">${cv.title || 'Untitled CV'}</td>
              <td style="padding:8px 10px;color:#94a3b8;font-size:11px;">${
                cv.updatedAt ? new Date(cv.updatedAt).toLocaleString() : '-'
              }</td>
              <td style="padding:8px 10px;color:#38bdf8;">${
                cv.dataJson ? Math.round(cv.dataJson.length / 1024) + ' KB' : '0 KB'
              }</td>
            </tr>
          `
            )
            .join('');
        }
      }

      showToast('Live Cloud SQL Database loaded successfully!', 'success');
    } catch (err) {
      console.error('Inspector error:', err);
      showToast('Server inspection request failed', 'error');
    }
  };

  // Role-based UI visibility: Master Admin vs Normal User / Operator
  window.applyUserRoleUI = function (user) {
    const isAdmin = Boolean(user && user.role === 'admin');
    const adminElements = document.querySelectorAll('.mos-admin-only');
    adminElements.forEach((el) => {
      if (isAdmin) {
        if (el.tagName === 'BUTTON') {
          el.style.display = 'inline-flex';
        } else if (el.id === 'mosServerSyncBanner') {
          el.style.display = 'flex';
        } else {
          el.style.display = 'block';
        }
      } else {
        el.style.display = 'none';
      }
    });

    const nameEl = document.getElementById('loggedUserName');
    const dotEl = document.getElementById('userStatusDot');
    const headerLoginBtn = document.getElementById('mosHeaderLoginBtn');
    const userBadge = document.getElementById('mosUserHeaderBadge');
    const sideLoginBtn = document.getElementById('mosSideLoginBtn');
    const sideLogoutBtn = document.getElementById('mosSideLogoutBtn');

    if (user) {
      if (headerLoginBtn) headerLoginBtn.style.display = 'none';
      if (userBadge) userBadge.style.display = 'flex';
      if (sideLogoutBtn) sideLogoutBtn.style.opacity = '1';
      if (sideLoginBtn) {
        sideLoginBtn.innerHTML = '<span>👤</span>' + (isAdmin ? '👑 Admin' : 'Staff');
        sideLoginBtn.style.opacity = '0.75';
      }
      if (nameEl) {
        if (isAdmin) {
          nameEl.textContent = '👑 ' + (user.displayName || user.username);
          nameEl.title = 'Master Admin & Owner (Full Control)';
          if (dotEl) dotEl.style.background = '#f59e0b';
        } else {
          nameEl.textContent = '👤 ' + (user.displayName || user.username);
          nameEl.title = user.shopName ? `Shop: ${user.shopName}` : 'Staff Operator';
          if (dotEl) dotEl.style.background = '#10b981';
        }
      }
    } else {
      if (headerLoginBtn) headerLoginBtn.style.display = 'flex';
      if (userBadge) userBadge.style.display = 'none';
      if (sideLogoutBtn) sideLogoutBtn.style.opacity = '0.5';
      if (sideLoginBtn) {
        sideLoginBtn.innerHTML = '<span>🔐</span>Login';
        sideLoginBtn.style.opacity = '1';
      }
    }
  };

  window.mosQuickFill = function (u, p) {
    const uIn = document.getElementById('mosLoginUsername');
    const pIn = document.getElementById('mosLoginPassword');
    if (uIn) uIn.value = u;
    if (pIn) pIn.value = p;
    const err = document.getElementById('mosLoginErrorMsg');
    if (err) err.style.display = 'none';
  };

  window.switchLoginTab = function (tab) {
    const adminBtn = document.getElementById('mosTabAdminBtn');
    const staffBtn = document.getElementById('mosTabStaffBtn');
    const loginForm = document.getElementById('mosLoginForm');
    const quickFill = document.getElementById('mosQuickFillContainer');
    const uLabel = document.getElementById('mosUsernameLabel');
    const uInput = document.getElementById('mosLoginUsername');
    const pInput = document.getElementById('mosLoginPassword');
    const submitBtn = document.getElementById('mosLoginSubmitBtn');
    const err = document.getElementById('mosLoginErrorMsg');
    if (err) err.style.display = 'none';

    // Reset styles
    [adminBtn, staffBtn].forEach((b) => {
      if (b) {
        b.style.background = 'transparent';
        b.style.color = '#94a3b8';
      }
    });

    if (tab === 'admin') {
      if (adminBtn) {
        adminBtn.style.background = '#2563eb';
        adminBtn.style.color = '#fff';
      }
      if (loginForm) loginForm.style.display = 'flex';
      if (quickFill) quickFill.style.display = 'flex';
      if (uLabel) uLabel.textContent = 'Admin Username / Mobile *';
      if (uInput) {
        uInput.placeholder = 'admin ya imran';
        uInput.value = 'admin';
      }
      if (pInput) pInput.value = 'muzammil786';
      if (submitBtn) submitBtn.textContent = '👑 Admin Login Karein';
    } else if (tab === 'staff') {
      if (staffBtn) {
        staffBtn.style.background = '#0284c7';
        staffBtn.style.color = '#fff';
      }
      if (loginForm) loginForm.style.display = 'flex';
      if (quickFill) quickFill.style.display = 'none';
      if (uLabel) uLabel.textContent = 'Operator / Staff Username *';
      if (uInput) {
        uInput.placeholder = 'Apna operator username daalein';
        uInput.value = '';
      }
      if (pInput) pInput.value = '';
      if (submitBtn) submitBtn.textContent = '👤 Staff Login Karein';
    }
  };

  window.handleMosRegister = async function (e) {
    if (e && e.preventDefault) e.preventDefault();
    const name = document.getElementById('mosRegName')?.value.trim();
    const shop = document.getElementById('mosRegShop')?.value.trim();
    const username = document.getElementById('mosRegUsername')?.value.trim();
    const phone = document.getElementById('mosRegPhone')?.value.trim();
    const password = document.getElementById('mosRegPassword')?.value;
    const err = document.getElementById('mosRegErrorMsg');
    const btn = document.getElementById('mosRegSubmitBtn');

    if (!name || !username || !password) {
      if (err) {
        err.textContent = 'Kripya sabhi zaroori fields bharein.';
        err.style.display = 'block';
      }
      return;
    }

    if (btn) {
      btn.disabled = true;
      btn.textContent = 'Creating Account in Cloud SQL...';
    }

    try {
      const res = await fetch(getApiBase() + '/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          displayName: name,
          shopName: shop,
          username,
          phone,
          password,
        }),
      });
      const data = await res.json();
      if (!data.success || !data.user) {
        throw new Error(data.error || 'Registration failed');
      }

      // Auto login with new user
      localStorage.setItem('mos_user_session', JSON.stringify(data.user));
      window.currentUser = data.user;
      const overlay = document.getElementById('mosAuthOverlay');
      if (overlay) overlay.style.display = 'none';
      const badge = document.getElementById('mosUserHeaderBadge');
      if (badge) badge.style.display = 'flex';
      window.applyUserRoleUI(data.user);
      showToast(`Account successfully ban gaya! Swagat hai, ${data.user.displayName}`, 'success');
    } catch (error) {
      if (err) {
        err.textContent = error.message || 'Registration me dikkat aayi.';
        err.style.display = 'block';
      }
    } finally {
      if (btn) {
        btn.disabled = false;
        btn.textContent = '✅ Naya Account Banayein & Login Karein';
      }
    }
  };

  window.openLoginModal = function () {
    const overlay = document.getElementById('mosAuthOverlay');
    const form = document.getElementById('mosLoginForm');
    const sessionCard = document.getElementById('mosExistingSessionCard');
    if (overlay) overlay.style.display = 'flex';
    if (form) form.style.display = 'flex';
    if (sessionCard) sessionCard.style.display = 'none';
  };

  window.showLoginFormDirectly = function () {
    const form = document.getElementById('mosLoginForm');
    const sessionCard = document.getElementById('mosExistingSessionCard');
    if (form) form.style.display = 'flex';
    if (sessionCard) sessionCard.style.display = 'none';
    const uIn = document.getElementById('mosLoginUsername');
    if (uIn) uIn.focus();
  };

  window.enterAppWithExistingSession = function () {
    const raw = localStorage.getItem('mos_user_session');
    if (!raw) {
      window.showLoginFormDirectly();
      return;
    }
    try {
      const user = JSON.parse(raw);
      window.currentUser = user;
      const overlay = document.getElementById('mosAuthOverlay');
      if (overlay) overlay.style.display = 'none';
      const badge = document.getElementById('mosUserHeaderBadge');
      if (badge) badge.style.display = 'flex';
      window.applyUserRoleUI(user);
      showToast(`Swagat hai, ${user.displayName || user.username}!`, 'success');
    } catch (e) {
      window.showLoginFormDirectly();
    }
  };

  window.continueAsGuest = function () {
    const overlay = document.getElementById('mosAuthOverlay');
    if (overlay) overlay.style.display = 'none';
    window.isGuest = true;
    showToast('Guest mode active. Admin control ke liye 🔐 Login karein.', 'info');
  };

  window.checkAuthSession = async function () {
    const raw = localStorage.getItem('mos_user_session');
    const overlay = document.getElementById('mosAuthOverlay');
    const badge = document.getElementById('mosUserHeaderBadge');
    const sessionCard = document.getElementById('mosExistingSessionCard');
    const form = document.getElementById('mosLoginForm');
    const sessionName = document.getElementById('mosExistingSessionName');
    const sessionRole = document.getElementById('mosExistingSessionRole');

    // On app launch, ALWAYS present the login screen first!
    if (overlay) overlay.style.display = 'flex';

    if (!raw) {
      if (sessionCard) sessionCard.style.display = 'none';
      if (form) form.style.display = 'flex';
      if (badge) badge.style.display = 'none';
      window.applyUserRoleUI(null);
      return false;
    }

    try {
      const user = JSON.parse(raw);
      if (!user || (!user.username && !user.uid)) {
        throw new Error('Invalid session');
      }

      window.currentUser = user;
      window.applyUserRoleUI(user);

      // Show welcome session card on the login screen
      if (sessionCard) {
        sessionCard.style.display = 'block';
        if (sessionName) {
          sessionName.textContent = (user.role === 'ADMIN' ? '👑 ' : '👤 ') + (user.displayName || user.username);
        }
        if (sessionRole) {
          sessionRole.textContent = (user.role === 'ADMIN' ? 'Master Admin & Owner • Full Control' : 'Authorized Staff Operator • ' + (user.shopName || 'Active'));
        }
      }
      if (form) form.style.display = 'none';

      // Pre-fill fields in form
      window.mosQuickFill(user.username, '');

      // Verify in background with server
      fetch(getApiBase() + '/api/auth/verify-session', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: user.username, uid: user.uid }),
      })
        .then((r) => r.json())
        .then((res) => {
          if (!res.valid) {
            localStorage.removeItem('mos_user_session');
            window.showLoginFormDirectly();
            if (badge) badge.style.display = 'none';
            window.applyUserRoleUI(null);
            showToast(res.error || 'Aapka account block ya session expire ho gaya hai.', 'error');
          } else if (res.user) {
            localStorage.setItem('mos_user_session', JSON.stringify(res.user));
            window.currentUser = res.user;
            window.applyUserRoleUI(res.user);
          }
        })
        .catch(() => {});

      return true;
    } catch (e) {
      localStorage.removeItem('mos_user_session');
      if (sessionCard) sessionCard.style.display = 'none';
      if (form) form.style.display = 'flex';
      if (badge) badge.style.display = 'none';
      window.applyUserRoleUI(null);
      return false;
    }
  };

  window.handleMosLogin = async function (e) {
    if (e && e.preventDefault) e.preventDefault();
    const usernameInput = document.getElementById('mosLoginUsername');
    const passwordInput = document.getElementById('mosLoginPassword');
    const errorMsg = document.getElementById('mosLoginErrorMsg');
    const btn = document.getElementById('mosLoginSubmitBtn');

    const username = usernameInput ? usernameInput.value.trim() : '';
    const password = passwordInput ? passwordInput.value : '';

    if (!username || !password) {
      if (errorMsg) {
        errorMsg.textContent = 'Kripya username aur password dono bharein.';
        errorMsg.style.display = 'block';
      }
      return;
    }

    if (errorMsg) errorMsg.style.display = 'none';
    if (btn) {
      btn.disabled = true;
      btn.textContent = 'Verifying with Cloud SQL...';
    }

    // Immediate offline / APK check for Master Admin
    const isMasterAdmin =
      (username.toLowerCase() === 'admin' ||
        username.toLowerCase() === 'imran' ||
        username === '9561460313') &&
      password === 'muzammil786';

    try {
      let data = null;
      try {
        const res = await fetch(getApiBase() + '/api/auth/login', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ username, password }),
        });
        data = await res.json();
      } catch (networkErr) {
        // If network / server is unreachable but master credentials match
        if (isMasterAdmin) {
          data = {
            success: true,
            user: {
              uid: 'admin_imran_master',
              username: 'imran',
              displayName: 'Imran Khan',
              role: 'ADMIN',
              status: 'ACTIVE',
              shopName: 'Muzammil Online Service',
            },
          };
        } else {
          throw networkErr;
        }
      }

      if (!data || !data.success || !data.user) {
        if (errorMsg) {
          errorMsg.textContent =
            (data && data.error) ||
            'Galat username ya password! Kripya sahi details bharein.';
          errorMsg.style.display = 'block';
        }
        if (btn) {
          btn.disabled = false;
          btn.textContent = '🔐 Login Karein';
        }
        return;
      }

      // Success!
      localStorage.setItem('mos_user_session', JSON.stringify(data.user));
      window.currentUser = data.user;

      const overlay = document.getElementById('mosAuthOverlay');
      if (overlay) overlay.style.display = 'none';

      const badge = document.getElementById('mosUserHeaderBadge');
      if (badge) badge.style.display = 'flex';

      window.applyUserRoleUI(data.user);

      showToast(`Swagat hai, ${data.user.displayName || data.user.username}!`, 'success');

      // Sync latest cloud data
      if (window.CloudServerSync) {
        window.CloudServerSync.pullFromServer(true);
      }
    } catch (err) {
      console.error('Login error:', err);
      if (errorMsg) {
        errorMsg.textContent = 'Server se connect nahi ho saka. Kripya dobara koshish karein.';
        errorMsg.style.display = 'block';
      }
    } finally {
      if (btn) {
        btn.disabled = false;
        btn.textContent = '🔐 Login Karein';
      }
    }
  };

  window.mosLogout = function () {
    if (!confirm('Kya aap sach me logout karna chahte hain?')) return;
    localStorage.removeItem('mos_user_session');
    window.currentUser = null;
    window.applyUserRoleUI(null);

    const overlay = document.getElementById('mosAuthOverlay');
    const sessionCard = document.getElementById('mosExistingSessionCard');
    const form = document.getElementById('mosLoginForm');
    if (overlay) overlay.style.display = 'flex';
    if (sessionCard) sessionCard.style.display = 'none';
    if (form) form.style.display = 'flex';

    const passInput = document.getElementById('mosLoginPassword');
    if (passInput) passInput.value = '';
    const errorMsg = document.getElementById('mosLoginErrorMsg');
    if (errorMsg) errorMsg.style.display = 'none';

    const badge = document.getElementById('mosUserHeaderBadge');
    if (badge) badge.style.display = 'none';

    showToast('Aap successfully logout ho chuke hain.', 'success');
  };

  window.toggleLoginPasswordVisibility = function () {
    const input = document.getElementById('mosLoginPassword');
    if (!input) return;
    input.type = input.type === 'password' ? 'text' : 'password';
  };

  // PWA & Mobile Installation Handler
  let deferredInstallPrompt = null;
  window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    deferredInstallPrompt = e;
  });

  window.triggerPWAInstall = async function () {
    if (deferredInstallPrompt) {
      deferredInstallPrompt.prompt();
      const { outcome } = await deferredInstallPrompt.userChoice;
      if (outcome === 'accepted') {
        showToast('App aapke mobile par install ho raha hai! 🎉', 'success');
        deferredInstallPrompt = null;
      }
    } else {
      showToast('📱 Android par install karne ke liye Chrome menu (⋮) me "Install app" ya "Add to Home screen" par tap karein.', 'info');
    }
  };

  // Register Service Worker for PWA
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('/sw.js').catch((err) => {
        console.warn('SW registration failed:', err);
      });
    });
  }

  const initMosBridge = () => {
    initLiveClock();
    // Check mandatory login session
    window.checkAuthSession();
    // Pull and sync latest cloud data on page load
    if (window.CloudServerSync) {
      window.CloudServerSync.pullFromServer(true);
    }
  };

  if (document.readyState === 'loading') {
    window.addEventListener('DOMContentLoaded', initMosBridge);
  } else {
    initMosBridge();
  }
})();


