# Muzammil Online Service

A comprehensive all-in-one digital services portal and utility hub for online citizen services, document tools, and billing management.

## Features
- **Official Government Portals**: Direct access to central and state portals for Aadhaar, PAN card, Voter ID, Ration Card, Driving Licence, PM-KISAN, Majhi Ladki Bahin Yojana, Ayushman Bharat, and more.
- **PVC Card Maker**: Standard 4x6 inch 300 DPI layout creator for printing 2 ID cards (Front and Back) with live zoom, move, crop, snap, and enhance controls.
- **Passport Photo Maker**: 300 DPI photo sheet generator for 6, 8, 12, 16, or 32 copies with beauty retouching, background selection, curves, and color grading.
- **PDF to JPG Converter**: Convert normal and password-protected PDF files to high-resolution 300 DPI JPEGs.
- **CV / BioData Generator**: Professional A4 curriculum vitae / biodata generator with photo, education, and family details.
- **Billing & Receipt Generator**: Generate and track service receipts with customer information, amount, and direct WhatsApp sharing.
- **AI Digital Assistant**: Instant guidance on document requirements and application procedures for all major government schemes.
- **Downloads Manager**: Built-in tracking of generated PDFs, JPGs, and backups.

## Running Locally
```bash
npm install
npm run dev
```
The application runs on `http://localhost:3000`.
