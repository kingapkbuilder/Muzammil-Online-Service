plugins { id("com.android.application") }
android {
    namespace="com.muzammil.onlineservice"
    compileSdk=35
    defaultConfig {
        applicationId="com.muzammil.onlineservice"
        minSdk=24
        targetSdk=35
        versionCode = 48
        versionName = "4.9"
    }
}


dependencies { implementation("androidx.core:core:1.15.0") }
