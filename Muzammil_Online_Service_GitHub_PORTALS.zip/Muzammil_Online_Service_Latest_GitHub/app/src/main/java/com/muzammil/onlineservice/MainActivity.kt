package com.muzammil.onlineservice

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.webkit.*
import android.widget.*

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var lang: TextView
    private var translationOn = false

    override fun onCreate(b: Bundle?) { super.onCreate(b); build() }

    private fun build() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(244,247,251)) }
        val bar = LinearLayout(this).apply { setPadding(12,8,12,8); setBackgroundColor(Color.rgb(23,104,255)) }
        val title = TextView(this).apply { text="Muzammil Online Service"; textSize=18f; setTextColor(Color.WHITE); setTypeface(null,1); gravity=16 }
        bar.addView(title, LinearLayout.LayoutParams(0,55,1f))
        lang = TextView(this).apply { text="Translate: OFF"; textSize=12f; gravity=17; setTextColor(Color.WHITE); setPadding(8,0,8,0); setOnClickListener{toggleTranslation()} }
        bar.addView(lang, LinearLayout.LayoutParams(120,55)); root.addView(bar)
        web=WebView(this)
        web.settings.javaScriptEnabled=true; web.settings.domStorageEnabled=true; web.settings.databaseEnabled=true; web.settings.loadsImagesAutomatically=true; web.settings.cacheMode=WebSettings.LOAD_DEFAULT
        web.webViewClient=object:WebViewClient(){ override fun shouldOverrideUrlLoading(v:WebView,r:WebResourceRequest):Boolean{v.loadUrl(r.url.toString());return true} }
        root.addView(web,LinearLayout.LayoutParams(-1,0,1f)); setContentView(root); web.loadDataWithBaseURL(null,html(),"text/html","UTF-8",null)
    }
    private fun toggleTranslation(){ translationOn=!translationOn; lang.text=if(translationOn)"Translate: ON" else "Translate: OFF"; Toast.makeText(this,if(translationOn)"Translation mode ON" else "Translation mode OFF",Toast.LENGTH_SHORT).show() }
    override fun onBackPressed(){if(::web.isInitialized&&web.canGoBack())web.goBack()else super.onBackPressed()}

    private fun html():String = """<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'><style>
body{font-family:Arial;background:#f4f7fb;margin:0;color:#172033}.hero{background:#1768ff;color:white;padding:22px;border-radius:0 0 18px 18px}.hero h2{margin:0 0 6px}.section{padding:14px 14px 4px;font-size:18px;font-weight:700}.grid{display:grid;grid-template-columns:1fr 1fr;gap:10px;padding:10px 14px}.card{background:white;padding:16px;border-radius:15px;box-shadow:0 2px 8px #00000012;min-height:72px;cursor:pointer}.ico{font-size:25px}.name{font-weight:700;margin-top:5px}.sub{color:#6d7788;font-size:12px;margin-top:4px}.note{margin:14px;padding:12px;background:white;border-radius:12px;color:#596579;font-size:12px}</style></head><body>
<div class='hero'><h2>Muzammil Online Service</h2><div>Professional services & official government portals</div></div>
<div class='note'>Sirf official portal links connect kiye gaye hain. Government website ki speed/server availability unke server aur internet par depend karti hai.</div>
<div class='section'>🪪 Citizen Services</div><div class='grid' id='citizen'></div><div class='section'>🏛️ Government Services</div><div class='grid' id='gov'></div><div class='section'>📋 Central & Maharashtra Schemes</div><div class='grid' id='schemes'></div><div class='section'>🏦 Banking & AePS</div><div class='grid' id='bank'></div><div class='section'>🤝 Partner Services</div><div class='grid' id='partner'></div><div class='section'>📄 Other Services</div><div class='grid' id='other'></div>
<script>
const citizen=[['🪪','Aadhaar Card','https://uidai.gov.in/'],['💳','PAN Card','https://www.pan.utiitsl.com/'],['🗳️','Voter ID','https://voters.eci.gov.in/'],['🏥','Ayushman Card','https://beneficiary.nha.gov.in/'],['🩺','ABHA Card','https://abha.abdm.gov.in/'],['👷','e-Shram Card','https://eshram.gov.in/']];
const gov=[['🚗','MahaSarathi / Transport','https://transport.maharashtra.gov.in/'],['🏢','Udyam Registration','https://udyamregistration.gov.in/'],['🏛️','Aaple Sarkar','https://aaplesarkar.mahaonline.gov.in/'],['🎓','MahaDBT','https://mahadbt.maharashtra.gov.in/'],['📁','DigiLocker','https://www.digilocker.gov.in/'],['🛂','Passport Seva','https://passportindia.gov.in/']];
const schemes=[['🇮🇳','Central Government Schemes','https://www.myscheme.gov.in/'],['🟠','Maharashtra Government Schemes','https://www.myscheme.gov.in/'],['🏠','PM Awas Yojana','https://pmaymis.gov.in/'],['🌾','PM-KISAN','https://pmkisan.gov.in/'],['☀️','PM Surya Ghar','https://pmsuryaghar.gov.in/'],['🏦','PM Jan-Dhan','https://pmjdy.gov.in/'],['🏥','PM-JAY / Ayushman Bharat','https://pmjay.gov.in/'],['🌾','PM Fasal Bima','https://pmfby.gov.in/'],['👷','PM Shram Yogi Maandhan','https://maandhan.in/'],['🏭','PMEGP','https://www.kviconline.gov.in/pmegpeportal/'],['💰','PM Mudra Yojana','https://www.mudra.org.in/'],['🛡️','PM Jeevan Jyoti Bima','https://jansuraksha.gov.in/'],['🛡️','PM Suraksha Bima','https://jansuraksha.gov.in/'],['👧','Sukanya Samriddhi','https://www.indiapost.gov.in/'],['🔥','PM Ujjwala','https://www.pmuy.gov.in/'],['💧','Jal Jeevan Mission','https://jaljeevanmission.gov.in/'],['🛺','PM SVANidhi','https://pmsvanidhi.mohua.gov.in/'],['🧰','PM Vishwakarma','https://pmvishwakarma.gov.in/'],['🌱','PM-KUSUM','https://pmkusum.mnre.gov.in/'],['🛣️','PM Gram Sadak Yojana','https://pmgsy.nic.in/']];
const bank=[['🏦','Banking Information / RBI','https://www.rbi.org.in/'],['💳','UPI','https://www.npci.org.in/what-we-do/upi/product-overview'],['💳','AePS','https://www.npci.org.in/what-we-do/aeps/product-overview'],['💵','Aadhaar Banking','https://www.npci.org.in/what-we-do/aeps/product-overview']];
const partner=[['🔴','Airtel Payments Bank','https://www.airtel.in/bank'],['🟠','Spice Money','https://www.spicemoney.com/'],['🟢','PayNearby','https://paynearby.in/']];
const other=[['🧾','CSC Services','https://register.csc.gov.in/'],['📜','Income / Domicile / Certificates','https://aaplesarkar.mahaonline.gov.in/'],['🪪','Driving Licence / Sarathi','https://sarathi.parivahan.gov.in/'],['🚘','Vehicle Services / Vahan','https://vahan.parivahan.gov.in/'],['🔎','Find Government Scheme','https://www.myscheme.gov.in/']];
function render(id,items){document.getElementById(id).innerHTML=items.map(x=>'<div class="card" onclick="openPortal(\\''+x[2]+'\\')"><div class="ico">'+x[0]+'</div><div class="name">'+x[1]+'</div><div class="sub">Open official portal →</div></div>').join('');}
function openPortal(url){location.href=url;} render('citizen',citizen);render('gov',gov);render('schemes',schemes);render('bank',bank);render('partner',partner);render('other',other);
</script></body></html>"""
}
